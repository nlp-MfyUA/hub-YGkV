from typing import NotRequired, TypedDict

from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, StateGraph

from .config import ModelConfig
from .prompts import CLASSIFIER_PROMPT, RESPONDER_PROMPT, responder_input
from .workflow import Sentiment, WorkflowResult, parse_sentiment, require_text


class EmotionState(TypedDict):
    message: str
    sentiment: NotRequired[Sentiment]
    reply: NotRequired[str]


def create_graph(model: ChatOpenAI):
    async def classifier_agent(state: EmotionState) -> dict[str, Sentiment]:
        result = await model.ainvoke(
            [("system", CLASSIFIER_PROMPT), ("human", state["message"])]
        )
        return {"sentiment": parse_sentiment(require_text(result.content))}

    async def responder_agent(state: EmotionState) -> dict[str, str]:
        result = await model.ainvoke(
            [
                ("system", RESPONDER_PROMPT),
                ("human", responder_input(state["message"], state["sentiment"])),
            ]
        )
        return {"reply": require_text(result.content)}

    graph = StateGraph(EmotionState)
    graph.add_node("classifier_agent", classifier_agent)
    graph.add_node("responder_agent", responder_agent)
    graph.add_edge(START, "classifier_agent")
    graph.add_edge("classifier_agent", "responder_agent")
    graph.add_edge("responder_agent", END)
    return graph.compile()


class LangGraphWorkflow:
    def __init__(self, config: ModelConfig):
        model = ChatOpenAI(
            model=config.model, api_key=config.api_key, base_url=config.base_url
        )
        self.graph = create_graph(model)

    async def run(self, message: str) -> WorkflowResult:
        result = await self.graph.ainvoke({"message": message})
        return WorkflowResult(
            sentiment=result["sentiment"], reply=result["reply"]
        )
