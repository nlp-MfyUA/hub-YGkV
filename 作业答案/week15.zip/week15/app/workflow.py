from dataclasses import dataclass
from typing import Literal, Protocol


Sentiment = Literal["positive", "negative"]


@dataclass(frozen=True)
class WorkflowResult:
    sentiment: Sentiment
    reply: str


class Workflow(Protocol):
    async def run(self, message: str) -> WorkflowResult: ...


def parse_sentiment(value: str) -> Sentiment:
    sentiment = value.strip().strip("`'\".。 ").lower()
    if sentiment not in ("positive", "negative"):
        raise ValueError("情感识别结果必须是 positive 或 negative")
    return sentiment


def require_text(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("模型没有返回有效文本")
    return value.strip()
