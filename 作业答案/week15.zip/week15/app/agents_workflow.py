from agents import Agent, OpenAIChatCompletionsModel, RunConfig, Runner
from openai import AsyncOpenAI

from .config import ModelConfig
from .prompts import CLASSIFIER_PROMPT, RESPONDER_PROMPT, responder_input
from .workflow import WorkflowResult, parse_sentiment, require_text


class AgentsWorkflow:
    def __init__(self, config: ModelConfig):
        client = AsyncOpenAI(api_key=config.api_key, base_url=config.base_url)
        model = OpenAIChatCompletionsModel(
            model=config.model, openai_client=client
        )
        self.classifier = Agent(
            name="情感识别", instructions=CLASSIFIER_PROMPT, model=model
        )
        self.responder = Agent(
            name="情绪回应", instructions=RESPONDER_PROMPT, model=model
        )

    async def run(self, message: str) -> WorkflowResult:
        run_config = RunConfig(tracing_disabled=True)
        classification = await Runner.run(
            self.classifier, message, run_config=run_config
        )
        sentiment = parse_sentiment(require_text(classification.final_output))
        response = await Runner.run(
            self.responder,
            responder_input(message, sentiment),
            run_config=run_config,
        )
        return WorkflowResult(
            sentiment=sentiment, reply=require_text(response.final_output)
        )
