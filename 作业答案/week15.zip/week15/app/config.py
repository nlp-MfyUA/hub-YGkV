import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class ModelConfig:
    api_key: str
    model: str
    base_url: str | None

    @classmethod
    def from_env(cls) -> "ModelConfig":
        load_dotenv()
        deepseek_key = os.getenv("DEEPSEEK_API_KEY")
        api_key = deepseek_key or os.getenv("OPENAI_API_KEY")
        if not api_key or api_key.startswith("${"):
            raise ValueError("请在 .env 中设置 DEEPSEEK_API_KEY 或 OPENAI_API_KEY")

        model = (
            os.getenv("DEEPSEEK_MODEL")
            or os.getenv("OPENAI_MODEL")
            or ("deepseek-chat" if deepseek_key else "gpt-4.1-mini")
        )
        base_url = os.getenv("DEEPSEEK_BASE_URL") or os.getenv("OPENAI_BASE_URL")
        if deepseek_key and not base_url:
            base_url = "https://api.deepseek.com"
        return cls(api_key=api_key, model=model, base_url=base_url)
