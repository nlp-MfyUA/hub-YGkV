import logging
from functools import lru_cache
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .config import ModelConfig
from .workflow import Sentiment, Workflow


logger = logging.getLogger(__name__)
STATIC_DIR = Path(__file__).parent / "static"
WorkflowName = Literal["agents", "langgraph"]


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)


class ChatResponse(BaseModel):
    workflow: WorkflowName
    sentiment: Sentiment
    reply: str


@lru_cache(maxsize=2)
def get_service(workflow_name: WorkflowName) -> Workflow:
    config = ModelConfig.from_env()
    if workflow_name == "agents":
        from .agents_workflow import AgentsWorkflow

        return AgentsWorkflow(config)
    from .langgraph_workflow import LangGraphWorkflow

    return LangGraphWorkflow(config)


def create_app() -> FastAPI:

    app = FastAPI(title="情绪支持 Demo")

    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/api/health")
    async def health() -> dict[str, str | list[str]]:
        return {"status": "ok", "workflows": ["agents", "langgraph"]}

    @app.post("/api/chat", response_model=ChatResponse)
    async def chat(
        request: ChatRequest,
        workflow: WorkflowName = Query(...),
    ) -> ChatResponse:
        message = request.message.strip()
        if not message:
            raise HTTPException(status_code=422, detail="请输入内容")
        try:
            result = await get_service(workflow).run(message)
        except Exception:
            logger.exception("Workflow 调用失败")
            raise HTTPException(status_code=502, detail="模型调用失败，请稍后重试") from None
        return ChatResponse(
            workflow=workflow,
            sentiment=result.sentiment,
            reply=result.reply,
        )

    return app
