import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="启动情绪支持 Demo")
    parser.add_argument(
        "--workflow",
        action="store_true",
        required=True,
        help="通过请求参数选择 agents 或 langgraph",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    import uvicorn

    from .api import create_app

    uvicorn.run(create_app(), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
