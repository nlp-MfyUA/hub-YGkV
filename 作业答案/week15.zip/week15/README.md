# 情绪支持双 Agent 作业

同一个网页和 FastAPI 后端提供两套独立实现。只启动一次服务，通过访问参数 `?workflow=langgraph` 或 `?workflow=agents` 选择框架。每套实现都按以下顺序调用两个 agent：

```text
网页输入 → POST /api/chat → 情感识别 agent → 情绪回应 agent → 网页显示
```

识别结果只有 `positive` 和 `negative`。积极时给予鼓励；消极时给予共情和一条具体建议。中性或不明确的输入按 `negative` 处理，以便给予温和支持。

## 本地运行

需要 Python 3.11 或更新版本。先安装依赖：

```bash
pip install -r requirements.txt
```

如果没有 `.env`，执行 `cp .env.example .env`，然后填入 `DEEPSEEK_API_KEY`。也可以按 `.env.example` 的注释使用 OpenAI。不要把 `.env` 提交到版本库。

只需启动一次：

```bash
python -m app --workflow
```

然后访问 <http://127.0.0.1:8000/?workflow=agents> 或 <http://127.0.0.1:8000/?workflow=langgraph>。页面上的链接也可以切换框架；后端根据每次请求的 `workflow` 参数选择实现。

接口示例：

```bash
curl -X POST 'http://127.0.0.1:8000/api/chat?workflow=agents' \
  -H 'Content-Type: application/json' \
  -d '{"message":"今天顺利完成了作业，很开心！"}'
```

响应包含 `workflow`、`sentiment`、`reply`。`GET /api/health` 返回可用的 workflow。模型请求会产生 API 费用。

## Docker 打包

`Dockerfile` 使用同一个 `requirements.txt`，启动同一个后端；镜像中包含 OpenAI Agents 和 LangGraph 两套实现：

```bash
docker build -t emotion-agents:homework .
docker run --rm -p 8000:8000 --env-file .env emotion-agents:homework
```

打开 <http://127.0.0.1:8000/?workflow=agents> 使用作业 2 的 OpenAI Agents 版本。密钥通过运行时环境变量传入，不会复制进镜像。也可以把镜像另行推送到阿里云容器镜像服务；本作业使用本地 Docker 打包。

实现参考：[LangGraph Graph API](https://docs.langchain.com/oss/python/langgraph/graph-api)、[LangChain ChatOpenAI](https://docs.langchain.com/oss/python/integrations/chat/openai)、[OpenAI Agents SDK Models](https://openai.github.io/openai-agents-python/models/)。
