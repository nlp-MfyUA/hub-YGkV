import type { StepItem } from "@/lib/types";

const NODE_LABELS: Record<string, string> = {
  parse_database: "解析数据库",
  select_tables: "选择数据表",
  generate_sql: "生成 SQL",
  validate_sql: "校验 SQL",
  rewrite_sql: "改写 SQL",
  execute_sql: "执行 SQL",
  summarize_result: "汇总结果",
  fail_result: "失败收尾",
};

function isError(step: StepItem): boolean {
  const data = step.data;
  if (step.node === "fail_result" || Boolean(data.fatal_error)) return true;
  if (step.node === "validate_sql" && data.is_valid === false) return true;
  if (step.node === "execute_sql" && !data.query_result) return true;
  return false;
}

function isSuccess(step: StepItem): boolean {
  if (step.node === "validate_sql" && step.data.is_valid === true) return true;
  if (step.node === "execute_sql" && Boolean(step.data.query_result)) return true;
  return false;
}

export function StepTimeline({ steps }: { steps: StepItem[] }) {
  if (steps.length === 0) {
    return <p className="empty">查询开始后，这里会实时显示每个节点。</p>;
  }

  return (
    <div className="steps">
      {steps.map((step) => {
        const failed = isError(step);
        const className = [
          "step",
          failed ? "is-error" : "",
          !failed && isSuccess(step) ? "is-success" : "",
        ]
          .filter(Boolean)
          .join(" ");
        const summary = step.summary.replace(/^\[[^\]]+\]\s*/, "");

        return (
          <article
            key={`${step.index}-${step.node}`}
            className={className}
            data-index={step.index}
          >
            <div className="step-head">
              <span className="step-node">{step.node}</span>
              <span className="step-label">
                {NODE_LABELS[step.node] || ""}
              </span>
            </div>
            <p className="step-summary">{summary}</p>
            {Object.keys(step.data).length > 0 ? (
              <details>
                <summary>查看节点数据</summary>
                <pre>{JSON.stringify(step.data, null, 2)}</pre>
              </details>
            ) : null}
          </article>
        );
      })}
    </div>
  );
}
