import type { FinalEvent } from "@/lib/types";

export function AnswerCard({ final }: { final: FinalEvent | null }) {
  if (!final) return null;

  const success = final.status === "success";

  return (
    <section className="card answer-card">
      <div className="panel-head">
        <h2>最终结果</h2>
        <span className={`badge ${success ? "success" : "failed"}`}>
          {success ? "成功" : "失败"}
        </span>
      </div>
      <p className="answer-text">{final.answer || "无"}</p>
      <details open={!success}>
        <summary>SQL 与元信息</summary>
        <pre>
          {JSON.stringify(
            {
              sql: final.sql,
              selected_tables: final.selected_tables,
              retry_count: final.retry_count,
              error: final.error,
            },
            null,
            2
          )}
        </pre>
      </details>
    </section>
  );
}
