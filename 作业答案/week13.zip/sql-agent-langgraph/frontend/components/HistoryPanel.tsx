import type { HistoryEntry } from "@/lib/types";

interface HistoryPanelProps {
  entries: HistoryEntry[];
  loading: boolean;
  error: string;
  memoryPath: string;
  onRefresh: () => void;
}

function formatTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("zh-CN", { hour12: false });
}

export function HistoryPanel({
  entries,
  loading,
  error,
  memoryPath,
  onRefresh,
}: HistoryPanelProps) {
  return (
    <aside className="card history-card">
      <div className="panel-head">
        <h2>历史运行</h2>
        <div className="panel-actions">
          <span className="muted">
            {loading ? "加载中…" : `${entries.length} 条`}
          </span>
          <button
            type="button"
            className="secondary small"
            onClick={onRefresh}
            disabled={loading}
          >
            刷新
          </button>
        </div>
      </div>

      {error ? <p className="error-banner">{error}</p> : null}

      <div className="history-list">
        {entries.length === 0 && !loading ? (
          <p className="empty">该会话暂无历史执行记录。</p>
        ) : null}

        {entries.map((entry) => {
          const success = entry.status === "success";
          return (
            <article
              className="history-item"
              key={entry.checkpoint_id || `${entry.question}-${entry.created_at}`}
            >
              <div className="history-top">
                <span className="history-time">
                  {formatTime(entry.created_at)}
                </span>
                <span className={`badge ${success ? "success" : "failed"}`}>
                  {success ? "成功" : "失败"}
                </span>
              </div>
              <p className="history-question">{entry.question}</p>
              <p className="history-answer">
                {entry.final_answer || "无回答"}
              </p>
              <details>
                <summary>查看 SQL 与元信息</summary>
                <pre>
                  {JSON.stringify(
                    {
                      sql: entry.sql,
                      selected_tables: entry.selected_tables,
                      retry_count: entry.retry_count,
                      error: entry.error,
                    },
                    null,
                    2
                  )}
                </pre>
              </details>
            </article>
          );
        })}
      </div>

      {memoryPath ? (
        <p className="memory-path" title={memoryPath}>
          记忆库：{memoryPath}
        </p>
      ) : null}
    </aside>
  );
}
