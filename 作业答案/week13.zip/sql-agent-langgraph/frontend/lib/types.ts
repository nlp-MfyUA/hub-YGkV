export type StepData = Record<string, unknown>;

export interface StartEvent {
  type: "start";
  question: string;
  thread_id: string;
}

export interface StepEvent {
  type: "step";
  node: string;
  summary: string;
  data: StepData;
}

export interface FinalEvent {
  type: "final";
  status: "success" | "failed" | "unknown";
  answer: string;
  sql: string | null;
  retry_count: number;
  selected_tables: string[];
  error: string | null;
}

export interface ErrorEvent {
  type: "error";
  message: string;
}

export type StreamEvent = StartEvent | StepEvent | FinalEvent | ErrorEvent;

export interface StepItem extends StepEvent {
  index: number;
}

export interface HistoryEntry {
  checkpoint_id: string | null;
  thread_id: string;
  question: string;
  final_answer: string;
  sql: string | null;
  selected_tables: string[];
  retry_count: number;
  status: "success" | "failed";
  error: string | null;
  created_at: string;
}

export interface HistoryResponse {
  thread_id: string;
  memory_path: string;
  entries: HistoryEntry[];
}
