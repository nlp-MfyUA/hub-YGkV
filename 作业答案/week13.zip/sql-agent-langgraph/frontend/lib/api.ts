import type { HistoryResponse, StreamEvent } from "./types";

const API_BASE = (
  process.env.NEXT_PUBLIC_API_BASE || "http://127.0.0.1:8000"
).replace(/\/$/, "");

async function readError(response: Response): Promise<string> {
  try {
    const payload = await response.json();
    if (typeof payload?.detail === "string") {
      return payload.detail;
    }
  } catch {
    // 忽略非 JSON 响应。
  }
  return `请求失败（HTTP ${response.status}）`;
}

export async function fetchHistory(
  threadId: string,
  limit = 20
): Promise<HistoryResponse> {
  const response = await fetch(
    `${API_BASE}/api/history?thread_id=${encodeURIComponent(threadId)}&limit=${limit}`,
    { cache: "no-store" }
  );
  if (!response.ok) {
    throw new Error(await readError(response));
  }
  return (await response.json()) as HistoryResponse;
}

export async function streamQuery(
  payload: { question: string; thread_id: string },
  onEvent: (event: StreamEvent) => void
): Promise<void> {
  const response = await fetch(`${API_BASE}/api/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(await readError(response));
  }
  if (!response.body) {
    throw new Error("当前浏览器不支持流式响应");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let boundary = buffer.indexOf("\n\n");
    while (boundary >= 0) {
      const chunk = buffer.slice(0, boundary);
      buffer = buffer.slice(boundary + 2);

      const data = chunk
        .split("\n")
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trimStart())
        .join("\n");

      if (data) {
        try {
          onEvent(JSON.parse(data) as StreamEvent);
        } catch (error) {
          console.error("无法解析 SSE 事件", error, data);
        }
      }
      boundary = buffer.indexOf("\n\n");
    }
  }
}
