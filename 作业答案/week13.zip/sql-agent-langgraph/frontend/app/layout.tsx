import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SQL Agent · Chinook",
  description: "基于 LangGraph 的自然语言 SQL 查询工作流",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
