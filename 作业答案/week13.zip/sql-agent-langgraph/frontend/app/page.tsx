"use client";

import { useCallback, useEffect, useState } from "react";

import { AnswerCard } from "@/components/AnswerCard";
import { HistoryPanel } from "@/components/HistoryPanel";
import { StepTimeline } from "@/components/StepTimeline";
import { fetchHistory, streamQuery } from "@/lib/api";
import type { FinalEvent, HistoryEntry, StepItem } from "@/lib/types";

export default function HomePage() {
  const [question, setQuestion] = useState("");
  const [threadId, setThreadId] = useState("default");
  const [steps, setSteps] = useState<StepItem[]>([]);
  const [final, setFinal] = useState<FinalEvent | null>(null);
  const [busy, setBusy] = useState(false);
  const [statusText, setStatusText] = useState("");
  const [statusTone, setStatusTone] = useState("");
  const [error, setError] = useState("");

  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState("");
  const [memoryPath, setMemoryPath] = useState("");

  const loadHistory = useCallback(async (thread: string) => {
    setHistoryLoading(true);
    setHistoryError("");
    try {
      const data = await fetchHistory(thread || "default", 20);
      setHistory(data.entries);
      setMemoryPath(data.memory_path);
    } catch (err) {
      setHistoryError(err instanceof Error ? err.message : String(err));
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadHistory("default");
  }, [loadHistory]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmed = question.trim();
    const thread = threadId.trim() || "default";
    if (!trimmed || busy) return;

    setBusy(true);
    setSteps([]);
    setFinal(null);
    setError("");
    setStatusText("执行中…");
    setStatusTone("running");

    let sawFinal = false;
    try {
      await streamQuery(
        { question: trimmed, thread_id: thread },
        (streamEvent) => {
          if (streamEvent.type === "start") {
            setStatusText("执行中…");
            setStatusTone("running");
            return;
          }
          if (streamEvent.type === "step") {
            setSteps((previous) => [
              ...previous,
              { ...streamEvent, index: previous.length + 1 },
            ]);
            return;
          }
          if (streamEvent.type === "final") {
            sawFinal = true;
            setFinal(streamEvent);
            const success = streamEvent.status === "success";
            setStatusText(success ? "执行完成" : "执行失败");
            setStatusTone(success ? "" : "error");
            void loadHistory(thread);
            return;
          }
          if (streamEvent.type === "error") {
            setError(streamEvent.message);
            setStatusText("执行失败");
            setStatusTone("error");
          }
        }
      );

      if (!sawFinal) {
        setStatusText("连接已结束");
        setStatusTone("error");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setStatusText("查询失败");
      setStatusTone("error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">SQL</span>
          <div>
            <h1>SQL Agent</h1>
            <p>LangGraph · Chinook 数据库</p>
          </div>
        </div>
        <label className="thread-field">
          <span>会话标识</span>
          <input
            value={threadId}
            onChange={(event) => setThreadId(event.target.value)}
            onBlur={() => void loadHistory(threadId.trim() || "default")}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                void loadHistory(threadId.trim() || "default");
              }
            }}
            autoComplete="off"
          />
        </label>
      </header>

      <main className="layout">
        <section className="workspace">
          <form className="card query-card" onSubmit={handleSubmit}>
            <label htmlFor="question">用自然语言查询数据库</label>
            <textarea
              id="question"
              rows={3}
              placeholder="例如：销售额最高的五位艺术家是谁？"
              value={question}
              onChange={(event) => setQuestion(event.target.value)}
              required
            />
            <div className="actions">
              <button type="submit" disabled={busy}>
                {busy ? "查询中…" : "开始查询"}
              </button>
              <button
                type="button"
                className="secondary"
                onClick={() => void loadHistory(threadId.trim() || "default")}
                disabled={historyLoading}
              >
                刷新历史
              </button>
              <span
                className={["status", statusTone].filter(Boolean).join(" ")}
              >
                {statusText}
              </span>
            </div>
          </form>

          {error ? <div className="error-banner">{error}</div> : null}

          <section className="card steps-card">
            <div className="panel-head">
              <h2>执行步骤</h2>
              <span className="muted">{steps.length} 步</span>
            </div>
            <StepTimeline steps={steps} />
          </section>

          <AnswerCard final={final} />
        </section>

        <HistoryPanel
          entries={history}
          loading={historyLoading}
          error={historyError}
          memoryPath={memoryPath}
          onRefresh={() => void loadHistory(threadId.trim() || "default")}
        />
      </main>
    </div>
  );
}
