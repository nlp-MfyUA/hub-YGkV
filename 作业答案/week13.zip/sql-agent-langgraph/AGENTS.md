# AGENTS.md

## Repository status
- The project is implemented under `backend/`; there is no `sql_agent/` package. The CLI entry is `python -m backend.main`, and the compiled LangGraph workflow lives in `backend/workflow.py`.
- `README.md` is the source of truth for the intended workflow and acceptance criteria; its §6–§7.5 now match the implementation. `docs/langgraph-sql-agent.txt` and `docs/langgraph.txt` are captured LangGraph docs; consult them before fetching external pages.
- The CLI gives a live end-to-end check; there is no automated test suite, CI, or lint/typecheck config yet.
- User-facing docs, prompts, and error messages are in Chinese; preserve that language when adding them.

## Database asset
- The Chinook database is at `asserts/chinook.db` (note: `asserts`, not `assets`). README §7.3/§7.4 use this path; keep code consistent with it.
- Inspect it directly without Python:
  `sqlite3 asserts/chinook.db '.schema <table>'`
  Tables: `albums`, `artists`, `customers`, `employees`, `genres`, `invoice_items`, `invoices`, `media_types`, `playlist_track`, `playlists`, `tracks`.

## Architecture
- Data structures are Pydantic models in `backend/schemas.py` (not in `backend/agent/base.py`). Keep schemas free of agent/model-call logic.
- `backend/config.py` owns `.env` / environment parsing and returns Pydantic `LLMConfig`, `DatabaseConfig`, and `WorkflowConfig`; keep env helpers out of agent classes.
- `backend/agent/base.py` defines `BaseAgent`: it consumes `load_llm_config()`, builds `ChatOpenAI`, and exposes sync/async invoke helpers. Subclasses go in `backend/agent/`.
- `from backend.agent import BaseAgent, LLMConfig` is the public import path.
- LangGraph state is `AgentState` in `backend/graph/state.py`; node-facing DB/safety wrappers are in `backend/graph/tools.py`; node functions live in `backend/graph/nodes.py` and call the agents through `AgentSet`.
- `backend/workflow.py` assembles the graph, owns conditional routing, creates the `SqliteSaver` checkpointer, exposes `build_workflow` / `run_workflow` / `stream_workflow`, and provides `load_history` for reading completed runs. Keep graph wiring there, not in nodes.
- Persistence uses `langgraph-checkpoint-sqlite`; do not add a second history table or wrapper module. The memory DB is separate from the read-only Chinook DB, and history is not injected into prompts (no multi-turn).
- `backend/main.py` is the CLI; `python -m backend.workflow` runs a live end-to-end demo.
- `backend/api.py` exposes FastAPI endpoints: `POST /api/query` streams node updates over SSE, `GET /api/history` reads completed runs. `backend/presentation.py` holds formatting shared by the CLI and API.
- `frontend/` is a standalone Next.js app (same level as `backend/`) that consumes the SSE API; it is not served by FastAPI. Backend CORS allows local ports 3000/3001.

## Environment config
- `.env.example` is the canonical, documented template; `.env` is the local ignored copy (already created). Never commit `.env` or real keys.
- `OPENAI_API_KEY`, `OPENAI_BASE_URL`, and `MODEL_NAME` configure any OpenAI-compatible endpoint. Pass `OPENAI_BASE_URL` explicitly as the model's `base_url`; do not rely on SDK defaults.
- `DATABASE_PATH=asserts/chinook.db`.
- `MEMORY_DATABASE_PATH=asserts/sql_agent_memory.db` is the writable `SqliteSaver` checkpoint DB; it must never point at the Chinook DB.
- Keep the three retry/limit settings distinct: `SQL_AGENT_MAX_RETRIES` = SQL rewrite cap, `LLM_REQUEST_MAX_RETRIES` = model API call retries, `SQL_AGENT_RECURSION_LIMIT` = LangGraph execution steps.

## Testing
- **Do not write new unit tests unless the user explicitly asks for them.** There is currently no automated test suite.
- Use `python -m backend.main --question "..." --show-sql` or `python -m backend.workflow` for end-to-end checks (these consume tokens).

## Behavior constraints that are easy to get wrong
- Enforce read-only SQLite (`mode=ro`) **and** structural SELECT/read-only validation before execution; prompt wording alone is not a safety boundary.
- `retry_count` increments only when entering `rewrite_sql`. It is shared by validation failures and execution failures; default `max_retries` is `10`.
- `recursion_limit` limits graph execution steps, not SQL rewrites. Size it for the full rewrite→revalidate→execute loop.
- Every rewritten SQL must re-enter `validate_sql`; reset the prior SQL's validation state so stale `is_valid`/`error` is not reused.
- A zero-row result is a successful query: summarize “no matching records”, do not retry.
- Final answers must be grounded in actual execution results; on unrecoverable failure, return the error instead of fabricating data.

## When implementing
- Use Python 3.10+ as specified in README §2.
- Add new dependencies to `requirements.txt`; keep `.env.example` in sync with every config value the code reads. Never commit `.env` or API keys.
- Do not add unit tests for README §8 scenarios unless explicitly requested; rely on existing offline tests for regression coverage where possible.
- **Prefer Pydantic (v2) over plain dicts, tuples, or `@dataclass` for any data structure that crosses a boundary**: config, node inputs/outputs, LLM structured output, tool arguments, and API payloads. Define them in `backend/schemas.py`, not inline in agent logic.
- Use Pydantic features instead of hand-written validation: `Field` constraints (`min_length`, `ge`, `gt`, ...), `SecretStr` for API keys, and `model_config = ConfigDict(frozen=True, extra="forbid")` for config-like immutable models. Validation errors must surface as Chinese messages at the boundary where user input enters.
- LangGraph's graph state stays a `TypedDict` as described in README §5; nest Pydantic models inside it (e.g. a `QueryResult` model) rather than replacing the state schema.
- Add `pydantic` to `requirements.txt` whenever the code imports it.
- **End every Python file with a runnable usage demo**, following `backend/agent/base.py`: a module-level `def main() -> None:` whose Chinese docstring says what the demo shows, then the `if __name__ == "__main__":` guard calling `main()` as the last lines of the file. The demo must run via `python -m <module.path>` (relative imports intact) with no arguments, and must print a clear Chinese error instead of a traceback when config or a real API key is missing.

## Git workflow
- **Commit automatically after finishing a code change** — do not wait to be asked. Stage only the files you touched (plus directly related docs/config), then commit with a concise Chinese message such as `feat: 增加 SQL 校验节点`.
- Never stage `.env`, real keys, `__pycache__/`, `.venv/`, or anything covered by `.gitignore`; check `git status` before committing.
- Leave unrelated user changes untouched and out of the commit. If there is nothing to commit, or the user explicitly says not to commit, skip it.
- Never push, force-push, rewrite history, or amend commits you did not create unless explicitly asked.
