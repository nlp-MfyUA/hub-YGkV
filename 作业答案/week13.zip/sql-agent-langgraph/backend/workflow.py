"""LangGraph 工作流定义。

工作流结构（与 README §3 一致）：

```text
START -> parse_database -> select_tables -> generate_sql -> validate_sql
                                                        -> execute_sql -> summarize_result -> END
                                                        -> rewrite_sql  -> validate_sql（重新校验）
任意不可恢复错误 / 达到改写上限 -> fail_result -> END
```

节点实现位于 `backend.graph.nodes`，状态定义位于 `backend.graph.state`，
数据库与安全工具位于 `backend.graph.tools`。本模块负责组装图、定义条件
路由、通过 `SqliteSaver` 持久化每次执行，并对外提供 `build_workflow`、
`run_workflow` 与 `stream_workflow`。
"""

from __future__ import annotations

import sqlite3
from collections.abc import Callable, Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, cast

from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from .graph.nodes import AgentSet, WorkflowNodes
from .graph.state import AgentState, build_initial_state
from .config import load_memory_path, load_workflow_config
from .schemas import (
    HistoryEntry,
    WorkflowConfig,
    WorkflowInput,
    WorkflowStep,
)


def route_after_parse(state: AgentState) -> Literal["select_tables", "fail_result"]:
    """数据库不可用时直接结束，否则进入表选择。"""

    return "fail_result" if state.get("fatal_error") else "select_tables"


def route_after_select(state: AgentState) -> Literal["generate_sql", "fail_result"]:
    """表选择失败时无法继续生成 SQL。"""

    return "fail_result" if state.get("fatal_error") else "generate_sql"


def route_after_generate(state: AgentState) -> Literal["validate_sql", "fail_result"]:
    """SQL 生成失败时不再进入校验。"""

    return "fail_result" if state.get("fatal_error") else "validate_sql"


def route_after_rewrite(state: AgentState) -> Literal["validate_sql", "fail_result"]:
    """改写失败则终止；改写成功必须重新校验，不能直接执行。"""

    return "fail_result" if state.get("fatal_error") else "validate_sql"


def route_after_validation(
    state: AgentState,
) -> Literal["execute_sql", "rewrite_sql", "fail_result"]:
    """校验通过才执行；未通过且未达上限则改写，否则失败。"""

    if state.get("fatal_error"):
        return "fail_result"
    if state.get("is_valid"):
        return "execute_sql"
    if state.get("retry_count", 0) < state.get("max_retries", 10):
        return "rewrite_sql"
    return "fail_result"


def route_after_execution(
    state: AgentState,
) -> Literal["summarize_result", "rewrite_sql", "fail_result"]:
    """执行成功（包括零行）就汇总；执行失败则按重试上限决定是否改写。"""

    if not state.get("error"):
        return "summarize_result"
    if state.get("retry_count", 0) < state.get("max_retries", 10):
        return "rewrite_sql"
    return "fail_result"


def build_workflow(
    *,
    nodes: WorkflowNodes | None = None,
    agents: AgentSet | None = None,
    config: WorkflowConfig | None = None,
    database_path: str | Path | None = None,
    checkpointer: Any | None = None,
) -> CompiledStateGraph:
    """组装并编译 SQL Agent 图。

    Args:
        nodes: 已构造的节点集合；传入后忽略 `agents` / `database_path`。
        agents: 可注入的 Agent 集合，便于测试或替换模型。
        config: 工作流配置；不传时读取 `.env`。
        database_path: 数据库路径；不传时使用 `DATABASE_PATH`。
        checkpointer: 可选的 LangGraph checkpointer。

    Raises:
        ValueError: Agent 初始化失败或配置非法。
    """

    workflow_config = config or load_workflow_config()
    node_set = nodes or WorkflowNodes(
        agents=agents,
        config=workflow_config,
        database_path=database_path,
    )

    builder = StateGraph(AgentState)
    builder.add_node("parse_database", node_set.parse_database)
    builder.add_node("select_tables", node_set.select_tables)
    builder.add_node("generate_sql", node_set.generate_sql)
    builder.add_node("validate_sql", node_set.validate_sql)
    builder.add_node("rewrite_sql", node_set.rewrite_sql)
    builder.add_node("execute_sql", node_set.execute_sql)
    builder.add_node("summarize_result", node_set.summarize_result)
    builder.add_node("fail_result", node_set.fail_result)

    builder.add_edge(START, "parse_database")
    builder.add_conditional_edges(
        "parse_database",
        route_after_parse,
        {"select_tables": "select_tables", "fail_result": "fail_result"},
    )
    builder.add_conditional_edges(
        "select_tables",
        route_after_select,
        {"generate_sql": "generate_sql", "fail_result": "fail_result"},
    )
    builder.add_conditional_edges(
        "generate_sql",
        route_after_generate,
        {"validate_sql": "validate_sql", "fail_result": "fail_result"},
    )
    builder.add_conditional_edges(
        "validate_sql",
        route_after_validation,
        {
            "execute_sql": "execute_sql",
            "rewrite_sql": "rewrite_sql",
            "fail_result": "fail_result",
        },
    )
    builder.add_conditional_edges(
        "rewrite_sql",
        route_after_rewrite,
        {"validate_sql": "validate_sql", "fail_result": "fail_result"},
    )
    builder.add_conditional_edges(
        "execute_sql",
        route_after_execution,
        {
            "summarize_result": "summarize_result",
            "rewrite_sql": "rewrite_sql",
            "fail_result": "fail_result",
        },
    )
    builder.add_edge("summarize_result", END)
    builder.add_edge("fail_result", END)

    return builder.compile(checkpointer=checkpointer)


def _create_checkpointer(connection: sqlite3.Connection) -> SqliteSaver:
    """创建允许反序列化工作流状态模型的 SqliteSaver。"""

    checkpointer = SqliteSaver(
        connection,
        serde=JsonPlusSerializer(
            allowed_msgpack_modules=[("backend.schemas", "QueryResult")]
        ),
    )
    checkpointer.setup()
    return checkpointer


def _prepare_run(
    question: str,
    *,
    thread_id: str,
    max_retries: int | None,
    recursion_limit: int | None,
    agents: AgentSet | None,
    config: WorkflowConfig | None,
    database_path: str | Path | None,
) -> tuple[
    CompiledStateGraph,
    AgentState,
    dict[str, Any],
    sqlite3.Connection,
]:
    """校验输入、创建 SqliteSaver 并编译图。

    返回的 SQLite 连接必须在执行结束后关闭。
    """

    workflow_config = config or load_workflow_config()
    request = WorkflowInput(
        question=question,
        thread_id=thread_id,
        max_retries=max_retries,
    )

    limit = (
        workflow_config.recursion_limit
        if recursion_limit is None
        else recursion_limit
    )
    if limit <= 0:
        raise ValueError("recursion_limit 必须大于 0")

    memory_path = load_memory_path()
    connection: sqlite3.Connection | None = None
    try:
        memory_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(
            memory_path,
            timeout=5.0,
            check_same_thread=False,
        )
        checkpointer = _create_checkpointer(connection)
        state = build_initial_state(request, workflow_config)
        graph = build_workflow(
            agents=agents,
            config=workflow_config,
            database_path=database_path,
            checkpointer=checkpointer,
        )
    except (OSError, sqlite3.Error) as exc:
        if connection is not None:
            connection.close()
        raise ValueError(
            f"初始化历史记忆数据库失败（{memory_path}）：{exc}"
        ) from exc
    except Exception:
        if connection is not None:
            connection.close()
        raise

    run_config: dict[str, Any] = {
        "configurable": {"thread_id": request.thread_id},
        "recursion_limit": limit,
    }
    return graph, state, run_config, connection


def _iter_steps(
    graph: CompiledStateGraph,
    state: AgentState,
    run_config: dict[str, Any],
) -> Iterator[WorkflowStep]:
    """按节点逐一产出状态增量。"""

    for chunk in graph.stream(
        state,
        config=run_config,
        stream_mode="updates",
    ):
        for node, update in chunk.items():
            yield WorkflowStep(node=node, update=dict(update or {}))


def stream_workflow(
    question: str,
    *,
    thread_id: str = "default",
    max_retries: int | None = None,
    recursion_limit: int | None = None,
    agents: AgentSet | None = None,
    config: WorkflowConfig | None = None,
    database_path: str | Path | None = None,
) -> Iterator[WorkflowStep]:
    """流式执行工作流，逐节点产出中间结果。

    每个检查点都会由 `SqliteSaver` 写入 SQLite，可通过
    `graph.get_state_history()` 回看。历史记录不会注入 Prompt，
    因此不支持多轮对话。

    Args:
        thread_id: 会话标识，用于区分历史检查点。

    Raises:
        ValueError: 问题为空、配置非法或 Agent 初始化失败。
    """

    graph, state, run_config, connection = _prepare_run(
        question,
        thread_id=thread_id,
        max_retries=max_retries,
        recursion_limit=recursion_limit,
        agents=agents,
        config=config,
        database_path=database_path,
    )
    try:
        yield from _iter_steps(graph, state, run_config)
    finally:
        connection.close()


def run_workflow(
    question: str,
    *,
    thread_id: str = "default",
    max_retries: int | None = None,
    recursion_limit: int | None = None,
    agents: AgentSet | None = None,
    config: WorkflowConfig | None = None,
    database_path: str | Path | None = None,
    on_step: Callable[[WorkflowStep], None] | None = None,
) -> AgentState:
    """执行一次完整的自然语言查询。

    Args:
        question: 用户问题，不能为空。
        thread_id: 会话标识，用于区分 SQLite 历史检查点。
        max_retries: 覆盖 SQL 改写上限；不传时使用配置值。
        recursion_limit: 覆盖图执行步数上限；不传时使用配置值。
        agents: 可注入的 Agent 集合，测试时可替换为离线替身。
        config: 工作流配置；不传时读取 `.env`。
        database_path: 数据库路径；不传时使用 `DATABASE_PATH`。
        on_step: 可选的节点回调，每完成一个节点调用一次；传入后内部改用
            `graph.stream` 执行，并在回调中提供该节点的状态增量。

    Raises:
        ValueError: 问题为空、配置非法或 Agent 初始化失败。
        Exception: LangGraph 执行过程中的未捕获异常（如步数超限）。
    """

    graph, state, run_config, connection = _prepare_run(
        question,
        thread_id=thread_id,
        max_retries=max_retries,
        recursion_limit=recursion_limit,
        agents=agents,
        config=config,
        database_path=database_path,
    )
    try:
        if on_step is None:
            result: AgentState = graph.invoke(state, config=run_config)
            return result

        final_state: dict[str, Any] = dict(state)
        for step in _iter_steps(graph, state, run_config):
            on_step(step)
            final_state.update(step.update)
        return cast(AgentState, final_state)
    finally:
        connection.close()


def load_history(
    thread_id: str = "default",
    *,
    limit: int = 10,
) -> list[HistoryEntry]:
    """从 SqliteSaver 检查点读取最近的完整执行记录。

    Args:
        thread_id: 会话标识。
        limit: 最多返回的记录数；记录按时间从新到旧排列。

    Raises:
        ValueError: `thread_id` 为空、`limit` 非法或记忆数据库无法读取。
    """

    thread = thread_id.strip() if isinstance(thread_id, str) else ""
    if not thread:
        raise ValueError("thread_id 不能为空")
    if limit <= 0:
        return []

    path = load_memory_path()
    if not path.is_file():
        return []

    connection = sqlite3.connect(path, timeout=5.0, check_same_thread=False)
    try:
        checkpointer = _create_checkpointer(connection)
        entries: list[HistoryEntry] = []

        # 一次执行会产生多个检查点，多扫描一些再筛选终态检查点。
        for item in checkpointer.list(
            {"configurable": {"thread_id": thread}},
            limit=max(limit * 20, 100),
        ):
            values = item.checkpoint.get("channel_values", {})
            status = values.get("status")
            if status not in ("success", "failed"):
                continue

            question = str(values.get("question") or "").strip()
            answer = str(values.get("final_answer") or "").strip()
            if not question or not answer:
                continue

            sql = values.get("sql")
            entries.append(
                HistoryEntry(
                    checkpoint_id=_checkpoint_id(item.config),
                    thread_id=thread,
                    question=question,
                    final_answer=answer,
                    sql=None if not sql else str(sql),
                    selected_tables=[
                        str(name)
                        for name in (values.get("selected_tables") or [])
                        if isinstance(name, str)
                    ],
                    retry_count=int(values.get("retry_count") or 0),
                    status=status,
                    error=(
                        None
                        if values.get("error") is None
                        else str(values.get("error"))
                    ),
                    created_at=_checkpoint_time(item.checkpoint),
                )
            )
            if len(entries) >= limit:
                break

        return entries
    except (OSError, sqlite3.Error) as exc:
        raise ValueError(f"读取历史执行记录失败（{path}）：{exc}") from exc
    finally:
        connection.close()


def _checkpoint_id(config: dict[str, Any]) -> str | None:
    value = config.get("configurable", {}).get("checkpoint_id")
    return None if value is None else str(value)


def _checkpoint_time(checkpoint: dict[str, Any]) -> datetime:
    raw = checkpoint.get("ts")
    if not raw:
        return datetime.now(timezone.utc)
    try:
        return datetime.fromisoformat(str(raw))
    except ValueError:
        return datetime.now(timezone.utc)


def main() -> None:
    """演示运行完整 LangGraph 工作流并输出最终答案。"""

    question = "数据库中有多少位艺术家？"

    try:
        result = run_workflow(question)
    except Exception as exc:
        print(f"工作流演示失败：{exc}")
        return

    print(f"问题：{question}")
    print(f"状态：{result.get('status', 'unknown')}")
    print(f"已选表：{'、'.join(result.get('selected_tables', [])) or '无'}")
    print(f"SQL：{result.get('sql') or '无'}")
    print(f"改写次数：{result.get('retry_count', 0)}")
    print(f"回答：{result.get('final_answer') or '无'}")


if __name__ == "__main__":
    main()
