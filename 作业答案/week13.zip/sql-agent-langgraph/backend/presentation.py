"""CLI 与 Web API 共用的展示格式。

只负责把节点状态、历史记录转换为人类可读文本或可 JSON 序列化的结构，
不包含工作流、数据库或模型调用逻辑。
"""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel

from .schemas import HistoryEntry, QueryResult, WorkflowStep


def _preview_rows(rows: list[dict[str, Any]], limit: int = 3) -> str:
    """把前几行结果压缩成一行，便于在终端观察。"""

    preview = json.dumps(rows[:limit], ensure_ascii=False, default=str)
    if len(rows) > limit:
        preview += f" ...（共 {len(rows)} 行）"
    return preview


def format_step(step: WorkflowStep) -> str:
    """把单个节点的状态增量格式化为一行/几行文本。"""

    node = step.node
    data = step.update

    if node == "fail_result":
        return f"[{node}] {data.get('final_answer') or '查询失败'}"
    if data.get("fatal_error"):
        return f"[{node}] 失败：{data.get('error') or '未知错误'}"

    if node == "parse_database":
        tables = data.get("all_tables") or []
        return f"[{node}] 读取 {len(tables)} 张表"
    if node == "select_tables":
        tables = data.get("selected_tables") or []
        return f"[{node}] 已选表：{'、'.join(tables) or '无'}"
    if node == "generate_sql":
        return f"[{node}] {data.get('sql') or '未生成 SQL'}"
    if node == "validate_sql":
        if data.get("is_valid"):
            return f"[{node}] 通过"
        return f"[{node}] 未通过：{data.get('error') or '未知原因'}"
    if node == "rewrite_sql":
        return (
            f"[{node}] 第 {data.get('retry_count', 0)} 次改写："
            f"{data.get('sql') or '未生成新 SQL'}"
        )
    if node == "execute_sql":
        result = data.get("query_result")
        if result is None:
            return f"[{node}] 执行失败：{data.get('error') or '未知错误'}"
        text = (
            f"[{node}] 返回 {result.row_count} 行，"
            f"耗时 {result.elapsed_ms:.1f} ms"
        )
        if result.truncated:
            text += "（已截断）"
        if result.rows:
            text += f"\n  首行：{_preview_rows(result.rows)}"
        return text
    if node == "summarize_result":
        return f"[{node}] 已生成最终回答"
    return f"[{node}] {data}"


def format_history_entry(entry: HistoryEntry, index: int) -> str:
    """把一条历史记录格式化为终端可读文本。"""

    timestamp = entry.created_at.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        f"{index}. [{timestamp}] 状态：{entry.status}，"
        f"改写 {entry.retry_count} 次",
        f"   问题：{entry.question}",
    ]
    if entry.selected_tables:
        lines.append(f"   数据表：{'、'.join(entry.selected_tables)}")
    if entry.sql:
        lines.append(f"   SQL：{entry.sql}")
    lines.append(f"   回答：{entry.final_answer}")
    if entry.error:
        lines.append(f"   错误：{entry.error}")
    return "\n".join(lines)


def step_payload(step: WorkflowStep) -> dict[str, Any]:
    """把节点结果转换为 SSE 可发送的结构。

    `schema` / `full_schema` 体积较大且前端不需要，直接省略；查询结果只保留
    前 5 行，避免一次响应过大。
    """

    return {
        "node": step.node,
        "summary": format_step(step),
        "data": _sanitize_update(step.update),
    }


def _sanitize_update(update: dict[str, Any]) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for key, value in update.items():
        if key in {"schema", "full_schema"}:
            continue
        if key == "query_result" and isinstance(value, QueryResult):
            payload[key] = {
                "columns": value.columns,
                "rows": value.rows[:5],
                "row_count": value.row_count,
                "truncated": value.truncated,
                "elapsed_ms": value.elapsed_ms,
            }
        elif isinstance(value, BaseModel):
            payload[key] = value.model_dump(mode="json")
        else:
            payload[key] = value
    return payload


def main() -> None:
    """演示节点结果与历史记录的展示格式。"""

    from datetime import datetime, timezone

    from .schemas import WorkflowStep

    step = WorkflowStep(
        node="generate_sql",
        update={"sql": "SELECT COUNT(*) AS total FROM artists"},
    )
    print(format_step(step))
    print(step_payload(step))

    entry = HistoryEntry(
        thread_id="demo",
        question="数据库中有多少位艺术家？",
        final_answer="数据库中共有 275 位艺术家。",
        sql="SELECT COUNT(*) AS total FROM artists",
        selected_tables=["artists"],
        status="success",
        created_at=datetime.now(timezone.utc),
    )
    print(format_history_entry(entry, 1))


if __name__ == "__main__":
    main()
