"""FastAPI 服务：流式执行 SQL Agent 并查看历史。

接口：

- `POST /api/query`：SSE 流式返回每个节点结果和最终答案；
- `GET /api/history`：读取某个会话的历史执行结果；
- `GET /api/health`：健康检查。

前端是独立的 Next.js 项目（`frontend/`），通过 CORS 调用本服务。

启动：

```bash
python -m backend.api
# 或
uvicorn backend.api:app --reload
```
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from .config import load_memory_path
from .presentation import step_payload
from .schemas import WorkflowInput
from .workflow import load_history, stream_workflow

app = FastAPI(
    title="SQL Agent API",
    description="基于 LangGraph 的 Chinook 数据库自然语言查询服务。",
    version="1.0.0",
)

# 本地 Next.js 开发服务器；如前端部署在其他域名，请按需调整。
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _sse(event: dict[str, Any]) -> str:
    """把事件编码为 Server-Sent Events 数据帧。"""

    payload = json.dumps(event, ensure_ascii=False, default=str)
    return f"data: {payload}\n\n"


def _event_stream(payload: WorkflowInput) -> Iterator[str]:
    """执行工作流并把每个节点结果作为 SSE 事件输出。"""

    final_state: dict[str, Any] = {}
    yield _sse(
        {
            "type": "start",
            "question": payload.question,
            "thread_id": payload.thread_id,
        }
    )

    try:
        for step in stream_workflow(
            payload.question,
            thread_id=payload.thread_id,
            max_retries=payload.max_retries,
        ):
            final_state.update(step.update)
            yield _sse({"type": "step", **step_payload(step)})
    except Exception as exc:
        yield _sse({"type": "error", "message": f"执行失败：{exc}"})
        return

    yield _sse(
        {
            "type": "final",
            "status": final_state.get("status", "unknown"),
            "answer": final_state.get("final_answer") or "",
            "sql": final_state.get("sql") or None,
            "retry_count": final_state.get("retry_count", 0),
            "selected_tables": final_state.get("selected_tables") or [],
            "error": final_state.get("error"),
        }
    )


@app.exception_handler(RequestValidationError)
async def _validation_error_handler(
    request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    """把 FastAPI 的校验错误转换为中文提示。"""

    messages: list[str] = []
    for error in exc.errors():
        message = str(error.get("msg") or "参数不合法")
        if message.startswith("Value error, "):
            message = message[len("Value error, ") :]
        location = ".".join(
            str(part)
            for part in error.get("loc", [])
            if part not in {"body", "query", "path"}
        )
        messages.append(f"{location}：{message}" if location else message)

    return JSONResponse(
        status_code=422,
        content={"detail": "；".join(messages) or "请求参数不合法"},
    )


@app.get("/", include_in_schema=False)
def index() -> dict[str, str]:
    """返回 API 基本信息。"""

    return {
        "service": "SQL Agent API",
        "docs": "/docs",
        "health": "/api/health",
    }


@app.get("/api/health")
def health() -> dict[str, str]:
    """健康检查。"""

    return {"status": "ok"}


@app.get("/api/history")
def history(
    thread_id: str = "default",
    limit: int = Query(default=10, ge=1, le=100),
) -> dict[str, Any]:
    """读取某个会话最近的完整执行结果。"""

    try:
        entries = load_history(thread_id, limit=limit)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "thread_id": thread_id,
        "memory_path": str(load_memory_path()),
        "entries": [entry.model_dump(mode="json") for entry in entries],
    }


@app.post("/api/query")
def query(payload: WorkflowInput) -> StreamingResponse:
    """流式执行一次自然语言查询。"""

    return StreamingResponse(
        _event_stream(payload),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


def main() -> None:
    """启动本地 Web 服务。"""

    import uvicorn

    print("SQL Agent Web 服务：http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()
