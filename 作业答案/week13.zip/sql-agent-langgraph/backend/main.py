"""SQL Agent 命令行入口。

用法：

```bash
python -m backend.main --question "数据库中有多少位艺术家？"
python -m backend.main --question "销售额最高的五位艺术家是谁？" --max-retries 5
python -m backend.main --question "数据库中有多少位艺术家？" --no-trace
python -m backend.main --show-history
python -m backend.main --show-history 5 --thread-id demo
```
"""

from __future__ import annotations

import argparse
from typing import Sequence

from .config import load_memory_path
from .presentation import format_history_entry, format_step
from .schemas import WorkflowStep
from .workflow import load_history, run_workflow


def build_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器。"""

    parser = argparse.ArgumentParser(
        prog="python -m backend.main",
        description="使用自然语言查询 Chinook SQLite 数据库。",
    )
    parser.add_argument(
        "--question",
        required=False,
        help="要查询的自然语言问题。",
    )
    parser.add_argument(
        "--thread-id",
        default="default",
        help="历史记录会话标识，默认为 default。",
    )
    parser.add_argument(
        "--max-retries",
        type=int,
        default=None,
        help="SQL 改写次数上限；不传时读取 SQL_AGENT_MAX_RETRIES。",
    )
    parser.add_argument(
        "--recursion-limit",
        type=int,
        default=None,
        help="LangGraph 图执行步数上限；不传时读取 SQL_AGENT_RECURSION_LIMIT。",
    )
    parser.add_argument(
        "--show-sql",
        action="store_true",
        help="额外输出实际执行的 SQL 与改写次数。",
    )
    parser.add_argument(
        "--no-trace",
        action="store_true",
        help="不打印各节点的中间结果，只输出最终答案。",
    )
    parser.add_argument(
        "--show-history",
        nargs="?",
        type=int,
        const=10,
        default=None,
        metavar="N",
        help="查看该会话最近 N 条历史执行结果（默认 10），不执行查询。",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """解析参数、执行工作流并打印各节点结果与最终答案。"""

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.show_history is not None:
        try:
            entries = load_history(args.thread_id, limit=args.show_history)
        except ValueError as exc:
            print(f"读取历史执行结果失败：{exc}")
            return

        print(f"会话：{args.thread_id}")
        print(f"记忆数据库：{load_memory_path()}")
        if not entries:
            print("暂无历史执行记录。")
            return

        for index, entry in enumerate(entries, start=1):
            print()
            print(format_history_entry(entry, index))
        return

    if not args.question:
        parser.error("必须提供 --question，或使用 --show-history 查看历史")

    def _print_step(step: WorkflowStep) -> None:
        print(format_step(step), flush=True)

    try:
        result = run_workflow(
            args.question,
            thread_id=args.thread_id,
            max_retries=args.max_retries,
            recursion_limit=args.recursion_limit,
            on_step=None if args.no_trace else _print_step,
        )
    except Exception as exc:
        print(f"查询失败：{exc}")
        return

    if not args.no_trace:
        print()

    if args.show_sql:
        print(f"SQL：{result.get('sql') or '无'}")
        print(f"改写次数：{result.get('retry_count', 0)}")
        print(f"状态：{result.get('status', 'unknown')}")

    print(f"回答：{result.get('final_answer') or '无'}")
    print(f"历史检查点已写入：{load_memory_path()}")


if __name__ == "__main__":
    main()
