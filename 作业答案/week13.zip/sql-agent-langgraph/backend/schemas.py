"""Pydantic 数据结构定义。

本模块只存放数据模型，不包含 Agent 调用逻辑。
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SecretStr,
    field_validator,
    model_validator,
)


class LLMConfig(BaseModel):
    """大模型配置。

    使用 `SecretStr` 保存 API Key，避免日志或异常信息中意外泄露密钥。
    """

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    api_key: SecretStr = Field(
        default_factory=lambda: SecretStr(""),
        repr=False,
    )
    base_url: str | None = None
    model_name: str = Field(default="gpt-4o-mini", min_length=1)
    temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    timeout: float = Field(default=60.0, gt=0.0)
    max_retries: int = Field(default=2, ge=0)
    max_tokens: int | None = Field(default=2048, gt=0)
    structured_output_method: Literal[
        "json_schema",
        "function_calling",
        "json_mode",
    ] = Field(
        default="json_mode",
        description=(
            "结构化输出方式。DeepSeek、Ollama 等 OpenAI 兼容接口建议使用 "
            "json_mode；OpenAI 官方模型可使用 json_schema。"
        ),
    )


class DatabaseConfig(BaseModel):
    """SQLite 数据库访问配置。

    数据库始终以只读模式打开；`max_rows` 和 `timeout` 用于限制单次查询的
    返回行数与执行时间。
    """

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    path: Path = Field(description="SQLite 数据库文件路径。")
    max_rows: int = Field(default=200, ge=1, description="单次查询最多返回的行数。")
    timeout: float = Field(default=5.0, gt=0.0, description="单条 SQL 的最长执行秒数。")


class WorkflowConfig(BaseModel):
    """LangGraph 工作流配置。

    `max_retries` 是 SQL 改写次数上限，`recursion_limit` 是图执行步数上限，
    二者含义不同，不能混用。
    """

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    max_retries: int = Field(
        default=10,
        ge=0,
        description="SQL 校验或执行失败后允许的最大改写次数。",
    )
    recursion_limit: int = Field(
        default=100,
        ge=1,
        description="LangGraph 单次运行的最大执行步数。",
    )


class WorkflowInput(BaseModel):
    """用户发起的 SQL 查询请求。"""

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    question: str = Field(description="用户的自然语言问题。")
    thread_id: str = Field(
        default="default",
        max_length=128,
        description="用于区分 SqliteSaver 历史检查点的会话标识。",
    )
    max_retries: int | None = Field(
        default=None,
        description="覆盖配置中的 SQL 改写次数上限；为 null 时使用 WorkflowConfig。",
    )

    @field_validator("question")
    @classmethod
    def _check_question(cls, value: str) -> str:
        """保证问题包含实际内容，而不是纯空白。"""

        if not value.strip():
            raise ValueError("question 不能为空")
        return value.strip()

    @field_validator("thread_id")
    @classmethod
    def _check_thread_id(cls, value: str) -> str:
        """保证会话标识非空，避免所有历史写入同一个空键。"""

        if not value.strip():
            raise ValueError("thread_id 不能为空")
        return value.strip()

    @field_validator("max_retries")
    @classmethod
    def _check_max_retries(cls, value: int | None) -> int | None:
        """用中文错误提示代替默认的英文约束信息。"""

        if value is not None and value < 0:
            raise ValueError("max_retries 不能小于 0")
        return value


class WorkflowStep(BaseModel):
    """LangGraph 中单个节点的执行结果。

    `update` 是该节点返回的状态增量，可直接用于观察中间过程或调试路由。
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    node: str = Field(min_length=1, description="节点名称。")
    update: dict[str, Any] = Field(
        default_factory=dict,
        description="该节点写入 AgentState 的字段。",
    )


class HistoryEntry(BaseModel):
    """从 SqliteSaver 检查点中整理出的一次完整执行记录。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    checkpoint_id: str | None = Field(default=None, description="检查点 ID。")
    thread_id: str = Field(min_length=1, description="会话标识。")
    question: str = Field(min_length=1, description="用户问题。")
    final_answer: str = Field(min_length=1, description="最终回答或失败说明。")
    sql: str | None = Field(default=None, description="最后一次执行的 SQL。")
    selected_tables: list[str] = Field(
        default_factory=list,
        description="本次查询选中的数据表。",
    )
    retry_count: int = Field(default=0, ge=0, description="SQL 改写次数。")
    status: Literal["success", "failed"] = Field(description="最终状态。")
    error: str | None = Field(default=None, description="失败时的错误信息。")
    created_at: datetime = Field(description="检查点创建时间（UTC）。")


class AgentOutput(BaseModel):
    """所有 Agent 结构化输出的公共基类。"""

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )


class TableSelection(AgentOutput):
    """表选择结果。"""

    selected_tables: list[str] = Field(
        min_length=1,
        description="回答问题所需的数据表，按重要性排序；必须使用真实表名。",
    )
    reasoning: str = Field(
        default="",
        max_length=1000,
        description="选择这些表的简要理由，尤其是跨表关联路径。",
    )

    @field_validator("selected_tables")
    @classmethod
    def _normalize_tables(cls, value: list[str]) -> list[str]:
        """去除空白、空项和重复表名，保持原有顺序。"""

        normalized: list[str] = []
        seen: set[str] = set()
        for raw_name in value:
            name = raw_name.strip()
            if not name:
                continue
            key = name.casefold()
            if key in seen:
                continue
            seen.add(key)
            normalized.append(name)
        if not normalized:
            raise ValueError("selected_tables 至少需要包含一个非空表名")
        return normalized


class SQLGeneration(AgentOutput):
    """SQL 生成结果。"""

    sql: str = Field(min_length=1, description="一条可执行的只读 SQLite SQL。")
    explanation: str = Field(
        default="",
        max_length=1000,
        description="对查询思路或关键字段的简要说明，不包含 SQL 之外的执行结果。",
    )


class SQLValidation(AgentOutput):
    """SQL 校验结果。"""

    is_valid: bool = Field(description="SQL 是否安全、语法正确且能回答用户问题。")
    error: str | None = Field(
        default=None,
        max_length=2000,
        description="未通过时的具体错误说明，供改写节点使用；通过时必须为 null。",
    )

    @model_validator(mode="after")
    def _check_error(self) -> "SQLValidation":
        """保证校验状态与错误信息一致。"""

        if self.is_valid:
            self.error = None
        elif not self.error:
            raise ValueError("SQL 校验未通过时必须提供 error 说明")
        return self


class SQLRewrite(AgentOutput):
    """SQL 改写结果。"""

    sql: str = Field(min_length=1, description="修复后的一条只读 SQLite SQL。")
    explanation: str = Field(
        default="",
        max_length=1000,
        description="本次修改了什么、为什么这样修改。",
    )


class QuerySummary(AgentOutput):
    """查询结果的自然语言汇总。"""

    answer: str = Field(
        min_length=1,
        max_length=4000,
        description="严格基于真实查询结果生成的中文回答。",
    )


class ColumnSchema(BaseModel):
    """数据表的一列。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str = Field(min_length=1, description="列名。")
    type: str = Field(default="", description="SQLite 声明类型，可能为空。")
    not_null: bool = Field(default=False, description="是否带 NOT NULL 约束。")
    default: str | None = Field(default=None, description="默认值的 SQL 文本。")
    primary_key: bool = Field(default=False, description="是否为主键列。")


class ForeignKeySchema(BaseModel):
    """数据表的一条外键关系。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    columns: list[str] = Field(min_length=1, description="本表中的外键列。")
    referenced_table: str = Field(min_length=1, description="被引用的表名。")
    referenced_columns: list[str] = Field(
        default_factory=list,
        description="被引用的列；SQLite 未声明时可能为空。",
    )
    on_update: str = Field(default="NO ACTION", description="更新时的外键动作。")
    on_delete: str = Field(default="NO ACTION", description="删除时的外键动作。")


class TableSchema(BaseModel):
    """一张数据表或视图的结构。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str = Field(min_length=1, description="表名。")
    columns: list[ColumnSchema] = Field(
        default_factory=list,
        description="按定义顺序排列的列。",
    )
    foreign_keys: list[ForeignKeySchema] = Field(
        default_factory=list,
        description="外键关系列表。",
    )


class DatabaseSchema(BaseModel):
    """数据库 Schema 概览。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    path: str = Field(min_length=1, description="数据库文件路径。")
    tables: list[TableSchema] = Field(
        default_factory=list,
        description="按名称排序的表结构。",
    )


class QueryResult(BaseModel):
    """一次只读查询的真实执行结果。

    零行结果也是成功结果：`rows` 为空、`truncated` 为 `False`，
    不应据此触发 SQL 改写。
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    columns: list[str] = Field(default_factory=list, description="结果列名。")
    rows: list[dict[str, Any]] = Field(
        default_factory=list,
        description="结果行，每行以列名为键。",
    )
    row_count: int = Field(default=0, ge=0, description="实际返回的行数。")
    truncated: bool = Field(
        default=False,
        description="是否因达到 max_rows 限制而截断。",
    )
    elapsed_ms: float = Field(default=0.0, ge=0.0, description="执行耗时（毫秒）。")


def main() -> None:
    """演示数据库配置、查询结果模型与 Agent 输出模型的校验。"""

    from .config import load_database_config

    try:
        config = load_database_config()
    except ValueError as exc:
        print(f"配置读取失败：{exc}")
        return

    print(f"数据库路径：{config.path}")
    print(f"单次最多返回：{config.max_rows} 行，超时：{config.timeout} 秒")

    result = QueryResult(
        columns=["ArtistId", "Name"],
        rows=[{"ArtistId": 1, "Name": "AC/DC"}],
        row_count=1,
        elapsed_ms=0.5,
    )
    print(f"示例查询结果：{result.model_dump()}")

    selection = TableSelection(
        selected_tables=["artists", "albums", "artists"],
        reasoning="通过 artist_id 关联",
    )
    print(f"表选择结果：{selection.selected_tables}")

    validation = SQLValidation(is_valid=False, error="字段 nonexistent 不存在")
    print(f"校验结果：is_valid={validation.is_valid}，error={validation.error}")

    try:
        SQLValidation(is_valid=False)
    except ValueError as exc:
        message = exc.errors()[0].get("msg", "未知校验错误")
        print(f"校验失败示例：{message}")

    workflow_config = WorkflowConfig(max_retries=5, recursion_limit=80)
    request = WorkflowInput(question="销售额最高的五位艺术家是谁？")
    print(
        f"工作流配置：改写上限 {workflow_config.max_retries} 次，"
        f"执行步数上限 {workflow_config.recursion_limit}"
    )
    print(f"用户请求：{request.question}")

    step = WorkflowStep(
        node="generate_sql",
        update={"sql": "SELECT COUNT(*) AS total FROM artists"},
    )
    print(f"节点中间结果：{step.node} -> {step.update}")


if __name__ == "__main__":
    main()
