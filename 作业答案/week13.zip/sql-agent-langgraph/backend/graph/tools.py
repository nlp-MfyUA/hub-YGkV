"""LangGraph 节点使用的工具函数。

本模块是工作流与底层能力之间的薄封装：节点只依赖这里的函数读取 Schema、
做只读校验和执行查询；真正的数据库访问与安全兜底仍在
`backend.tools.database` / `backend.tools.sql` 中实现。

这样拆分后，`nodes.py` 只负责编排 Agent 与状态更新，`tools.py` 负责与
数据库交互，二者都可以独立测试。
"""

from __future__ import annotations

from pathlib import Path

from ..schemas import DatabaseSchema, QueryResult
from ..tools.database import (
    execute_query,
    format_schema_overview,
    get_database_schema,
    list_tables,
)
from ..tools.sql import ensure_read_only_sql


def list_all_tables(database_path: str | Path | None = None) -> list[str]:
    """列出数据库中可供查询的表和视图。"""

    return list_tables(database_path)


def load_schema(
    tables: list[str] | None = None,
    database_path: str | Path | None = None,
) -> DatabaseSchema:
    """读取完整 Schema 或指定表的 Schema。

    Raises:
        ValueError: 指定了不存在的表。
    """

    return get_database_schema(tables, database_path)


def format_schema(schema: DatabaseSchema) -> str:
    """把 Schema 格式化为供 Prompt 使用的中文文本。"""

    return format_schema_overview(schema)


def load_selected_schema(
    tables: list[str],
    database_path: str | Path | None = None,
) -> tuple[list[str], str]:
    """读取已选表的真实表名与格式化 Schema。

    返回值中的表名以数据库中的规范大小写为准，避免模型输出的表名大小写
    与数据库不一致。
    """

    schema = get_database_schema(tables, database_path)
    return [table.name for table in schema.tables], format_schema_overview(schema)


def check_read_only(sql: str) -> tuple[bool, str | None]:
    """静态检查 SQL 是否为单条只读查询。

    Returns:
        `(True, None)` 表示通过；否则返回 `(False, 中文错误说明)`。
    """

    try:
        ensure_read_only_sql(sql)
    except ValueError as exc:
        return False, str(exc)
    return True, None


def execute_readonly(
    sql: str,
    database_path: str | Path | None = None,
    *,
    max_rows: int | None = None,
    timeout: float | None = None,
) -> QueryResult:
    """在只读连接上执行 SQL 并返回真实结果。

    零行结果同样视为成功，不会抛异常。
    """

    return execute_query(
        sql,
        database_path=database_path,
        max_rows=max_rows,
        timeout=timeout,
    )


def main() -> None:
    """演示工作流工具：读取 Schema、静态校验并执行只读查询。"""

    try:
        tables = list_all_tables()
        schema = load_schema(["artists", "albums"])
        overview = format_schema(schema)
        result = execute_readonly("SELECT COUNT(*) AS total FROM artists", max_rows=10)
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        print(f"工作流工具演示失败：{exc}")
        return

    print(f"数据库共有 {len(tables)} 张表：{'、'.join(tables)}")
    print(f"已读取 {len(schema.tables)} 张表的 Schema：\n{overview}")

    allowed, error = check_read_only("DELETE FROM customers")
    print(f"写操作是否允许：{allowed}（{error}）")
    print(f"查询结果：{result.rows}")


if __name__ == "__main__":
    main()
