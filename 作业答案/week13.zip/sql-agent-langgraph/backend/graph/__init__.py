"""LangGraph 工作流包。

对外暴露状态、节点与图构建入口；子模块按需加载，避免只使用状态定义时
也初始化大模型或 LangGraph。
"""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .state import AgentState, build_initial_state, create_state
    from .nodes import AgentSet, WorkflowNodes
    from ..workflow import (
        build_workflow,
        load_history,
        run_workflow,
        stream_workflow,
    )

__all__ = [
    "AgentSet",
    "AgentState",
    "WorkflowNodes",
    "build_initial_state",
    "build_workflow",
    "create_state",
    "load_history",
    "run_workflow",
    "stream_workflow",
]

_LAZY_EXPORTS = {
    "AgentSet": (".nodes", "AgentSet"),
    "AgentState": (".state", "AgentState"),
    "WorkflowNodes": (".nodes", "WorkflowNodes"),
    "build_initial_state": (".state", "build_initial_state"),
    "build_workflow": ("..workflow", "build_workflow"),
    "create_state": (".state", "create_state"),
    "load_history": ("..workflow", "load_history"),
    "run_workflow": ("..workflow", "run_workflow"),
    "stream_workflow": ("..workflow", "stream_workflow"),
}


def _package_name() -> str:
    """返回当前包的绝对名称，兼容 `python -m backend.graph.__init__`。"""

    return __package__ or "backend.graph"


def __getattr__(name: str) -> object:
    """按需导入工作流组件。"""

    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute = target
    module = import_module(module_name, _package_name())
    return getattr(module, attribute)


def main() -> None:
    """演示工作流包的结构与主要导出。"""

    from .state import create_state

    state = create_state("数据库中有多少位艺术家？")
    print("backend.graph 包含以下模块：")
    print("- backend.graph.state：AgentState 与初始状态")
    print("- backend.graph.tools：Schema / 只读校验 / 查询执行")
    print("- backend.graph.nodes：调用 Agent 的节点函数")
    print("- backend.workflow：LangGraph 图定义与运行入口")
    print(f"初始问题：{state['question']}")


if __name__ == "__main__":
    main()
