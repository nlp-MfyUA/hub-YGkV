"""LangGraph 工作流状态定义。

`AgentState` 使用 `TypedDict`，各节点只返回需要更新的字段；跨节点传递的
结构化数据（如 `QueryResult`）仍是 Pydantic 模型，不在这里重复定义。

状态字段说明：
- `thread_id` 用于区分 `SqliteSaver` 历史检查点，不参与 SQL 生成；
- `schema` 只包含已选中的相关表，供 SQL 生成/校验/改写使用；
- `full_schema` 是全部表的概览，仅供表选择节点使用；
- `error` 保存最近一次校验或执行错误，路由函数据此决定是否改写；
- `fatal_error` 表示问题无法通过 SQL 改写恢复（如数据库或模型不可用）。
"""

from __future__ import annotations

from typing import Literal, TypedDict

from ..config import load_workflow_config
from ..schemas import QueryResult, WorkflowConfig, WorkflowInput


class AgentState(TypedDict, total=False):
    """SQL Agent 在 LangGraph 各节点之间共享的状态。"""

    question: str
    thread_id: str
    all_tables: list[str]
    full_schema: str
    selected_tables: list[str]
    schema: str

    sql: str
    is_valid: bool
    error: str | None
    query_result: QueryResult | None

    retry_count: int
    max_retries: int
    final_answer: str
    status: Literal["running", "success", "failed"]
    fatal_error: bool


def build_initial_state(
    request: WorkflowInput,
    config: WorkflowConfig | None = None,
) -> AgentState:
    """根据用户请求构造初始状态。

    Args:
        request: 已通过 Pydantic 校验的用户请求。
        config: 工作流配置；不传时读取 `.env`。

    Raises:
        ValueError: 工作流配置读取失败。
    """

    workflow_config = config or load_workflow_config()
    return AgentState(
        question=request.question,
        thread_id=request.thread_id,
        all_tables=[],
        full_schema="",
        selected_tables=[],
        schema="",
        sql="",
        is_valid=False,
        error=None,
        query_result=None,
        retry_count=0,
        max_retries=(
            workflow_config.max_retries
            if request.max_retries is None
            else request.max_retries
        ),
        final_answer="",
        status="running",
        fatal_error=False,
    )


def create_state(
    question: str,
    *,
    thread_id: str = "default",
    max_retries: int | None = None,
    config: WorkflowConfig | None = None,
) -> AgentState:
    """校验问题并创建初始状态，便于不经过图直接检查状态结构。"""

    request = WorkflowInput(
        question=question,
        thread_id=thread_id,
        max_retries=max_retries,
    )
    return build_initial_state(request, config)


def main() -> None:
    """演示校验用户问题并构造 SQL Agent 的初始状态。"""

    try:
        state = create_state("数据库中有多少位艺术家？", max_retries=3)
    except ValueError as exc:
        print(f"初始状态创建失败：{exc}")
        return

    print(f"问题：{state['question']}")
    print(f"改写上限：{state['max_retries']} 次")
    print(f"当前重试次数：{state['retry_count']}")

    try:
        create_state("   ")
    except ValueError as exc:
        print(f"空问题被拒绝：{exc}")


if __name__ == "__main__":
    main()
