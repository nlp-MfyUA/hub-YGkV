"""LangGraph 节点函数。

每个节点只做一件事，并返回需要写入 `AgentState` 的字段：

- 节点内部调用 `backend.agent` 中已定义的专用 Agent；
- 数据库读取、只读校验与查询执行统一走 `backend.graph.tools`；
- 节点不直接拼接最终答案，`fail_result` 与 `summarize_result` 分别处理
  失败说明和成功汇总。

重试语义：`rewrite_sql` 每进入一次就把 `retry_count` 加一；路由函数在
进入改写节点之前检查上限，因此最多执行 `max_retries` 次改写。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..agent import (
    ResultSummarizerAgent,
    SQLGeneratorAgent,
    SQLRewriterAgent,
    SQLValidatorAgent,
    TableSelectorAgent,
)
from ..config import load_workflow_config
from ..schemas import WorkflowConfig
from ..utils import format_rows, normalize_sql
from . import tools
from .state import AgentState


class AgentSet:
    """工作流使用的全部 Agent，便于注入测试替身或自定义模型。"""

    def __init__(
        self,
        *,
        table_selector: TableSelectorAgent,
        sql_generator: SQLGeneratorAgent,
        sql_validator: SQLValidatorAgent,
        sql_rewriter: SQLRewriterAgent,
        summarizer: ResultSummarizerAgent,
    ) -> None:
        self.table_selector = table_selector
        self.sql_generator = sql_generator
        self.sql_validator = sql_validator
        self.sql_rewriter = sql_rewriter
        self.summarizer = summarizer


def build_agents() -> AgentSet:
    """创建默认 Agent 集合，并让所有 Agent 复用同一个 ChatModel 实例。"""

    selector = TableSelectorAgent()
    shared = {"llm": selector.llm, "config": selector.config}
    return AgentSet(
        table_selector=selector,
        sql_generator=SQLGeneratorAgent(**shared),
        sql_validator=SQLValidatorAgent(**shared),
        sql_rewriter=SQLRewriterAgent(**shared),
        summarizer=ResultSummarizerAgent(**shared),
    )


def _failure(stage: str, exc: Exception) -> dict[str, Any]:
    """把不可恢复异常转换成状态更新，交给 `fail_result` 统一收尾。"""

    return {
        "error": f"{stage}失败：{exc}",
        "fatal_error": True,
    }


class WorkflowNodes:
    """SQL Agent 工作流节点的集合。

    Args:
        agents: 可注入的 Agent 集合；不传时按 `.env` 创建真实 Agent。
        config: 工作流配置；不传时读取 `.env`。
        database_path: 数据库路径；不传时使用 `DATABASE_PATH`。
    """

    def __init__(
        self,
        *,
        agents: AgentSet | None = None,
        config: WorkflowConfig | None = None,
        database_path: str | Path | None = None,
    ) -> None:
        self.config = config or load_workflow_config()
        self.agents = agents or build_agents()
        self.database_path = database_path

    def parse_database(self, state: AgentState) -> dict[str, Any]:
        """读取全部表名和完整 Schema 概览。"""

        try:
            all_tables = tools.list_all_tables(self.database_path)
            if not all_tables:
                raise ValueError("数据库中没有可查询的表或视图")
            overview = tools.format_schema(
                tools.load_schema(all_tables, self.database_path)
            )
        except Exception as exc:
            return _failure("数据库解析", exc)

        return {
            "all_tables": all_tables,
            "full_schema": overview,
            "error": None,
            "is_valid": False,
            "fatal_error": False,
        }

    def select_tables(self, state: AgentState) -> dict[str, Any]:
        """调用表选择 Agent，并把状态更新为已选表的 Schema。"""

        question = state.get("question") or ""
        all_tables = state.get("all_tables") or []
        full_schema = state.get("full_schema") or ""

        try:
            selection = self.agents.table_selector.select(
                question,
                full_schema,
                available_tables=all_tables,
            )
            selected_tables, selected_schema = tools.load_selected_schema(
                selection.selected_tables,
                self.database_path,
            )
        except Exception as exc:
            return _failure("表选择", exc)

        return {
            "selected_tables": selected_tables,
            "schema": selected_schema,
            "error": None,
            "fatal_error": False,
        }

    def generate_sql(self, state: AgentState) -> dict[str, Any]:
        """根据问题和相关表 Schema 生成候选 SQL。"""

        try:
            generation = self.agents.sql_generator.generate(
                state.get("question") or "",
                state.get("schema") or "",
            )
            sql = normalize_sql(generation.sql)
        except Exception as exc:
            return _failure("SQL 生成", exc)

        return {
            "sql": sql,
            "is_valid": False,
            "error": None,
            "query_result": None,
            "fatal_error": False,
        }

    def validate_sql(self, state: AgentState) -> dict[str, Any]:
        """先做结构化只读校验，再调用校验 Agent 检查语法与语义。

        结构化校验是安全边界的一部分：即使模型认为 SQL 合法，写操作也不会
        进入执行节点。
        """

        sql = state.get("sql") or ""
        is_safe, static_error = tools.check_read_only(sql)
        if not is_safe:
            return {
                "is_valid": False,
                "error": f"只读安全校验未通过：{static_error}",
                "fatal_error": False,
            }

        try:
            validation = self.agents.sql_validator.validate(
                state.get("question") or "",
                sql,
                state.get("schema") or "",
            )
        except Exception as exc:
            return _failure("SQL 校验", exc)

        if not validation.is_valid:
            return {
                "is_valid": False,
                "error": validation.error or "SQL 校验未通过，但未提供具体原因",
                "fatal_error": False,
            }

        return {"is_valid": True, "error": None, "fatal_error": False}

    def rewrite_sql(self, state: AgentState) -> dict[str, Any]:
        """根据最近一次错误改写 SQL，并清除上一条 SQL 的校验状态。"""

        retry_count = state.get("retry_count", 0)
        max_retries = state.get("max_retries", self.config.max_retries)
        if retry_count >= max_retries:
            return {
                "error": (
                    f"已达到最大 SQL 改写次数 {max_retries}，"
                    "不能继续改写"
                ),
                "fatal_error": True,
            }

        try:
            rewrite = self.agents.sql_rewriter.rewrite(
                state.get("question") or "",
                state.get("sql") or "",
                state.get("error") or "未知错误",
                state.get("schema") or "",
                attempt=retry_count + 1,
            )
            sql = normalize_sql(rewrite.sql)
        except Exception as exc:
            return _failure("SQL 改写", exc)

        # 新 SQL 必须重新校验，不能沿用上一条 SQL 的 is_valid / error。
        return {
            "sql": sql,
            "retry_count": retry_count + 1,
            "is_valid": False,
            "error": None,
            "query_result": None,
            "fatal_error": False,
        }

    def execute_sql(self, state: AgentState) -> dict[str, Any]:
        """执行校验通过的 SQL；执行失败时把数据库错误交给路由决定是否改写。"""

        sql = state.get("sql") or ""
        try:
            result = tools.execute_readonly(sql, self.database_path)
        except Exception as exc:
            message = str(exc)
            if not message.startswith("SQL 执行失败"):
                message = f"SQL 执行失败：{message}"
            return {
                "is_valid": False,
                "error": message,
                "query_result": None,
                "fatal_error": False,
            }

        return {
            "query_result": result,
            "is_valid": True,
            "error": None,
            "fatal_error": False,
        }

    def summarize_result(self, state: AgentState) -> dict[str, Any]:
        """严格依据真实查询结果生成最终答案。"""

        result = state.get("query_result")
        if result is None:
            return {
                "final_answer": "查询结果缺失，无法生成答案。",
                "status": "failed",
                "fatal_error": True,
            }

        try:
            answer = self.agents.summarizer.summarize(
                state.get("question") or "",
                state.get("sql") or "",
                result.rows,
            )
        except Exception as exc:
            # 汇总失败时退回真实结果，仍然不编造数据。
            answer = self._fallback_answer(result.rows, exc)

        if result.truncated:
            answer = (
                f"{answer}\n\n（结果超过单次返回上限，仅展示前 "
                f"{result.row_count} 行。）"
            )

        return {
            "final_answer": answer,
            "status": "success",
            "fatal_error": False,
        }

    def fail_result(self, state: AgentState) -> dict[str, Any]:
        """把不可恢复的错误整理成用户可读的失败说明。"""

        error = state.get("error") or "未知错误"
        lines = [f"无法完成查询：{error}"]

        sql = (state.get("sql") or "").strip()
        if sql:
            lines.append(
                f"已改写 {state.get('retry_count', 0)} 次，"
                f"上限 {state.get('max_retries', self.config.max_retries)} 次。"
            )
            lines.append(f"最后一次 SQL：\n{sql}")

        return {
            "final_answer": "\n".join(lines),
            "status": "failed",
            "fatal_error": True,
        }

    @staticmethod
    def _fallback_answer(rows: list[dict[str, Any]], exc: Exception) -> str:
        """模型汇总失败时，直接展示真实结果作为兜底答案。"""

        rows_text = format_rows(rows, max_rows=20) if rows else "（无数据行）"
        return (
            f"SQL 已执行成功，但自动汇总失败（{exc}）。"
            f"以下是真实查询结果：\n{rows_text}"
        )


def main() -> None:
    """演示工作流节点：解析数据库并选择相关表。"""

    try:
        nodes = WorkflowNodes()
        parsed = nodes.parse_database(
            {"question": "AC/DC 乐队有多少首歌曲？"}
        )
        if parsed.get("fatal_error"):
            print(f"数据库解析失败：{parsed.get('error')}")
            return

        state = {
            "question": "AC/DC 乐队有多少首歌曲？",
            **parsed,
        }
        selected = nodes.select_tables(state)
    except Exception as exc:
        print(f"工作流节点演示失败：{exc}")
        return

    if selected.get("fatal_error"):
        print(f"表选择失败：{selected.get('error')}")
        return

    print(f"已选表：{'、'.join(selected.get('selected_tables', []))}")
    print(f"相关 Schema 预览：\n{(selected.get('schema') or '')[:300]}")


if __name__ == "__main__":
    main()
