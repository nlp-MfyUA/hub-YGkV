"""配置加载模块。

集中处理 `.env` / 环境变量读取和类型转换，不包含 Agent 或模型调用逻辑。
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from .schemas import DatabaseConfig, LLMConfig, WorkflowConfig

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ENV_FILE = REPO_ROOT / ".env"
DEFAULT_DATABASE_PATH = REPO_ROOT / "asserts" / "chinook.db"


def _clean_env(name: str) -> str:
    """读取并去除环境变量首尾空白；不存在时返回空字符串。"""

    return (os.getenv(name) or "").strip()


def _env_float(name: str, default: float) -> float:
    raw = _clean_env(name)
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise ValueError(f"环境变量 {name} 必须是数字，当前值为 {raw!r}") from exc


def _env_int(name: str, default: int, *, minimum: int = 0) -> int:
    raw = _clean_env(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"环境变量 {name} 必须是整数，当前值为 {raw!r}") from exc
    if value < minimum:
        raise ValueError(f"环境变量 {name} 不能小于 {minimum}，当前值为 {value}")
    return value


def _env_optional_int(name: str, default: int | None) -> int | None:
    """读取可选的整数；显式设置为 0 或负数时表示不限制。"""

    raw = _clean_env(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"环境变量 {name} 必须是整数，当前值为 {raw!r}") from exc
    return value if value > 0 else None


def _env_choice(name: str, default: str, choices: tuple[str, ...]) -> str:
    """读取枚举值，并在取值非法时给出中文错误。"""

    raw = _clean_env(name) or default
    if raw not in choices:
        raise ValueError(
            f"环境变量 {name} 必须是 {'、'.join(choices)} 之一，当前值为 {raw!r}"
        )
    return raw


def load_llm_config(env_file: str | Path | None = None) -> LLMConfig:
    """从 `.env` 加载大模型配置。

    默认读取仓库根目录的 `.env`；已存在的进程环境变量优先，不会被
    `.env` 覆盖。配置格式见仓库根目录的 `.env.example`。
    """

    load_dotenv(
        dotenv_path=Path(env_file) if env_file is not None else DEFAULT_ENV_FILE,
        override=False,
    )
    return LLMConfig(
        api_key=_clean_env("OPENAI_API_KEY"),
        base_url=_clean_env("OPENAI_BASE_URL") or None,
        model_name=_clean_env("MODEL_NAME") or "gpt-4o-mini",
        temperature=_env_float("LLM_TEMPERATURE", 0.0),
        timeout=_env_float("LLM_TIMEOUT", 60.0),
        max_retries=_env_int("LLM_REQUEST_MAX_RETRIES", 2),
        max_tokens=_env_optional_int("LLM_MAX_TOKENS", 2048),
        structured_output_method=_env_choice(
            "LLM_STRUCTURED_OUTPUT_METHOD",
            "json_mode",
            ("json_schema", "function_calling", "json_mode"),
        ),
    )


def load_database_config(env_file: str | Path | None = None) -> DatabaseConfig:
    """从 `.env` 加载 SQLite 数据库访问配置。

    相对路径按仓库根目录解析。数据库缺失时不在配置层报错，
    由 `backend.tools.database` 在真正连接时给出中文提示。
    """

    load_dotenv(
        dotenv_path=Path(env_file) if env_file is not None else DEFAULT_ENV_FILE,
        override=False,
    )

    raw_path = _clean_env("DATABASE_PATH")
    path = Path(raw_path).expanduser() if raw_path else DEFAULT_DATABASE_PATH
    if not path.is_absolute():
        path = REPO_ROOT / path

    return DatabaseConfig(
        path=path.resolve(),
        max_rows=_env_int("SQL_AGENT_MAX_ROWS", 200, minimum=1),
        timeout=_env_float("SQL_AGENT_QUERY_TIMEOUT", 5.0),
    )


def load_workflow_config(env_file: str | Path | None = None) -> WorkflowConfig:
    """从 `.env` 加载 LangGraph 工作流配置。

    `SQL_AGENT_MAX_RETRIES` 控制 SQL 改写次数，`SQL_AGENT_RECURSION_LIMIT`
    控制图执行步数；后者必须为完整的多节点循环预留足够步数。
    """

    load_dotenv(
        dotenv_path=Path(env_file) if env_file is not None else DEFAULT_ENV_FILE,
        override=False,
    )
    return WorkflowConfig(
        max_retries=_env_int("SQL_AGENT_MAX_RETRIES", 10, minimum=0),
        recursion_limit=_env_int("SQL_AGENT_RECURSION_LIMIT", 100, minimum=1),
    )


def load_memory_path(env_file: str | Path | None = None) -> Path:
    """从 `.env` 加载 LangGraph `SqliteSaver` 的记忆数据库路径。

    记忆数据库与业务数据库分离，默认放在 `asserts/sql_agent_memory.db`；
    相对路径按仓库根目录解析。
    """

    load_dotenv(
        dotenv_path=Path(env_file) if env_file is not None else DEFAULT_ENV_FILE,
        override=False,
    )

    raw_path = _clean_env("MEMORY_DATABASE_PATH")
    path = (
        Path(raw_path).expanduser()
        if raw_path
        else REPO_ROOT / "asserts" / "sql_agent_memory.db"
    )
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


def main() -> None:
    """演示从 `.env` 和环境变量加载并打印当前大模型与数据库配置。"""

    try:
        llm_config = load_llm_config()
        database_config = load_database_config()
        workflow_config = load_workflow_config()
        memory_path = load_memory_path()
    except ValueError as exc:
        print(f"配置加载失败：{exc}")
        return

    print(llm_config)
    print(database_config)
    print(workflow_config)
    print(f"memory_path={memory_path}")


if __name__ == "__main__":
    main()