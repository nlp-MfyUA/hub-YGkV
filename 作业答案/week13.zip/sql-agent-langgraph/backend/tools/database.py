"""SQLite 数据库工具。

提供工作流节点需要的四类能力：
1. 以只读模式打开数据库（`mode=ro`）；
2. 读取表名与表结构（字段、主键、外键）；
3. 把 Schema 格式化为便于模型阅读的中文文本；
4. 在只读连接 + authorizer + 超时限制下执行单条 SELECT 查询。

安全边界是分层实现的：本模块的静态校验见 `backend.tools.sql`，
连接层的 `mode=ro`、`PRAGMA query_only` 与 authorizer 负责最终兜底。
"""

from __future__ import annotations

import sqlite3
import time
from collections.abc import Iterable, Sequence
from contextlib import closing
from pathlib import Path
from typing import Any

from ..config import REPO_ROOT, load_database_config
from ..schemas import (
    ColumnSchema,
    DatabaseSchema,
    ForeignKeySchema,
    QueryResult,
    TableSchema,
)
from ..utils import require_text
from .sql import ensure_read_only_sql

# 只允许读取类操作，其余动作（写、DDL、PRAGMA、ATTACH 等）一律拒绝。
_ALLOWED_AUTHORIZER_ACTIONS = frozenset(
    {
        sqlite3.SQLITE_SELECT,
        sqlite3.SQLITE_READ,
        sqlite3.SQLITE_FUNCTION,
        getattr(sqlite3, "SQLITE_RECURSIVE", 33),
    }
)


def _read_only_authorizer(
    action: int,
    arg1: str | None,
    arg2: str | None,
    database: str | None,
    trigger: str | None,
) -> int:
    """SQLite authorizer 回调：只放行读取类动作。"""

    if action in _ALLOWED_AUTHORIZER_ACTIONS:
        return sqlite3.SQLITE_OK
    return sqlite3.SQLITE_DENY


def resolve_database_path(database_path: str | Path | None = None) -> Path:
    """解析数据库路径；相对路径按仓库根目录处理。"""

    if database_path is None:
        return load_database_config().path

    path = Path(database_path).expanduser()
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


def connect_readonly(database_path: str | Path | None = None) -> sqlite3.Connection:
    """以只读模式打开 SQLite 数据库。

    除 URI 的 `mode=ro` 外，还会开启 `PRAGMA query_only`，即使调用方
    忘记校验 SQL，也无法通过该连接写入数据。
    """

    path = resolve_database_path(database_path)
    if not path.is_file():
        raise FileNotFoundError(f"数据库文件不存在：{path}")

    connection = sqlite3.connect(
        path.as_uri() + "?mode=ro",
        uri=True,
        timeout=5.0,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only = ON")
    return connection


def list_tables(database_path: str | Path | None = None) -> list[str]:
    """列出数据库中的表和视图，按名称排序，排除 SQLite 内部对象。"""

    with closing(connect_readonly(database_path)) as connection:
        return _list_tables(connection)


def _canonical_table_name(connection: sqlite3.Connection, table: str) -> str:
    """按 SQLite 大小写不敏感规则返回真实表名。"""

    name = require_text(table, "table")
    row = connection.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type IN ('table', 'view') AND name = ? COLLATE NOCASE
        """,
        (name,),
    ).fetchone()
    if row is None:
        raise ValueError(f"数据表不存在：{name}")
    return str(row["name"])


def _table_schema(connection: sqlite3.Connection, table: str) -> TableSchema:
    """读取单张表的字段与外键信息（表名必须已确认存在）。"""

    columns = [
        ColumnSchema(
            name=str(row["name"]),
            type=str(row["type"] or ""),
            not_null=bool(row["notnull"]),
            default=None if row["dflt_value"] is None else str(row["dflt_value"]),
            primary_key=bool(row["pk"]),
        )
        for row in connection.execute(
            "SELECT * FROM pragma_table_info(?)", (table,)
        ).fetchall()
    ]

    grouped: dict[int, dict[str, Any]] = {}
    for row in connection.execute(
        "SELECT * FROM pragma_foreign_key_list(?)", (table,)
    ).fetchall():
        group = grouped.setdefault(
            int(row["id"]),
            {
                "columns": [],
                "referenced_table": str(row["table"]),
                "referenced_columns": [],
                "on_update": str(row["on_update"] or "NO ACTION"),
                "on_delete": str(row["on_delete"] or "NO ACTION"),
            },
        )
        group["columns"].append(str(row["from"]))
        if row["to"] is not None:
            group["referenced_columns"].append(str(row["to"]))

    foreign_keys = [ForeignKeySchema(**group) for group in grouped.values()]
    return TableSchema(name=table, columns=columns, foreign_keys=foreign_keys)


def get_table_schema(
    table: str,
    database_path: str | Path | None = None,
) -> TableSchema:
    """读取指定表的字段、主键与外键信息。

    Raises:
        ValueError: 表名为空或表不存在。
    """

    with closing(connect_readonly(database_path)) as connection:
        canonical = _canonical_table_name(connection, table)
        return _table_schema(connection, canonical)


def get_database_schema(
    tables: Iterable[str] | None = None,
    database_path: str | Path | None = None,
) -> DatabaseSchema:
    """读取数据库 Schema；传入 `tables` 时只返回指定表。

    Raises:
        ValueError: 指定了不存在的表。
    """

    with closing(connect_readonly(database_path)) as connection:
        available = {
            name.casefold(): name
            for name in _list_tables(connection)
        }

        if tables is None:
            names = [available[key] for key in sorted(available)]
        else:
            requested: list[str] = []
            unknown: list[str] = []
            seen: set[str] = set()
            for raw_name in tables:
                name = require_text(raw_name, "table")
                key = name.casefold()
                if key in seen:
                    continue
                seen.add(key)
                if key not in available:
                    unknown.append(name)
                    continue
                requested.append(available[key])
            if unknown:
                raise ValueError(
                    "以下数据表不存在："
                    + "、".join(unknown)
                    + "；可用表为："
                    + "、".join(available[key] for key in sorted(available))
                )
            names = requested

        return DatabaseSchema(
            path=str(resolve_database_path(database_path)),
            tables=[_table_schema(connection, name) for name in names],
        )


def _list_tables(connection: sqlite3.Connection) -> list[str]:
    """在已有连接上列出表和视图。"""

    rows = connection.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type IN ('table', 'view')
          AND name NOT LIKE 'sqlite_%'
        ORDER BY name
        """
    ).fetchall()
    return [str(row["name"]) for row in rows]


def format_schema_overview(schema: DatabaseSchema | TableSchema) -> str:
    """把 Schema 格式化为中文文本，供表选择与 SQL 生成 Prompt 使用。

    既可传入整个 `DatabaseSchema`，也可只传入单张 `TableSchema`。
    """

    tables = [schema] if isinstance(schema, TableSchema) else list(schema.tables)
    lines: list[str] = []
    if isinstance(schema, DatabaseSchema):
        lines.append(f"数据库：{schema.path}")
    lines.append(f"相关表（{len(tables)} 张）：")

    for table in tables:
        lines.append("")
        lines.append(f"表 {table.name}")
        for column in table.columns:
            flags: list[str] = []
            if column.primary_key:
                flags.append("主键")
            if column.not_null:
                flags.append("非空")

            column_type = f" {column.type}" if column.type else ""
            flag_text = f"（{'、'.join(flags)}）" if flags else ""
            default_text = (
                f"，默认值 {column.default}" if column.default is not None else ""
            )
            lines.append(f"  - {column.name}{column_type}{flag_text}{default_text}")

        for foreign_key in table.foreign_keys:
            referenced = (
                "、".join(foreign_key.referenced_columns) or "主键"
            )
            lines.append(
                f"  外键：{'、'.join(foreign_key.columns)}"
                f" -> {foreign_key.referenced_table}({referenced})"
            )

    return "\n".join(lines)


def _unique_columns(names: Sequence[str]) -> list[str]:
    """为重复列名追加序号，避免结果字典互相覆盖。"""

    counts: dict[str, int] = {}
    unique: list[str] = []
    for name in names:
        count = counts.get(name, 0) + 1
        counts[name] = count
        unique.append(name if count == 1 else f"{name}_{count}")
    return unique


def execute_query(
    sql: str,
    *,
    database_path: str | Path | None = None,
    max_rows: int | None = None,
    timeout: float | None = None,
) -> QueryResult:
    """执行单条只读 SQL 并返回真实结果。

    零行结果是成功查询，会返回 `rows=[]`，不会抛异常。

    Args:
        sql: 待执行的 SQL，必须通过只读结构校验。
        database_path: 数据库路径；不传时读取 `.env` 的 `DATABASE_PATH`。
        max_rows: 最多返回的行数；不传时读取 `SQL_AGENT_MAX_ROWS`。
        timeout: 最长执行秒数；不传时读取 `SQL_AGENT_QUERY_TIMEOUT`。

    Raises:
        ValueError: SQL 不满足只读要求，或行数/超时参数非法。
        FileNotFoundError: 数据库文件不存在。
        RuntimeError: SQL 执行失败或超时。
    """

    config = load_database_config()
    limit = config.max_rows if max_rows is None else max_rows
    deadline_seconds = config.timeout if timeout is None else timeout
    if limit <= 0:
        raise ValueError("max_rows 必须大于 0")
    if deadline_seconds <= 0:
        raise ValueError("timeout 必须大于 0")

    statement = ensure_read_only_sql(sql)

    timed_out = False
    deadline = time.monotonic() + deadline_seconds

    def _progress_handler() -> int:
        nonlocal timed_out
        if time.monotonic() >= deadline:
            timed_out = True
            return 1
        return 0

    started = time.monotonic()
    with closing(connect_readonly(database_path)) as connection:
        connection.set_authorizer(_read_only_authorizer)
        connection.set_progress_handler(_progress_handler, 1000)

        try:
            cursor = connection.execute(statement)
            columns = _unique_columns(
                [str(item[0]) for item in cursor.description or []]
            )
            fetched = cursor.fetchmany(limit + 1)
        except sqlite3.Error as exc:
            if timed_out:
                raise RuntimeError(
                    f"查询超时（超过 {deadline_seconds:g} 秒），已中止执行"
                ) from exc
            raise RuntimeError(f"SQL 执行失败：{exc}") from exc

    elapsed_ms = (time.monotonic() - started) * 1000
    truncated = len(fetched) > limit
    rows = [dict(zip(columns, row)) for row in fetched[:limit]]

    return QueryResult(
        columns=columns,
        rows=rows,
        row_count=len(rows),
        truncated=truncated,
        elapsed_ms=round(elapsed_ms, 3),
    )


def main() -> None:
    """演示读取 Chinook Schema 并执行一条只读查询。"""

    try:
        schema = get_database_schema(["artists", "albums"])
        print(format_schema_overview(schema))

        result = execute_query("SELECT COUNT(*) AS total FROM artists", max_rows=10)
        print("\n查询结果：", result.rows)
        print(f"返回 {result.row_count} 行，耗时 {result.elapsed_ms} ms")
    except FileNotFoundError as exc:
        print(f"数据库不可用：{exc}")
    except ValueError as exc:
        print(f"输入不合法：{exc}")
    except RuntimeError as exc:
        print(f"查询失败：{exc}")


if __name__ == "__main__":
    main()
