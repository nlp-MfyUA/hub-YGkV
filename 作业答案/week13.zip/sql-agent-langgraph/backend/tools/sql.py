"""SQL 结构安全校验工具。

本模块只做静态的只读判定：单条语句、以 SELECT/WITH 开头、不包含写操作
或管理关键字。它是执行层安全的一部分，不能单独构成安全边界——真正执行
时仍必须使用 SQLite 只读连接（`mode=ro` + authorizer）。

字符串字面量、引号标识符和注释中的内容会被正确跳过，避免把
`SELECT 'delete'` 之类的合法查询误判为写操作。
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Literal

from ..utils import require_text

TokenKind = Literal["word", "literal", "identifier", "punct", "semicolon", "comment"]

# 只允许只读查询；WITH 用于 CTE。
_ALLOWED_FIRST_KEYWORDS = frozenset({"select", "with"})

# 在 SQL 语句任意位置出现都视为危险（replace 等函数名不在此列）。
_FORBIDDEN_KEYWORDS = frozenset(
    {
        "insert",
        "update",
        "delete",
        "drop",
        "alter",
        "create",
        "vacuum",
        "pragma",
        "attach",
        "detach",
        "reindex",
        "analyze",
        "begin",
        "commit",
        "rollback",
        "savepoint",
        "release",
        "load_extension",
        "writefile",
        "into",
    }
)

_QUOTE_PAIRS = {"'": "'", '"': '"', "`": "`", "[": "]"}


def _scan_quoted(sql: str, start: int) -> int:
    """返回引号内容结束后的下标，按 SQLite 规则处理成对引号转义。"""

    opener = sql[start]
    closer = _QUOTE_PAIRS[opener]
    index = start + 1
    length = len(sql)
    while index < length:
        if sql[index] == closer:
            # ''、""、``、]] 表示转义后的引号字符本身。
            if index + 1 < length and sql[index + 1] == closer:
                index += 2
                continue
            return index + 1
        index += 1
    raise ValueError("SQL 中的字符串或引号标识符未闭合")


def _iter_tokens(sql: str) -> Iterator[tuple[TokenKind, str]]:
    """逐个产出 SQL 词法单元，忽略空白并对注释单独标记。"""

    index = 0
    length = len(sql)
    while index < length:
        char = sql[index]

        if char.isspace():
            index += 1
            continue

        if char == "-" and sql.startswith("--", index):
            end = sql.find("\n", index)
            end = length if end < 0 else end
            yield "comment", sql[index:end]
            index = end
            continue

        if char == "/" and sql.startswith("/*", index):
            end = sql.find("*/", index + 2)
            if end < 0:
                raise ValueError("SQL 中的块注释未闭合")
            yield "comment", sql[index : end + 2]
            index = end + 2
            continue

        if char in _QUOTE_PAIRS:
            end = _scan_quoted(sql, index)
            kind: TokenKind = "literal" if char == "'" else "identifier"
            yield kind, sql[index:end]
            index = end
            continue

        if char == ";":
            yield "semicolon", char
            index += 1
            continue

        if char.isalnum() or char in "_$":
            end = index + 1
            while end < length and (sql[end].isalnum() or sql[end] in "_$"):
                end += 1
            yield "word", sql[index:end]
            index = end
            continue

        yield "punct", char
        index += 1


def split_sql_statements(sql: str) -> list[str]:
    """按分号拆分 SQL，忽略字符串、引号标识符和注释中的分号。

    返回去除首尾空白的非空语句列表；注释保留在语句文本中。
    """

    text = require_text(sql, "sql")

    statements: list[str] = []
    buffer: list[str] = []
    index = 0
    length = len(text)

    while index < length:
        char = text[index]

        if char == "-" and text.startswith("--", index):
            end = text.find("\n", index)
            end = length if end < 0 else end
            buffer.append(text[index:end])
            index = end
            continue

        if char == "/" and text.startswith("/*", index):
            end = text.find("*/", index + 2)
            if end < 0:
                raise ValueError("SQL 中的块注释未闭合")
            buffer.append(text[index : end + 2])
            index = end + 2
            continue

        if char in _QUOTE_PAIRS:
            end = _scan_quoted(text, index)
            buffer.append(text[index:end])
            index = end
            continue

        if char == ";":
            statement = "".join(buffer).strip()
            if statement:
                statements.append(statement)
            buffer = []
            index += 1
            continue

        buffer.append(char)
        index += 1

    tail = "".join(buffer).strip()
    if tail:
        statements.append(tail)
    return statements


def ensure_read_only_sql(sql: str) -> str:
    """校验 SQL 是否为单条只读查询，返回去除首尾空白的语句。

    Raises:
        ValueError: SQL 为空、包含多条语句、不是 SELECT/WITH，或包含
            写操作/管理关键字。错误信息可直接反馈给 SQL 改写节点。
    """

    text = require_text(sql, "sql")
    statements = split_sql_statements(text)
    if not statements:
        raise ValueError("SQL 不能为空")
    if len(statements) > 1:
        raise ValueError(
            f"只允许执行一条 SQL 语句，当前检测到 {len(statements)} 条；"
            "请删除多余语句，不要使用分号拼接"
        )

    statement = statements[0]
    words = [value.casefold() for kind, value in _iter_tokens(statement) if kind == "word"]
    if not words:
        raise ValueError("SQL 中没有可执行的关键字")

    first = words[0]
    if first not in _ALLOWED_FIRST_KEYWORDS:
        raise ValueError(
            f"只允许只读查询，SQL 必须以 SELECT 或 WITH 开头，当前为 {first.upper()}"
        )

    forbidden = sorted({word for word in words if word in _FORBIDDEN_KEYWORDS})
    if forbidden:
        raise ValueError(
            "SQL 包含不允许的写操作或管理关键字："
            + "、".join(word.upper() for word in forbidden)
        )

    return statement


def is_read_only_sql(sql: str) -> bool:
    """判断 SQL 是否通过只读结构校验；不抛异常，便于做条件判断。"""

    try:
        ensure_read_only_sql(sql)
    except ValueError:
        return False
    return True


def main() -> None:
    """演示只读 SQL 校验：接受普通查询与 CTE，拒绝写操作和多语句。"""

    samples = [
        "SELECT Name FROM artists LIMIT 3;",
        "WITH t AS (SELECT 1 AS x) SELECT x FROM t",
        "SELECT replace('abc', 'a', 'z') AS v",
        "DELETE FROM customers",
        "SELECT 1; DROP TABLE customers",
        "PRAGMA table_info(artists)",
    ]

    for sample in samples:
        try:
            statement = ensure_read_only_sql(sample)
        except ValueError as exc:
            print(f"拒绝：{sample!r} -> {exc}")
        else:
            print(f"允许：{sample!r} -> {statement}")


if __name__ == "__main__":
    main()
