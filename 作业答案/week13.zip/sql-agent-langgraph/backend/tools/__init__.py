"""SQL Agent 工具包。

包含 SQLite 只读访问、Schema 读取、结果格式化与 SQL 结构安全校验。
工作流节点应优先复用这里的函数，避免重复实现数据库连接与安全判断。
"""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .database import (
        connect_readonly,
        execute_query,
        format_schema_overview,
        get_database_schema,
        get_table_schema,
        list_tables,
        resolve_database_path,
    )
    from .sql import (
        ensure_read_only_sql,
        is_read_only_sql,
        split_sql_statements,
    )

__all__ = [
    "connect_readonly",
    "ensure_read_only_sql",
    "execute_query",
    "format_schema_overview",
    "get_database_schema",
    "get_table_schema",
    "is_read_only_sql",
    "list_tables",
    "resolve_database_path",
    "split_sql_statements",
]

_LAZY_EXPORTS = {
    "connect_readonly": (".database", "connect_readonly"),
    "ensure_read_only_sql": (".sql", "ensure_read_only_sql"),
    "execute_query": (".database", "execute_query"),
    "format_schema_overview": (".database", "format_schema_overview"),
    "get_database_schema": (".database", "get_database_schema"),
    "get_table_schema": (".database", "get_table_schema"),
    "is_read_only_sql": (".sql", "is_read_only_sql"),
    "list_tables": (".database", "list_tables"),
    "resolve_database_path": (".database", "resolve_database_path"),
    "split_sql_statements": (".sql", "split_sql_statements"),
}


def __getattr__(name: str) -> object:
    """按需导入工具函数，避免 `python -m backend.tools.*` 时重复导入。"""

    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute = target
    module = import_module(module_name, __name__)
    return getattr(module, attribute)
