"""SQL Agent 共用的轻量工具函数。

本模块只处理字符串与展示格式，不做数据库连接、SQL 执行或安全裁决。
真正的只读安全边界必须在执行层（SQLite `mode=ro` + 结构化校验）实现，
不能只依赖这里或 Prompt。
"""

from __future__ import annotations

import json
import re
from typing import Any, Mapping, Sequence

_CODE_FENCE_RE = re.compile(
    r"^\s*```(?:sql|sqlite)?\s*(.*?)\s*```\s*$",
    flags=re.IGNORECASE | re.DOTALL,
)


def require_text(value: str, name: str) -> str:
    """校验字符串非空，并返回去除首尾空白后的结果。"""

    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} 不能为空")
    return value.strip()


def normalize_sql(sql: str) -> str:
    """清理模型返回的 SQL：去掉 Markdown 代码围栏和首尾空白。"""

    text = require_text(sql, "sql")
    match = _CODE_FENCE_RE.match(text)
    if match:
        text = match.group(1).strip()
    if not text:
        raise ValueError("模型返回的 SQL 为空")
    return text


def format_rows(
    rows: Sequence[Mapping[str, Any]] | Sequence[Sequence[Any]],
    *,
    max_rows: int = 50,
) -> str:
    """把查询结果格式化为便于模型阅读的 JSON 文本。"""

    if max_rows <= 0:
        raise ValueError("max_rows 必须大于 0")

    limited = list(rows)[:max_rows]
    try:
        payload: Any = [dict(row) for row in limited]
    except (TypeError, ValueError):
        payload = [list(row) for row in limited]

    text = json.dumps(payload, ensure_ascii=False, default=str, indent=2)
    if len(rows) > max_rows:
        text += f"\n\n（仅展示前 {max_rows} 行，共 {len(rows)} 行）"
    return text


def main() -> None:
    """演示 SQL 清理与查询结果格式化工具。"""

    try:
        sql = normalize_sql("```sql\nSELECT name FROM artists LIMIT 5;\n```")
        rows = format_rows([{"name": "AC/DC"}, {"name": "Accept"}])
    except ValueError as exc:
        print(f"工具函数演示失败：{exc}")
        return

    print(f"清理后的 SQL：{sql}")
    print(f"格式化后的结果：\n{rows}")


if __name__ == "__main__":
    main()
