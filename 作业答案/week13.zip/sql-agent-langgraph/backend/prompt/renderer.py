"""Jinja2 提示词渲染器。

所有 Agent 的 Prompt 模板直接放在 `backend/prompt/` 下，
代码只负责准备变量和调用 `render_prompt`，不再内联长段提示词。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateNotFound
from jinja2.exceptions import UndefinedError

TEMPLATE_DIR = Path(__file__).resolve().parent

_environment = Environment(
    loader=FileSystemLoader(TEMPLATE_DIR),
    undefined=StrictUndefined,
    trim_blocks=True,
    lstrip_blocks=True,
    autoescape=False,
    keep_trailing_newline=False,
)


def render_prompt(template_name: str, /, **context: Any) -> str:
    """渲染指定 Prompt 模板。

    Args:
        template_name: 模板文件名，例如 `"sql_generator_system.j2"`。
        **context: 模板变量。

    Raises:
        ValueError: 模板不存在、缺少变量或渲染结果为空。
    """

    try:
        template = _environment.get_template(template_name)
    except TemplateNotFound as exc:
        raise ValueError(f"提示词模板不存在：{template_name}") from exc

    try:
        text = template.render(**context).strip()
    except UndefinedError as exc:
        raise ValueError(
            f"提示词模板 {template_name} 缺少变量或变量为空：{exc}"
        ) from exc

    if not text:
        raise ValueError(f"提示词模板 {template_name} 渲染结果为空")
    return text


def main() -> None:
    """演示使用 Jinja2 渲染系统提示词模板。"""

    try:
        text = render_prompt("table_selector_system.j2")
    except ValueError as exc:
        print(f"提示词渲染失败：{exc}")
        return

    preview = text[:80] + ("..." if len(text) > 80 else "")
    print(f"模板渲染成功，预览：\n{preview}")


if __name__ == "__main__":
    main()
