"""Prompt 模板包。"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .renderer import TEMPLATE_DIR, render_prompt

__all__ = ["TEMPLATE_DIR", "render_prompt"]


def __getattr__(name: str) -> object:
    """按需导入渲染器，避免运行子模块时重复加载。"""

    if name in __all__:
        from . import renderer

        return getattr(renderer, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def main() -> None:
    """演示通过 Prompt 包入口渲染带变量的用户提示词。"""

    from .renderer import render_prompt

    try:
        text = render_prompt(
            "table_selector_user.j2",
            available_text="artists、albums",
            schema_overview="artists(id, name)；albums(id, artist_id, title)",
            question="有多少位艺术家？",
        )
    except ValueError as exc:
        print(f"提示词渲染失败：{exc}")
        return

    print(text)


if __name__ == "__main__":
    main()
