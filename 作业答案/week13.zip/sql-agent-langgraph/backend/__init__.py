"""后端业务包。"""


def main() -> None:
    """演示后端包包含的主要模块。"""

    modules = [
        "config",
        "schemas",
        "utils",
        "prompt",
        "agent",
        "tools",
        "graph",
        "workflow",
        "presentation",
        "api",
        "main",
    ]
    print("backend 包包含以下模块：")
    for name in modules:
        print(f"- backend.{name}")


if __name__ == "__main__":
    main()
