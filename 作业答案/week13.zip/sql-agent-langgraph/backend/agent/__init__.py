"""Agent 模块。

对外暴露 `BaseAgent` 以及 SQL 工作流所需的各个专用 Agent。
所有 Agent 均通过延迟导入加载，避免直接运行子模块时重复执行包初始化。
"""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING

from ..schemas import LLMConfig

if TYPE_CHECKING:
    from .base import BaseAgent
    from .sql_generator import SQLGeneratorAgent
    from .sql_rewriter import SQLRewriterAgent
    from .sql_validator import SQLValidatorAgent
    from .summarizer import ResultSummarizerAgent
    from .table_selector import TableSelectorAgent

__all__ = [
    "BaseAgent",
    "LLMConfig",
    "ResultSummarizerAgent",
    "SQLGeneratorAgent",
    "SQLRewriterAgent",
    "SQLValidatorAgent",
    "TableSelectorAgent",
]

_LAZY_EXPORTS = {
    "BaseAgent": (".base", "BaseAgent"),
    "ResultSummarizerAgent": (".summarizer", "ResultSummarizerAgent"),
    "SQLGeneratorAgent": (".sql_generator", "SQLGeneratorAgent"),
    "SQLRewriterAgent": (".sql_rewriter", "SQLRewriterAgent"),
    "SQLValidatorAgent": (".sql_validator", "SQLValidatorAgent"),
    "TableSelectorAgent": (".table_selector", "TableSelectorAgent"),
}


def _package_name() -> str:
    """返回当前包的绝对名称，兼容 `python -m backend.agent.__init__`。"""

    return __package__ or "backend.agent"


def __getattr__(name: str) -> object:
    """按需导入 Agent 类，保持包导入轻量。"""

    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute = target
    module = import_module(module_name, _package_name())
    return getattr(module, attribute)


def main() -> None:
    """演示 Agent 包对外暴露的类与说明。"""

    for name in __all__:
        target = _LAZY_EXPORTS.get(name)
        if target is None:
            print(f"{name}：配置数据模型")
            continue
        module_name, attribute = target
        module = import_module(module_name, _package_name())
        obj = getattr(module, attribute)
        summary = (obj.__doc__ or "").strip().splitlines()[0]
        print(f"{name}：{summary}")


if __name__ == "__main__":
    main()
