"""SQL 改写 Agent。

根据校验失败原因或数据库执行错误，对原 SQL 做最小必要修复。
"""

from __future__ import annotations

from ..prompt import render_prompt
from ..schemas import SQLRewrite
from ..utils import normalize_sql, require_text
from .base import BaseAgent


class SQLRewriterAgent(BaseAgent):
    """根据错误反馈修复 SQL。"""

    default_system_prompt = render_prompt("sql_rewriter_system.j2")

    def rewrite(
        self,
        question: str,
        sql: str,
        error: str,
        schema_overview: str,
        *,
        attempt: int = 1,
        dialect: str = "SQLite",
    ) -> SQLRewrite:
        """修复 SQL。

        Args:
            question: 用户的原始问题。
            sql: 上一次生成的 SQL。
            error: 校验失败或数据库执行失败的原因。
            schema_overview: 相关表的 Schema。
            attempt: 当前是第几次改写，从 1 开始；用于提示模型不要重复错误。
            dialect: SQL 方言，默认为 SQLite。

        Raises:
            ValueError: 必填输入为空，或改写次数非法。
        """

        question = require_text(question, "question")
        sql = require_text(sql, "sql")
        error = require_text(error, "error")
        schema_overview = require_text(schema_overview, "schema_overview")
        dialect = require_text(dialect, "dialect")
        if attempt < 1:
            raise ValueError("attempt 必须大于等于 1")

        prompt = render_prompt(
            "sql_rewriter_user.j2",
            dialect=dialect,
            attempt=attempt,
            schema_overview=schema_overview,
            question=question,
            sql=sql,
            error=error,
        )

        rewrite = self.invoke_structured(prompt, SQLRewrite)
        return rewrite.model_copy(update={"sql": normalize_sql(rewrite.sql)})


def main() -> None:
    """演示根据校验错误修复 SQL。"""

    try:
        agent = SQLRewriterAgent()
        result = agent.rewrite(
            question="数据库中有多少位艺术家？",
            sql="SELECT nonexistent FROM artists",
            error="字段 nonexistent 不存在",
            schema_overview="artists(id, name)",
        )
    except Exception as exc:
        print(f"SQL 改写演示失败：{exc}")
        return

    print(f"修复后的 SQL：{result.sql}")
    print(f"修改说明：{result.explanation or '无'}")


if __name__ == "__main__":
    main()
