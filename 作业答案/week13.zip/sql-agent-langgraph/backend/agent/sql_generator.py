"""SQL 生成 Agent。

结合用户问题与相关表 Schema，生成一条只读 SQLite SQL。
"""

from __future__ import annotations

from ..prompt import render_prompt
from ..schemas import SQLGeneration
from ..utils import normalize_sql, require_text
from .base import BaseAgent


class SQLGeneratorAgent(BaseAgent):
    """根据自然语言问题生成候选 SQL。"""

    default_system_prompt = render_prompt("sql_generator_system.j2")

    def generate(
        self,
        question: str,
        schema_overview: str,
        *,
        dialect: str = "SQLite",
        hints: str | None = None,
    ) -> SQLGeneration:
        """生成候选 SQL。

        Args:
            question: 用户的自然语言问题。
            schema_overview: 相关表的 Schema，建议包含字段类型、主外键。
            dialect: SQL 方言，默认为 SQLite。
            hints: 可选的额外约束，例如必须使用的过滤条件或排序规则。

        Raises:
            ValueError: 必填输入为空或模型返回空 SQL。
        """

        question = require_text(question, "question")
        schema_overview = require_text(schema_overview, "schema_overview")
        dialect = require_text(dialect, "dialect")

        prompt = render_prompt(
            "sql_generator_user.j2",
            dialect=dialect,
            schema_overview=schema_overview,
            question=question,
            hints=hints.strip() if hints and hints.strip() else None,
        )

        generation = self.invoke_structured(prompt, SQLGeneration)
        return generation.model_copy(update={"sql": normalize_sql(generation.sql)})


def main() -> None:
    """演示根据自然语言问题与 Schema 生成只读 SQL。"""

    try:
        agent = SQLGeneratorAgent()
        result = agent.generate(
            "数据库中有多少位艺术家？",
            "artists(id, name)",
        )
    except Exception as exc:
        print(f"SQL 生成演示失败：{exc}")
        return

    print(f"生成的 SQL：{result.sql}")
    print(f"说明：{result.explanation or '无'}")


if __name__ == "__main__":
    main()
