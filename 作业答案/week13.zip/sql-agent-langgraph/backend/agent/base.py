"""Agent 基础设施。

`BaseAgent` 负责三件事：
1. 通过 `backend.config` 加载 Pydantic 配置对象；
2. 创建并持有一个 LangChain ChatModel；
3. 提供统一的同步/异步调用与文本提取接口。

数据结构定义在 `backend/schemas.py`，配置读取逻辑在 `backend/config.py`，
本模块不重复定义数据模型或环境变量解析。
子类通常只需要覆盖 `default_system_prompt`，或在此基础上增加自己的
Prompt、工具和业务节点逻辑。
"""

from __future__ import annotations

import json
from typing import Any, Sequence, TypeVar

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from pydantic import BaseModel

from ..config import load_llm_config
from ..schemas import LLMConfig

_PLACEHOLDER_MARKERS = ("your-api-key", "your_api_key", "replace-me", "changeme")

StructuredOutputT = TypeVar("StructuredOutputT", bound=BaseModel)


class BaseAgent:
    """所有 Agent 的基类：加载模型配置并封装模型调用。"""

    default_system_prompt = "你是一个严谨、可靠的 AI 助手。"

    def __init__(
        self,
        *,
        llm: BaseChatModel | None = None,
        config: LLMConfig | None = None,
        system_prompt: str | None = None,
    ) -> None:
        """初始化 Agent。

        Args:
            llm: 可注入自定义 ChatModel，便于测试或切换非 OpenAI 兼容模型。
            config: 显式传入的配置；不传时从 `.env` 加载。
            system_prompt: 系统提示词；不传时使用类属性
                `default_system_prompt`，传空字符串可禁用系统提示。
        """

        self.config = config or load_llm_config()
        self.system_prompt = (
            self.default_system_prompt if system_prompt is None else system_prompt
        )
        self.llm = llm if llm is not None else self._build_chat_model()

    @staticmethod
    def _has_valid_api_key(api_key: str) -> bool:
        """判断密钥是否已填写，且不是 `.env.example` 中的占位符。"""

        key = api_key.strip()
        if not key:
            return False
        lowered = key.lower()
        return not any(marker in lowered for marker in _PLACEHOLDER_MARKERS)

    def _build_chat_model(self) -> ChatOpenAI:
        """按当前配置创建 LangChain ChatModel。

        使用 `ChatOpenAI` 是为了兼容 OpenAI、DeepSeek、Ollama 等
        OpenAI 兼容接口；只需切换 `OPENAI_BASE_URL` 和 `MODEL_NAME`。
        """

        api_key = self.config.api_key.get_secret_value().strip()
        if not self._has_valid_api_key(api_key):
            raise ValueError(
                "未配置有效的 OPENAI_API_KEY，请在 .env 中填写真实密钥"
                "（可参考 .env.example）"
            )

        kwargs: dict[str, Any] = {
            "model": self.config.model_name,
            "api_key": api_key,
            "temperature": self.config.temperature,
            "timeout": self.config.timeout,
            "max_retries": self.config.max_retries,
        }
        if self.config.base_url:
            kwargs["base_url"] = self.config.base_url
        if self.config.max_tokens:
            kwargs["max_tokens"] = self.config.max_tokens

        try:
            return ChatOpenAI(**kwargs)
        except Exception as exc:
            raise ValueError(
                "初始化大模型失败"
                f"（model={self.config.model_name}，"
                f"base_url={self.config.base_url or 'default'}）：{exc}"
            ) from exc

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"model={self.config.model_name!r}, "
            f"base_url={self.config.base_url!r})"
        )

    def build_messages(
        self,
        prompt: str,
        history: Sequence[BaseMessage] | None = None,
    ) -> list[BaseMessage]:
        """把用户输入和历史消息组装成 LangChain 消息列表。"""

        if not prompt or not prompt.strip():
            raise ValueError("prompt 不能为空")

        messages: list[BaseMessage] = []
        if self.system_prompt.strip():
            messages.append(SystemMessage(content=self.system_prompt))
        if history:
            messages.extend(history)
        messages.append(HumanMessage(content=prompt))
        return messages

    def invoke_messages(
        self,
        messages: Sequence[BaseMessage],
        **kwargs: Any,
    ) -> AIMessage:
        """直接调用模型并返回原始消息对象，便于获取 token 用量等元数据。"""

        if not messages:
            raise ValueError("messages 不能为空")
        return self.llm.invoke(list(messages), **kwargs)

    def invoke(
        self,
        prompt: str,
        *,
        history: Sequence[BaseMessage] | None = None,
        **kwargs: Any,
    ) -> AIMessage:
        """发送一条用户消息，返回模型原始响应。"""

        return self.invoke_messages(self.build_messages(prompt, history), **kwargs)

    async def ainvoke(
        self,
        prompt: str,
        *,
        history: Sequence[BaseMessage] | None = None,
        **kwargs: Any,
    ) -> AIMessage:
        """`invoke` 的异步版本。"""

        return await self.llm.ainvoke(self.build_messages(prompt, history), **kwargs)

    def invoke_structured(
        self,
        prompt: str,
        schema: type[StructuredOutputT],
        *,
        history: Sequence[BaseMessage] | None = None,
        **kwargs: Any,
    ) -> StructuredOutputT:
        """调用模型并返回经过 Pydantic 校验的结构化结果。

        Args:
            prompt: 用户提示词。
            schema: 期望的 Pydantic 输出模型。
            history: 可选的历史消息。
            **kwargs: 透传给模型调用的参数。

        Raises:
            ValueError: prompt 为空或模型不支持结构化输出。
            RuntimeError: 模型返回的内容无法转换为目标模型。
        """

        return self.invoke_messages_structured(
            self.build_messages(prompt, history),
            schema,
            **kwargs,
        )

    def _structured_runnable(
        self,
        schema: type[StructuredOutputT],
    ) -> tuple[Any, str | None]:
        """按配置创建结构化输出 Runnable，并返回实际使用的方式。"""

        method = self.config.structured_output_method
        try:
            return self.llm.with_structured_output(schema, method=method), method
        except TypeError:
            # 兼容未实现 method 参数的自定义 ChatModel。
            return self.llm.with_structured_output(schema), None

    @staticmethod
    def _prepare_structured_messages(
        messages: Sequence[BaseMessage],
        schema: type[StructuredOutputT],
        method: str | None,
    ) -> list[BaseMessage]:
        """为 json_mode 补充 JSON Schema 指令，避免模型输出非 JSON 文本。"""

        prepared = list(messages)
        if method != "json_mode":
            return prepared

        schema_json = json.dumps(schema.model_json_schema(), ensure_ascii=False)
        instruction = (
            "请严格按下面的 JSON Schema 输出一个 JSON 对象，"
            "不要输出 Markdown 代码围栏、注释或任何额外说明。\n"
            f"JSON Schema：{schema_json}"
        )
        if (
            prepared
            and isinstance(prepared[0], SystemMessage)
            and isinstance(prepared[0].content, str)
        ):
            prepared[0] = SystemMessage(
                content=f"{prepared[0].content}\n\n{instruction}"
            )
        else:
            prepared.insert(0, SystemMessage(content=instruction))
        return prepared

    def invoke_messages_structured(
        self,
        messages: Sequence[BaseMessage],
        schema: type[StructuredOutputT],
        **kwargs: Any,
    ) -> StructuredOutputT:
        """`invoke_structured` 的消息列表版本。"""

        if not messages:
            raise ValueError("messages 不能为空")
        try:
            runnable, method = self._structured_runnable(schema)
        except (AttributeError, NotImplementedError) as exc:
            raise ValueError(
                f"当前模型 {self.config.model_name!r} 不支持结构化输出，"
                "请更换支持工具调用或 JSON 输出的模型"
            ) from exc

        prepared = self._prepare_structured_messages(messages, schema, method)
        try:
            result = runnable.invoke(prepared, **kwargs)
        except Exception as exc:
            raise RuntimeError(
                f"模型 {self.config.model_name!r} 结构化输出调用失败"
                f"（method={method or 'default'}）：{exc}"
            ) from exc

        if not isinstance(result, schema):
            raise RuntimeError(
                f"模型 {self.config.model_name!r} 返回的结果不是预期的 "
                f"{schema.__name__} 结构：{type(result).__name__}"
            )
        return result

    async def ainvoke_structured(
        self,
        prompt: str,
        schema: type[StructuredOutputT],
        *,
        history: Sequence[BaseMessage] | None = None,
        **kwargs: Any,
    ) -> StructuredOutputT:
        """`invoke_structured` 的异步版本。"""

        if not prompt or not prompt.strip():
            raise ValueError("prompt 不能为空")
        try:
            runnable, method = self._structured_runnable(schema)
        except (AttributeError, NotImplementedError) as exc:
            raise ValueError(
                f"当前模型 {self.config.model_name!r} 不支持结构化输出，"
                "请更换支持工具调用或 JSON 输出的模型"
            ) from exc

        prepared = self._prepare_structured_messages(
            self.build_messages(prompt, history),
            schema,
            method,
        )
        try:
            result = await runnable.ainvoke(prepared, **kwargs)
        except Exception as exc:
            raise RuntimeError(
                f"模型 {self.config.model_name!r} 结构化输出调用失败"
                f"（method={method or 'default'}）：{exc}"
            ) from exc

        if not isinstance(result, schema):
            raise RuntimeError(
                f"模型 {self.config.model_name!r} 返回的结果不是预期的 "
                f"{schema.__name__} 结构：{type(result).__name__}"
            )
        return result

    @staticmethod
    def extract_text(message: BaseMessage) -> str:
        """兼容字符串和 content blocks 两种响应格式，提取纯文本。"""

        content = message.content
        if isinstance(content, str):
            return content.strip()

        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                text = block.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts).strip()

    def ask(self, prompt: str, **kwargs: Any) -> str:
        """调用模型并直接返回文本答案，适合普通问答场景。"""

        text = self.extract_text(self.invoke(prompt, **kwargs))
        if not text:
            raise RuntimeError("大模型返回了空响应")
        return text

    async def aask(self, prompt: str, **kwargs: Any) -> str:
        """`ask` 的异步版本。"""

        text = self.extract_text(await self.ainvoke(prompt, **kwargs))
        if not text:
            raise RuntimeError("大模型返回了空响应")
        return text


def main() -> None:
    """演示 BaseAgent 的基础同步调用。"""

    try:
        agent = BaseAgent(system_prompt="你是一个简洁的助手，请用一句话回答。")
        answer = agent.ask("请介绍机器学习。")
    except Exception as exc:
        print(f"BaseAgent 演示失败：{exc}")
        return

    print(f"模型: {agent.config.model_name}")
    print(f"回答: {answer}")


if __name__ == "__main__":
    main()
