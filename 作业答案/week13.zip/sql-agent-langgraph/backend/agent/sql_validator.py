"""SQL 校验 Agent。

从安全、语法、Schema 引用和业务语义四个角度审核候选 SQL。
本 Agent 的结论只用于工作流路由，不能替代执行层的只读安全校验。
"""

from __future__ import annotations

from ..prompt import render_prompt
from ..schemas import SQLValidation
from ..utils import require_text
from .base import BaseAgent


class SQLValidatorAgent(BaseAgent):
    """审核候选 SQL 是否可安全执行并能回答用户问题。"""

    default_system_prompt = render_prompt("sql_validator_system.j2")

    def validate(
        self,
        question: str,
        sql: str,
        schema_overview: str,
        *,
        dialect: str = "SQLite",
    ) -> SQLValidation:
        """校验候选 SQL。

        Args:
            question: 用户的原始问题，用于判断查询语义是否匹配。
            sql: 待校验的 SQL。
            schema_overview: 相关表的 Schema。
            dialect: SQL 方言，默认为 SQLite。

        Raises:
            ValueError: 必填输入为空。
        """

        question = require_text(question, "question")
        sql = require_text(sql, "sql")
        schema_overview = require_text(schema_overview, "schema_overview")
        dialect = require_text(dialect, "dialect")

        prompt = render_prompt(
            "sql_validator_user.j2",
            dialect=dialect,
            schema_overview=schema_overview,
            question=question,
            sql=sql,
        )

        return self.invoke_structured(prompt, SQLValidation)


def main() -> None:
    """演示从安全性、语法和语义角度审核候选 SQL。"""

    try:
        agent = SQLValidatorAgent()
        result = agent.validate(
            "数据库中有多少位艺术家？",
            "SELECT nonexistent FROM artists",
            "artists(id, name)",
        )
    except Exception as exc:
        print(f"SQL 校验演示失败：{exc}")
        return

    print(f"是否通过：{result.is_valid}")
    print(f"错误说明：{result.error or '无'}")


if __name__ == "__main__":
    main()
