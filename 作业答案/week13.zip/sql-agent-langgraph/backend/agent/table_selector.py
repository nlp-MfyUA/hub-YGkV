"""表选择 Agent。

根据用户问题与数据库 Schema 概览，筛选回答问题所需的最小表集合，
并保留跨表查询所必需的关联表。
"""

from __future__ import annotations

from collections.abc import Iterable

from ..prompt import render_prompt
from ..schemas import TableSelection
from ..utils import require_text
from .base import BaseAgent


class TableSelectorAgent(BaseAgent):
    """从完整 Schema 中选出与问题相关的表。"""

    default_system_prompt = render_prompt("table_selector_system.j2")

    def select(
        self,
        question: str,
        schema_overview: str,
        *,
        available_tables: Iterable[str] | None = None,
    ) -> TableSelection:
        """选择与问题相关的数据表。

        Args:
            question: 用户的自然语言问题。
            schema_overview: 数据库 Schema 概览，建议包含表名、字段、主外键。
            available_tables: 可选的真实表名列表；传入时会校验模型输出并
                统一为列表中的规范写法，防止模型返回不存在的表。

        Raises:
            ValueError: 输入为空，或可用表列表为空。
            RuntimeError: 模型选择了不存在的表。
        """

        question = require_text(question, "question")
        schema_overview = require_text(schema_overview, "schema_overview")

        canonical: dict[str, str] | None = None
        available_text = "未提供，请仅依据 Schema 概览中的表名"
        if available_tables is not None:
            names = [name.strip() for name in available_tables if name.strip()]
            if not names:
                raise ValueError("available_tables 不能为空")
            canonical = {name.casefold(): name for name in names}
            available_text = "、".join(names)

        prompt = render_prompt(
            "table_selector_user.j2",
            available_text=available_text,
            schema_overview=schema_overview,
            question=question,
        )

        selection = self.invoke_structured(prompt, TableSelection)

        if canonical is None:
            return selection

        unknown = [
            name for name in selection.selected_tables if name.casefold() not in canonical
        ]
        if unknown:
            raise RuntimeError(
                "表选择模型返回了不存在的表："
                + "、".join(unknown)
                + "；可用表为："
                + "、".join(canonical.values())
            )

        normalized = [canonical[name.casefold()] for name in selection.selected_tables]
        return selection.model_copy(update={"selected_tables": normalized})


def main() -> None:
    """演示根据问题与 Schema 选择需要查询的数据表。"""

    try:
        agent = TableSelectorAgent()
        result = agent.select(
            "AC/DC 乐队有多少首歌曲？",
            "artists(id, name)；albums(id, artist_id, title)；"
            "tracks(id, album_id, name)",
            available_tables=["artists", "albums", "tracks"],
        )
    except Exception as exc:
        print(f"表选择演示失败：{exc}")
        return

    print(f"已选表：{'、'.join(result.selected_tables)}")
    print(f"选择理由：{result.reasoning or '无'}")


if __name__ == "__main__":
    main()
