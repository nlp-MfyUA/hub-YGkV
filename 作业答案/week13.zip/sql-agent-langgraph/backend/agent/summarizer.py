"""结果汇总 Agent。

严格依据真实查询结果生成自然语言答案；空结果视为成功查询，不触发重试。
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from ..prompt import render_prompt
from ..schemas import QuerySummary
from ..utils import format_rows, require_text
from .base import BaseAgent

_NO_ROWS_ANSWER = "未查询到匹配记录。"


class ResultSummarizerAgent(BaseAgent):
    """把 SQL 执行结果整理成用户可读的中文答案。"""

    default_system_prompt = render_prompt("summarizer_system.j2")

    def summarize(
        self,
        question: str,
        sql: str,
        rows: Sequence[Mapping[str, Any]] | Sequence[Sequence[Any]] | str | None = None,
        *,
        max_rows: int = 50,
    ) -> str:
        """汇总查询结果。

        Args:
            question: 用户的原始问题。
            sql: 实际执行的 SQL。
            rows: 查询结果，可以是字典列表、元组列表，或已格式化的文本；
                为空或 `None` 表示查询成功但返回零行。
            max_rows: 最多展示给模型的行数，避免上下文过长。

        Raises:
            ValueError: 问题或 SQL 为空，或 `max_rows` 非法。
        """

        question = require_text(question, "question")
        sql = require_text(sql, "sql")

        if rows is None or (isinstance(rows, str) and not rows.strip()):
            return _NO_ROWS_ANSWER

        if isinstance(rows, str):
            result_text = rows.strip()
            row_count = None
        else:
            row_list = list(rows)
            if not row_list:
                return _NO_ROWS_ANSWER
            result_text = format_rows(row_list, max_rows=max_rows)
            row_count = len(row_list)

        prompt = render_prompt(
            "summarizer_user.j2",
            question=question,
            sql=sql,
            result_text=result_text,
            row_count=row_count,
        )

        summary = self.invoke_structured(prompt, QuerySummary)
        return summary.answer


def main() -> None:
    """演示依据真实查询结果生成中文答案。"""

    try:
        agent = ResultSummarizerAgent()
        answer = agent.summarize(
            question="数据库中有多少位艺术家？",
            sql="SELECT COUNT(*) AS total FROM artists",
            rows=[{"total": 275}],
        )
    except Exception as exc:
        print(f"结果汇总演示失败：{exc}")
        return

    print(f"汇总答案：{answer}")


if __name__ == "__main__":
    main()
