# SQL Agent：基于 LangGraph 的 Chinook 数据库智能查询系统

## 1. 项目简介

本项目基于 **LangGraph + LLM + SQLite**，面向 `chinook.db` 构建一个可以用自然语言查询数据库的 SQL Agent。

用户输入中文或英文问题后，Agent 自动解析数据库结构、选择相关数据表、生成 SQL、进行安全与正确性校验、在必要时改写 SQL、执行查询，并将查询结果整理成自然语言答案。

与一次性生成 SQL 的简单方案不同，本项目通过 LangGraph 的 **State（状态）**、**Node（节点）** 和 **Conditional Edge（条件路由）** 构建可追踪、可纠错的工作流。

### 核心功能

- **数据库解析**：读取表名、字段、主键、外键及相关 Schema 信息。
- **Table 选择**：根据用户问题筛选相关表，识别跨表关联路径。
- **SQL 生成**：结合用户问题和 Schema 生成 SQLite SQL。
- **SQL 校验**：检查只读安全性、语法、表字段引用及查询语义。
- **SQL 改写**：依据校验错误或数据库执行异常自动修复 SQL。
- **SQL 执行**：通过受限的 SQLite 只读连接执行查询。
- **结果汇总**：基于真实查询结果生成用户可读的答案。

## 2. 技术栈

| 技术 | 用途 |
| --- | --- |
| Python 3.10+ | 项目开发语言（建议版本） |
| LangGraph | 工作流编排、状态管理与条件路由 |
| LangChain | LLM 调用、Prompt 组织及数据库工具封装 |
| SQLite | 数据库引擎 |
| Chinook | 音乐商店示例数据库 |
| SQLGlot（推荐） | SQL 解析与静态检查 |
| Pydantic（推荐） | LLM 结构化输出校验 |
| FastAPI | 后端 SSE 流式接口 |
| Node.js + Next.js | 独立的 Web 前端（`frontend/`） |

## 3. 工作流设计

```mermaid
flowchart TD
    A([用户提问]) --> B[数据库解析]
    B --> C[Table 选择]
    C --> D[SQL 生成]
    D --> E[SQL 校验]
    E --> F{校验通过?}
    F -- 是 --> G[SQL 执行]
    F -- 否 --> H{达到最大重试次数?}
    G --> I{执行成功?}
    I -- 是 --> J[结果汇总]
    I -- 否 --> H
    H -- 否 --> K[SQL 改写]
    K --> E
    H -- 是 --> L[失败结果说明]
    J --> M([最终答案])
    L --> M
```

### 节点职责

| 节点 | 输入 | 主要输出 |
| --- | --- | --- |
| `parse_database` | 数据库连接信息 | `all_tables`、Schema 概览 |
| `select_tables` | 用户问题、Schema 概览 | `selected_tables`、相关 Schema |
| `generate_sql` | 问题、相关 Schema | `sql` |
| `validate_sql` | `sql`、Schema、问题 | `is_valid`、`error` |
| `rewrite_sql` | 原 SQL、错误反馈、Schema | 修复后的 `sql`、`retry_count` |
| `execute_sql` | 校验通过的 SQL | `query_result` 或 `error` |
| `summarize_result` | 问题、SQL、真实查询结果 | `final_answer` |

> SQL 改写不是必经步骤：只有校验或执行失败时才进入改写节点。改写后必须重新校验。

## 4. 重试机制（默认 10 次，可配置）

SQL 修复共用一个重试计数器，适用于**校验失败**和**执行失败**两个场景。

- `max_retries`：最大 SQL 改写次数，**默认 `10`**，允许用户自定义。
- `retry_count`：实际已执行的 SQL 改写次数，初始为 `0`。
- 只有进入 `rewrite_sql` 并发起改写时，`retry_count` 才增加 `1`。
- 每次改写后重新经过 `validate_sql`；校验通过后才能执行。
- 达到重试上限时停止修复，返回可理解的失败说明与最后一次错误信息。
- **空结果不等于执行失败**：SQL 正常执行但返回零行，应正常汇总为“未查询到匹配记录”。

按上述定义，默认情况下最多允许 **1 次初始 SQL 生成 + 10 次 SQL 改写**。

重试次数可在初始 State 或配置层设置：

```python
initial_state = {
    "question": "销售额最高的五位艺术家是谁？",
    "retry_count": 0,
    "max_retries": 10,  # 可改为 3、5、20 等
}

result = graph.invoke(
    initial_state,
    config={"recursion_limit": 100},
)
```

**注意**：LangGraph 的 `recursion_limit` 限制的是图执行步数，**不是** SQL 改写次数。应为多节点循环预留足够的执行步数。

## 5. State 设计

工作流状态使用 `TypedDict`（实现见 `backend/graph/state.py`），各节点只返回需要更新的字段：

```python
from typing import Literal, TypedDict

from backend.schemas import QueryResult

class AgentState(TypedDict, total=False):
    question: str
    thread_id: str            # 区分 SqliteSaver 历史检查点
    all_tables: list[str]
    full_schema: str          # 全部表概览，仅表选择节点使用
    selected_tables: list[str]
    schema: str               # 已选表概览，供生成/校验/改写使用

    sql: str
    is_valid: bool
    error: str | None
    query_result: QueryResult | None

    retry_count: int
    max_retries: int
    final_answer: str
    status: Literal["running", "success", "failed"]
    fatal_error: bool         # 数据库或模型不可用等不可恢复错误
```

各节点仅返回需要更新的字段。每次改写 SQL 时需清除或重置前一个 SQL 的校验状态，防止错误复用。

## 6. 推荐项目结构

下面是当前实现采用的目录结构：

```text
sql-agent-langgraph/
├── README.md
├── requirements.txt
├── .env.example
├── asserts/
│   ├── chinook.db
│   └── sql_agent_memory.db # SqliteSaver 历史检查点（运行时生成，不提交）
├── backend/
│   ├── __init__.py
│   ├── main.py             # CLI 入口
│   ├── config.py           # 模型、数据库与工作流配置
│   ├── schemas.py          # Pydantic 数据模型
│   ├── utils.py            # SQL 清理与结果格式化
│   ├── workflow.py         # 图定义、条件路由、SqliteSaver 记忆与运行入口
│   ├── api.py              # FastAPI 服务（SSE 流式 + 历史接口）
│   ├── presentation.py     # CLI 与 Web 共用的展示格式
│   ├── graph/
│   │   ├── __init__.py
│   │   ├── state.py        # AgentState 与初始状态
│   │   ├── tools.py        # 图使用的 Schema / 只读校验 / 执行工具
│   │   └── nodes.py        # 节点函数，节点内部调用专用 Agent
│   ├── agent/
│   │   ├── base.py
│   │   ├── table_selector.py
│   │   ├── sql_generator.py
│   │   ├── sql_validator.py
│   │   ├── sql_rewriter.py
│   │   └── summarizer.py
│   ├── tools/
│   │   ├── database.py     # SQLite 只读连接与 Schema 读取
│   │   └── sql.py          # SQL 结构安全校验
│   └── prompt/             # Jinja2 提示词模板
├── frontend/               # 独立 Next.js 前端
│   ├── app/                # 页面与全局样式
│   ├── components/         # 步骤、答案、历史组件
│   ├── lib/                # API 客户端与类型
│   ├── package.json
│   └── .env.local.example  # NEXT_PUBLIC_API_BASE
```

`nodes.py` 只负责调用 Agent 和更新状态，`tools.py` 封装数据库访问，
`workflow.py` 只负责组装节点与条件边，便于分别替换和调试。
前端与后端同级、独立启动，通过 FastAPI 的 SSE 接口实时获取节点结果。

## 7. 环境准备与运行（推荐约定）

> 以下命令与当前实现一致，可直接运行。

### 7.1 创建虚拟环境

```bash
python -m venv .venv

# macOS / Linux
source .venv/bin/activate

# Windows PowerShell
# .venv\Scripts\Activate.ps1
```

### 7.2 安装依赖

在项目中建立 `requirements.txt`，按所选 LLM 提供商配置相应集成包。例如：

```text
langgraph
langgraph-checkpoint-sqlite
langchain
langchain-openai
python-dotenv
pydantic
jinja2
fastapi
uvicorn[standard]
fastapi
uvicorn
```

然后执行：

```bash
pip install -r requirements.txt
```

### 7.3 准备数据库

Chinook SQLite 数据库已放在：

```text
asserts/chinook.db
```

> 目录名是 `asserts`（不是 `assets`），与 `.env` 中的 `DATABASE_PATH` 保持一致。

数据库结构通常包括 `artists`、`albums`、`tracks`、`customers`、`invoices`、`invoice_items` 等表，实际表结构以本地 `chinook.db` 为准。

### 7.4 配置模型

复制环境变量模板并填写真实值（不要提交 `.env` 或密钥）：

```bash
cp .env.example .env
```

所有可用变量及说明见 `.env.example`，至少需要配置：

```dotenv
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://api.openai.com/v1
MODEL_NAME=your_model_name
DATABASE_PATH=asserts/chinook.db
SQL_AGENT_MAX_RETRIES=10
```

`OPENAI_BASE_URL` 可指向任意 OpenAI 兼容服务（如 DeepSeek、Ollama），代码中应显式传给模型的 `base_url` 参数。

### 7.5 启动（CLI）

CLI 默认逐节点输出中间结果，最后再输出最终答案：

```bash
python -m backend.main --question "数据库中有多少位艺术家？"
```

输出示例：

```text
[parse_database] 读取 11 张表
[select_tables] 已选表：artists
[generate_sql] SELECT COUNT(*) AS artist_count FROM artists
[validate_sql] 通过
[execute_sql] 返回 1 行，耗时 4.4 ms
  首行：[{"artist_count": 275}]
[summarize_result] 已生成最终回答

回答：数据库中共有 275 位艺术家。
```

其他参数：

```bash
# 只输出最终答案
python -m backend.main --question "数据库中有多少位艺术家？" --no-trace

# 覆盖默认重试次数，并输出实际执行的 SQL
python -m backend.main --question "销售额最高的五位艺术家是谁？" --max-retries 5 --show-sql

# 覆盖 LangGraph 执行步数上限
python -m backend.main --question "哪种音乐类型的歌曲最多？" --recursion-limit 120

# 指定历史检查点的会话标识
python -m backend.main --question "数据库中有多少位艺术家？" --thread-id demo
```

也可以在 Python 中逐节点消费中间结果：

```python
from backend.workflow import stream_workflow

for step in stream_workflow("数据库中有多少位艺术家？"):
    print(step.node, step.update)
```

或者使用回调获取最终状态：

```python
from backend.workflow import run_workflow

result = run_workflow(
    "数据库中有多少位艺术家？",
    max_retries=5,
    on_step=lambda step: print(step.node, step.update),
)
print(result["final_answer"])
```

### 7.6 历史记忆（SqliteSaver）

工作流使用 `langgraph-checkpoint-sqlite` 的 `SqliteSaver`，在每个节点执行后自动把状态写入独立的 SQLite 文件，无需手动保存。

- 默认路径：`asserts/sql_agent_memory.db`
- 可通过 `MEMORY_DATABASE_PATH` 修改
- 与只读的 `asserts/chinook.db` 完全分离，不会向业务数据库写入任何内容
- `thread_id` 用于区分检查点序列，默认 `default`
- 历史记录不会注入 Prompt，因此**不支持多轮对话**，每次查询仍然独立

查看检查点：

```bash
sqlite3 asserts/sql_agent_memory.db \
  "SELECT thread_id, COUNT(*) FROM checkpoints GROUP BY thread_id;"
```

也可以直接通过 CLI 查看历史运行结果：

```bash
# 查看默认会话最近 10 条
python -m backend.main --show-history

# 查看指定会话最近 5 条
python -m backend.main --show-history 5 --thread-id demo
```

Python 中读取：

```python
from backend.workflow import load_history

for entry in load_history("default", limit=5):
    print(entry.created_at, entry.status, entry.question)
    print(entry.final_answer)
```

> `*.db` 记忆文件不应提交到 Git，已加入 `.gitignore`。

### 7.7 启动 Web 服务（FastAPI + Next.js）

后端（默认 `http://127.0.0.1:8000`）：

```bash
pip install -r requirements.txt
python -m backend.api
```

前端（独立目录，默认 `http://localhost:3000`）：

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

页面支持：

- 输入自然语言问题并实时查看每个 LangGraph 节点结果；
- 查看最终答案、SQL、改写次数与查询结果；
- 按会话标识查看历史执行记录。

主要接口：

| 接口 | 说明 |
| --- | --- |
| `POST /api/query` | SSE 流式执行查询，逐节点返回结果 |
| `GET /api/history` | 按 `thread_id` 读取历史执行记录 |
| `GET /api/health` | 健康检查 |
| `GET /docs` | FastAPI 自动接口文档 |

前端通过 `NEXT_PUBLIC_API_BASE` 指定后端地址；后端默认允许 `localhost:3000` 和 `127.0.0.1:3000` 的 CORS 请求。

## 8. 测试用例与验收标准

| 场景 | 示例输入 | 期望行为 |
| --- | --- | --- |
| 单表查询 | 数据库中有多少位艺术家？ | 生成 COUNT 查询并返回数量 |
| 多表 JOIN | AC/DC 乐队有多少首歌曲？ | 正确关联 Artist、Album、Track |
| 分组聚合 | 哪种音乐类型的歌曲最多？ | GROUP BY、COUNT、排序正确 |
| 多表销售统计 | 销售额最高的五位艺术家是谁？ | 正确关联订单明细和曲目等表，按销售收入排序 |
| SQL 校验失败 | 注入不存在的字段名 | 发现错误并触发 SQL 改写 |
| SQL 执行失败 | 人为制造可修复的查询错误 | 收集数据库报错并重新校验、执行 |
| 空查询结果 | 查询一个不存在的歌曲名 | 正常告知未找到结果，不触发无意义重试 |
| 重试上限 | 连续制造不可修复错误 | 至多改写 `max_retries` 次并终止 |
| 安全测试 | 删除所有客户记录 | 拒绝非只读 SQL，不执行写操作 |

建议重点记录：SQL 生成成功率、最终查询正确率、平均改写次数、错误恢复成功率与安全测试通过率。

## 9. 技术难点

1. **Schema Linking**：从自然语言准确选表，并识别必要的关联表和主外键。
2. **复杂 Text-to-SQL**：正确处理 JOIN、GROUP BY、聚合、排序、过滤及 SQLite 语法。
3. **SQL 正确性校验**：区分语法正确、可执行和业务语义正确。
4. **错误恢复闭环**：利用错误反馈改写 SQL，并控制重试上限，避免死循环。
5. **状态一致性**：确保节点间的 SQL、校验状态、错误信息和重试计数同步更新。
6. **查询安全**：限制只读操作，防止危险 SQL、过量结果及长时间执行。

## 10. 安全与限制

- 数据库连接使用 **SQLite 只读模式**（如 `mode=ro`），并限制 SQL 为允许的只读查询语句。
- SQL 执行前做结构化安全校验，不能仅凭 Prompt 中“只生成 SELECT”保证安全。
- 对 SQL 设置执行时间、返回行数等资源限制，避免过慢或过量查询。
- LLM 仅负责生成与解释；最终答案必须以实际数据库执行结果为依据。
- 对无法修复的错误返回失败原因，不伪造查询结果。
- 开发过程中建议记录节点输入输出和重试路径，必要时接入 LangSmith。

## 11. 参考文档

- [LangGraph 官方 SQL Agent 教程](https://docs.langchain.com/oss/python/langgraph/sql-agent)
- [LangGraph Graph API](https://docs.langchain.com/oss/python/langgraph/graph-api)
- [SQLGlot](https://github.com/tobymao/sqlglot)
- [Chinook 数据库](https://github.com/lerocha/chinook-database)

---

**作业目标**：以 LangGraph 为核心，实现一个具备数据库解析、表选择、SQL 生成、校验、改写、执行和结果汇总能力，且支持可配置错误重试的完整 SQL Agent。
