"""第 6 章：Streams 消费者组、ACK 与 XAUTOCLAIM 故障恢复。"""
import redis

from redis_common import Lab, connect_local


def demo(lab: Lab) -> None:
    r = lab.r
    stream = lab.key("agent:stream:tasks")
    group = "agent-workers"

    try:
        r.xgroup_create(stream, group, id="0-0", mkstream=True)
    except redis.exceptions.ResponseError as exc:
        if "BUSYGROUP" not in str(exc):
            raise

    print("\n[生产任务]")
    for i in range(1, 4):
        msg_id = r.xadd(stream, {"task_id": f"stream-task-{i}",
                                 "task_type": "summarize", "input": f"待摘要文档 {i}"},
                        maxlen=100, approximate=True)
        print("XADD:", msg_id)

    print("\n[Worker-1 消费；只确认第一条，模拟宕机]")
    batches = r.xreadgroup(group, "worker-1", {stream: ">"}, count=3, block=1000)
    for stream_name, messages in batches:
        for idx, (msg_id, fields) in enumerate(messages):
            print("收到:", msg_id, fields)
            if idx == 0:
                r.xack(stream_name, group, msg_id)
                print(" -> XACK 成功")
            else:
                print(" -> 未 ACK，消息进入 Pending")

    print("Pending:", r.xpending(stream, group))
    print("\n[故障恢复：XAUTOCLAIM 重新认领]")
    # 教学目的设置 min_idle_time=0；生产环境须设置合理超时防止抢占正常任务。
    recovered = r.xautoclaim(stream, group, "worker-recovery",
                              min_idle_time=0, start_id="0-0", count=20)
    for msg_id, fields in recovered[1]:
        print("重新认领:", msg_id, fields)
        # 此处可调用真正的 Agent；确认处理成功后才 ACK。
        r.xack(stream, group, msg_id)
    print("恢复后 Pending:", r.xpending(stream, group))
    # Streams 可能重复投递；正式业务应使用 task_id 做幂等处理。


if __name__ == "__main__":
    demo(connect_local())
