"""依次运行全部 Redis 基础与 Agent 示例，共用同一个本次实验前缀。"""
from redis_common import connect_local
import basic_types
import session_memory
import task_state
import tool_cache
import rate_limit
import streams_queue
import pubsub_notifications
import distributed_lock
import long_term_memory
import mini_agent
from inspect_cleanup import inspect_keys


def main() -> None:
    lab = connect_local()
    steps = [
        ("Redis 基础数据类型", basic_types.demo),
        ("短期会话记忆", session_memory.demo),
        ("Agent 任务状态", task_state.demo),
        ("工具调用缓存", tool_cache.demo),
        ("固定窗口限流", rate_limit.demo),
        ("Streams 任务队列", streams_queue.demo),
        ("Pub/Sub 通知", pubsub_notifications.demo),
        ("分布式锁", distributed_lock.demo),
        ("长期偏好记忆", long_term_memory.demo),
        ("端到端迷你 Agent", mini_agent.demo),
    ]
    for idx, (name, func) in enumerate(steps, 1):
        print("\n" + "=" * 55)
        print(f"[{idx}/{len(steps)}] {name}")
        print("=" * 55)
        func(lab)
    print("\n所有示例完成。实验键列表：")
    inspect_keys(lab)
    print(f"\n清理本次数据：python inspect_cleanup.py --run-id {lab.run_id} --confirm")


if __name__ == "__main__":
    main()
