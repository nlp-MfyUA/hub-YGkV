"""查看/按确认删除指定实验前缀下的键；绝不执行 FLUSHDB 或 FLUSHALL。"""
import argparse
import os

from redis_common import Lab, connect_local


def inspect_keys(lab: Lab, max_display: int = 30) -> list[str]:
    found = sorted(lab.r.scan_iter(match=lab.key("*"), count=100))
    print(f"命名空间 {lab.prefix} 下共有 {len(found)} 个键")
    for name in found[:max_display]:
        print(" -", name)
    if len(found) > max_display:
        print(f"...省略 {len(found) - max_display} 个键")
    return found


def cleanup(lab: Lab, confirm: bool = False) -> int:
    keys = inspect_keys(lab)
    if not confirm:
        print("仅查看，未删除。若确定删除，指定 --confirm")
        return 0
    count = 0
    # 只删除本次前缀的键，不删除数据库中的其他数据。
    for start in range(0, len(keys), 100):
        count += lab.r.delete(*keys[start:start + 100])
    print(f"已删除 {count} 个实验键（仅匹配 {lab.prefix}）。")
    return count


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="查看/删除指定 Redis 实验数据")
    parser.add_argument("--run-id", help="此前运行输出的 RUN_ID，例如 a1b2c3d4e5")
    parser.add_argument("--confirm", action="store_true", help="确认删除此 RUN_ID 下的实验数据")
    args = parser.parse_args()
    if args.run_id:
        os.environ["REDIS_RUN_ID"] = args.run_id
    elif not os.getenv("REDIS_RUN_ID"):
        parser.error("须通过 --run-id 或 REDIS_RUN_ID 指定目标，避免清理无关数据")
    cleanup(connect_local(), confirm=args.confirm)
