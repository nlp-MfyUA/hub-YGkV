"""第 5 章：Agent/API 固定窗口限流（Lua 原子执行）。"""
from uuid import uuid4

from redis_common import Lab, connect_local


RATE_LIMIT_LUA = """
local n = redis.call('INCR', KEYS[1])
if n == 1 then
  redis.call('EXPIRE', KEYS[1], tonumber(ARGV[1]))
end
return n
"""


def allow_request(lab: Lab, user_id: str, limit: int = 3, window_seconds: int = 60) -> dict:
    counter_key = lab.key(f"agent:ratelimit:{user_id}")
    count = int(lab.r.eval(RATE_LIMIT_LUA, 1, counter_key, window_seconds))
    return {"allowed": count <= limit, "count": count, "limit": limit, "ttl": lab.r.ttl(counter_key)}


def demo(lab: Lab) -> None:
    demo_user = "demo-rate-" + uuid4().hex[:8]
    for i in range(5):
        print(f"第 {i + 1} 次请求:", allow_request(lab, demo_user, limit=3))
    # 固定窗口仅供基础教学；高精度限流可使用滑动窗口或令牌桶。


if __name__ == "__main__":
    demo(connect_local())
