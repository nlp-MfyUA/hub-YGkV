"""第 8 章：redis-py 分布式锁，模拟两个 Worker 争抢资源。"""
from redis_common import Lab, connect_local


def demo(lab: Lab) -> None:
    lock_name = lab.key("agent:lock:resource-A")
    worker_a = lab.r.lock(lock_name, timeout=10, blocking_timeout=1)
    worker_b = lab.r.lock(lock_name, timeout=10, blocking_timeout=0)

    with worker_a:
        print("Worker A：成功获得锁")
        acquired_b = worker_b.acquire(blocking=False)
        print("Worker B 能否同时获得锁：", acquired_b)
        if acquired_b:
            worker_b.release()
    print("锁释放后是否仍存在：", bool(lab.r.exists(lock_name)))
    # 注意锁租约过期、续期和 fencing token；勿以此保证所有业务只执行一次。


if __name__ == "__main__":
    demo(connect_local())
