"""第 1 章：String、Hash、List、Set、Sorted Set、TTL、Pipeline。"""
import json

from redis_common import Lab, as_json, connect_local


def demo(lab: Lab) -> None:
    r, key = lab.r, lab.key
    print("\n[1] String + TTL + 原子计数")
    r.set(key("basic:hello"), "你好，Redis")
    print("GET:", r.get(key("basic:hello")))
    r.set(key("basic:api_result"), as_json({"status": "ok", "count": 3}), ex=120)
    print("TTL:", r.ttl(key("basic:api_result")), "秒")
    print("缓存数据:", json.loads(r.get(key("basic:api_result"))))
    for _ in range(3):
        r.incr(key("basic:counter"))
    print("计数器:", r.get(key("basic:counter")))

    print("\n[2] Hash：任务元数据")
    job_key = key("basic:task:001")
    r.hset(job_key, mapping={"task_id": "001", "status": "running", "step": "search", "progress": 20})
    r.hset(job_key, "step", "summarize")
    r.hincrby(job_key, "progress", 30)
    print("Hash:", r.hgetall(job_key))

    print("\n[3] List：最近对话")
    chat_key = key("basic:messages")
    r.rpush(chat_key, "用户: 介绍 Redis", "助手: Redis 是内存数据存储系统", "用户: 如何用于 Agent?")
    print("全部:", r.lrange(chat_key, 0, -1))
    r.ltrim(chat_key, -2, -1)
    print("最近两条:", r.lrange(chat_key, 0, -1))

    print("\n[4] Set：去重")
    seen_key = key("basic:seen_docs")
    print("首次加入:", r.sadd(seen_key, "doc-A"))
    print("重复加入:", r.sadd(seen_key, "doc-A"))
    r.sadd(seen_key, "doc-B")
    print("是否见过 doc-A:", bool(r.sismember(seen_key, "doc-A")))
    print("集合:", sorted(r.smembers(seen_key)))

    print("\n[5] Sorted Set：任务优先级")
    prio_key = key("basic:priority")
    r.zadd(prio_key, {"task-A": 8, "task-B": 3, "task-C": 10})
    print("优先级降序:", r.zrevrange(prio_key, 0, -1, withscores=True))

    print("\n[6] Pipeline：减少网络往返")
    with r.pipeline(transaction=True) as pipe:
        pipe.set(key("basic:pipeline:state"), "running")
        pipe.incr(key("basic:pipeline:count"))
        pipe.expire(key("basic:pipeline:state"), 120)
        print("批量返回:", pipe.execute())
    print("状态:", r.get(key("basic:pipeline:state")))
    # 注意：Redis 的 MULTI/EXEC 不提供 SQL 事务式自动回滚。


if __name__ == "__main__":
    demo(connect_local())
