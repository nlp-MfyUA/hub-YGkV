"""第 7 章：Pub/Sub 多 Agent 实时通知（非持久化消息）。"""
import json

from redis_common import Lab, as_json, connect_local


def demo(lab: Lab) -> None:
    channel = lab.key("agent:notify")
    subscriber = lab.r.pubsub()
    try:
        subscriber.subscribe(channel)
        confirmed = False
        for _ in range(5):
            event = subscriber.get_message(timeout=1.0)
            if event and event.get("type") == "subscribe":
                confirmed = True
                break
        if not confirmed:
            raise RuntimeError("未收到 Pub/Sub 订阅确认")

        receivers = lab.r.publish(channel, as_json({"agent": "writer", "event": "draft_ready"}))
        print("在线订阅者数量:", receivers)
        message = subscriber.get_message(ignore_subscribe_messages=True, timeout=1.0)
        print("收到通知:", json.loads(message["data"]) if message else None)
    finally:
        subscriber.close()
    # 订阅者掉线期间发布的消息不保存；需要确认/恢复时使用 Streams。


if __name__ == "__main__":
    demo(connect_local())
