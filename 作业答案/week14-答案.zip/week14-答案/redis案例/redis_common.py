"""统一 Redis 连接、实验命名空间与 JSON 辅助函数。"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from uuid import uuid4

import redis


def as_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


@dataclass(frozen=True)
class Lab:
    r: redis.Redis
    run_id: str

    @property
    def prefix(self) -> str:
        return f"agentlab:{self.run_id}:"

    def key(self, name: str) -> str:
        return self.prefix + name


def connect_local() -> Lab:
    """默认连接 127.0.0.1:6379；支持通过环境变量覆盖。

    REDIS_RUN_ID 用于让多个独立的 Python 程序共享同一个实验键前缀。
    留空则每次新进程运行都创建不同的实验前缀。
    """
    host = os.getenv("REDIS_HOST", "127.0.0.1")
    port = int(os.getenv("REDIS_PORT", "6379"))
    db = int(os.getenv("REDIS_DB", "0"))
    password = os.getenv("REDIS_PASSWORD") or None
    run_id = os.getenv("REDIS_RUN_ID") or uuid4().hex[:10]
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", run_id):
        raise ValueError("REDIS_RUN_ID 只能使用 1–64 位英文、数字、下划线或连字符")

    client = redis.Redis(
        host=host,
        port=port,
        db=db,
        password=password,
        decode_responses=True,
        socket_connect_timeout=3,
        socket_timeout=5,
    )
    try:
        client.ping()
    except redis.exceptions.RedisError as exc:
        raise RuntimeError(
            f"无法连接 Redis {host}:{port}/db{db}。"
            "请先启动本地 Redis，并核对 REDIS_HOST / REDIS_PORT / REDIS_PASSWORD。"
        ) from exc

    lab = Lab(r=client, run_id=run_id)
    print(f"✅ Redis 已连接：{host}:{port} / db={db}")
    print(f"本次实验命名空间：{lab.prefix}")
    return lab
