"""第 9 章：用户授权的偏好记忆（Hash + Set 反向索引；非向量检索）。"""
from redis_common import Lab, connect_local


def demo(lab: Lab) -> None:
    user_id, memory_id = "demo-user-01", "memory-001"
    memory_key = lab.key(f"agent:memory:{user_id}:{memory_id}")
    lab.r.hset(memory_key, mapping={
        "content": "用户偏好简洁、带 Python 示例的技术讲解",
        "category": "answer_style",
        "source": "explicit_user_preference",  # 假设用户已明确同意保存
    })
    lab.r.sadd(lab.key(f"agent:memory-index:{user_id}:answer_style"), memory_id)

    index_key = lab.key(f"agent:memory-index:{user_id}:answer_style")
    for mid in sorted(lab.r.smembers(index_key)):
        print("找到偏好记忆：", lab.r.hgetall(lab.key(f"agent:memory:{user_id}:{mid}")))
    print("提示：这是标签索引，非 Embedding 语义检索。")


if __name__ == "__main__":
    demo(connect_local())
