"""第 4 章：Agent 工具结果缓存（String + TTL + SHA256 参数哈希）。"""
import hashlib
import json
from uuid import uuid4

from redis_common import Lab, as_json, connect_local


class ToolCache:
    def __init__(self, lab: Lab):
        self.lab = lab
        self.calls = 0

    def mock_search(self, query: str) -> dict:
        """模拟搜索：无网络请求，不需要 LLM API Key。"""
        self.calls += 1
        return {"query": query, "snippets": [f"【模拟资料】与「{query}」相关的示例内容"],
                "source": "mock-tool", "call_number": self.calls}

    def cached_search(self, query: str, tenant_id: str = "demo", ttl_seconds: int = 300) -> tuple[dict, str]:
        params = as_json({"tool": "mock_search", "tenant_id": tenant_id, "q": query.strip()})
        digest = hashlib.sha256(params.encode("utf-8")).hexdigest()
        cache_key = self.lab.key(f"agent:tool-cache:{digest}")
        cached = self.lab.r.get(cache_key)
        if cached is not None:
            return json.loads(cached), "HIT"
        value = self.mock_search(query)
        self.lab.r.set(cache_key, as_json(value), ex=ttl_seconds)
        return value, "MISS"


def demo(lab: Lab) -> None:
    cache = ToolCache(lab)
    demo_tenant = "demo-" + uuid4().hex[:8]  # 避免反复运行时碰到旧缓存
    for _ in range(2):
        value, status = cache.cached_search("Redis Agent 应用", tenant_id=demo_tenant)
        print(status, "| 实际工具调用次数:", cache.calls, "| 来源:", value["source"])
    assert cache.calls == 1, "缓存未按预期命中"
    # 生产环境应确认租户边界、缓存时效和并发缓存击穿处理。


if __name__ == "__main__":
    demo(connect_local())
