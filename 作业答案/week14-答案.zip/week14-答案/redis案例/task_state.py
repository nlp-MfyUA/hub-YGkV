"""第 3 章：Agent 任务状态与进度（Hash + TTL）。"""
from redis_common import Lab, connect_local


class TaskStore:
    def __init__(self, lab: Lab, ttl_seconds: int = 3600):
        self.lab = lab
        self.ttl_seconds = ttl_seconds

    def _key(self, task_id: str) -> str:
        return self.lab.key(f"agent:task:{task_id}")

    def create(self, task_id: str, name: str) -> None:
        self.lab.r.hset(self._key(task_id), mapping={
            "task_id": task_id, "name": name, "status": "pending",
            "step": "waiting", "progress": "0", "error": "",
        })
        self.lab.r.expire(self._key(task_id), self.ttl_seconds)

    def update(self, task_id: str, status: str, step: str, progress: int, error: str = "") -> None:
        self.lab.r.hset(self._key(task_id), mapping={
            "status": status, "step": step, "progress": str(progress), "error": error,
        })
        self.lab.r.expire(self._key(task_id), self.ttl_seconds)

    def get(self, task_id: str) -> dict | None:
        data = self.lab.r.hgetall(self._key(task_id))
        if not data:
            return None
        data["progress"] = int(data["progress"])
        return data


def demo(lab: Lab) -> None:
    store = TaskStore(lab)
    store.create("task-101", "生成技术综述")
    print("初始:", store.get("task-101"))
    store.update("task-101", "running", "retrieving_documents", 40)
    print("执行中:", store.get("task-101"))
    store.update("task-101", "completed", "done", 100)
    print("完成:", store.get("task-101"))
    # 重要：生产系统需要任务幂等性、合法状态转换及长期结果存储。


if __name__ == "__main__":
    demo(connect_local())
