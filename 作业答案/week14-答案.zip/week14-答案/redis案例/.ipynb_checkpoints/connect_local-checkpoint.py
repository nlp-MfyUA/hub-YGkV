"""第 0 章：连接本地 Redis，验证 PING。"""
from redis_common import connect_local


def demo(lab):
    print("PING:", lab.r.ping())
    print("Redis 服务器版本：", lab.r.info("server").get("redis_version", "unknown"))


if __name__ == "__main__":
    demo(connect_local())
