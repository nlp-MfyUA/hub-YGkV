"""第 10 章：端到端迷你 Agent：记忆 + 任务状态 + 工具缓存 + Stream 事件。"""
from uuid import uuid4

from redis_common import Lab, connect_local
from session_memory import SessionMemory
from task_state import TaskStore
from tool_cache import ToolCache


class DemoAgent:
    def __init__(self, lab: Lab):
        self.lab = lab
        self.memory = SessionMemory(lab)
        self.tasks = TaskStore(lab)
        self.tools = ToolCache(lab)
        self.event_stream = lab.key("agent:stream:events")

    @staticmethod
    def mock_generate_answer(question: str, tool_result: dict) -> str:
        """模拟 LLM 生成，不执行真实大模型调用。"""
        snippet = tool_result["snippets"][0]
        return f"【模拟 Agent 回答】针对「{question}」，我找到：{snippet}。"

    def run(self, session_id: str, question: str) -> dict:
        task_id = "agent-" + uuid4().hex[:8]
        self.tasks.create(task_id, f"处理用户问题：{question[:20]}")
        self.memory.append(session_id, "user", question)
        self.lab.r.xadd(self.event_stream, {"task_id": task_id, "event": "task_created"})
        try:
            self.tasks.update(task_id, "running", "tool_search", 30)
            result, cache_status = self.tools.cached_search(question, tenant_id=session_id)
            self.lab.r.xadd(self.event_stream, {
                "task_id": task_id, "event": "tool_finished", "cache": cache_status,
            })
            self.tasks.update(task_id, "running", "generate_answer", 80)
            answer = self.mock_generate_answer(question, result)
            self.memory.append(session_id, "assistant", answer)

            self.lab.r.set(self.lab.key(f"agent:result:{task_id}"), answer, ex=3600)
            self.tasks.update(task_id, "completed", "done", 100)
            self.lab.r.xadd(self.event_stream, {"task_id": task_id, "event": "task_completed"})
            return {"task_id": task_id, "answer": answer, "cache_status": cache_status}
        except Exception as exc:
            self.tasks.update(task_id, "failed", "error", 0, error=str(exc)[:300])
            self.lab.r.xadd(self.event_stream, {"task_id": task_id, "event": "task_failed"})
            raise


def demo(lab: Lab) -> None:
    agent = DemoAgent(lab)
    session = "demo-end-to-end-" + uuid4().hex[:8]
    first = agent.run(session, "Redis 在 Agent 系统中的作用")
    second = agent.run(session, "Redis 在 Agent 系统中的作用")
    print("首次工具缓存:", first["cache_status"])
    print("再次工具缓存:", second["cache_status"])
    print("模拟回答:", second["answer"])
    print("工具实际调用次数:", agent.tools.calls)
    print("会话消息数:", len(agent.memory.get_recent(session)))
    print("第二次任务状态:", agent.tasks.get(second["task_id"]))
    print("最近三个事件:", lab.r.xrevrange(agent.event_stream, count=3))
    assert second["cache_status"] == "HIT"
    assert agent.tasks.get(second["task_id"])["progress"] == 100
    print("说明：此案例展示的是 Agent 运行骨架，不依赖真实 LLM API Key。")


if __name__ == "__main__":
    demo(connect_local())
