"""第 2 章：Agent 多轮会话与短期记忆（List + JSON + TTL）。"""
import json
from datetime import datetime, timezone

from redis_common import Lab, as_json, connect_local


class SessionMemory:
    def __init__(self, lab: Lab, ttl_seconds: int = 1800, max_messages: int = 8):
        self.lab = lab
        self.ttl_seconds = ttl_seconds
        self.max_messages = max_messages

    def _key(self, session_id: str) -> str:
        return self.lab.key(f"agent:session:{session_id}:messages")

    def append(self, session_id: str, role: str, content: str) -> None:
        message = {"role": role, "content": content, "time": datetime.now(timezone.utc).isoformat()}
        with self.lab.r.pipeline(transaction=True) as pipe:
            pipe.rpush(self._key(session_id), as_json(message))
            pipe.ltrim(self._key(session_id), -self.max_messages, -1)
            pipe.expire(self._key(session_id), self.ttl_seconds)
            pipe.execute()

    def get_recent(self, session_id: str) -> list[dict]:
        return [json.loads(value) for value in self.lab.r.lrange(self._key(session_id), 0, -1)]


def demo(lab: Lab) -> None:
    store = SessionMemory(lab)
    sid = "demo-user-01"
    store.append(sid, "user", "请帮我安排周末读书计划")
    store.append(sid, "assistant", "周六读理论，周日做实践")
    store.append(sid, "user", "把周六安排改得轻松一点")
    for item in store.get_recent(sid):
        print(f"[{item['role']}] {item['content']}")
    print("会话剩余 TTL:", lab.r.ttl(store._key(sid)))
    print("说明：模型不会自动读取 Redis，调用模型前需把近期对话显式传入 Prompt。")


if __name__ == "__main__":
    demo(connect_local())
