# producer_async.py
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: v.encode('utf-8'),
)

def on_success(meta):
    print(f"成功: partition={meta.partition} offset={meta.offset}")

def on_error(exc):
    print("失败:", exc)

for i in range(10):
    producer.send('test-topic', value=f"async-{i}") \
            .add_callback(on_success) \
            .add_errback(on_error)

producer.flush()
print("全部发送完成")