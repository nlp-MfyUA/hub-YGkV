# manual_commit.py
from kafka import KafkaConsumer

consumer = KafkaConsumer(
    'test-topic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset='earliest',
    group_id='group1',
    enable_auto_commit=False,        # 关闭自动提交，手动控制
    consumer_timeout_ms=10000,
)

for record in consumer:
    value = record.value.decode()
    print(f"处理 offset={record.offset} value={value}")

    consumer.commit()                # 处理成功才提交
    print("  已提交 offset")