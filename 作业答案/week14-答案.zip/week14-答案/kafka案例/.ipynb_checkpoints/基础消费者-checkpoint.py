# offset_reset.py
from kafka import KafkaConsumer
import sys

consumer = KafkaConsumer(
    'test-topic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset="earliest",
    consumer_timeout_ms=10000,
)

print(f"auto_offset_reset=earliest，等待消息...")
for record in consumer:
    print(f"offset={record.offset} value={record.value.decode()}")


consumer = KafkaConsumer(
    'test-topic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset="latest",
    consumer_timeout_ms=10000,
)

print(f"auto_offset_reset=latest，等待消息...")
for record in consumer:
    print(f"offset={record.offset} value={record.value.decode()}")