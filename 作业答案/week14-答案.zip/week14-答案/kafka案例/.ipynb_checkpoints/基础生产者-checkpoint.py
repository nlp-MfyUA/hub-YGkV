# producer_basic.py
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: v.encode('utf-8'),   # 字符串转 bytes
)

for i in range(5):
    producer.send('test-topic', value=f"hello-{i}")

producer.flush()          # 确保都发出去
print("发送完成")