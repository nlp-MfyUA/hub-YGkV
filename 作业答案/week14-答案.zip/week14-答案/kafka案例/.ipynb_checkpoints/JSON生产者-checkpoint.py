# producer_json.py
from kafka import KafkaProducer
import json, time

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
)

for i in range(5):
    order = {"order_id": i, "amount": i * 100, "status": "created"}
    producer.send('test-topic', order)
    print("发送:", order)
    time.sleep(0.5)

producer.flush()