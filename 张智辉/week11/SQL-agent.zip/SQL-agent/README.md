# Chinook SQL Agent Workflow

基于 `chinook.db`（Chinook 数字音乐商店销售数据，SQLite）的完整 SQL Agent 工作流实现，
对标 `sql-agent.ipynb` 作业要求：

```
数据库解析 → table 选择 → sql 生成 → sql 校验 → sql 改写 → sql 执行 → 结果汇总
```

模型使用 **MiniMax-M3**，通过 `.env` 中的 `OPENAI_BASE_URL` / `OPENAI_API_KEY` 以
OpenAI 兼容协议接入。代码不绑定 MiniMax —— 换成 DeepSeek / OpenRouter 只需改两处配置。

---

## 一、运行

```bash
# 单次问答
python main.py "总销售额是多少"

# 交互式问答（exit / quit 退出）
python main.py

# 打印每个阶段的中间产物
python main.py "消费金额最高的5位客户是谁" --verbose

# 把完整工作流轨迹写成 JSON，便于复盘 / 做效果评测
python main.py "最贵的10首歌曲" --trace trace.json

# 只看生成的 SQL，跳过结果汇总
python main.py "每个国家有多少客户" --sql-only
```

### 依赖

```bash
pip install openai sqlalchemy pandas python-dotenv
```

> **关于 `openai-agents`**：课程 notebook `04_SQL-Code-Agent-Demo/sql-agent.ipynb` 里用到了
> `agents` SDK（`Agent` / `Runner` / `function_tool`）。该 SDK 的 `openai-agents>=0.18` 要求
> `openai>=2.45`，而当前环境装的是 `openai 1.59.9`，直接 `import agents` 会报
> `ModuleNotFoundError: No module named 'openai.types.shared.reasoning'`。
>
> 因此本实现把「table 选择」阶段的 Agent 用 **OpenAI 兼容接口的 tool calling 循环**
> 直接实现（见 `sql_agent/llm.py: run_tools`），效果等价，且不依赖 `agents` SDK、
> 不需要升级任何包。

---

## 二、目录结构

```
SQL-agent/
├── chinook.db                 # 数据库（课程原件在 04_SQL-Code-Agent-Demo/，此处为副本，保证本目录可独立运行）
├── main.py                    # 命令行入口
├── README.md
├── requirements.txt
└── sql_agent/
    ├── config.py              # 模型 / API / 路径 / 运行参数
    ├── utils.py               # Markdown 表格、思维链剥离、JSON 提取
    ├── llm.py                 # LLM 客户端：对话 / JSON 输出 / 工具调用循环
    ├── db_parser.py           # 数据库解析 + SQL 校验 + SQL 执行
    ├── stages.py              # 6 个业务阶段的具体实现
    └── workflow.py            # 工作流编排 + 轨迹记录
```

> 课程原始 notebook（`sql-agent.ipynb` / `code-agent.ipynb`）仍留在
> `Week11/04_SQL-Code-Agent-Demo/`，是本实现的参考来源。

---

## 三、七个阶段

| # | 阶段 | 实现位置 | 说明 |
|---|------|----------|------|
| 1 | 数据库解析 | `db_parser.DBParser` | SQLAlchemy Inspector 拿到表清单、字段明细、外键关系；再对每个字段统计 distinct / 缺失值 / 极值 / 众数 / 样例值；并补上人工整理的「表用途 + 字段含义」说明 |
| 2 | table 选择 | `stages.TableSelector` | 带工具调用的 Agent：`describe_table` 工具逐张确认候选表，最后输出 `{"tables": [...], "reason": "..."}`；模型不配合时降级为「中文业务词 → 表」的规则打分 |
| 3 | sql 生成 | `stages.SQLGenerator` | 带上选中表的完整 schema + 外键关系 + 样例数据，提示 SQLite 方言（`strftime` 而非 `YEAR()` 等），要求输出 JSON |
| 4 | sql 校验 | `stages.SQLValidator` | ① 只允许 `SELECT`/`WITH`；② 只允许单语句；③ 禁止 `INSERT/UPDATE/DROP/...` 等写操作关键字；④ `EXPLAIN` 预编译 —— 一次性验证语法、表名、列名 |
| 5 | sql 改写 | `stages.SQLRewriter` | 校验失败 / 执行报错时，把「原始问题 + 当前 SQL + 错误原因 + 表结构」一起交给模型重新生成。**改写必须带 schema** —— 否则模型会改出新的字段错误 |
| 6 | sql 执行 | `stages.SQLExecutor` | 只读连接执行，限制返回行数 |
| 7 | 结果汇总 | `stages.ResultSummarizer` | 把结果表 + 结果统计（数值列 count/sum/min/max/mean、文本列高频值）一起给模型，产出自然语言答案 + 关键发现 + 后续建议 |

### 阶段 4/5/6 构成的闭环

```
生成 SQL ─→ 校验 ──┬─(通过)─→ 执行 ──┬─(成功)─→ 汇总
                   │                  │
                   └─(不通过)─→ 改写─┘   └─(报错)─→ 改写 ─→ 重新校验 ─→ 重跑
```

改写与重跑都有次数上限（`RunConfig.max_validate_rounds` / `max_exec_retries`），
避免模型在错误里反复打转。

---

## 四、设计要点

### 1. 安全：两层只读保护

- **数据库层**：整条链路使用 SQLite 的 `mode=ro` URI 连接，
  `sqlite:///file:<path>?mode=ro&uri=true`。即使模型生成了 `DELETE`，数据库层面也无法落盘。
- **SQL 层**：`check_sql` 做关键字白名单 + 单语句检查，写操作语句在执行前就被拦下。

### 2. 容错：每一步都有兜底

| 失败点 | 兜底策略 |
|--------|----------|
| 选表 Agent 调用异常 | 降级为中文业务词规则打分 |
| 选表 Agent 输出无法解析成 JSON | 从正文里正则捞表名；再失败则规则打分 |
| 模型 JSON 输出格式错误 | `chat_json` 自动追加一条纠正消息重试一次 |
| 模型输出带 `<think>` 思维链 / ```` ``` ```` 围栏 | `strip_think` / `clean_sql` 统一清洗 |
| 模型用错字段名或表名 | 校验阶段发现 → 改写阶段修复 |
| 改写后仍不合法 | 放弃本次执行并如实报错，不会拿未校验的 SQL 去跑 |

### 3. 可观测：全流程轨迹

每个阶段都会产生一条 `StageTrace`（序号、名称、耗时、详情、是否通过），
`--trace` 可以把整条链路连同 SQL 演进过程导出成 JSON。

`sql_history` 记录了 SQL 的每一次改写及改写原因，方便复盘「模型为什么走偏了」。

### 4. 中文数据的编码处理

Windows 控制台默认 GBK，而 Chinook 的地址字段里存在非 GBK 字符（如 `São Paulo`），
`main.py` 启动时会强制 `sys.stdout.reconfigure(encoding="utf-8")`，
避免 `UnicodeEncodeError`。

---

## 五、切换模型

改 `sql_agent/config.py` 里的 `LLMConfig` 即可：

```python
@dataclass(frozen=True)
class LLMConfig:
    model: str = "MiniMax-M3"
    api_key_env: str = "OPENAI_API_KEY"
    base_url_env: str = "OPENAI_BASE_URL"
```

换成 DeepSeek：

```python
model: str = "deepseek-chat"
api_key_env: str = "DEEPSEEK_API_KEY"
base_url_env: str = "DEEPSEEK_API_URL"   # 注意末尾要补 /v1
```

换成 OpenRouter 则是 `OPENROUTE_API_KEY` + `OPENROUTE_API_URL`（末尾补 `/v1`）。

> `.env` 里的 key 建议不要提交到版本库；本仓库的 `.env` 已在 `.gitignore` 中。

---

## 六、参考问题

```bash
python main.py "总销售额是多少"
python main.py "消费金额最高的5位客户是谁？列出姓名、国家和消费总额"
python main.py "每位销售代表一共卖出了多少销售额？只列出销售额超过10的"
python main.py "Rock 流派有哪些专辑？按发行数量排序"
python main.py "数据库里一共有多少首歌曲"
python main.py "最贵的10首歌曲"
```

---

## 七、已知限制

- **延迟**：MiniMax-M3 是推理模型，选表阶段（多次工具调用往返）耗时在 5s~50s 之间波动。
  生产环境建议把选表阶段换成「一次调用直接给表名 + 缓存 schema 摘要」。
- **兜底词表有限**：`db_parser.BUSINESS_KEYWORDS` 是人工整理的中文业务词映射，
  换业务库时需要重新维护。
- **只读**：本实现刻意不支持写操作（`UPDATE` / `INSERT` / DDL）。要做数据分析师类
  「查完顺手改」的 Agent，需要额外加白名单表和审计日志。
- **统计口径**：`invoices.Total` 是订单总金额，`invoice_items` 里是明细金额，
  两者口径不同（前者已含税、后者按单价×数量）。问「销售额」时默认用 `invoices.Total`。
