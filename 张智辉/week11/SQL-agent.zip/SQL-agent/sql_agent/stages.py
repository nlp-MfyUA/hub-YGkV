"""
工作流各阶段实现。

每个 Stage 都是「输入 -> 输出」的独立单元，方便单独调试和替换：
    TableSelector     table 选择（带工具调用的 Agent）
    SQLGenerator      sql 生成
    SQLValidator      sql 校验
    SQLRewriter       sql 改写
    SQLExecutor       sql 执行
    ResultSummarizer  结果汇总
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from .db_parser import BUSINESS_KEYWORDS, DBParser, QueryResult
from .llm import LLMClient
from .utils import clean_sql, extract_json

# ------------------------------------------------------------------ 工具定义
TABLE_TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "list_tables",
            "description": "列出数据库中所有表的用途说明和字段列表。",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "describe_table",
            "description": "查看某个表的完整字段明细（类型、主键、缺失值、取值范围、样例值）和样例数据行。",
            "parameters": {
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "要查看的表名，例如 invoices"}
                },
                "required": ["table_name"],
            },
        },
    },
]


# ==================================================================== 数据结构
@dataclass
class TableSelection:
    tables: list[str]
    reason: str = ""
    source: str = "llm"            # llm | fallback
    tool_calls: list[dict] = field(default_factory=list)


@dataclass
class GeneratedSQL:
    sql: str
    explanation: str = ""
    tables_used: list[str] = field(default_factory=list)
    change_reason: str = ""


@dataclass
class ValidationResult:
    ok: bool
    reason: str


@dataclass
class ExecutionResult:
    ok: bool
    result: QueryResult | None = None
    error: str = ""


@dataclass
class Summary:
    answer: str
    key_findings: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


# ==================================================================== 阶段 2
class TableSelector:
    """
    table 选择 —— 带工具调用的 Agent。

    Agent 先 list_tables 摸清全貌，再用 describe_table 逐个确认候选表，
    最后输出 JSON 给出选中的表。模型不配合时降级为「中文业务词 -> 表」的兜底打分。
    """

    SYSTEM_PROMPT = """你是一个数据库选表专家。用户会提出一个自然语言的数据问题，
你需要判断：回答这个问题需要用到数据库里的哪些表。

工作流程：
1. 库表总览已经写在用户消息里了，不需要再调用 list_tables，直接进入下一步。
2. 挑选你怀疑相关的表，逐个调用 describe_table 查看字段明细，确认字段是否真的支持该问题。
   最多确认 3 张表即可，不要逐张遍历所有表。
3. 确认后，在最后一条回复中输出最终结论。

最终结论必须是一个 JSON 对象，且不要包含任何其它文字或代码块围栏：
{"tables": ["表1", "表2"], "reason": "为什么需要这些表"}

注意：
- 只选必需的表，不要把所有表都列上。
- 表名必须来自用户消息里的库表总览，不要臆造。
- 如果涉及金额/销量，需要同时选中存放明细和存放订单的表。
"""

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm

    def run(self, question: str) -> TableSelection:
        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"数据库共有以下表：\n{self.parser.schema_digest()}\n\n"
                f"用户问题：{question}\n\n请开始选表。",
            },
        ]

        def handler(name: str, arguments: dict) -> str:
            if name == "list_tables":
                return self.parser.schema_digest()
            if name == "describe_table":
                table = str(arguments.get("table_name") or "").strip()
                return self.parser.describe_table(table)
            return f"未知工具：{name}"

        try:
            loop = self.llm.run_tools(messages, TABLE_TOOLS, handler)
        except Exception as exc:
            fallback = self._fallback(question)
            fallback.reason = f"选表 Agent 调用失败（{type(exc).__name__}: {exc}），改用规则兜底"
            return fallback

        tool_calls = [
            {"name": c.name, "arguments": c.arguments, "result_preview": c.result_preview}
            for c in loop.calls
        ]

        tables = self._parse_tables(loop.final_text)
        if tables:
            return TableSelection(
                tables=tables,
                reason=self._parse_reason(loop.final_text),
                source="llm",
                tool_calls=tool_calls,
            )

        fallback = self._fallback(question)
        fallback.tool_calls = tool_calls
        fallback.reason = "选表 Agent 未给出可解析的 JSON，改用规则兜底"
        return fallback

    # ---------------------------------------------------------- 内部工具方法
    def _parse_tables(self, text: str) -> list[str]:
        """从模型最终回复里解析表名列表。"""
        data = extract_json(text) or {}
        candidates = data.get("tables") or []
        if isinstance(candidates, str):
            candidates = [c.strip() for c in re.split(r"[,，\s]+", candidates) if c.strip()]

        valid = [t for t in candidates if t in self.parser.table_names]
        if valid:
            return list(dict.fromkeys(valid))

        # JSON 解析失败时，退而求其次：正文里出现过的表名
        mentioned = [t for t in self.parser.table_names if re.search(rf"\b{re.escape(t)}\b", text)]
        return list(dict.fromkeys(mentioned))

    @staticmethod
    def _parse_reason(text: str) -> str:
        data = extract_json(text) or {}
        return str(data.get("reason") or "")[:500]

    def _fallback(self, question: str) -> TableSelection:
        """中文业务词打分兜底：把问题里的业务词映射到候选表。"""
        scores: dict[str, float] = {}
        for keyword, tables in BUSINESS_KEYWORDS.items():
            if keyword in question:
                for table in tables:
                    scores[table] = scores.get(table, 0) + 2.0

        # 表名/字段名里直接出现英文词也算命中
        lowered = question.lower()
        for table in self.parser.table_names:
            if table.lower() in lowered:
                scores[table] = scores.get(table, 0) + 3.0
            for column in self.parser.get_table_fields(table)["name"]:
                if len(column) > 3 and column.lower() in lowered:
                    scores[table] = scores.get(table, 0) + 1.0

        if not scores:
            # 完全没有线索时，按「最核心的三张业务表」兜底
            scores = {"invoices": 1.0, "tracks": 1.0, "customers": 1.0}

        from .config import RunConfig

        top = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        tables = [t for t, _ in top[: RunConfig().fallback_top_tables]]
        return TableSelection(tables=tables, reason="基于业务关键词的规则兜底选表", source="fallback")


# ==================================================================== 阶段 3
class SQLGenerator:
    """sql 生成 —— 依据选中的表结构和用户问题产出 SQL。"""

    SYSTEM_PROMPT = """你是一个 SQL 生成专家，服务于 Chinook 数字音乐商店数据库（SQLite）。

规则：
1. 只能生成 **一条** SELECT 查询语句，不要写 INSERT/UPDATE/DELETE/DDL。
2. 只能使用给定表结构中真实存在的表名和字段名，大小写与给出的结构保持一致。
3. 需要关联时使用外键字段 JOIN，不要臆造关联关系。
4. SQLite 方言注意：
   - 取年份/月份用 strftime('%Y', InvoiceDate)，没有 YEAR()/MONTH() 函数
   - 字符串拼接用 ||，大小写不敏感比较用 LIKE
   - 除法可能返回整数，注意用 1.0 * a / b
5. 聚合查询注意去重：例如「有多少位客户」要用 COUNT(DISTINCT CustomerId)。
6. 除非用户要求，不要返回过多明细行，必要时加 LIMIT。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{"sql": "SELECT ...", "explanation": "这条 SQL 如何回答问题", "tables_used": ["表1"]}
"""

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm

    def run(self, question: str, tables: list[str]) -> GeneratedSQL:
        prompt = self._build_prompt(question, tables)
        data = self.llm.chat_json(
            [
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )
        return self._to_generated(data)

    def _build_prompt(self, question: str, tables: list[str]) -> str:
        sections = [
            "### 可用的表结构",
            self.parser.describe_tables(tables),
            "",
            "### 表关联关系",
            self.parser.relations_digest(tables),
            "",
            "### 用户问题",
            question,
            "",
            "请生成 SQL。",
        ]
        return "\n".join(sections)

    @staticmethod
    def _to_generated(data: dict) -> GeneratedSQL:
        sql = clean_sql(str(data.get("sql") or ""))
        used = data.get("tables_used") or []
        if isinstance(used, str):
            used = [used]
        return GeneratedSQL(
            sql=sql,
            explanation=str(data.get("explanation") or ""),
            tables_used=[str(t) for t in used],
        )


# ==================================================================== 阶段 4
class SQLValidator:
    """sql 校验 —— 只读白名单 + 单语句 + EXPLAIN 语法/表/列校验。"""

    def __init__(self, parser: DBParser) -> None:
        self.parser = parser

    def run(self, sql: str) -> ValidationResult:
        ok, reason = self.parser.check_sql(sql)
        return ValidationResult(ok=ok, reason=reason)


# ==================================================================== 阶段 5
class SQLRewriter:
    """
    sql 改写 —— 校验失败或执行报错时，带着「原始问题 + 当前 SQL + 错误原因 + 表结构」
    重新生成一条正确的 SQL。

    表结构必须带上：改写时模型需要重新对齐表名/字段名，缺少 schema 很容易改出新错。
    """

    SYSTEM_PROMPT = """你是一个 SQL 修复专家。你会收到一条出错的 SQL、错误原因和数据库表结构，
请修正这条 SQL，使其能在 SQLite 上正确执行并回答原始问题。

要求：
1. 严格保持原 SQL 的业务语义，只修正错误的部分。
2. 只能使用表结构中真实存在的表名和字段名。
3. 只能生成一条 SELECT 查询语句。
4. 在 "change_reason" 里用一句话说明你改了什么、为什么。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{"sql": "SELECT ...", "change_reason": "修改说明"}
"""

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm

    def run(self, question: str, sql: str, feedback: str, tables: list[str]) -> GeneratedSQL:
        prompt = "\n".join(
            [
                "### 可用的表结构",
                self.parser.describe_tables(tables),
                "",
                "### 表关联关系",
                self.parser.relations_digest(tables),
                "",
                "### 原始问题",
                question,
                "",
                "### 出错的 SQL",
                sql,
                "",
                "### 错误原因",
                feedback,
                "",
                "请修正这条 SQL。",
            ]
        )
        data = self.llm.chat_json(
            [
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )
        generated = SQLGenerator._to_generated(data)
        generated.change_reason = str(data.get("change_reason") or "")
        return generated


# ==================================================================== 阶段 6
class SQLExecutor:
    """sql 执行 —— 只读连接执行，限制返回行数。"""

    def __init__(self, parser: DBParser, row_limit: int = 5000) -> None:
        self.parser = parser
        self.row_limit = row_limit

    def run(self, sql: str) -> ExecutionResult:
        try:
            result = self.parser.execute_sql(sql, limit=self.row_limit)
            return ExecutionResult(ok=True, result=result)
        except Exception as exc:
            return ExecutionResult(ok=False, error=f"{type(exc).__name__}: {exc}")


# ==================================================================== 阶段 7
class ResultSummarizer:
    """结果汇总 —— 把查询结果翻译成自然语言答案。"""

    SYSTEM_PROMPT = """你是一个数据分析师，负责把 SQL 查询结果汇总成清晰的中文结论。

要求：
1. "answer" 直接回答用户的问题，数字必须来自查询结果，不要编造。
2. "key_findings" 是 2-4 条关键发现，每条一句话，必要时带上具体数值。
3. "suggestions" 是基于数据给出的后续分析建议，没有就返回空数组。
4. 回答语言要和用户提问的语言一致。
5. 不要复述 SQL，不要写"根据查询结果"这类空话。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{"answer": "...", "key_findings": ["..."], "suggestions": ["..."]}
"""

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    def run(self, question: str, sql: str, result: QueryResult, max_rows: int = 50) -> Summary:
        table_md = result.to_markdown(max_rows=max_rows)
        stats = describe_result_frame(result.frame)

        prompt = "\n".join(
            [
                f"### 用户问题\n{question}",
                "",
                f"### 执行的 SQL\n```sql\n{sql}\n```",
                "",
                f"### 查询结果（共 {result.row_count} 行"
                + ("，已截断" if result.truncated else "")
                + "）\n"
                + table_md,
                "",
                f"### 结果统计\n{stats}",
                "",
                "请汇总以上结果。",
            ]
        )

        data = self.llm.chat_json(
            [
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ]
        )
        findings = data.get("key_findings") or []
        suggestions = data.get("suggestions") or []
        if isinstance(findings, str):
            findings = [findings]
        if isinstance(suggestions, str):
            suggestions = [suggestions]
        return Summary(
            answer=str(data.get("answer") or "").strip(),
            key_findings=[str(f) for f in findings],
            suggestions=[str(s) for s in suggestions],
        )


# ==================================================================== 辅助
def describe_result_frame(frame: pd.DataFrame) -> str:
    """
    生成结果的统计摘要。

    只给 LLM 看前 N 行时，它很容易把「前 50 行的平均值」误当成整体结论，
    所以这里把数值列的 count/sum/min/max/mean 明确算出来喂给它。
    """
    if frame is None or frame.empty:
        return "(无数据)"

    lines: list[str] = []
    numeric = frame.select_dtypes(include="number")
    for column in numeric.columns:
        series = numeric[column].dropna()
        if series.empty:
            continue
        lines.append(
            f"- `{column}`：count={len(series)} sum={series.sum():.4f} "
            f"min={series.min():.4f} max={series.max():.4f} mean={series.mean():.4f}"
        )

    for column in frame.columns:
        if column in numeric.columns:
            continue
        series = frame[column].dropna()
        if series.empty:
            continue
        top = series.value_counts().head(3)
        detail = ", ".join(f"{value}({count}次)" for value, count in top.items())
        lines.append(f"- `{column}`：非空 {len(series)} 行，出现最多的值：{detail}")

    return "\n".join(lines) if lines else "(无可统计列)"
