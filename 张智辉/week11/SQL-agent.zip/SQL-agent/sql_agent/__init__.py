"""
SQL Agent —— 基于 Chinook 数据库的完整 SQL Agent Workflow。

工作流阶段：
    1. 数据库解析 (DBParser)     解析库表结构、字段统计、外键关系、样例数据
    2. table 选择 (TableSelector) Agent 通过工具探查数据库，选出需要用到的表
    3. sql 生成 (SQLGenerator)   依据选中的表生成 SQL
    4. sql 校验 (SQLValidator)   只读校验 + 语法/表/列存在性校验
    5. sql 改写 (SQLRewriter)    校验或执行失败时，带着表结构重新改写
    6. sql 执行 (SQLExecutor)    只读连接执行 SQL
    7. 结果汇总 (ResultSummarizer) 把查询结果汇总成自然语言答案
"""

from .config import LLMConfig, RunConfig
from .db_parser import DBParser
from .llm import LLMClient
from .workflow import SQLAgentWorkflow, WorkflowResult

__all__ = [
    "LLMConfig",
    "RunConfig",
    "DBParser",
    "LLMClient",
    "SQLAgentWorkflow",
    "WorkflowResult",
]
