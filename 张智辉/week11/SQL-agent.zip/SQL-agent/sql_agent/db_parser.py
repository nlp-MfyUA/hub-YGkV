"""
DBParser —— 数据库解析 + SQL 校验 + SQL 执行。

对应工作流里的三个环节：
    - 数据库解析：表清单、字段明细（含统计特征）、外键关系、样例数据
    - sql 校验  ：只读白名单 + 单语句检查 + EXPLAIN 语法/表/列存在性检查
    - sql 执行  ：以只读连接执行并截断结果

安全设计：整条链路使用 SQLite 的 `mode=ro` 只读连接，
即使模型生成了 INSERT / UPDATE / DROP，数据库层面也无法落盘。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import Engine

from .utils import to_markdown

# --------------------------------------------------------------- 业务语义说明
# 给 LLM 用的「表用途 / 字段含义」说明，让模型不用猜字段含义
TABLE_DESCRIPTIONS: dict[str, str] = {
    "albums": "专辑表。每行是一张专辑，隶属于一位艺术家（ArtistId）。",
    "artists": "艺术家（歌手/乐队）表。",
    "customers": "客户表。每行一位客户，归属某位销售代表（SupportRepId -> employees）。",
    "employees": "员工表。包含销售代表及其上下级汇报关系（ReportsTo）。",
    "genres": "音乐流派表。",
    "invoice_items": "发票明细表。每行是一首曲目（TrackId）在某张发票（InvoiceId）下的销售记录，"
                    "含单价 UnitPrice 与数量 Quantity。",
    "invoices": "发票（订单）表。每行是一笔交易，含订单日期 InvoiceDate 与订单总金额 Total。",
    "media_types": "媒体类型表（音频/视频等格式）。",
    "playlist_track": "播放列表与曲目的关联表（多对多）。",
    "playlists": "播放列表（歌单）表。",
    "tracks": "曲目（歌曲）表。含曲名、时长 Milliseconds、单价 UnitPrice、所属专辑/流派/媒体类型。",
}

FIELD_NOTES: dict[str, str] = {
    "invoices.Total": "订单总金额，即该笔订单的销售收入",
    "invoices.InvoiceDate": "订单（下单）日期，格式 YYYY-MM-DD HH:MM:SS",
    "invoices.CustomerId": "下单客户，关联 customers 表",
    "invoice_items.UnitPrice": "曲目销售单价",
    "invoice_items.Quantity": "购买数量",
    "invoice_items.TrackId": "售出的曲目，关联 tracks 表",
    "invoice_items.InvoiceId": "所属订单，关联 invoices 表",
    "tracks.UnitPrice": "曲目定价",
    "tracks.Milliseconds": "曲目时长（毫秒）",
    "tracks.Name": "曲名",
    "tracks.Composer": "作曲者",
    "customers.Country": "客户所在国家",
    "customers.City": "客户所在城市",
    "customers.State": "客户所在州/省",
    "customers.Company": "客户所属公司",
    "employees.Title": "员工职位，如 Sales Support Agent / Sales Manager",
    "albums.Title": "专辑名称",
    "artists.Name": "艺术家名称",
    "genres.Name": "流派名称",
    "playlists.Name": "歌单名称",
    "media_types.Name": "媒体类型名称",
}

# 中文业务词 -> 相关表，用于选表失败时的兜底打分
BUSINESS_KEYWORDS: dict[str, list[str]] = {
    "销售": ["invoices", "invoice_items"], "营收": ["invoices"], "收入": ["invoices"],
    "金额": ["invoices", "invoice_items"], "销售额": ["invoices", "invoice_items"],
    "订单": ["invoices"], "发票": ["invoices", "invoice_items"], "购买": ["invoice_items"],
    "消费": ["invoices"], "交易": ["invoices"], "付款": ["invoices"], "客单价": ["invoices"],
    "销量": ["invoice_items"], "卖了多少": ["invoice_items", "invoices"],
    "单价": ["invoice_items", "tracks"], "定价": ["tracks"], "价格": ["tracks", "invoice_items"],
    "客户": ["customers"], "顾客": ["customers"], "用户": ["customers"], "买家": ["customers"],
    "国家": ["customers", "invoices"], "地区": ["customers", "invoices"],
    "员工": ["employees"], "销售代表": ["employees"], "职员": ["employees"],
    "经理": ["employees"], "主管": ["employees"],
    "歌曲": ["tracks"], "曲目": ["tracks"], "音乐": ["tracks"], "音轨": ["tracks"], "歌": ["tracks"],
    "时长": ["tracks"], "长度": ["tracks"],
    "专辑": ["albums"], "唱片": ["albums"],
    "艺术家": ["artists"], "歌手": ["artists"], "乐队": ["artists"],
    "流派": ["genres"], "曲风": ["genres"], "风格": ["genres"],
    "摇滚": ["genres"], "爵士": ["genres"], "古典": ["genres"], "流行": ["genres"],
    "歌单": ["playlists"], "播放列表": ["playlists"],
    "格式": ["media_types"], "媒体": ["media_types"], "编码": ["media_types"],
}

# 只读白名单之外的危险关键字（用于改写/校验阶段）
FORBIDDEN_KEYWORDS = (
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "REPLACE", "TRUNCATE",
    "ATTACH", "DETACH", "PRAGMA", "VACUUM", "REINDEX", "BEGIN", "COMMIT", "ROLLBACK",
)

_COMMENT_RE = re.compile(r"--[^\n]*|/\*.*?\*/", re.DOTALL)
_STRING_RE = re.compile(r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"")


@dataclass
class QueryResult:
    """一次 SQL 执行的结果。"""

    columns: list[str]
    rows: list[tuple]
    row_count: int          # 数据库实际返回的行数
    truncated: bool         # 是否因为超过上限而被截断

    @property
    def frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.rows, columns=self.columns)

    def to_markdown(self, max_rows: int | None = None) -> str:
        return to_markdown(self.frame, max_rows)


def _strip_literals_and_comments(sql: str) -> str:
    """去掉字符串字面量和注释，避免关键字检查被内容里的单词干扰。"""
    sql = _COMMENT_RE.sub(" ", sql)
    sql = _STRING_RE.sub("''", sql)
    return sql


class DBParser:
    """Chinook 数据库解析器。"""

    def __init__(self, db_path: Path | str = None, *, read_only: bool = True) -> None:
        self.db_path = Path(db_path) if db_path else None
        if self.db_path is None:
            from .config import DB_PATH

            self.db_path = DB_PATH

        self.db_path = self.db_path.resolve()
        if not self.db_path.is_file():
            raise FileNotFoundError(f"数据库文件不存在：{self.db_path}")

        # 只读 URI：sqlite:///file:<path>?mode=ro&uri=true
        self.db_url = f"sqlite:///file:{self.db_path.as_posix()}?mode=ro&uri=true"
        self.engine: Engine = create_engine(self.db_url, echo=False)
        self.inspector = inspect(self.engine)

        self.table_names: list[str] = [
            t for t in self.inspector.get_table_names() if not t.startswith("sqlite_")
        ]
        self.foreign_keys: list[dict] = []
        for table in self.table_names:
            for fk in self.inspector.get_foreign_keys(table):
                self.foreign_keys.append(
                    {
                        "constrained_table": table,
                        "constrained_columns": list(fk.get("constrained_columns") or []),
                        "referred_table": fk.get("referred_table"),
                        "referred_columns": list(fk.get("referred_columns") or []),
                    }
                )

        self._fields_cache: dict[str, pd.DataFrame] = {}
        self._sample_cache: dict[str, pd.DataFrame] = {}

    # ================================================================ 数据库解析
    def get_table_names(self) -> list[str]:
        return list(self.table_names)

    def get_data_relations(self) -> pd.DataFrame:
        """外键关系表。"""
        rows = [
            [
                fk["constrained_table"],
                ", ".join(fk["constrained_columns"]),
                fk["referred_table"],
                ", ".join(fk["referred_columns"]),
            ]
            for fk in self.foreign_keys
        ]
        return pd.DataFrame(rows, columns=["constrained_table", "constrained_columns", "referred_table", "referred_columns"])

    def get_table_fields(self, table: str) -> pd.DataFrame:
        """
        解析单表的字段明细，并附带统计特征（缺失值、distinct、极值、众数、样例）。

        这些统计特征对 LLM 很关键：比如看到 invoices.Total 的 distinct=379、
        min/max 区间，模型才知道「总金额」该怎么算、「单价」该怎么去重。
        """
        if table in self._fields_cache:
            return self._fields_cache[table]

        if table not in self.table_names:
            raise KeyError(f"表不存在：{table}")

        pk_columns = set(
            (self.inspector.get_pk_constraint(table) or {}).get("constrained_columns") or []
        )
        columns = self.inspector.get_columns(table)

        records: list[dict[str, Any]] = []
        with self.engine.connect() as conn:
            for column in columns:
                name = column["name"]
                quoted = f'"{name}"'
                type_str = str(column["type"])

                row_count = conn.execute(text(f'SELECT COUNT(*) FROM "{table}"')).scalar() or 0
                nan_count = conn.execute(
                    text(f'SELECT COUNT(*) - COUNT({quoted}) FROM "{table}"')
                ).scalar() or 0
                distinct = conn.execute(
                    text(f'SELECT COUNT(DISTINCT {quoted}) FROM "{table}"')
                ).scalar() or 0

                is_text = any(t in type_str.upper() for t in ("CHAR", "TEXT", "CLOB", "STRING"))
                min_value = max_value = mode_value = sample_value = None
                if row_count:
                    if is_text:
                        min_value, max_value = conn.execute(
                            text(f'SELECT MIN({quoted}), MAX({quoted}) FROM "{table}"')
                        ).fetchone()
                    else:
                        min_value, max_value = conn.execute(
                            text(f'SELECT MIN({quoted}), MAX({quoted}) FROM "{table}"')
                        ).fetchone()
                    mode_value = conn.execute(
                        text(
                            f'SELECT {quoted} FROM "{table}" WHERE {quoted} IS NOT NULL '
                            f'GROUP BY {quoted} ORDER BY COUNT(*) DESC LIMIT 1'
                        )
                    ).scalar()
                    sample_value = conn.execute(
                        text(
                            f'SELECT DISTINCT {quoted} FROM "{table}" '
                            f'WHERE {quoted} IS NOT NULL LIMIT 3'
                        )
                    ).fetchall()
                    sample_value = [r[0] for r in sample_value]

                records.append(
                    {
                        "name": name,
                        "type": type_str,
                        "nullable": bool(column.get("nullable", True)),
                        "default": column.get("default"),
                        "primary_key": name in pk_columns,
                        "distinct": distinct,
                        "nan_count": nan_count,
                        "min": min_value,
                        "max": max_value,
                        "mode": mode_value,
                        "sample": ", ".join(str(v) for v in (sample_value or [])),
                        "note": FIELD_NOTES.get(f"{table}.{name}", ""),
                    }
                )

        frame = pd.DataFrame(records)
        self._fields_cache[table] = frame
        return frame

    def get_table_sample(self, table: str, n: int = 3) -> pd.DataFrame:
        """取样例数据行。"""
        if table in self._sample_cache:
            return self._sample_cache[table]
        with self.engine.connect() as conn:
            frame = pd.read_sql(text(f'SELECT * FROM "{table}" LIMIT {int(n)}'), conn)
        self._sample_cache[table] = frame
        return frame

    def describe_table(self, table: str) -> str:
        """生成一张表的 Markdown 说明（字段明细 + 样例数据），直接喂给 LLM。"""
        if table not in self.table_names:
            return f"表 {table} 不存在。可用表：{', '.join(self.table_names)}"

        fields = self.get_table_fields(table)
        description = TABLE_DESCRIPTIONS.get(table, "")

        lines = [f"### 表 `{table}`", ""]
        if description:
            lines.append(f"用途：{description}")
        lines.append(f"行数：{self._row_count(table)}")
        lines.append("")
        lines.append("字段：")
        for record in fields.to_dict("records"):
            note = f" —— {record['note']}" if record["note"] else ""
            lines.append(
                f"- `{record['name']}` ({record['type']})"
                f" | 主键={'是' if record['primary_key'] else '否'}"
                f" | 可空={'是' if record['nullable'] else '否'}"
                f" | distinct={record['distinct']} | 缺失={record['nan_count']}"
                f" | 范围=[{record['min']}, {record['max']}]"
                f" | 众数={record['mode']}{note}"
            )
        lines.append("")
        lines.append("样例数据：")
        lines.append(to_markdown(self.get_table_sample(table)))
        return "\n".join(lines)

    def describe_tables(self, tables: list[str]) -> str:
        return "\n\n".join(self.describe_table(t) for t in tables)

    def schema_digest(self) -> str:
        """紧凑的库表总览，供选表 Agent 快速浏览。"""
        lines = ["数据库：Chinook（数字音乐商店销售数据，SQLite）", ""]
        for table in self.table_names:
            description = TABLE_DESCRIPTIONS.get(table, "")
            columns = ", ".join(self.get_table_fields(table)["name"].tolist())
            lines.append(f"- `{table}`（{self._row_count(table)} 行）：{description}")
            lines.append(f"    字段：{columns}")
        return "\n".join(lines)

    def relations_digest(self, tables: list[str] | None = None) -> str:
        """外键关系说明（可只看选中的表）。"""
        subset = [
            fk
            for fk in self.foreign_keys
            if tables is None
            or fk["constrained_table"] in tables
            or fk["referred_table"] in tables
        ]
        if not subset:
            return "(无关联关系)"
        lines = []
        for fk in subset:
            lines.append(
                f"- {fk['constrained_table']}.{','.join(fk['constrained_columns'])}"
                f" -> {fk['referred_table']}.{','.join(fk['referred_columns'])}"
            )
        return "\n".join(lines)

    def _row_count(self, table: str) -> int:
        with self.engine.connect() as conn:
            return conn.execute(text(f'SELECT COUNT(*) FROM "{table}"')).scalar() or 0

    # ================================================================ SQL 校验
    def check_sql(self, sql: str) -> tuple[bool, str]:
        """
        校验 SQL 是否安全且可执行。

        依次检查：
            1. 非空、以 SELECT / WITH 开头
            2. 只含一条语句（去掉末尾分号后不允许再出现分号）
            3. 不包含 INSERT/UPDATE/DELETE/DROP 等写操作关键字
            4. EXPLAIN 能通过（等价于语法 + 表名 + 列名全部存在）
        """
        if not sql or not sql.strip():
            return False, "SQL 为空"

        statement = sql.strip().rstrip(";").strip()
        upper = statement.upper()

        if not (upper.startswith("SELECT") or upper.startswith("WITH")):
            return False, "只允许 SELECT / WITH 查询语句，当前语句类型不被允许"

        if ";" in statement:
            return False, "只允许执行单条 SQL，不允许多语句拼接"

        cleaned = _strip_literals_and_comments(statement).upper()
        for keyword in FORBIDDEN_KEYWORDS:
            if re.search(rf"\b{keyword}\b", cleaned):
                return False, f"SQL 中包含被禁止的关键字：{keyword}（本系统为只读查询）"

        try:
            with self.engine.connect() as conn:
                conn.execute(text("EXPLAIN " + statement)).fetchall()
        except Exception as exc:
            return False, f"SQL 无法通过语法/表/列校验：{type(exc).__name__}: {str(exc)[:200]}"

        return True, "ok"

    # ================================================================ SQL 执行
    def execute_sql(self, sql: str, limit: int = 5000) -> QueryResult:
        """以只读连接执行 SQL，并截断返回行数。"""
        with self.engine.connect() as conn:
            result = conn.execute(text(sql))
            columns = list(result.keys())
            rows = result.fetchmany(limit + 1)

        truncated = len(rows) > limit
        rows = rows[:limit]
        return QueryResult(
            columns=columns,
            rows=[tuple(r) for r in rows],
            row_count=len(rows),
            truncated=truncated,
        )

    def close(self) -> None:
        self.engine.dispose()
