"""通用小工具：Markdown 表格渲染、思维链剥离、JSON 提取。"""

from __future__ import annotations

import json
import re
import unicodedata
from typing import Any

import pandas as pd

# <think>...</think> 是推理模型（如 MiniMax-M3）把思维链混在正文里的产物
_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)
# ```sql ... ``` 代码块围栏
_FENCE_RE = re.compile(r"^\s*```(?:sql|sqlite)?\s*|\s*```\s*$", re.IGNORECASE)


def strip_think(text: str) -> str:
    """去掉 <think> 思维链和 ``` 代码块围栏。"""
    if not text:
        return ""
    text = _THINK_RE.sub("", text)
    text = _FENCE_RE.sub("", text)
    return text.strip()


def extract_json(text: str) -> dict | None:
    """
    从模型输出中提取 JSON 对象。

    模型即使被要求「只输出 JSON」，也常常带上前后缀说明或代码块围栏，
    所以这里做三级兜底：整体解析 -> 首个 `{` 到配对 `}` -> 数组。
    """
    if not text:
        return None
    text = strip_think(text)

    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else None
    except (json.JSONDecodeError, TypeError):
        pass

    # 扫描第一个配对完整的 { ... }
    start = text.find("{")
    while start != -1:
        depth, in_str, escape = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(text[start : i + 1])
                        if isinstance(obj, dict):
                            return obj
                    except json.JSONDecodeError:
                        break
        start = text.find("{", start + 1)

    return None


def _display_width(text: str) -> int:
    """按终端显示宽度计算字符串长度（中文/全角算 2 个字符）。"""
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1 for ch in text)


def _pad(text: str, width: int) -> str:
    return text + " " * max(0, width - _display_width(text))


def _fmt_cell(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, float):
        text = f"{value:.4f}".rstrip("0").rstrip(".")
        return text if text else "0"
    text = str(value)
    text = text.replace("|", r"\|").replace("\r", " ").replace("\n", " ")
    return text if text else "''"


def to_markdown(df: pd.DataFrame, max_rows: int | None = None) -> str:
    """
    把 DataFrame 渲染成 Markdown 表格。

    刻意不依赖 `DataFrame.to_markdown()`（它需要额外的 tabulate 包），
    这样本项目只依赖 sqlalchemy / pandas / openai 三个常用库。
    """
    if df is None or df.empty:
        return "(空结果)"

    frame = df.head(max_rows) if max_rows else df
    columns = [str(c) for c in frame.columns]
    rows = [[_fmt_cell(v) for v in record] for record in frame.itertuples(index=False, name=None)]

    widths = []
    for i, col in enumerate(columns):
        width = _display_width(col)
        for row in rows:
            width = max(width, _display_width(row[i]))
        widths.append(width)

    lines = [
        "| " + " | ".join(_pad(c, widths[i]) for i, c in enumerate(columns)) + " |",
        "| " + " | ".join("-" * widths[i] for i in range(len(columns))) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(_pad(v, widths[i]) for i, v in enumerate(row)) + " |")

    if max_rows and len(df) > max_rows:
        lines.append(f"\n(共 {len(df)} 行，此处仅展示前 {max_rows} 行)")
    return "\n".join(lines)


def clean_sql(sql: str) -> str:
    """
    清洗模型生成的 SQL：去掉思维链、代码块围栏、"SELECT"前缀的 sql 关键字、
    首尾空白和结尾分号。
    """
    if not sql:
        return ""
    text = strip_think(sql)
    text = re.sub(r"^\s*(sql|sqlite)\s*:?\s*", "", text, flags=re.IGNORECASE)
    text = text.strip()
    if text.endswith(";"):
        text = text[:-1].rstrip()
    return text


def truncate(text: str, limit: int = 4000, suffix: str = "...(已截断)") -> str:
    """按字符数截断长文本，避免 prompt 无限膨胀。"""
    if text and len(text) > limit:
        return text[:limit] + suffix
    return text or ""
