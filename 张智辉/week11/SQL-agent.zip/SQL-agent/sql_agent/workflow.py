"""
SQL Agent Workflow —— 把 7 个阶段串成一条可观测的流水线。

    1. 数据库解析 -> 2. table 选择 -> 3. sql 生成 -> 4. sql 校验
    -> 5. sql 改写 -> 6. sql 执行 -> 7. 结果汇总

其中 4/5/6 构成了一个「生成-校验-改写-执行」的闭环：
校验不通过就改写后重校验，执行报错就改写后重跑，各自都有次数上限，
避免模型在错误里反复打转。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from .config import RunConfig
from .db_parser import DBParser
from .llm import LLMClient
from .stages import (
    ExecutionResult,
    GeneratedSQL,
    ResultSummarizer,
    SQLExecutor,
    SQLGenerator,
    SQLRewriter,
    SQLValidator,
    Summary,
    TableSelection,
    TableSelector,
)


@dataclass
class StageTrace:
    """单个阶段的执行记录，用于展示 Agent 的工作轨迹。"""

    index: int
    name: str
    ok: bool
    detail: str
    elapsed_ms: float
    data: dict = field(default_factory=dict)


@dataclass
class WorkflowResult:
    """一次完整问答的结果。"""

    question: str
    success: bool = False
    tables: list[str] = field(default_factory=list)
    sql: str = ""
    sql_history: list[tuple[str, str]] = field(default_factory=list)  # (SQL, 说明)
    columns: list[str] = field(default_factory=list)
    rows: list[tuple] = field(default_factory=list)
    row_count: int = 0
    summary: Summary | None = None
    error: str = ""
    trace: list[StageTrace] = field(default_factory=list)


class SQLAgentWorkflow:
    """完整 SQL Agent 工作流。"""

    def __init__(
        self,
        parser: DBParser | None = None,
        llm: LLMClient | None = None,
        run_config: RunConfig | None = None,
        on_stage: Callable[[StageTrace], None] | None = None,
    ) -> None:
        self.run_config = run_config or RunConfig()
        self.parser = parser or DBParser()
        self.llm = llm or LLMClient()
        self.on_stage = on_stage

        self.selector = TableSelector(self.parser, self.llm)
        self.generator = SQLGenerator(self.parser, self.llm)
        self.validator = SQLValidator(self.parser)
        self.rewriter = SQLRewriter(self.parser, self.llm)
        self.executor = SQLExecutor(self.parser, row_limit=self.run_config.exec_row_limit)
        self.summarizer = ResultSummarizer(self.llm)

        self._counter = 0

    # ------------------------------------------------------------- 轨迹记录
    def _record(
        self,
        name: str,
        ok: bool,
        detail: str,
        elapsed: float,
        data: dict | None = None,
    ) -> StageTrace:
        self._counter += 1
        trace = StageTrace(
            index=self._counter,
            name=name,
            ok=ok,
            detail=detail,
            elapsed_ms=round(elapsed * 1000, 1),
            data=data or {},
        )
        if self.on_stage:
            self.on_stage(trace)
        return trace

    # ------------------------------------------------------------- 主流程
    def run(self, question: str) -> WorkflowResult:
        self._counter = 0
        result = WorkflowResult(question=question)
        trace = result.trace

        # ---------- 1. 数据库解析 ----------
        started = time.perf_counter()
        table_count = len(self.parser.table_names)
        field_count = sum(
            len(self.parser.inspector.get_columns(t)) for t in self.parser.table_names
        )
        trace.append(
            self._record(
                "数据库解析",
                True,
                f"解析到 {table_count} 张表 / {field_count} 个字段 / "
                f"{len(self.parser.foreign_keys)} 条外键关系",
                time.perf_counter() - started,
                {"tables": self.parser.table_names},
            )
        )

        # ---------- 2. table 选择 ----------
        started = time.perf_counter()
        selection = self.selector.run(question)
        result.tables = selection.tables
        trace.append(
            self._record(
                "table 选择",
                bool(selection.tables),
                f"选中表：{', '.join(selection.tables) or '（无）'}　|　{selection.reason}",
                time.perf_counter() - started,
                {"selection": selection},
            )
        )
        if not selection.tables:
            result.error = "未能选出任何表"
            return result

        # ---------- 3. sql 生成 ----------
        started = time.perf_counter()
        generated = self.generator.run(question, selection.tables)
        result.sql = generated.sql
        result.sql_history.append((generated.sql, "初次生成"))
        trace.append(
            self._record(
                "sql 生成",
                bool(generated.sql),
                f"{generated.sql}\n    {generated.explanation}",
                time.perf_counter() - started,
                {"generated": generated},
            )
        )

        # ---------- 4. sql 校验 + 5. sql 改写（校验不通过就改写后重校验）----------
        started = time.perf_counter()
        validation = self.validator.run(generated.sql)
        rewrite_count = 0
        while not validation.ok and rewrite_count < self.run_config.max_validate_rounds:
            rewrite_count += 1
            trace.append(
                self._record(
                    "sql 校验",
                    False,
                    f"校验未通过：{validation.reason}　-> 触发改写（第 {rewrite_count} 次）",
                    0.0,
                )
            )
            started_rewrite = time.perf_counter()
            generated = self.rewriter.run(
                question, generated.sql, validation.reason, selection.tables
            )
            result.sql_history.append((generated.sql, generated.change_reason or "校验失败改写"))
            trace.append(
                self._record(
                    "sql 改写",
                    bool(generated.sql),
                    f"{generated.sql}\n    {generated.change_reason}",
                    time.perf_counter() - started_rewrite,
                    {"generated": generated},
                )
            )
            validation = self.validator.run(generated.sql)
            if generated.sql:
                result.sql = generated.sql

        trace.append(
            self._record(
                "sql 校验",
                validation.ok,
                validation.reason if validation.ok else f"仍不通过：{validation.reason}",
                time.perf_counter() - started,
                {"validation": validation},
            )
        )
        if not validation.ok:
            result.error = f"SQL 校验始终未通过：{validation.reason}"
            return result

        # ---------- 6. sql 执行（报错则改写后重跑）----------
        started = time.perf_counter()
        execution = self.executor.run(result.sql)
        exec_retries = 0
        while not execution.ok and exec_retries < self.run_config.max_exec_retries:
            exec_retries += 1
            trace.append(
                self._record(
                    "sql 执行",
                    False,
                    f"执行失败：{execution.error}　-> 触发改写重跑（第 {exec_retries} 次）",
                    0.0,
                )
            )
            started_rewrite = time.perf_counter()
            generated = self.rewriter.run(
                question, result.sql, execution.error, selection.tables
            )
            result.sql_history.append((generated.sql, generated.change_reason or "执行失败改写"))
            trace.append(
                self._record(
                    "sql 改写",
                    bool(generated.sql),
                    f"{generated.sql}\n    {generated.change_reason}",
                    time.perf_counter() - started_rewrite,
                    {"generated": generated},
                )
            )
            if not generated.sql:
                break
            validation = self.validator.run(generated.sql)
            if not validation.ok:
                trace.append(self._record("sql 校验", False, f"改写后的 SQL 仍不合法：{validation.reason}", 0.0))
                break
            result.sql = generated.sql
            execution = self.executor.run(result.sql)

        trace.append(
            self._record(
                "sql 执行",
                execution.ok,
                f"返回 {execution.result.row_count} 行" if execution.ok else f"执行失败：{execution.error}",
                time.perf_counter() - started,
                {"execution": execution},
            )
        )
        if not execution.ok or execution.result is None:
            result.error = f"SQL 执行失败：{execution.error}"
            return result

        result.columns = execution.result.columns
        result.rows = execution.result.rows
        result.row_count = execution.result.row_count

        # ---------- 7. 结果汇总 ----------
        started = time.perf_counter()
        try:
            summary = self.summarizer.run(
                question, result.sql, execution.result, max_rows=self.run_config.result_rows_to_llm
            )
        except Exception as exc:
            trace.append(self._record("结果汇总", False, f"汇总失败：{type(exc).__name__}: {exc}", time.perf_counter() - started))
            result.error = f"结果汇总失败：{exc}"
            return result

        result.summary = summary
        result.success = True
        trace.append(
            self._record(
                "结果汇总",
                True,
                summary.answer,
                time.perf_counter() - started,
                {"summary": summary},
            )
        )
        return result
