"""
LLM 客户端封装。

底层用 OpenAI 兼容协议，因此 MiniMax / DeepSeek / OpenRouter 都可以直接复用，
上层只需要三个能力：
    chat()        —— 普通对话
    chat_json()   —— 结构化 JSON 输出（带一次自动修复重试）
    run_tools()   —— 工具调用循环（Agent 的最小实现）
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from openai import OpenAI

from .config import LLMConfig
from .utils import extract_json, strip_think


@dataclass
class ToolCallRecord:
    """一次工具调用的记录，用于展示 Agent 的执行轨迹。"""

    turn: int
    name: str
    arguments: str
    result_preview: str


@dataclass
class ToolLoopResult:
    """工具调用循环的结果。"""

    final_text: str
    calls: list[ToolCallRecord] = field(default_factory=list)
    turns: int = 0


class LLMClient:
    """对 OpenAI 兼容接口的薄封装。"""

    def __init__(self, cfg: LLMConfig = LLMConfig()) -> None:
        api_key = os.getenv(cfg.api_key_env)
        base_url = os.getenv(cfg.base_url_env)
        if not api_key:
            raise RuntimeError(
                f"未找到环境变量 {cfg.api_key_env}，请确认 .env 已加载（当前 .env: {os.getenv('_ENV_FILE', '未找到')}）"
            )

        self.cfg = cfg
        self.client = OpenAI(api_key=api_key, base_url=base_url, timeout=cfg.timeout)
        self._extra_body_supported = cfg.reasoning_split

    # ------------------------------------------------------------ 基础调用
    def chat(
        self,
        messages: list[dict],
        *,
        tools: list[dict] | None = None,
        json_mode: bool = False,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ):
        """
        发一次对话请求，返回 OpenAI 的 ChatCompletion 对象。

        json_mode=True 时请求 {"type": "json_object"}；个别兼容服务不支持该字段，
        捕获异常后自动降级为普通请求（调用方仍能从正文里抠出 JSON）。
        """
        kwargs: dict[str, Any] = {
            "model": self.cfg.model,
            "messages": messages,
            "temperature": self.cfg.temperature if temperature is None else temperature,
            "max_tokens": self.cfg.max_tokens if max_tokens is None else max_tokens,
        }
        if tools:
            kwargs["tools"] = tools
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        if self._extra_body_supported:
            kwargs["extra_body"] = {"reasoning_split": True}

        try:
            return self.client.chat.completions.create(**kwargs)
        except Exception:
            if self._extra_body_supported:
                # 该服务不认 reasoning_split，去掉后重试一次
                self._extra_body_supported = False
                kwargs.pop("extra_body", None)
                return self.client.chat.completions.create(**kwargs)
            if json_mode:
                kwargs.pop("response_format", None)
                return self.client.chat.completions.create(**kwargs)
            raise

    def chat_text(self, messages: list[dict], **kwargs) -> str:
        """发一次对话请求，返回去掉思维链的正文。"""
        response = self.chat(messages, **kwargs)
        return strip_think(response.choices[0].message.content or "")

    def chat_json(self, messages: list[dict], *, repair_hint: str | None = None) -> dict:
        """
        发一次对话请求并期望返回 JSON 对象。

        解析失败时会追加一条「只要 JSON」的纠正消息再试一次；
        仍然失败则抛出异常，由上层决定是重试整条链路还是走兜底逻辑。
        """
        response = self.chat(messages, json_mode=True)
        data = extract_json(response.choices[0].message.content or "")
        if data is not None:
            return data

        # —— 第一次没拿到 JSON，做一次修复重试 ——
        repair_messages = list(messages) + [
            {"role": "assistant", "content": response.choices[0].message.content or ""},
            {
                "role": "user",
                "content": repair_hint
                or "上一次回复不是合法 JSON。请只输出一个 JSON 对象，不要包含任何解释文字或代码块围栏。",
            },
        ]
        response = self.chat(repair_messages)
        data = extract_json(response.choices[0].message.content or "")
        if data is None:
            raise ValueError(
                f"模型未能返回合法 JSON：{strip_think(response.choices[0].message.content or '')[:300]}"
            )
        return data

    # ------------------------------------------------------------ 工具调用循环
    def run_tools(
        self,
        messages: list[dict],
        tools: list[dict],
        handler: Callable[[str, dict], str],
        *,
        max_turns: int | None = None,
    ) -> ToolLoopResult:
        """
        Agent 的最小实现：模型 -> 工具 -> 结果回填 -> 模型 …… 直到模型不再请求工具。

        handler(tool_name, arguments) 返回工具执行结果字符串，会作为 role=tool
        的消息回填给模型。
        """
        max_turns = max_turns or self.cfg.max_tool_turns
        conversation = list(messages)
        records: list[ToolCallRecord] = []

        for turn in range(1, max_turns + 1):
            response = self.chat(conversation, tools=tools)
            message = response.choices[0].message

            if not message.tool_calls:
                return ToolLoopResult(
                    final_text=strip_think(message.content or ""),
                    calls=records,
                    turns=turn,
                )

            conversation.append(
                {
                    "role": "assistant",
                    "content": message.content or "",
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                        }
                        for tc in message.tool_calls
                    ],
                }
            )

            for tool_call in message.tool_calls:
                name = tool_call.function.name
                try:
                    arguments = json.loads(tool_call.function.arguments or "{}")
                except json.JSONDecodeError:
                    arguments = {}
                if not isinstance(arguments, dict):
                    arguments = {}

                try:
                    result = handler(name, arguments)
                except Exception as exc:  # 工具出错不应该让整个 Agent 挂掉
                    result = f"ERROR: {type(exc).__name__}: {exc}"

                records.append(
                    ToolCallRecord(
                        turn=turn,
                        name=name,
                        arguments=json.dumps(arguments, ensure_ascii=False),
                        result_preview=result[:200],
                    )
                )
                conversation.append(
                    {"role": "tool", "tool_call_id": tool_call.id, "content": result}
                )

        # 达到轮数上限，模型还没给出结论
        return ToolLoopResult(final_text="", calls=records, turns=max_turns)


def wait_backoff(attempt: int, base: float = 1.0) -> float:
    """简单的指数退避等待。"""
    time.sleep(base * (2 ** max(0, attempt - 1)))
    return base * (2 ** max(0, attempt - 1))
