#!/usr/bin/env python
"""
SQL Agent 命令行入口。

用法：
    python main.py                      # 交互式问答
    python main.py "总销售额是多少"      # 单次问答
    python main.py "问题" --verbose     # 打印每个阶段的中间产物
    python main.py "问题" --trace out.json   # 把完整轨迹落盘
    python main.py "问题" --sql-only    # 只看生成的 SQL，不做汇总
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from pathlib import Path

# Windows 控制台默认是 GBK，而 Chinook 里存在非 GBK 字符（外文地址等），
# 强制用 UTF-8 输出，否则 print 会抛 UnicodeEncodeError。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sql_agent import LLMClient, RunConfig, SQLAgentWorkflow  # noqa: E402
from sql_agent.config import DB_PATH, llm_settings  # noqa: E402
from sql_agent.db_parser import DBParser  # noqa: E402
from sql_agent.utils import to_markdown  # noqa: E402
from sql_agent.workflow import StageTrace, WorkflowResult  # noqa: E402

RULE = "=" * 78
THIN = "-" * 78


def make_printer(verbose: bool):
    """返回一个阶段回调，实时打印工作流轨迹。"""

    def on_stage(trace: StageTrace) -> None:
        status = "OK " if trace.ok else "ERR"
        print(f"[{status}] {trace.index}. {trace.name} ({trace.elapsed_ms:.0f}ms)")
        if verbose or not trace.ok:
            for line in (trace.detail or "").splitlines():
                if line.strip():
                    print(f"       {line.strip()}")

    return on_stage


def print_result(result: WorkflowResult, verbose: bool) -> None:
    print()
    print(RULE)
    print("最终答案")
    print(RULE)

    if not result.success:
        print(f"执行失败：{result.error}")
        return

    if result.summary:
        print(result.summary.answer)

        if result.summary.key_findings:
            print()
            print("关键发现：")
            for finding in result.summary.key_findings:
                print(f"  - {finding}")

        if result.summary.suggestions:
            print()
            print("后续建议：")
            for suggestion in result.summary.suggestions:
                print(f"  - {suggestion}")

    print()
    print(THIN)
    print(f"选用表：{', '.join(result.tables)}")
    print(f"最终SQL：{result.sql}")
    print(f"返回行数：{result.row_count}")

    if result.rows and verbose:
        import pandas as pd

        frame = pd.DataFrame(result.rows, columns=result.columns)
        print()
        print(to_markdown(frame, max_rows=30))

    if len(result.sql_history) > 1 and verbose:
        print()
        print("SQL 演进过程：")
        for sql, reason in result.sql_history:
            print(f"  - [{reason}] {sql}")


def dump_trace(result: WorkflowResult, path: Path) -> None:
    """把工作流轨迹写成 JSON，方便复盘或做效果评测。"""

    def default(obj):
        if dataclasses.is_dataclass(obj):
            return dataclasses.asdict(obj)
        return str(obj)

    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "question": result.question,
        "success": result.success,
        "tables": result.tables,
        "sql": result.sql,
        "sql_history": [{"sql": s, "reason": r} for s, r in result.sql_history],
        "columns": result.columns,
        "rows": [list(r) for r in result.rows],
        "row_count": result.row_count,
        "error": result.error,
        "summary": dataclasses.asdict(result.summary) if result.summary else None,
        "trace": [
            {
                "index": t.index,
                "name": t.name,
                "ok": t.ok,
                "detail": t.detail,
                "elapsed_ms": t.elapsed_ms,
            }
            for t in result.trace
        ],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=default), encoding="utf-8")
    print(f"轨迹已写入：{path}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Chinook 数据库 SQL Agent Workflow",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("question", nargs="*", help="要查询的自然语言问题；不填则进入交互模式")
    parser.add_argument("-v", "--verbose", action="store_true", help="打印各阶段中间产物与结果明细")
    parser.add_argument("--trace", type=Path, default=None, help="把完整轨迹写入 JSON 文件")
    parser.add_argument("--sql-only", action="store_true", help="只输出生成的 SQL，跳过结果汇总")
    parser.add_argument("--db", type=Path, default=DB_PATH, help="数据库文件路径，默认 chinook.db")
    args = parser.parse_args()

    settings = llm_settings()
    print(RULE)
    print("Chinook SQL Agent")
    print(RULE)
    print(f"模型    : {settings['model']}")
    print(f"接口    : {settings['base_url']}")
    print(f"Key     : {settings['api_key']}")
    print(f"数据库  : {args.db}")
    print()

    # sql-only 模式下跳过汇总阶段，直接执行并打印 SQL
    run_config = RunConfig()
    parser_ = DBParser(args.db)
    llm = LLMClient()
    workflow = SQLAgentWorkflow(
        parser=parser_, llm=llm, run_config=run_config, on_stage=make_printer(args.verbose)
    )

    def ask(question: str) -> WorkflowResult:
        print()
        print(f"问题：{question}")
        print(THIN)
        if args.sql_only:
            return run_sql_only(workflow, question)
        return workflow.run(question)

    def run_sql_only(wf: SQLAgentWorkflow, question: str) -> WorkflowResult:
        """只跑到「生成 + 校验」为止，输出 SQL 不做汇总。"""
        wf.summarizer = _NullSummarizer()
        return wf.run(question)

    # ---- 单次问答 ----
    if args.question:
        question = " ".join(args.question)
        result = ask(question)
        print_result(result, args.verbose)
        if args.trace:
            dump_trace(result, args.trace)
        return 0 if result.success else 1

    # ---- 交互模式 ----
    print("输入问题开始查询，exit / quit 退出。")
    while True:
        try:
            question = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not question:
            continue
        if question.lower() in {"exit", "quit", "q"}:
            break
        try:
            result = ask(question)
            print_result(result, args.verbose)
            if args.trace:
                dump_trace(result, args.trace)
        except Exception as exc:
            print(f"处理失败：{type(exc).__name__}: {exc}")

    return 0


class _NullSummarizer:
    """--sql-only 模式下的占位汇总器：直接跳过 LLM 调用。"""

    def run(self, question, sql, result, max_rows=50):
        from sql_agent.stages import Summary

        return Summary(
            answer=f"(sql-only 模式) 共返回 {result.row_count} 行",
            key_findings=[],
            suggestions=[],
        )


if __name__ == "__main__":
    raise SystemExit(main())
