"""一键启动器：环境自检 → 启动 API 与 Worker → 健康检查 → 打开浏览器。

用法：
    python scripts/launcher.py                 # 标准启动
    python scripts/launcher.py --port 8600     # 指定端口
    python scripts/launcher.py --no-browser    # 不自动打开浏览器
    python scripts/launcher.py --install       # 启动前自动安装缺失依赖
    python scripts/launcher.py --check         # 只做环境自检，不启动
"""
from __future__ import annotations

import argparse
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _force_utf8_console() -> None:
    """Windows 控制台默认 GBK，无法输出 ✓/✗ 等符号；统一切到 UTF-8。"""
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
        except Exception:  # noqa: BLE001
            pass
    for stream in ("stdout", "stderr"):
        target = getattr(sys, stream, None)
        try:
            target.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass


_force_utf8_console()

# ---------------------------------------------------------------- 依赖自检
REQUIRED_MODULES = [
    ("fastapi", "fastapi"),
    ("uvicorn", "uvicorn"),
    ("multipart", "python-multipart"),
    ("pymupdf", "pymupdf"),
    ("numpy", "numpy"),
    ("httpx", "httpx"),
    ("PIL", "pillow"),
]
OPTIONAL_MODULES = [("kafka", "kafka-python-ng")]

IS_WINDOWS = os.name == "nt"


# ---------------------------------------------------------------- 终端输出
def _supports_color() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    return True


COLOR = _supports_color()


def _unicode_ok() -> bool:
    enc = (getattr(sys.stdout, "encoding", "") or "").lower()
    return "utf" in enc


UNICODE = _unicode_ok()
SYM = {
    "ok": "✓" if UNICODE else "[OK]",
    "warn": "!" if UNICODE else "[!]",
    "fail": "✗" if UNICODE else "[X]",
    "info": "·" if UNICODE else "-",
    "bar": "▌" if UNICODE else "|",
    "tl": "┌" if UNICODE else "+",
    "tr": "┐" if UNICODE else "+",
    "bl": "└" if UNICODE else "+",
    "br": "┘" if UNICODE else "+",
    "hb": "─" if UNICODE else "-",
    "v": "│" if UNICODE else "|",
    "arrow": "▶" if UNICODE else ">>",
    "dot": "●" if UNICODE else "*",
}


def paint(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if COLOR else text


def info(msg: str) -> None:
    print(paint("  " + SYM["info"], "36") + " " + msg)


def ok(msg: str) -> None:
    print(paint("  " + SYM["ok"], "32") + " " + msg)


def warn(msg: str) -> None:
    print(paint("  " + SYM["warn"], "33") + " " + msg)


def fail(msg: str) -> None:
    print(paint("  " + SYM["fail"], "31") + " " + msg)


def step(title: str) -> None:
    print()
    print(paint(SYM["bar"] + title, "1;36"))


def banner(port: int) -> None:
    line = SYM["hb"] * 62
    v = SYM["v"]
    print(paint(SYM["tl"] + line + SYM["tr"], "36"))
    print(paint(v, "36") + paint("  多模态 RAG 问答系统  ·  一键启动器", "1;97") + " " * 21 + paint(v, "36"))
    print(paint(v, "36") + "  Kafka 异步解析 · MinerU 版面还原 · 文本+图片联合检索" + " " * 8 + paint(v, "36"))
    print(paint(v, "36") + "  多模态 LLM 图文问答 · 引用定位 · 单用户本机 Demo" + " " * 13 + paint(v, "36"))
    print(paint(SYM["bl"] + line + SYM["br"], "36"))
    print(f"  服务地址: {paint('http://127.0.0.1:' + str(port), '1;32')}")


# ---------------------------------------------------------------- 环境检查
def check_python() -> bool:
    step("检查运行环境")
    if sys.version_info < (3, 9):
        fail(f"需要 Python 3.9+，当前为 {sys.version.split()[0]}")
        return False
    ok(f"Python {sys.version.split()[0]}  ({sys.executable})")
    return True


def missing_modules(modules) -> list[tuple[str, str]]:
    import importlib.util

    missing = []
    for module, package in modules:
        if importlib.util.find_spec(module) is None:
            missing.append((module, package))
    return missing


def check_dependencies(auto_install: bool) -> bool:
    step("检查依赖库")
    missing = missing_modules(REQUIRED_MODULES)
    if not missing:
        ok("核心依赖齐全")
    else:
        names = ", ".join(pkg for _, pkg in missing)
        warn(f"缺少依赖：{names}")
        if auto_install:
            info("正在安装缺失依赖 …")
            code = subprocess.call([sys.executable, "-m", "pip", "install", "-q", "-r", str(ROOT / "requirements.txt")])
            still = missing_modules(REQUIRED_MODULES)
            if code == 0 and not still:
                ok("依赖安装完成")
            else:
                fail("依赖安装失败，请手动执行：pip install -r requirements.txt")
                return False
        else:
            fail("请先执行：pip install -r requirements.txt  （或加 --install 自动安装）")
            return False

    for module, package in OPTIONAL_MODULES:
        if missing_modules([(module, package)]):
            warn(f"未安装 {package}：Kafka 不可用时将降级为本地持久化队列")
        else:
            ok(f"{package} 可用")
    return True


def check_env_file() -> None:
    step("准备配置文件")
    env_path = ROOT / ".env"
    example = ROOT / ".env.example"
    if env_path.is_file():
        ok(".env 已存在，沿用当前配置")
    elif example.is_file():
        env_path.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
        ok("已从 .env.example 生成 .env（可按需修改后重启）")
    else:
        warn("未找到 .env.example，使用代码内置默认配置")


def port_is_free(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((host, port))
            return True
        except OSError:
            return False


def pick_port(preferred: int, host: str = "127.0.0.1") -> int:
    """端口被占用时自动向后寻找可用端口。"""
    for candidate in range(preferred, preferred + 20):
        if port_is_free(candidate, host):
            if candidate != preferred:
                warn(f"端口 {preferred} 已被占用，自动改用 {candidate}")
            return candidate
    raise RuntimeError(f"{preferred}~{preferred + 19} 端口均被占用，请用 --port 指定其他端口")


# ---------------------------------------------------------------- 启动
def wait_health(url: str, timeout: float = 60.0) -> dict | None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as resp:
                if resp.status == 200:
                    import json

                    return json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, OSError, ValueError):
            time.sleep(0.5)
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="多模态 RAG 问答系统 · 一键启动器")
    parser.add_argument("--port", type=int, default=None, help="指定端口（默认读取 .env / PORT，默认 8600）")
    parser.add_argument("--host", default=None, help="监听地址（默认 127.0.0.1）")
    parser.add_argument("--no-browser", action="store_true", help="启动后不自动打开浏览器")
    parser.add_argument("--install", action="store_true", help="启动前自动安装缺失依赖")
    parser.add_argument("--check", action="store_true", help="只做环境自检，不启动服务")
    parser.add_argument("--reload", action="store_true", help="开启后端热重载（开发用）")
    args = parser.parse_args()

    # 让子进程与当前进程共享同一份配置
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    sys.path.insert(0, str(ROOT))
    from backend.config import CONFIG  # noqa: E402  需在设置环境变量之后导入

    host = args.host or CONFIG.host
    preferred_port = args.port or CONFIG.port
    if args.port:
        os.environ["PORT"] = str(args.port)

    banner(preferred_port)

    if not check_python():
        return 1
    if not check_dependencies(args.install):
        return 1
    check_env_file()

    step("选择端口")
    try:
        port = pick_port(preferred_port, host)
    except RuntimeError as exc:
        fail(str(exc))
        return 1
    ok(f"监听 {host}:{port}")

    if args.check:
        print()
        ok("环境自检通过，可以执行 python run.py 启动服务")
        return 0

    # ---------------- 启动解析 Worker ----------------
    step("启动服务")
    worker = None
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PORT"] = str(port)
    try:
        worker = subprocess.Popen(
            [sys.executable, str(ROOT / "worker" / "parse_worker.py")],
            cwd=str(ROOT), env=env,
        )
        ok(f"解析 Worker 已启动 (pid={worker.pid})")
    except Exception as exc:  # noqa: BLE001
        warn(f"解析 Worker 启动失败：{exc}")

    base = f"http://{host}:{port}"
    try:
        import uvicorn
    except ImportError:
        fail("未安装 uvicorn")
        if worker:
            worker.terminate()
        return 1

    # ---------------- 启动 API ----------------
    from backend.main import create_app

    app = create_app()
    config = uvicorn.Config(
        app, host=host, port=port, log_level="info", reload=args.reload, access_log=False
    )
    server = uvicorn.Server(config)

    import threading

    server_thread = threading.Thread(target=server.run, daemon=True)
    server_thread.start()

    step("健康检查")
    health = wait_health(f"{base}/api/health", timeout=60)
    if health is None:
        fail("服务启动超时，请检查下方日志")
        server.should_exit = True
        if worker:
            worker.terminate()
        return 1

    ok("API 已就绪")
    info(f"队列后端：{health['queue']['backend']}    积压：{health['queue']['backlog']}")
    info(f"嵌入后端：{health['embedder']['backend']}    索引：{health['index']['text_blocks']} 文本块 / {health['index']['images']} 图片")
    llm_state = health["llm"]["model"] if health["llm"]["available"] else "未配置（抽取式回答模式）"
    info(f"多模态 LLM：{llm_state}")

    step("就绪")
    print("  " + paint(SYM["arrow"] + "  请在浏览器中访问：", "1") + paint(base, "1;32"))
    print("  " + paint("  接口文档：", "1") + paint(f"{base}/docs", "36"))
    print("  " + paint("  停止服务：", "1") + "按 Ctrl+C")
    print()

    if not args.no_browser:
        try:
            webbrowser.open(base)
            ok("已自动打开浏览器")
        except Exception:  # noqa: BLE001
            info(f"请手动在浏览器打开 {base}")

    try:
        while server_thread.is_alive():
            server_thread.join(timeout=0.5)
    except KeyboardInterrupt:
        print()
        info("收到中断信号，正在优雅停止 …")
    finally:
        server.should_exit = True
        server_thread.join(timeout=10)
        if worker and worker.poll() is None:
            worker.terminate()
            try:
                worker.wait(timeout=10)
            except subprocess.TimeoutExpired:
                worker.kill()
        ok("服务已停止")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())