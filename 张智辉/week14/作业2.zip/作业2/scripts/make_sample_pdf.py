"""生成用于演示/测试的样例 PDF（含中文正文、表格与图片）。

用法：python scripts/make_sample_pdf.py [输出目录]
"""
from __future__ import annotations

import sys
from pathlib import Path

import pymupdf


def build(path: Path) -> Path:
    doc = pymupdf.open()
    cjk = "china-s"

    # ---------------- 第 1 页：标题 + 正文 ----------------
    page = doc.new_page()
    page.insert_text((60, 80), "多模态 RAG 系统技术白皮书", fontname=cjk, fontsize=22)
    paragraphs = [
        "1. 文档解析与版面还原",
        "本文采用 MinerU 对 PDF 进行解析，输出正文、表格、公式以及图片，并保留每块的页码与版面坐标。"
        "解析器在处理扫描件时启用 OCR 通道，对文本型 PDF 则直接提取字符，避免二次识别引入的噪声。",
        "2. 向量检索与召回策略",
        "检索阶段采用混合召回：稠密向量检索负责语义匹配，BM25 关键词检索负责精确术语匹配，"
        "两路结果通过 RRF 倒数排名融合重排。实验表明，混合召回在中文技术文档上的 nDCG@10 相比纯向量检索提升约 12%。",
        "3. 多模态问答",
        "生成阶段将检索到的文本片段、图片与用户上传的临时图片一并送入多模态大模型，"
        "要求模型在给出结论时标注来源标记，从而实现图文混排的答案与可追溯引用。",
    ]
    y = 130
    for para in paragraphs:
        page.insert_text((60, y), para[:38], fontname=cjk, fontsize=11)
        page.insert_text((60, y + 18), para[38:76], fontname=cjk, fontsize=11)
        page.insert_text((60, y + 36), para[76:], fontname=cjk, fontsize=11)
        y += 86

    # ---------------- 第 2 页：表格 + 流程图 ----------------
    page2 = doc.new_page()
    page2.insert_text((60, 70), "4. 召回效果对比", fontname=cjk, fontsize=16)
    page2.insert_text((60, 100), "在内部标注集上的对比结果如下表所示：", fontname=cjk, fontsize=11)

    table_data = [
        ["检索方式", "nDCG@10", "MRR", "耗时(ms)"],
        ["纯向量", "0.612", "0.548", "38"],
        ["纯 BM25", "0.534", "0.471", "12"],
        ["混合召回(RRF)", "0.685", "0.623", "45"],
    ]
    x0, y0 = 60, 130
    col_w, row_h = 130, 30
    for r, row in enumerate(table_data):
        for c, cell in enumerate(row):
            rect = pymupdf.Rect(x0 + c * col_w, y0 + r * row_h, x0 + (c + 1) * col_w, y0 + (r + 1) * row_h)
            page2.draw_rect(rect, color=(0.75, 0.79, 0.86), fill=(0.95, 0.96, 0.99) if r == 0 else (1, 1, 1), width=0.8)
            page2.insert_textbox(rect + (6, 8, -6, -6), cell, fontname=cjk, fontsize=10, align=1)

    # 生成一张简单的流程图图片并插入
    chart = pymupdf.open()
    cpage = chart.new_page(width=420, height=220)
    cpage.draw_rect(pymupdf.Rect(0, 0, 420, 220), color=(0.97, 0.98, 1), fill=(0.97, 0.98, 1))
    steps = [("上传", 30), ("解析", 150), ("索引", 270), ("问答", 380)]
    for label, x in steps:
        cpage.draw_circle(pymupdf.Point(x, 110), 38, color=(0.18, 0.43, 0.96), fill=(0.18, 0.43, 0.96))
        cpage.insert_text((x - 14, 116), label, fontname=cjk, fontsize=14, color=(1, 1, 1))
    for x in (80, 200, 320):
        cpage.draw_line(pymupdf.Point(x, 110), pymupdf.Point(x + 40, 110), color=(0.5, 0.55, 0.65), width=2)
    pix = cpage.get_pixmap(dpi=150)
    png_bytes = pix.tobytes("png")
    page2.insert_image(pymupdf.Rect(60, 300, 480, 520), stream=png_bytes)

    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    doc.close()
    chart.close()
    return path


if __name__ == "__main__":
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "samples"
    target = build(out_dir / "sample_rag.pdf")
    print(f"已生成样例 PDF：{target}")