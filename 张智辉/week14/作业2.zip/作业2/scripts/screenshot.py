"""用 Chrome DevTools Protocol 驱动前端，采集界面截图。

用法：python scripts/screenshot.py [base_url] [输出目录]
"""
from __future__ import annotations

import asyncio
import base64
import json
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def find_browser() -> str:
    for path in CHROME_CANDIDATES:
        if Path(path).is_file():
            return path
    raise SystemExit("未找到 Chrome / Edge")


class CDP:
    def __init__(self, ws) -> None:
        self.ws = ws
        self.counter = 0

    async def send(self, method: str, params: dict | None = None) -> dict:
        self.counter += 1
        msg_id = self.counter
        await self.ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
        while True:
            raw = await self.ws.recv()
            data = json.loads(raw)
            if data.get("id") == msg_id:
                if "error" in data:
                    raise RuntimeError(f"{method}: {data['error']}")
                return data.get("result", {})

    async def evaluate(self, expression: str, await_promise: bool = False):
        result = await self.send(
            "Runtime.evaluate",
            {"expression": expression, "returnByValue": True, "awaitPromise": await_promise},
        )
        if result.get("exceptionDetails"):
            raise RuntimeError(result["exceptionDetails"].get("text", "JS 执行失败"))
        return result.get("result", {}).get("value")

    async def screenshot(self, path: Path) -> None:
        data = await self.send("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True})
        path.write_bytes(base64.b64decode(data["data"]))
        print(f"  截图已保存：{path}")


async def run(base: str, out_dir: Path) -> None:
    import websockets

    profile = Path(tempfile.mkdtemp(prefix="cdp-profile-"))
    port = 9333
    browser = subprocess.Popen(
        [
            find_browser(),
            "--headless=new",
            "--disable-gpu",
            "--no-sandbox",
            "--hide-scrollbars",
            f"--remote-debugging-port={port}",
            f"--user-data-dir={profile}",
            "--window-size=1500,1080",
            "about:blank",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        ws_url = None
        for _ in range(60):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list", timeout=2) as resp:
                    targets = json.loads(resp.read())
                pages = [t for t in targets if t.get("type") == "page"]
                if pages:
                    ws_url = pages[0]["webSocketDebuggerUrl"]
                    break
            except Exception:  # noqa: BLE001
                time.sleep(0.3)
        if not ws_url:
            raise SystemExit("无法连接 Chrome 调试端口")

        async with websockets.connect(ws_url, max_size=64 * 1024 * 1024) as ws:
            cdp = CDP(ws)
            await cdp.send("Page.enable")
            await cdp.send("Runtime.enable")
            await cdp.send("Emulation.setDeviceMetricsOverride",
                           {"width": 1500, "height": 1080, "deviceScaleFactor": 1, "mobile": False})

            async def goto(url: str) -> None:
                await cdp.send("Page.navigate", {"url": url})
                await asyncio.sleep(2.5)

            print("1) 上传页")
            await goto(base + "/")
            await cdp.screenshot(out_dir / "01_upload.png")

            print("2) 文档管理页")
            await cdp.evaluate("document.querySelector('[data-tab=docs]').click()")
            await asyncio.sleep(1.5)
            await cdp.screenshot(out_dir / "02_documents.png")

            print("3) 问答页（发起一次提问）")
            await cdp.evaluate("document.querySelector('[data-tab=qa]').click()")
            await asyncio.sleep(1.0)
            await cdp.evaluate(
                "document.querySelector('#question').value = '混合召回是怎么做的？RRF 融合起到了什么作用？';"
                "document.querySelector('#sendBtn').click();"
            )
            await asyncio.sleep(6.0)
            await cdp.screenshot(out_dir / "03_qa.png")

            print("4) 图片放大（灯箱）")
            has = await cdp.evaluate(
                "(function(){var i=document.querySelector('#panel-qa .bubble img');"
                "if(i){i.click();return true}return false})()"
            )
            await asyncio.sleep(1.0)
            if has:
                await cdp.screenshot(out_dir / "04_lightbox.png")
            else:
                print("  （本次回答没有内嵌图片，跳过灯箱截图）")

            print("5) 运行状态弹窗")
            await cdp.evaluate("document.querySelector('#lbClose') && document.querySelector('#lbClose').click();")
            await cdp.evaluate("document.querySelector('#healthBtn').click()")
            await asyncio.sleep(1.2)
            await cdp.screenshot(out_dir / "05_health.png")
    finally:
        browser.terminate()
        try:
            browser.wait(timeout=10)
        except subprocess.TimeoutExpired:
            browser.kill()
        shutil.rmtree(profile, ignore_errors=True)


def main() -> int:
    base = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8600"
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parent.parent / "docs" / "screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    asyncio.run(run(base, out_dir))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())