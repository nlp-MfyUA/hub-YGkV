"""端到端联调脚本：上传 → 解析 → 检索问答 → 引用 → 删除。

用法：python scripts/e2e_check.py [base_url] [pdf_path]
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import httpx


def main() -> int:
    base = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8600"
    pdf_path = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parent.parent / "samples" / "sample_rag.pdf"
    client = httpx.Client(base_url=base, timeout=120.0)

    print("=" * 70)
    print("1) 健康检查")
    health = client.get("/api/health").json()
    print(json.dumps(health, ensure_ascii=False, indent=2))

    print("=" * 70)
    print(f"2) 上传 PDF：{pdf_path.name}")
    with pdf_path.open("rb") as handle:
        res = client.post("/api/documents/upload", files=[("files", (pdf_path.name, handle, "application/pdf"))])
    res.raise_for_status()
    body = res.json()
    print(json.dumps(body, ensure_ascii=False, indent=2))
    doc_id = body["files"][0]["doc_id"]

    print("=" * 70)
    print("3) 轮询状态")
    final = None
    for _ in range(60):
        time.sleep(1.0)
        status = client.get("/api/documents/status", params={"doc_ids": [doc_id]}).json()
        doc = status["documents"][0]
        print(f"   状态：{doc['status_label']}", end="")
        if doc.get("error_message"):
            print(f"  错误：{doc['error_message'][:120]}")
        else:
            print()
        if doc["status"] in {"completed", "failed"}:
            final = doc
            break
    if final is None or final["status"] != "completed":
        print("解析未完成，终止")
        return 1
    print(f"   解析完成，用时 {final.get('parse_duration_ms')}ms，引擎 {final.get('parser_engine')}")

    print("=" * 70)
    print("4) 元数据与索引")
    meta = client.get(f"/api/documents/{doc_id}/metadata").json()
    print(f"   页数：{meta['page_count']}  文本块：{len(meta['text_blocks'])}  图片：{len(meta['images'])}")
    for img in meta["images"][:5]:
        print(f"   - 图片 {img['image_id']} 第 {img['page']} 页 {img['width']}x{img['height']}")

    print("=" * 70)
    print("5) 图片可访问性")
    if meta["images"]:
        img_id = meta["images"][0]["image_id"]
        r = client.get(f"/api/documents/{doc_id}/images/{img_id}")
        print(f"   GET /images/{img_id} -> {r.status_code} ({len(r.content)} bytes)")
    r = client.get(f"/api/documents/{doc_id}/pdf")
    print(f"   GET /pdf -> {r.status_code} ({len(r.content)} bytes)")

    print("=" * 70)
    print("6) 文字提问")
    qa = client.post("/api/qa", json={"question": "混合召回是怎么做的？RRF 融合起到了什么作用？"})
    qa.raise_for_status()
    answer = qa.json()
    print(f"   模式：{answer['mode']}  召回：{answer['retrieved_count']}  耗时：{answer['elapsed_ms']}ms")
    print("-" * 70)
    print(answer["answer"])
    print("-" * 70)
    print(f"   引用来源（{len(answer['citations'])} 条）")
    for cite in answer["citations"]:
        print(f"   [{cite['marker']}] {cite['doc_name']} 第 {cite['page']} 页  {cite['pdf_url']}")
        print(f"        片段：{cite['text'][:90]}")

    print("=" * 70)
    print("7) 多轮会话")
    conv = answer["conversation_id"]
    qa2 = client.post("/api/qa", json={"question": "那召回效果如何？", "conversation_id": conv})
    qa2.raise_for_status()
    print(f"   追问耗时：{qa2.json()['elapsed_ms']}ms")
    conv_detail = client.get(f"/api/conversations/{conv}").json()
    print(f"   会话消息数：{len(conv_detail['messages'])}")

    print("=" * 70)
    print("8) 删除文档并校验清理")
    res = client.delete(f"/api/documents/{doc_id}")
    print(f"   DELETE -> {res.status_code} {res.json()['message']}")
    listing = client.get("/api/documents").json()
    print(f"   剩余文档数：{listing['total']}")
    print(f"   原 PDF 可访问性：{client.get(f'/api/documents/{doc_id}/pdf').status_code}（期望 404）")

    print("=" * 70)
    print("端到端检查完成 ✅")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())