# 多模态 RAG 问答系统

基于《多模态 RAG 问答系统设计文档 V1.0》实现的完整系统：**Kafka 异步解析 + MinerU 版面还原 + 文本/图片联合检索 + 多模态 LLM 图文问答**。

单用户本机 Demo，无登录、无多租户、无流式输出。

---

## 1. 功能特性

| 能力 | 说明 | 对应设计章节 |
|---|---|---|
| 多 PDF 上传 | 拖拽/多选上传，前后端双重校验（≤10 个、单文件 ≤50MB、合计 ≤200MB、单 PDF ≤300 页） | §3.1、§8 |
| 异步解析 | 一 PDF 一条 Kafka 消息，Key = 文档 ID 保证顺序 | §4 |
| 按文件状态展示 | 待解析 / 解析中 / 解析完成 / 解析失败，前端 2.5s 轮询 | §5、§9.2 |
| 失败重试 | 展示失败原因，重试次数持久化，上限 3 次后禁用按钮 | §3.4 |
| 重新解析 | 清理旧索引与 MinerU 产物后重新投递 | §3.6 |
| 文本+图片联合检索 | 稠密向量 + BM25 双路召回，RRF 融合重排 | §7.3 |
| 图文混排问答 | 答案带 `[S1]`/`[I1]` 引用标记，引用列表含文档名/页码/原文片段/版面坐标 | §7.5、§9.3 |
| 用户图片提问 | 1–2 张临时图片仅当轮送入多模态 LLM，问完即清 | §3.5、§6.4 |
| 多轮会话 | 会话历史持久化，支持追问 | §3.5 |
| 图片放大 / 页码定位 | 灯箱预览原图，引用可一键跳转原 PDF 指定页 | §9.3 |
| 删除清理 | 同步清理原文件、MinerU 输出、图片、索引、状态 | §3.6、§6.4 |
| 引用幻觉防护 | 后端校验 LLM 输出的引用标记，非法标记不进入引用列表 | §13 |
| 运维指标 | `/api/health` 暴露队列积压、索引规模、解析耗时、嵌入与 LLM 状态 | §10 |

---

## 1.1 界面预览

| 文档上传与状态 | 文档管理 | 图文问答与引用 | 图片放大 |
|---|---|---|---|
| ![上传页](docs/screenshots/01_upload.png) | ![文档管理](docs/screenshots/02_documents.png) | ![问答](docs/screenshots/03_qa.png) | ![放大](docs/screenshots/04_lightbox.png) |

---

## 2. 系统架构

```
┌──────────────┐   HTTP    ┌────────────────────────────────────────┐
│   前端 Web   │──────────▶│  后端 API 服务（FastAPI）                │
│  上传/状态/问答│◀──────────│  校验 · 落盘 · 生成消息 · 状态/文档/问答  │
└──────────────┘           └───────┬────────────────────────┬───────┘
                                   │ publish(Key=doc_id)     │ 同步调用
                          ┌────────▼────────┐      ┌────────▼────────┐
                          │  Kafka          │      │  多模态 RAG 层    │
                          │  pdf-parse-task │      │  检索 → 上下文     │
                          └────────┬────────┘      │  → 多模态 LLM     │
                                   │ consume       └────────┬────────┘
                          ┌────────▼────────┐               │
                          │  解析 Worker     │               │
                          │  MinerU CLI      │               │
                          │  →图片/分块/索引  │               │
                          └────────┬────────┘               │
                                   │                        │
                    ┌──────────────▼────────────────────────▼───────┐
                    │  本地存储：原文件 / MinerU 输出 / 抽取图片 /     │
                    │  元数据 / 状态库 / 文本索引 / 图片索引 / 会话历史 │
                    └────────────────────────────────────────────────┘
```

### 目录结构

```
.
├── backend/                     后端 API 服务
│   ├── main.py                  FastAPI 应用、静态前端挂载、健康检查
│   ├── config.py                集中配置（环境变量 > .env > 默认值）
│   ├── schemas.py               接口数据模型
│   ├── core/
│   │   ├── state_store.py       状态库（SQLite）与文档状态机
│   │   ├── storage.py           本地存储布局与清理策略
│   │   └── logging_setup.py     统一日志
│   ├── messaging/
│   │   ├── base.py              任务消息模型与队列接口
│   │   ├── kafka_queue.py       Kafka 实现（手动提交、按文档 ID 分区）
│   │   ├── local_queue.py       本地持久化队列（Kafka 的降级实现）
│   │   └── factory.py           队列工厂（Kafka 不可用时自动降级）
│   ├── parsing/
│   │   ├── mineru_adapter.py    MinerU CLI 封装与产物归一化
│   │   ├── fallback_parser.py   PyMuPDF 兜底解析器
│   │   ├── chunker.py           文本分块
│   │   ├── models.py            解析产物统一模型
│   │   └── pipeline.py          解析流水线（解析→图片→元数据→索引）
│   ├── rag/
│   │   ├── embedder.py          嵌入模型（openai / local / hash 可插拔）
│   │   ├── index_store.py       文本索引 + 图片索引（SQLite + 向量缓存）
│   │   ├── retriever.py         向量 + BM25 联合召回与 RRF 融合
│   │   ├── context.py           上下文构造与多模态内容块
│   │   └── llm.py               多模态 LLM 客户端与引用校验
│   ├── services/
│   │   ├── document_service.py  上传 / 状态 / 重试 / 重新解析 / 删除
│   │   └── qa_service.py        问答编排
│   └── api/                     文档与问答路由
├── worker/parse_worker.py       解析 Worker（消费 Kafka → 调用 MinerU）
├── frontend/                    原生 HTML/CSS/JS 单页应用（无构建步骤）
├── scripts/
│   ├── make_sample_pdf.py       生成演示用样例 PDF
│   ├── e2e_check.py             端到端联调脚本
│   └── screenshot.py            CDP 驱动界面截图
├── tests/                       pytest 测试（34 个用例）
├── samples/sample_rag.pdf       演示样例 PDF
└── data/                        运行时数据（上传/索引/状态/会话）
```

---

## 3. 快速开始

### 3.0 一键启动（Windows 双击即可）

双击项目根目录的 **`一键启动.bat`**（或 `start.bat`），脚本会自动完成：

1. 定位可用的 Python 解释器（自动跳过没装依赖的解释器）
2. 检查依赖库，缺失时提示或用 `--install` 自动安装
3. 首次运行自动从 `.env.example` 生成 `.env`
4. 检测端口占用，被占用时自动顺延到下一个可用端口
5. 启动解析 Worker 与 API 服务，等待健康检查通过
6. 自动打开浏览器到服务地址

> 停止服务：在窗口中按 `Ctrl+C`（若出现 `Terminate batch job` 提示选 `Y`）。

命令行参数（可透传给启动器）：

```bash
python scripts/launcher.py                 # 标准启动
python scripts/launcher.py --port 8600     # 指定端口
python scripts/launcher.py --no-browser    # 不自动打开浏览器
python scripts/launcher.py --install       # 启动前自动安装缺失依赖
python scripts/launcher.py --check         # 只做环境自检，不启动服务
python scripts/launcher.py --reload        # 后端热重载（开发用）
```

一键启动器输出示例：

```
┌──────────────────────────────────────────────────────────────┐
│  多模态 RAG 问答系统  ·  一键启动器                     │
│  Kafka 异步解析 · MinerU 版面还原 · 文本+图片联合检索        │
│  多模态 LLM 图文问答 · 引用定位 · 单用户本机 Demo             │
└──────────────────────────────────────────────────────────────┘
  服务地址: http://127.0.0.1:8600

▌检查运行环境
  ✓ Python 3.12.13  (C:\\Users\\admin\\.conda\\envs\\py312\\python.exe)
▌检查依赖库
  ✓ 核心依赖齐全
  ✓ kafka-python-ng 可用
▌准备配置文件
  ✓ .env 已存在，沿用当前配置
▌选择端口
  ✓ 监听 127.0.0.1:8600
▌启动服务
  ✓ 解析 Worker 已启动 (pid=43452)
▌健康检查
  ✓ API 已就绪
  · 队列后端：local-sqlite    积压：0
  · 嵌入后端：hash    索引：19 文本块 / 1 图片
  · 多模态 LLM：未配置（抽取式回答模式）

▌就绪
  ▶  请在浏览器中访问：http://127.0.0.1:8600
    接口文档：http://127.0.0.1:8600/docs
    停止服务：按 Ctrl+C
```

### 3.1 安装依赖

```bash
pip install -r requirements.txt
```

> Windows 上 `kafka-python` 偶有安装失败，`requirements.txt` 中已给出替代包 `kafka-python-ng`（导入名同样是 `kafka`）。

### 3.2 生成成演示 PDF（可选）

```bash
python scripts/make_sample_pdf.py
```

生成 `samples/sample_rag.pdf`：2 页中文技术文档，含正文、表格与流程图。

### 3.3 启动

```bash
python run.py            # 同时启动 API 与解析 Worker
python run.py api        # 仅启动 API
python run.py worker     # 仅启动解析 Worker
```

打开 <http://127.0.0.1:8600> 即可使用。

### 3.4 端到端自检

```bash
python scripts/e2e_check.py http://127.0.0.1:8600
```

依次验证：健康检查 → 上传 → 状态轮询 → 元数据/索引 → 图片与 PDF 可访问 → 文字提问与引用 → 多轮会话 → 删除清理。

### 3.5 运行测试

```bash
python -m pytest tests -q
```

---

## 4. 接入真实组件

系统开箱即用，但默认走的是**降级链路**（见第 7 节）。接入真实组件只需改 `.env`：

### 4.1 Kafka

```bash
KAFKA_ENABLED=true
KAFKA_BOOTSTRAP_SERVERS=127.0.0.1:9092
KAFKA_TOPIC=pdf-parse-task
KAFKA_GROUP_ID=pdf-parse-worker
KAFKA_FALLBACK_LOCAL=false      # 关闭自动降级，Kafka 不可用时直接报错
```

Topic 无需预建，首次投递会自动创建。消费者使用 `enable_auto_commit=False` 手动提交。

### 4.2 MinerU

```bash
# 安装（任选其一）
pip install -U "mineru[core]"
pip install -U magic-pdf

# 指定固定版本与命令（可选，留空则自动探测 mineru / magic-pdf）
MINERU_COMMAND=C:/Python/Scripts/mineru.exe
MINERU_VERSION=2.0.4
MINERU_EXTRA_ARGS=-m auto
```

MinerU 2.x 输出 `*_content_list.json`（正文/表格/公式/图片 + 页码）与 `*_middle.json`（版面坐标），系统自动归一化；**原始输出目录全量保留**在 `data/documents/{doc_id}/mineru/`。

### 4.3 嵌入模型（可选）

```bash
EMBEDDING_PROVIDER=openai
EMBEDDING_BASE_URL=https://api.siliconflow.cn/v1
EMBEDDING_API_KEY=sk-xxxx
EMBEDDING_MODEL=BAAI/bge-m3
IMAGE_EMBEDDING_MODEL=OpenAI/clip-vit-base-patch32   # 图片多模态向量
```

任何 OpenAI 兼容的 `/embeddings` 服务均可（SiliconFlow / DashScope / OpenAI / 自建 vLLM、TEI）。

### 4.4 多模态 LLM

```bash
LLM_BASE_URL=https://api.siliconflow.cn/v1
LLM_API_KEY=sk-xxxx
LLM_MODEL=Qwen/Qwen2.5-VL-7B-Instruct
LLM_VISION_ENABLED=true
```

系统会以 `chat/completions` + `image_url` 内容块把「检索上下文 + 检索到的图片 + 用户临时图片 + 会话历史」一起送入模型，要求模型输出 `[S1]`/`[I1]` 引用标记；后端会校验标记合法性，非法引用不进入引用列表。

---

## 5. 配置项

全部配置见 `.env.example`（复制为 `.env` 即生效）。核心项：

| 分类 | 配置 | 默认值 | 说明 |
|---|---|---|---|
| 服务 | `HOST` / `PORT` | 127.0.0.1 / 8600 | 监听地址（8000 已被本机其他程序占用） |
| 服务 | `STORAGE_ROOT` | `./data` | 本地存储根目录 |
| Kafka | `KAFKA_BOOTSTRAP_SERVERS` | 127.0.0.1:9092 | Broker 地址 |
| Kafka | `KAFKA_TOPIC` | pdf-parse-task | 解析任务 Topic |
| Kafka | `KAFKA_GROUP_ID` | pdf-parse-worker | 消费者组 |
| Kafka | `KAFKA_FALLBACK_LOCAL` | true | Kafka 不可用时是否降级为本地队列 |
| 上传 | `MAX_FILES_PER_UPLOAD` | 10 | 单次文件数上限 |
| 上传 | `MAX_FILE_SIZE_MB` / `MAX_TOTAL_SIZE_MB` | 50 / 200 | 单文件、总大小上限 |
| 上传 | `MAX_PDF_PAGES` | 300 | 单 PDF 页数上限 |
| 解析 | `PARSE_TIMEOUT_SECONDS` | 1800 | 单 PDF 解析超时（30 分钟） |
| 解析 | `MINERU_COMMAND` | 自动探测 | MinerU 命令 |
| 解析 | `PARSER_FALLBACK_ENABLED` | true | MinerU 不可用时是否启用 PyMuPDF 兜底 |
| 解析 | `IMAGE_CAPTION_ENABLED` | true | 是否用多模态 LLM 为图片生成描述 |
| 状态 | `MAX_RETRIES` | 3 | 手动重试上限（初始解析 + 3 次重试） |
| 检索 | `RETRIEVAL_TEXT_TOP_K` / `RETRIEVAL_IMAGE_TOP_K` / `RETRIEVAL_FINAL_TOP_K` | 8 / 4 / 10 | 各路召回条数 |
| 检索 | `BM25_K1` / `BM25_B` | 1.5 / 0.75 | BM25 参数 |
| 检索 | `MAX_CONTEXT_CHARS` / `MAX_CONTEXT_IMAGES` | 12000 / 6 | 上下文长度与图片数上限 |
| 嵌入 | `EMBEDDING_PROVIDER` | auto | auto / openai / hash |
| LLM | `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL` | 空 | OpenAI 兼容多模态 LLM |
| LLM | `LLM_TIMEOUT_SECONDS` | 60 | 问答超时 |
| LLM | `LLM_FALLBACK_EXTRACTIVE` | true | 无 LLM 时是否退化为抽取式回答 |

---

## 6. API

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/documents/upload` | POST | 多 PDF 上传（`multipart/form-data`，字段名 `files`） |
| `/api/documents` | GET | 文档列表 |
| `/api/documents/status?doc_ids=` | GET | 批量状态查询（供轮询） |
| `/api/documents/{id}/retry` | POST | 失败重试（校验重试上限） |
| `/api/documents/{id}/reparse` | POST | 重新解析 |
| `/api/documents/{id}` | DELETE | 删除文档并清理关联数据 |
| `/api/documents/{id}/result` | GET | 下载解析结果（zip） |
| `/api/documents/{id}/images/{imageId}` | GET | 访问抽取图片 |
| `/api/documents/{id}/pdf` | GET | 访问原 PDF（`#page=N` 定位页码） |
| `/api/documents/{id}/metadata` | GET | 查看解析元数据（额外提供） |
| `/api/qa` | POST | 同步问答 |
| `/api/conversations` | GET | 会话列表（额外提供） |
| `/api/conversations/{id}` | GET | 会话历史 |
| `/api/conversations/{id}` | DELETE | 删除会话（额外提供） |
| `/api/health` | GET | 健康检查与运行指标（额外提供） |
| `/api/config` | GET | 当前运行配置（脱敏） |

`POST /api/qa` 请求体：

```json
{
  "question": "混合召回是怎么做的？",
  "doc_scope": ["<doc_id>"],
  "conversation_id": "<conv_id>",
  "images": ["data:image/png;base64,..."]
}
```

响应体包含 `answer`（Markdown）、`citations`（引用列表）、`images`（使用图片）、`conversation_id`、`elapsed_ms`、`mode`、`used_markers` 等。

---

## 7. 与设计文档的差异说明

设计文档假定本机已具备 Kafka、MinerU、多模态 LLM 与嵌入服务。**当前开发机上这四者均不可用**，因此实现上采取「真实实现 + 自动降级」策略，保证开箱即用且链路完整可验证：

| 组件 | 真实实现 | 本机降级行为 |
|---|---|---|
| Kafka | `backend/messaging/kafka_queue.py`，真实 producer/consumer，按文档 ID 分区、手动提交、失败也提交 | Broker 不可达时自动切换到 `local_queue.py`（SQLite 持久化队列，语义对齐：一 PDF 一消息、FIFO 保序、手动提交、不自动重投），并打印显著告警；`KAFKA_FALLBACK_LOCAL=false` 可关闭降级 |
| MinerU | `backend/parsing/mineru_adapter.py`，真实调用 CLI（`mineru`/`magic-pdf` 自动探测、超时控制、全量保留原始输出、`content_list.json` 归一化） | 未安装 MinerU 时由 `fallback_parser.py`（PyMuPDF）接管，产出**完全相同**的 `ParsedDocument` 结构（页码 + 版面 bbox + 图片），下游无感知 |
| 嵌入模型 | `EMBEDDING_PROVIDER=openai`，任意 OpenAI 兼容 `/embeddings` | 未配置时使用离线确定性字符 n-gram 哈希向量（`hash` 后端），保证检索链路可用；BM25 关键词召回始终并行工作 |
| 多模态 LLM | `EMBEDDING/LLM_BASE_URL` + `LLM_API_KEY`，`chat/completions` + `image_url` 多模态内容块 | 未配置时退化为**抽取式回答**：直接引用检索到的原文片段并保留完整引用链路，不编造内容 |
| 索引存储 | 设计文档给出的是概念设计 | 用 SQLite（`data/index/index.db`）落地文本索引与图片索引：向量以 float32 BLOB 存储，删除文档时可事务化清理，进程内缓存整矩阵并按版本号失效 |

> MinerU 分支已用「假 MinerU CLI」（`tests/fake_mineru.py`）在测试中完整验证：真实 MinerU 装好后无需改代码即可切换。

---

## 8. 目录与数据

```
data/
├── documents/{doc_id}/
│   ├── original.pdf        原文件
│   ├── mineru/             MinerU 原始输出（全量保留）
│   ├── images/             抽取图片
│   ├── metadata.json       元数据（块/图片/页码/坐标）
│   ├── parse.log           解析日志
│   └── failures.jsonl      失败记录
├── index/index.db          文本索引 + 图片索引
├── state/state.db          状态库（文档/任务/失败/会话/消息）
├── state/local_queue.db    本地降级队列
├── conversations/          会话历史
├── tmp/uploads/            用户临时图片（问答后清理）
├── exports/                解析结果 zip
└── logs/app.log            运行日志
```

---

## 9. 常见问题

**Q：状态一直停在「待解析」？**
A：解析 Worker 未启动。`python run.py` 会同时拉起；也可单独执行 `python run.py worker`。查看 `data/logs/app.log` 确认消费情况。

**Q：提示「Kafka 不可用」？**
A：本机没有 Kafka，属预期降级。装 Kafka 后改 `.env` 指向真实 Broker 即可；`/api/health` 的 `queue.backend` 会显示当前实际使用的后端。

**Q：检索不到内容？**
A：确认文档状态为「解析完成」，且未配置 LLM 时回答为「抽取式」——它只复述原文，不会生成式改写。重新解析（reparse）可刷新索引。

**Q：换了嵌入模型后检索异常？**
A：索引维度与查询向量不一致时系统会降级为纯关键词检索并打印告警。请对文档执行「重新解析」以重建索引。

**Q：图片检索召回不准？**
A：图片语义召回依赖 MinerU 产出的 OCR/图注，或配置多模态 LLM 自动生成图片描述（`IMAGE_CAPTION_ENABLED=true`）。两者都没有时图片只能按位置信息弱召回。
