@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Multimodal RAG - One-Click Launcher
call "%~dp0一键启动.bat" %*
exit /b %errorlevel%