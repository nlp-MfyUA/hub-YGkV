@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"
title 多模态 RAG 问答系统 - 一键启动

echo.
echo   正在定位 Python 运行环境 ...
set "PYEXE="
for %%C in (python python3 py) do (
    if not defined PYEXE (
        %%C -c "import fastapi, uvicorn, pymupdf, numpy" >nul 2>&1
        if !errorlevel! equ 0 set "PYEXE=%%C"
    )
)
if not defined PYEXE (
    if exist "%USERPROFILE%\.conda\envs\py312\python.exe" (
        "%USERPROFILE%\.conda\envs\py312\python.exe" -c "import fastapi, uvicorn, pymupdf, numpy" >nul 2>&1
        if !errorlevel! equ 0 set "PYEXE=%USERPROFILE%\.conda\envs\py312\python.exe"
    )
)
if not defined PYEXE (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" -c "import fastapi, uvicorn, pymupdf, numpy" >nul 2>&1
        if !errorlevel! equ 0 set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    )
)
if not defined PYEXE (
    where python >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
    echo.
    echo   [X] 未找到 Python，请先安装 Python 3.9+ 并勾选 "Add to PATH"
    echo.
    pause
    exit /b 1
)

echo   启动中，停止服务请按 Ctrl+C（若提示 Terminate batch job 请选 Y）
"%PYEXE%" "scripts\launcher.py" %*
set "EXITCODE=%errorlevel%"

echo.
if not "%EXITCODE%"=="0" (
    echo   服务未正常启动，退出码 %EXITCODE%
    echo   可尝试：  "%PYEXE%" scripts\launcher.py --install
    echo.
    pause
)
exit /b %EXITCODE%