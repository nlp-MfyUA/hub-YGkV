/* 多模态 RAG 问答系统 · 前端主逻辑 */
(function () {
  "use strict";

  // ---------------------------------------------------------------- 状态
  const state = {
    selected: [],
    documents: [],
    conversations: [],
    currentConvId: null,
    tempImages: [],
    pollTimer: null,
    uploadXhr: null,
  };

  const LIMITS = { count: 10, fileMB: 50, totalMB: 200 };
  const STATUS_LABEL = { pending: "待解析", parsing: "解析中", completed: "解析完成", failed: "解析失败", deleted: "已删除" };

  // ---------------------------------------------------------------- 工具
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function escapeHtml(text) {
    return String(text == null ? "" : text)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function fmtSize(bytes) {
    if (!bytes) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    let value = bytes, i = 0;
    while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
    return value.toFixed(i === 0 ? 0 : 1) + " " + units[i];
  }

  function fmtTime(iso) {
    if (!iso) return "-";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString("zh-CN", { hour12: false });
  }

  function toast(message, kind) {
    const el = $("#toast");
    el.textContent = message;
    el.className = "toast " + (kind || "");
    clearTimeout(el._timer);
    el._timer = setTimeout(function () { el.classList.add("hidden"); }, 3200);
  }

  async function api(path, options) {
    const res = await fetch(path, options);
    let data = null;
    const text = await res.text();
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = { detail: text }; }
    if (!res.ok) {
      const detail = (data && (data.detail || data.message)) || ("请求失败 (" + res.status + ")");
      throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
    }
    return data;
  }

  // ---------------------------------------------------------------- Markdown
  function renderMarkdown(src) {
    if (!src) return "";
    const blocks = [];
    let text = String(src).replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, alt, url) {
      blocks.push({ alt: alt, url: url });
      return "@@IMG" + (blocks.length - 1) + "@@";
    });

    text = escapeHtml(text);
    const codeBlocks = [];
    text = text.replace(/```(\w*)\n?([\s\S]*?)```/g, function (_, lang, code) {
      codeBlocks.push("<pre><code>" + code.replace(/\n$/, "") + "</code></pre>");
      return "@@CODE" + (codeBlocks.length - 1) + "@@";
    });

    const lines = text.split(/\r?\n/);
    const out = [];
    let inList = false, inQuote = false;

    function closeBlocks() {
      if (inList) { out.push("</ul>"); inList = false; }
      if (inQuote) { out.push("</blockquote>"); inQuote = false; }
    }

    lines.forEach(function (line) {
      const trimmed = line.trim();
      if (!trimmed) { closeBlocks(); return; }
      if (/^@@(CODE|IMG)\d+@@$/.test(trimmed)) { closeBlocks(); out.push(trimmed); return; }

      const heading = trimmed.match(/^(#{1,6})\s+(.*)$/);
      if (heading) {
        closeBlocks();
        const level = Math.min(heading[1].length, 6);
        out.push("<h" + level + ">" + inline(heading[2]) + "</h" + level + ">");
        return;
      }
      if (/^---+$/.test(trimmed)) { closeBlocks(); out.push("<hr />"); return; }

      const quote = trimmed.match(/^&gt;\s?(.*)$/);
      if (quote) {
        if (inList) { out.push("</ul>"); inList = false; }
        if (!inQuote) { out.push("<blockquote>"); inQuote = true; }
        out.push("<p>" + inline(quote[1]) + "</p>");
        return;
      }

      const bullet = trimmed.match(/^[-*+]\s+(.*)$/);
      const numbered = trimmed.match(/^\d+[.)]\s+(.*)$/);
      if (bullet || numbered) {
        if (inQuote) { out.push("</blockquote>"); inQuote = false; }
        if (!inList) { out.push("<ul>"); inList = true; }
        out.push("<li>" + inline((bullet || numbered)[1]) + "</li>");
        return;
      }
      closeBlocks();
      out.push("<p>" + inline(trimmed) + "</p>");
    });
    closeBlocks();

    let html = out.join("\n");
    html = html.replace(/@@CODE(\d+)@@/g, function (_, i) { return codeBlocks[Number(i)] || ""; });
    html = html.replace(/@@IMG(\d+)@@/g, function (_, i) {
      const b = blocks[Number(i)];
      if (!b) return "";
      return '<img src="' + escapeHtml(b.url) + '" alt="' + escapeHtml(b.alt) + '" loading="lazy" />';
    });
    return html;
  }

  function inline(text) {
    let out = escapeHtml(text);
    out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    out = out.replace(/\[(S\d+|I\d+)\]/g, '<span class="cite-tag">[$1]</span>');
    return out;
  }

  // ---------------------------------------------------------------- 标签页
  function switchTab(name) {
    $$(".tab").forEach(function (t) { t.classList.toggle("active", t.dataset.tab === name); });
    ["upload", "docs", "qa"].forEach(function (key) {
      $("#panel-" + key).classList.toggle("hidden", key !== name);
    });
    if (name === "docs") loadDocuments();
    if (name === "qa") { loadScope(); loadConversations(); }
  }
  $$(".tab").forEach(function (tab) { tab.addEventListener("click", function () { switchTab(tab.dataset.tab); }); });

  // ---------------------------------------------------------------- 上传
  const dropzone = $("#dropzone");
  const fileInput = $("#fileInput");

  dropzone.addEventListener("click", function (e) {
    if (e.target.tagName !== "LABEL" && e.target.tagName !== "INPUT") fileInput.click();
  });
  fileInput.addEventListener("change", function () { addFiles(fileInput.files); fileInput.value = ""; });
  ["dragenter", "dragover"].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) { e.preventDefault(); dropzone.classList.add("drag"); });
  });
  ["dragleave", "drop"].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) { e.preventDefault(); dropzone.classList.remove("drag"); });
  });
  dropzone.addEventListener("drop", function (e) {
    if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
  });
  $("#clearSel").addEventListener("click", function () { state.selected = []; renderSelected(); });

  function addFiles(fileList) {
    const files = Array.from(fileList || []);
    const errors = [];
    files.forEach(function (file) {
      const lower = file.name.toLowerCase();
      if (!lower.endsWith(".pdf")) { errors.push(file.name + "：不是 PDF 文件"); return; }
      if (file.size > LIMITS.fileMB * 1024 * 1024) { errors.push(file.name + "：超过 " + LIMITS.fileMB + "MB"); return; }
      if (state.selected.length >= LIMITS.count) { errors.push(file.name + "：超出 " + LIMITS.count + " 个上限"); return; }
      const total = state.selected.reduce(function (sum, f) { return sum + f.size; }, 0) + file.size;
      if (total > LIMITS.totalMB * 1024 * 1024) { errors.push(file.name + "：合计超过 " + LIMITS.totalMB + "MB"); return; }
      if (state.selected.some(function (f) { return f.name === file.name && f.size === file.size; })) return;
      state.selected.push(file);
    });
    if (errors.length) toast(errors.slice(0, 3).join("；"), "err");
    renderSelected();
  }

  function renderSelected() {
    const list = $("#selectedList");
    $("#selCount").textContent = state.selected.length;
    list.innerHTML = "";
    state.selected.forEach(function (file, index) {
      const li = document.createElement("li");
      li.innerHTML =
        '<span class="sel-name" title="' + escapeHtml(file.name) + '">' + escapeHtml(file.name) + "</span>" +
        '<span class="sel-meta">' + fmtSize(file.size) + "</span>" +
        '<button class="mini" type="button">移除</button>';
      li.querySelector("button").addEventListener("click", function () {
        state.selected.splice(index, 1);
        renderSelected();
      });
      list.appendChild(li);
    });
    $("#uploadBtn").disabled = state.selected.length === 0;
  }

  $("#uploadBtn").addEventListener("click", function () {
    if (!state.selected.length) return;
    const form = new FormData();
    state.selected.forEach(function (file) { form.append("files", file, file.name); });

    const btn = $("#uploadBtn");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> 上传中…';

    const xhr = new XMLHttpRequest();
    state.uploadXhr = xhr;
    xhr.open("POST", "/api/documents/upload");
    xhr.upload.onprogress = function (e) {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      btn.innerHTML = '<span class="spinner"></span> 上传中 ' + pct + "%";
    };
    xhr.onload = function () {
      btn.disabled = false;
      btn.textContent = "上传并解析";
      state.selected = [];
      renderSelected();
      let data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) { data = null; }
      if (xhr.status >= 200 && xhr.status < 300 && data) {
        const n = (data.files || []).length;
        const rejected = (data.rejected || []).length;
        toast("已提交 " + n + " 个解析任务" + (rejected ? "，" + rejected + " 个被拒绝" : ""), "ok");
        startPolling();
        refreshStatusCards();
      } else {
        toast((data && data.detail) || "上传失败", "err");
      }
    };
    xhr.onerror = function () { btn.disabled = false; btn.textContent = "上传并解析"; toast("网络错误", "err"); };
    xhr.send(form);
  });

  // ---------------------------------------------------------------- 状态轮询
  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(function () {
      refreshStatusCards();
      if (!$("#panel-docs").classList.contains("hidden")) loadDocuments(true);
      updateQueueStat();
    }, 2500);
  }

  async function refreshStatusCards() {
    let docs;
    try { docs = await api("/api/documents"); } catch (e) { return; }
    state.documents = docs.documents || [];
    renderStatusCards(state.documents);
  }

  function renderStatusCards(documents) {
    const box = $("#statusCards");
    if (!documents.length) {
      box.innerHTML = '<li class="empty">暂无任务。上传 PDF 后这里会显示每个文件的独立状态。</li>';
      return;
    }
    box.innerHTML = "";
    documents.forEach(function (doc) {
      const li = document.createElement("li");
      const actions = [];
      if (doc.status === "failed") {
        const disabled = doc.retry_count >= doc.max_retries;
        actions.push('<button class="mini" data-act="retry" data-id="' + doc.doc_id + '"' + (disabled ? " disabled" : "") + ">" +
          (disabled ? "已达重试上限" : "重试") + "</button>");
      }
      if (doc.status === "completed") {
        actions.push('<button class="mini" data-act="reparse" data-id="' + doc.doc_id + '">重新解析</button>');
      }
      li.innerHTML =
        '<div class="sc-head"><span class="sc-name" title="' + escapeHtml(doc.file_name) + '">' + escapeHtml(doc.file_name) + "</span>" +
        '<span class="badge ' + doc.status + '"><span class="dot"></span>' + escapeHtml(doc.status_label || STATUS_LABEL[doc.status] || doc.status) + "</span></div>" +
        '<div class="sc-sub">' + fmtSize(doc.file_size) + " · " + doc.page_count + " 页 · 重试 " + doc.retry_count + "/" + doc.max_retries +
        (doc.parse_duration_ms ? " · 用时 " + (doc.parse_duration_ms / 1000).toFixed(1) + "s" : "") + "</div>" +
        (doc.error_message ? '<div class="sc-err">' + escapeHtml(doc.error_message) + "</div>" : "") +
        (actions.length ? '<div class="cite-actions">' + actions.join("") + "</div>" : "");
      box.appendChild(li);
    });
    box.querySelectorAll("button[data-act]").forEach(function (btn) {
      btn.addEventListener("click", function () { handleAction(btn.dataset.act, btn.dataset.id, btn); });
    });
  }

  async function handleAction(action, docId, btn) {
    if (action === "delete") {
      if (!confirm("确定删除该文档？原文件、图片、索引与状态都会被清理。")) return;
    }
    btn.disabled = true;
    try {
      const result = await api("/api/documents/" + docId + "/" + action, { method: "POST" });
      toast(result.message || "操作成功", "ok");
      refreshStatusCards();
      loadDocuments(true);
    } catch (e) {
      toast(e.message, "err");
      btn.disabled = false;
    }
  }

  // ---------------------------------------------------------------- 文档列表
  async function loadDocuments(silent) {
    try {
      const data = await api("/api/documents");
      state.documents = data.documents || [];
    } catch (e) {
      if (!silent) toast(e.message, "err");
      return;
    }
    renderDocs();
    renderScope();
  }
  $("#refreshDocs").addEventListener("click", function () { loadDocuments(); });
  $("#filterStatus").addEventListener("change", renderDocs);

  function renderDocs() {
    const filter = $("#filterStatus").value;
    const rows = state.documents.filter(function (d) { return !filter || d.status === filter; });
    const body = $("#docsBody");
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="8" class="empty">暂无文档</td></tr>';
      return;
    }
    body.innerHTML = "";
    rows.forEach(function (doc) {
      const tr = document.createElement("tr");
      const retryDisabled = doc.retry_count >= doc.max_retries;
      const actions = [];
      if (doc.status === "failed") {
        actions.push('<button class="mini" data-act="retry" data-id="' + doc.doc_id + '"' + (retryDisabled ? " disabled" : "") + ">" +
          (retryDisabled ? "已达上限" : "重试") + "</button>");
      }
      if (doc.status === "completed" || doc.status === "failed") {
        actions.push('<button class="mini" data-act="reparse" data-id="' + doc.doc_id + '">重新解析</button>');
        actions.push('<a class="mini" href="/api/documents/' + doc.doc_id + '/result">下载结果</a>');
      }
      actions.push('<button class="mini" data-act="pdf" data-id="' + doc.doc_id + '">原PDF</button>');
      actions.push('<button class="mini danger" data-act="delete" data-id="' + doc.doc_id + '">删除</button>');

      tr.innerHTML =
        '<td class="fname">' + escapeHtml(doc.file_name) + "</td>" +
        "<td>" + fmtSize(doc.file_size) + "</td>" +
        "<td>" + doc.page_count + "</td>" +
        '<td><span class="badge ' + doc.status + '"><span class="dot"></span>' + escapeHtml(doc.status_label || STATUS_LABEL[doc.status]) + "</span></td>" +
        '<td class="err-text">' + (doc.error_message ? escapeHtml(doc.error_message).slice(0, 160) : "") + "</td>" +
        "<td>" + doc.retry_count + "/" + doc.max_retries + "</td>" +
        "<td>" + fmtTime(doc.uploaded_at) + "</td>" +
        '<td class="right"><div class="actions">' + actions.join("") + "</div></td>";
      body.appendChild(tr);
    });
    body.querySelectorAll("button[data-act]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const act = btn.dataset.act;
        if (act === "pdf") { window.open("/api/documents/" + btn.dataset.id + "/pdf", "_blank"); return; }
        handleAction(act, btn.dataset.id, btn);
      });
    });
  }

  // ---------------------------------------------------------------- 检索范围
  function renderScope() {
    const list = $("#scopeList");
    const completed = state.documents.filter(function (d) { return d.status === "completed"; });
    list.innerHTML = "";
    if (!completed.length) {
      list.innerHTML = '<div class="muted">暂无已解析完成的文档</div>';
      return;
    }
    completed.forEach(function (doc) {
      const label = document.createElement("label");
      label.className = "check";
      label.innerHTML = '<input type="checkbox" value="' + doc.doc_id + '" checked><span title="' +
        escapeHtml(doc.file_name) + '">' + escapeHtml(doc.file_name) + "（" + doc.page_count + "页）</span>";
      list.appendChild(label);
    });
  }
  async function loadScope() {
    if (!state.documents.length) await loadDocuments(true);
    else renderScope();
  }

  // ---------------------------------------------------------------- 会话
  async function loadConversations() {
    try {
      state.conversations = await api("/api/conversations");
    } catch (e) { return; }
    const list = $("#convList");
    list.innerHTML = "";
    if (!state.conversations.length) {
      list.innerHTML = '<li class="muted" style="cursor:default">暂无会话</li>';
      return;
    }
    state.conversations.forEach(function (conv) {
      const li = document.createElement("li");
      li.className = conv.conversation_id === state.currentConvId ? "active" : "";
      li.innerHTML = '<div>' + escapeHtml(conv.title || "新会话") + '</div><div class="conv-sub">' +
        conv.message_count + " 条 · " + fmtTime(conv.updated_at) + "</div>";
      li.addEventListener("click", function () { openConversation(conv.conversation_id); });
      list.appendChild(li);
    });
  }
  $("#newConv").addEventListener("click", function () {
    state.currentConvId = null;
    $("#chatScroll").innerHTML = welcomeHtml();
    loadConversations();
  });
  function welcomeHtml() {
    return '<div class="welcome" id="welcome"><h2>开始提问</h2>' +
      "<p>支持纯文字提问，也可以上传 1–2 张图片与问题一起交给多模态 LLM。</p>" +
      '<ul class="hints"><li>回答会附带<strong>文档名 + 页码 + 原文片段</strong>引用</li>' +
      "<li>检索到的图片会随答案一起返回，可点击放大</li>" +
      "<li>引用中的页码可一键跳转到原 PDF 对应页</li></ul></div>";
  }

  async function openConversation(convId) {
    state.currentConvId = convId;
    try {
      const data = await api("/api/conversations/" + convId);
      const scroll = $("#chatScroll");
      scroll.innerHTML = "";
      (data.messages || []).forEach(function (msg) {
        if (msg.role === "user") appendUser(msg.content, []);
        else appendAssistant(msg.content, msg.citations || [], msg.images || [], msg.elapsed_ms);
      });
      scroll.scrollTop = scroll.scrollHeight;
      loadConversations();
    } catch (e) { toast(e.message, "err"); }
  }

  // ---------------------------------------------------------------- 问答
  $("#qaImages").addEventListener("change", function () {
    const files = Array.from($("#qaImages").files || []);
    if (state.tempImages.length + files.length > 2) {
      toast("最多上传 2 张临时图片", "err");
      $("#qaImages").value = "";
      return;
    }
    files.forEach(function (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        state.tempImages.push({ name: file.name, dataUrl: e.target.result });
        renderTempImages();
      };
      reader.readAsDataURL(file);
    });
    $("#qaImages").value = "";
  });

  function renderTempImages() {
    const box = $("#tempImages");
    box.innerHTML = "";
    state.tempImages.forEach(function (img, index) {
      const wrap = document.createElement("div");
      wrap.innerHTML = '<img src="' + img.dataUrl + '" alt=""><button class="remove" type="button">✕</button>';
      wrap.querySelector("button").addEventListener("click", function () {
        state.tempImages.splice(index, 1);
        renderTempImages();
      });
      box.appendChild(wrap);
    });
    $("#composerHint").textContent = state.tempImages.length
      ? "临时图片仅用于本轮提问，回答后自动清理。" : "";
  }

  function currentScope() {
    if ($("#scopeAll").checked) return null;
    const ids = Array.from($("#scopeList").querySelectorAll("input:checked")).map(function (i) { return i.value; });
    return ids.length ? ids : [];
  }

  $("#sendBtn").addEventListener("click", sendQuestion);
  $("#question").addEventListener("keydown", function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") sendQuestion();
  });

  async function sendQuestion() {
    const question = $("#question").value.trim();
    if (!question) { toast("请输入问题", "err"); return; }
    const btn = $("#sendBtn");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> 生成中';

    const images = state.tempImages.map(function (i) { return i.dataUrl; });
    appendUser(question, state.tempImages);
    $("#question").value = "";

    const typing = document.createElement("div");
    typing.className = "msg assistant";
    typing.innerHTML = '<div class="bubble"><div class="typing"><span class="spinner"></span> 正在检索资料并生成回答…</div></div>';
    $("#chatScroll").appendChild(typing);
    $("#chatScroll").scrollTop = $("#chatScroll").scrollHeight;

    try {
      const payload = { question: question, images: images, doc_scope: currentScope() };
      if (state.currentConvId) payload.conversation_id = state.currentConvId;
      const data = await api("/api/qa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      typing.remove();
      state.currentConvId = data.conversation_id;
      appendAssistant(data.answer, data.citations || [], data.images || [], data.elapsed_ms, data);
      state.tempImages = [];
      renderTempImages();
      loadConversations();
    } catch (e) {
      typing.remove();
      toast(e.message, "err");
      appendUser(question, []);
    } finally {
      btn.disabled = false;
      btn.textContent = "发送";
    }
  }

  function appendUser(text, images) {
    const welcome = $("#welcome");
    if (welcome) welcome.remove();
    const div = document.createElement("div");
    div.className = "msg user";
    let imgHtml = "";
    if (images && images.length) {
      imgHtml = '<div class="imgs">' + images.map(function (i) {
        return '<img src="' + (i.dataUrl || i) + '" alt="临时图片">';
      }).join("") + "</div>";
    }
    div.innerHTML = '<div class="bubble-user">' + imgHtml + escapeHtml(text) + "</div>";
    $("#chatScroll").appendChild(div);
    $("#chatScroll").scrollTop = $("#chatScroll").scrollHeight;
  }

  function appendAssistant(text, citations, images, elapsed, extra) {
    const div = document.createElement("div");
    div.className = "msg assistant";
    let citeHtml = "";
    if (citations && citations.length) {
      citeHtml = '<div class="citations"><h4>引用来源 (' + citations.length + ")</h4>" +
        citations.map(function (c) {
          const thumb = c.kind === "image" && c.image_url
            ? '<img class="cite-thumb" src="' + c.image_url + '" alt="引用图片">'
            : '<div class="cite-thumb" style="display:grid;place-items:center;color:#9aa6bb;font-size:22px">📄</div>';
          return '<div class="cite-item">' + thumb +
            '<div class="cite-body"><div class="cite-title">' +
            '<span class="cite-tag">' + escapeHtml(c.marker) + "</span>" +
            "<span>" + escapeHtml(c.doc_name) + " · 第 " + c.page + " 页</span>" +
            (c.section_path ? '<span class="muted">' + escapeHtml(c.section_path) + "</span>" : "") +
            "</div>" +
            '<div class="cite-snippet">' + escapeHtml((c.text || "").slice(0, 220)) + "</div>" +
            '<div class="cite-actions">' +
            (c.kind === "image" && c.image_url ? '<button class="mini" data-zoom="' + c.image_url + '">放大图片</button>' : "") +
            '<a class="mini" href="' + c.pdf_url + '" target="_blank" rel="noopener">定位原 PDF</a>' +
            "</div></div></div>";
        }).join("") + "</div>";
    }
    let meta = '<div class="meta-row">';
    if (extra && extra.mode) meta += "<span>模式：" + escapeHtml(extra.mode) + "</span>";
    if (extra && extra.retrieved_count != null) meta += "<span>召回 " + extra.retrieved_count + " 条</span>";
    if (extra && extra.model) meta += "<span>模型：" + escapeHtml(extra.model) + "</span>";
    if (elapsed != null) meta += "<span>耗时 " + elapsed + " ms</span>";
    meta += "</div>";

    div.innerHTML = '<div class="bubble">' + renderMarkdown(text) + meta + citeHtml + "</div>";
    $("#chatScroll").appendChild(div);
    // 滚动到本条回答的开头，避免引用列表过长时把正文顶出视口
    requestAnimationFrame(function () {
      div.scrollIntoView({ block: "start", behavior: "smooth" });
    });

    div.querySelectorAll("img").forEach(function (img) {
      img.addEventListener("click", function () { openLightbox(img.src, img.alt || ""); });
    });
    div.querySelectorAll("[data-zoom]").forEach(function (btn) {
      btn.addEventListener("click", function () { openLightbox(btn.dataset.zoom, "引用图片"); });
    });
  }

  // ---------------------------------------------------------------- 灯箱
  function openLightbox(src, caption) {
    $("#lbImg").src = src;
    $("#lbCaption").textContent = caption || "";
    $("#lightbox").classList.remove("hidden");
  }
  $("#lbClose").addEventListener("click", function () { $("#lightbox").classList.add("hidden"); });
  $("#lightbox").addEventListener("click", function (e) {
    if (e.target.id === "lightbox") $("#lightbox").classList.add("hidden");
  });

  // ---------------------------------------------------------------- 运行状态
  $("#healthBtn").addEventListener("click", async function () {
    try {
      const data = await api("/api/health");
      $("#healthBody").textContent = JSON.stringify(data, null, 2);
    } catch (e) {
      $("#healthBody").textContent = e.message;
    }
    $("#healthModal").classList.remove("hidden");
  });
  $("#healthClose").addEventListener("click", function () { $("#healthModal").classList.add("hidden"); });
  $("#healthModal").addEventListener("click", function (e) {
    if (e.target.id === "healthModal") $("#healthModal").classList.add("hidden");
  });

  async function updateQueueStat() {
    try {
      const data = await api("/api/health");
      $("#backlog").textContent = data.queue.backlog;
      $("#indexStat").textContent = data.index.text_blocks + " 块 / " + data.index.images + " 图";
    } catch (e) { /* 静默 */ }
  }

  // ---------------------------------------------------------------- 初始化
  renderSelected();
  refreshStatusCards();
  updateQueueStat();
  startPolling();
  setInterval(updateQueueStat, 5000);
})();