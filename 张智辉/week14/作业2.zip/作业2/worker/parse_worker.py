"""解析 Worker（设计文档 §2.2 组件 4）。

消费 Kafka 的 PDF 解析任务，调用 MinerU CLI，抽取图片、生成元数据、建立索引、更新状态。
- 消费者并发默认 1，串行解析；
- 处理成功提交；失败也提交（失败状态与失败记录已落库），避免阻塞队列；
- 不做无限自动重试，重试由用户手动触发。
"""
from __future__ import annotations

import signal
import sys
import threading
import time
from pathlib import Path

# 允许以 `python worker/parse_worker.py` 直接运行
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.config import CONFIG, Config
from backend.core.logging_setup import get_logger, setup_logging
from backend.core.state_store import StateStore
from backend.core.storage import Storage
from backend.messaging.factory import create_task_queue
from backend.parsing.pipeline import ParsePipeline
from backend.rag.embedder import Embedder
from backend.rag.index_store import IndexStore

logger = get_logger(__name__)

_stop = threading.Event()


def _handle_signal(signum, frame):  # noqa: ARG001
    logger.info("收到信号 %s，准备退出解析 Worker", signum)
    _stop.set()


def run_worker(config: Config = CONFIG) -> int:
    setup_logging(config.log_level)
    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    storage = Storage(config)
    storage.ensure_layout()
    state = StateStore(config.state_db_path)
    embedder = Embedder(config)
    index = IndexStore(config.index_dir / "index.db", embedder, config)
    queue = create_task_queue(config)
    pipeline = ParsePipeline(storage, state, index, config)

    logger.info("解析 Worker 启动，队列后端=%s topic=%s", queue.name, config.kafka_topic)
    processed = 0
    failures = 0
    try:
        while not _stop.is_set():
            message = queue.poll(timeout=1.0)
            if message is None:
                continue
            logger.info("收到解析任务 doc_id=%s task_id=%s", message.document_id, message.task_id)
            ok = True
            try:
                pipeline.run(message)
                processed += 1
            except Exception as exc:  # noqa: BLE001
                ok = False
                failures += 1
                logger.error("任务处理失败 doc_id=%s: %s", message.document_id, exc)
            finally:
                # 处理成功提交；失败也提交（失败状态与失败记录已落库），避免阻塞队列
                queue.commit(message)
                state.finish_task(message.task_id, "done" if ok else "failed")
    finally:
        queue.close()
        index.close()
        state.close()
        logger.info("解析 Worker 退出：成功 %s 失败 %s", processed, failures)
    return 0


if __name__ == "__main__":
    raise SystemExit(run_worker())