"""一键启动脚本。

用法：
    python run.py            # 同时启动后端 API 与解析 Worker
    python run.py api        # 仅启动后端 API
    python run.py worker     # 仅启动解析 Worker
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from backend.config import CONFIG
from backend.core.logging_setup import setup_logging


def start_worker() -> subprocess.Popen:
    cmd = [sys.executable, str(ROOT / "worker" / "parse_worker.py")]
    print("[run] 启动解析 Worker …", flush=True)
    return subprocess.Popen(cmd, cwd=str(ROOT))


def start_api() -> None:
    import uvicorn

    print(f"[run] 启动 API：http://{CONFIG.host}:{CONFIG.port}", flush=True)
    uvicorn.run(
        "backend.main:app",
        host=CONFIG.host,
        port=CONFIG.port,
        log_level=CONFIG.log_level.lower(),
        reload=False,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="多模态 RAG 问答系统启动器")
    parser.add_argument("mode", nargs="?", default="all", choices=["all", "api", "worker"])
    args = parser.parse_args()

    setup_logging(CONFIG.log_level)
    worker = None
    if args.mode in {"all", "worker"}:
        if args.mode == "worker":
            from worker.parse_worker import run_worker

            return run_worker()
        worker = start_worker()
        time.sleep(1.0)

    try:
        start_api()
    except KeyboardInterrupt:
        print("\n[run] 正在退出 …", flush=True)
    finally:
        if worker is not None and worker.poll() is None:
            worker.terminate()
            try:
                worker.wait(timeout=10)
            except subprocess.TimeoutExpired:
                worker.kill()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())