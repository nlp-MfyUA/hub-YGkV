"""问答与会话接口（设计文档 §8）。"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..schemas import ConversationDetail, ConversationSummary, MessageItem, QAResponse
from ..services.document_service import ValidationError

router = APIRouter(prefix="/api", tags=["qa"])


class QAForm(BaseModel):
    question: str = Field(..., description="问题")
    doc_scope: list[str] | None = Field(default=None, description="限定文档范围")
    conversation_id: str | None = Field(default=None, description="会话 ID")
    images: list[str] | None = Field(default=None, description="临时图片（data URL 或 base64）")


@router.post("/qa", response_model=QAResponse, summary="同步问答")
async def ask(request: Request, form: QAForm) -> QAResponse:
    service = request.app.state.services.qa
    try:
        result = service.ask(
            question=form.question,
            doc_scope=form.doc_scope,
            conversation_id=form.conversation_id,
            user_images=form.images,
        )
    except (ValueError, ValidationError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return QAResponse(**result)


@router.get("/conversations", response_model=list[ConversationSummary], summary="会话列表")
async def list_conversations(request: Request) -> list[ConversationSummary]:
    store = request.app.state.services.state
    out = []
    for row in store.list_conversations():
        messages = store.get_messages(row["conv_id"], limit=500)
        out.append(
            ConversationSummary(
                conversation_id=row["conv_id"],
                title=row["title"] or "新会话",
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                message_count=len(messages),
            )
        )
    return out


@router.get("/conversations/{conv_id}", response_model=ConversationDetail, summary="会话历史")
async def get_conversation(request: Request, conv_id: str) -> ConversationDetail:
    store = request.app.state.services.state
    row = store.get_conversation(conv_id)
    if row is None:
        raise HTTPException(status_code=404, detail="会话不存在")
    messages = store.get_messages(conv_id, limit=500)
    return ConversationDetail(
        conversation=ConversationSummary(
            conversation_id=row["conv_id"],
            title=row["title"] or "新会话",
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            message_count=len(messages),
        ),
        messages=[MessageItem(**m) for m in messages],
    )


@router.delete("/conversations/{conv_id}", summary="删除会话")
async def delete_conversation(request: Request, conv_id: str) -> dict[str, bool]:
    store = request.app.state.services.state
    if store.get_conversation(conv_id) is None:
        raise HTTPException(status_code=404, detail="会话不存在")
    store.delete_conversation(conv_id)
    return {"ok": True}
