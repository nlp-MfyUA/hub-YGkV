"""文档相关接口（设计文档 §8）。"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse

from ..core.logging_setup import get_logger
from ..schemas import (
    ActionResponse,
    DocumentListResponse,
    DocumentSummary,
    StatusResponse,
    UploadedFileResult,
    UploadResponse,
)
from ..services.document_service import ValidationError

logger = get_logger(__name__)

router = APIRouter(prefix="/api/documents", tags=["documents"])


def _service(request: Request):
    return request.app.state.services.documents


@router.post("/upload", response_model=UploadResponse, summary="多 PDF 上传")
async def upload_documents(request: Request, files: list[UploadFile] = File(...)) -> UploadResponse:
    service = _service(request)
    try:
        payloads = []
        for item in files:
            payloads.append((item.filename, await item.read()))
        accepted, rejected = service.upload(payloads)
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return UploadResponse(
        files=[UploadedFileResult(**item) for item in accepted],
        rejected=rejected,
    )


@router.get("", response_model=DocumentListResponse, summary="文档列表")
async def list_documents(request: Request) -> DocumentListResponse:
    documents = _service(request).list_documents()
    return DocumentListResponse(documents=[DocumentSummary(**d) for d in documents], total=len(documents))


@router.get("/status", response_model=StatusResponse, summary="批量状态查询（供轮询）")
async def document_status(
    request: Request,
    doc_ids: list[str] | None = Query(default=None, description="文档 ID 列表，缺省返回全部"),
) -> StatusResponse:
    from datetime import datetime, timezone

    documents = _service(request).statuses(doc_ids)
    return StatusResponse(
        documents=[DocumentSummary(**d) for d in documents],
        server_time=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
    )


@router.post("/{doc_id}/retry", response_model=ActionResponse, summary="失败重试")
async def retry_document(request: Request, doc_id: str) -> ActionResponse:
    try:
        result = _service(request).retry(doc_id)
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ActionResponse(**result)


@router.post("/{doc_id}/reparse", response_model=ActionResponse, summary="重新解析")
async def reparse_document(request: Request, doc_id: str) -> ActionResponse:
    try:
        result = _service(request).reparse(doc_id)
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ActionResponse(**result)


@router.delete("/{doc_id}", response_model=ActionResponse, summary="删除文档并清理关联数据")
async def delete_document(request: Request, doc_id: str) -> ActionResponse:
    try:
        result = _service(request).delete(doc_id)
    except ValidationError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return ActionResponse(**result)


@router.get("/{doc_id}/result", summary="下载解析结果")
async def download_result(request: Request, doc_id: str) -> FileResponse:
    try:
        archive = _service(request).result_bundle(doc_id)
    except ValidationError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(archive, media_type="application/zip", filename=f"{doc_id}_result.zip")


@router.get("/{doc_id}/images/{image_id}", summary="访问抽取图片")
async def get_image(request: Request, doc_id: str, image_id: str) -> FileResponse:
    try:
        path = _service(request).image_path(doc_id, image_id)
    except ValidationError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(path)


@router.get("/{doc_id}/pdf", summary="访问原 PDF（支持页码定位）")
async def get_pdf(request: Request, doc_id: str) -> FileResponse:
    try:
        path = _service(request).pdf_path(doc_id)
    except ValidationError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(path, media_type="application/pdf", filename=path.name)


@router.get("/{doc_id}/metadata", summary="查看解析元数据")
async def get_metadata(request: Request, doc_id: str) -> dict[str, Any]:
    metadata = _service(request).metadata(doc_id)
    if metadata is None:
        raise HTTPException(status_code=404, detail="元数据不存在")
    return metadata
