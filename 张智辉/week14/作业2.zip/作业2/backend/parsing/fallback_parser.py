"""兜底解析器（PyMuPDF）。

当本机没有安装 MinerU CLI 时使用，保证单机 Demo 的「上传→解析→检索→问答」链路可跑通。
输出的 ParsedDocument 结构与 MinerU 路径完全一致，因此下游无感知。

抽取内容：
- 每页文本块（含版面 bbox）
- 表格（find_tables，最佳努力）
- 内嵌图片（含在页面上的放置矩形 bbox）
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..core.logging_setup import get_logger
from .models import ImageAsset, ParsedDocument, TextBlock

logger = get_logger(__name__)


def parse_pdf_with_pymupdf(document_id: str, pdf_path: Path, output_dir: Path) -> ParsedDocument:
    import pymupdf

    parsed = ParsedDocument(
        document_id=document_id,
        engine="pymupdf-fallback",
        engine_version=getattr(pymupdf, "__version__", "unknown"),
        raw_dir=str(output_dir),
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    images_dir = output_dir / "_extracted"
    images_dir.mkdir(parents=True, exist_ok=True)

    doc = pymupdf.open(str(pdf_path))
    parsed.page_count = doc.page_count
    block_index = 0
    image_order = 0
    seen_xrefs: set[int] = set()

    for page_index in range(doc.page_count):
        page = doc.load_page(page_index)
        page_no = page_index + 1
        page_try = getattr(page, "try_get_text", None)
        text_dict: dict[str, Any] = page.get_text("dict")

        # ---------- 文本块 ----------
        for block in text_dict.get("blocks", []):
            if block.get("type", 0) != 0:
                continue
            lines = block.get("lines") or []
            parts: list[str] = []
            for line in lines:
                span_text = "".join(span.get("text", "") for span in line.get("spans", []))
                if span_text.strip():
                    parts.append(span_text.strip())
            text = "\n".join(parts).strip()
            if not text:
                continue
            bbox = tuple(float(v) for v in block.get("bbox", (0, 0, 0, 0)))
            parsed.text_blocks.append(
                TextBlock(
                    block_id=parsed.make_block_id(page_no, block_index, text),
                    text=text,
                    page=page_no,
                    bbox=bbox,
                    block_index=block_index,
                    kind="text",
                    source="pymupdf",
                )
            )
            block_index += 1

        # ---------- 表格（最佳努力） ----------
        try:
            finder = page.find_tables()
            for table in getattr(finder, "tables", []) or []:
                table_text = _table_to_text(table)
                if not table_text:
                    continue
                bbox = tuple(float(v) for v in (table.bbox or (0, 0, 0, 0)))
                parsed.text_blocks.append(
                    TextBlock(
                        block_id=parsed.make_block_id(page_no, block_index, table_text),
                        text=table_text,
                        page=page_no,
                        bbox=bbox,
                        block_index=block_index,
                        kind="table",
                        source="pymupdf",
                    )
                )
                block_index += 1
        except Exception as exc:  # noqa: BLE001
            logger.debug("表格抽取失败 page=%s: %s", page_no, exc)

        # ---------- 图片 ----------
        for info in page.get_images(full=True):
            xref = info[0]
            if xref in seen_xrefs:
                continue
            seen_xrefs.add(xref)
            try:
                rects = page.get_image_rects(xref)
            except Exception:  # noqa: BLE001
                rects = []
            bbox = tuple(float(v) for v in rects[0]) if rects else None
            try:
                extracted = doc.extract_image(xref)
            except Exception as exc:  # noqa: BLE001
                logger.debug("图片抽取失败 xref=%s: %s", xref, exc)
                continue
            data = extracted.get("image")
            if not data:
                continue
            image_id = parsed.make_image_id(page_no, image_order, f"{xref}.{extracted.get('ext','png')}")
            suffix = f".{extracted.get('ext', 'png')}"
            dest = images_dir / f"{image_id}{suffix}"
            try:
                dest.write_bytes(data)
            except OSError as exc:
                logger.warning("写入图片失败: %s", exc)
                continue
            asset = ImageAsset(
                image_id=image_id,
                filename=dest.name,
                source_path=str(dest),
                stored_path=str(dest),
                page=page_no,
                bbox=bbox,
                caption=f"第 {page_no} 页插图",
                order=image_order,
            )
            _fill_size(asset)
            parsed.images.append(asset)
            image_order += 1

    doc.close()
    logger.info("兜底解析完成 doc_id=%s 页数=%s 文本块=%s 图片=%s",
                document_id, parsed.page_count, len(parsed.text_blocks), len(parsed.images))
    return parsed


def _table_to_text(table: Any) -> str:
    try:
        rows = table.extract()
    except Exception:  # noqa: BLE001
        rows = []
    lines: list[str] = []
    for row in rows or []:
        cells = [str(c).strip() if c is not None else "" for c in row]
        if any(cells):
            lines.append(" | ".join(cells))
    return "\n".join(lines)


def _fill_size(asset: ImageAsset) -> None:
    try:
        from PIL import Image

        with Image.open(asset.stored_path) as img:
            asset.width, asset.height = img.size
    except Exception:  # noqa: BLE001
        pass