"""解析流水线（设计文档 §3.2）。

待解析 → 解析中 → （保存 MinerU 原始输出 → 抽取图片 → 生成 OCR/描述/嵌入
→ 分块 → 元数据 → 建索引 → 校验索引）→ 解析完成
任一步失败 → 解析失败 + 失败原因（不自动无限重试）
"""
from __future__ import annotations

import json
import shutil
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from ..core.state_store import StateStore
from ..core.storage import Storage
from ..rag.index_store import IndexStore
from . import fallback_parser, mineru_adapter
from .chunker import chunk_document
from .models import ImageAsset, ParsedDocument, TextBlock

logger = get_logger(__name__)


class ParsePipeline:
    def __init__(
        self,
        storage: Storage,
        state: StateStore,
        index: IndexStore,
        config: Config = CONFIG,
    ) -> None:
        self.storage = storage
        self.state = state
        self.index = index
        self.config = config

    # ------------------------------------------------------------------
    def run(self, message) -> dict[str, Any]:
        doc_id = message.document_id
        trace_id = message.trace_id or ""
        started = time.perf_counter()

        doc = self.state.get_document(doc_id)
        if doc is None:
            raise RuntimeError(f"文档不存在：{doc_id}")
        if doc["status"] == "completed":
            logger.info("[%s] 文档已是解析完成，幂等跳过 doc_id=%s", trace_id, doc_id)
            return {"doc_id": doc_id, "skipped": True, "reason": "already_completed"}

        self._prepare_for_parsing(doc_id, message)

        pdf_path = self.storage.doc_paths(doc_id).original
        if not pdf_path.is_file():
            raise RuntimeError(f"原文件不存在：{pdf_path}")

        paths = self.storage.create_document_dir(doc_id)
        try:
            parsed = self._parse(pdf_path, paths, trace_id)
            chunks = chunk_document(parsed, self.config.chunk_size, self.config.chunk_overlap)
            images = self._persist_images(parsed, paths)
            images = self._enrich_images(images, trace_id)
            self._build_metadata(doc_id, parsed, chunks, images, paths, message)
            stats = self.index.upsert_document(doc_id, chunks, images)
            self._verify_index(doc_id)
        except Exception as exc:  # noqa: BLE001
            duration = int((time.perf_counter() - started) * 1000)
            detail = traceback.format_exc()
            self.state.transition(doc_id, "failed", error_message=str(exc)[:2000])
            self.state.record_failure(doc_id, str(exc), message.task_id, trace_id, detail)
            self.storage.append_failure(
                doc_id,
                {
                    "task_id": message.task_id,
                    "trace_id": trace_id,
                    "message": str(exc),
                    "detail": detail,
                    "created_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                },
            )
            self.storage.append_log(doc_id, f"[{trace_id}] 解析失败：{exc}")
            logger.error("[%s] 解析失败 doc_id=%s: %s", trace_id, doc_id, exc)
            raise

        duration = int((time.perf_counter() - started) * 1000)
        self.state.transition(
            doc_id,
            "completed",
            extra={
                "parse_started_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                "parse_duration_ms": duration,
                "parser_engine": parsed.engine,
                "mineru_version": parsed.engine_version,
                "page_count": parsed.page_count,
            },
        )
        self.storage.append_log(doc_id, f"[{trace_id}] 解析完成，用时 {duration}ms，索引 {stats}")
        logger.info("[%s] 解析完成 doc_id=%s 用时=%sms %s", trace_id, doc_id, duration, stats)
        return {
            "doc_id": doc_id,
            "skipped": False,
            "duration_ms": duration,
            "engine": parsed.engine,
            "page_count": parsed.page_count,
            **stats,
        }

    # ------------------------------------------------------------------
    def _prepare_for_parsing(self, doc_id: str, message) -> None:
        doc = self.state.get_document(doc_id)
        status = doc["status"] if doc else "pending"
        if status == "failed":
            # 解析失败 → 待解析 → 解析中（设计文档 §5 的状态迁移）
            self.state.transition(doc_id, "pending")
        self.state.transition(
            doc_id,
            "parsing",
            task_id=message.task_id,
            extra={"parse_started_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds")},
            enforce=False,
        )
        self.storage.append_log(doc_id, f"[{message.trace_id}] 开始解析 task_id={message.task_id}")

    # ------------------------------------------------------------------
    def _parse(self, pdf_path: Path, paths, trace_id: str) -> ParsedDocument:
        binary = mineru_adapter.find_mineru_binary(self.config.mineru_command)
        if binary:
            try:
                return self._parse_with_mineru(pdf_path, paths, binary, trace_id)
            except Exception as exc:  # noqa: BLE001
                if not self.config.parser_fallback_enabled:
                    raise
                logger.warning("[%s] MinerU 解析失败，回退到兜底解析器：%s", trace_id, exc)
                self.storage.append_log(doc_id_safe(paths), f"[{trace_id}] MinerU 失败，回退兜底解析：{exc}")
        if not self.config.parser_fallback_enabled:
            raise RuntimeError("未安装 MinerU CLI，且已禁用兜底解析器")
        logger.info("[%s] 使用兜底解析器（PyMuPDF）", trace_id)
        return fallback_parser.parse_pdf_with_pymupdf(doc_id_safe(paths), pdf_path, paths.mineru_dir)

    def _parse_with_mineru(
        self, pdf_path: Path, paths, binary: str, trace_id: str
    ) -> ParsedDocument:
        version = mineru_adapter.mineru_version(binary)
        code, log = mineru_adapter.run_mineru(
            pdf_path,
            paths.mineru_dir,
            binary,
            extra_args=self.config.mineru_extra_args,
            timeout_seconds=self.config.parse_timeout_seconds,
            trace_id=trace_id,
        )
        self.storage.append_log(doc_id_safe(paths), f"[{trace_id}] MinerU 输出：\n{log[-8000:]}")
        if code != 0:
            raise RuntimeError(f"MinerU 退出码 {code}：{log[-1500:]}")
        return mineru_adapter.normalize_mineru_output(
            doc_id_safe(paths), paths.mineru_dir
        )

    # ------------------------------------------------------------------
    def _persist_images(self, parsed: ParsedDocument, paths) -> list[ImageAsset]:
        """把抽取图片统一复制到 文档ID/images/ 目录。"""
        target_dir = paths.images_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        kept: list[ImageAsset] = []
        for asset in parsed.images:
            if not asset.stored_path or not Path(asset.stored_path).is_file():
                continue
            suffix = Path(asset.stored_path).suffix or ".png"
            dest = target_dir / f"{asset.image_id}{suffix}"
            try:
                shutil.copy2(asset.stored_path, dest)
            except OSError as exc:
                logger.warning("复制图片失败：%s", exc)
                continue
            asset.stored_path = str(dest)
            asset.filename = dest.name
            kept.append(asset)
        return kept

    def _enrich_images(self, images: list[ImageAsset], trace_id: str) -> list[ImageAsset]:
        """为缺少描述的图片生成多模态描述（可选）。"""
        if not images or not self.config.image_caption_enabled:
            return images
        from ..rag.llm import MultimodalLLM

        llm = MultimodalLLM(self.config)
        if not llm.available:
            return images

        pending = [a for a in images if not a.description][: self.config.image_caption_max]
        if not pending:
            return images

        for asset in pending:
            try:
                description = llm.describe_image(
                    asset.stored_path, f"这是文档第 {asset.page} 页中的一张图片，请用一句话描述其内容。"
                )
                if description:
                    asset.description = description.strip()
            except Exception as exc:  # noqa: BLE001
                logger.debug("[%s] 图片描述生成失败 %s: %s", trace_id, asset.image_id, exc)
        return images

    # ------------------------------------------------------------------
    def _build_metadata(
        self,
        doc_id: str,
        parsed: ParsedDocument,
        chunks: list[TextBlock],
        images: list[ImageAsset],
        paths,
        message,
    ) -> None:
        doc = self.state.get_document(doc_id) or {}
        metadata = {
            "document_id": doc_id,
            "file_name": doc.get("file_name", ""),
            "file_size": doc.get("file_size", 0),
            "page_count": parsed.page_count,
            "uploaded_at": doc.get("uploaded_at"),
            "parser_engine": parsed.engine,
            "parser_version": parsed.engine_version,
            "raw_output_dir": str(paths.mineru_dir),
            "text_blocks": [
                {
                    "block_id": b.block_id,
                    "page": b.page,
                    "bbox": list(b.bbox) if b.bbox else None,
                    "kind": b.kind,
                    "caption": b.caption,
                    "section_path": b.section_path,
                    "text_preview": b.text[:300],
                    "length": len(b.text),
                }
                for b in chunks
            ],
            "images": [
                {
                    "image_id": a.image_id,
                    "filename": a.filename,
                    "page": a.page,
                    "bbox": list(a.bbox) if a.bbox else None,
                    "ocr_text": a.ocr_text,
                    "caption": a.caption,
                    "description": a.description,
                    "width": a.width,
                    "height": a.height,
                }
                for a in images
            ],
            "task_id": message.task_id,
            "trace_id": message.trace_id,
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        }
        self.storage.write_metadata(doc_id, metadata)

    def _verify_index(self, doc_id: str) -> None:
        stats = self.index.stats(doc_id)
        if stats["text_blocks"] == 0 and stats["images"] == 0:
            raise RuntimeError("索引为空，判定解析失败（一致性要求：只有索引就绪才允许置为解析完成）")


def doc_id_safe(paths) -> str:
    """从目录名反推文档 ID。"""
    return paths.root.name