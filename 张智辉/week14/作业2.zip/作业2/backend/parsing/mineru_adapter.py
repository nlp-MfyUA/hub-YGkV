"""本地 MinerU CLI 封装（设计文档 §2.2 组件 5）。

要点：
- 固定版本与命令，命令模板可通过配置覆盖；
- 保留原始输出的全部文件；
- 归一化 MinerU 的 content_list.json / middle.json 输出。

MinerU 版本差异：
- 2.x：``mineru -p <pdf> -o <out> -m auto``，产物含 ``*_content_list.json``、``*_middle.json``、``images/``
- 0.x：``magic-pdf -p <pdf> -o <out> -m auto``，产物结构相近
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from ..core.logging_setup import get_logger
from .models import ImageAsset, ParsedDocument, TextBlock

logger = get_logger(__name__)

MINERU_BINARIES = ("mineru", "magic-pdf")


def find_mineru_binary(configured: str = "") -> str | None:
    """返回可用的 MinerU 命令；找不到返回 None。"""
    if configured:
        return configured
    for name in MINERU_BINARIES:
        path = shutil.which(name)
        if path:
            return path
    return None


def mineru_version(binary: str) -> str:
    try:
        proc = subprocess.run(
            [binary, "--version"], capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace"
        )
        out = (proc.stdout or proc.stderr or "").strip().splitlines()
        return out[0].strip() if out else "unknown"
    except Exception as exc:  # noqa: BLE001
        logger.debug("读取 MinerU 版本失败: %s", exc)
        return "unknown"


def run_mineru(
    pdf_path: Path,
    output_dir: Path,
    binary: str,
    extra_args: str = "-m auto",
    timeout_seconds: int = 1800,
    trace_id: str = "",
) -> tuple[int, str]:
    """调用 MinerU CLI 解析 PDF。返回 (退出码, 合并后的日志)。"""
    output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [binary, "-p", str(pdf_path), "-o", str(output_dir)]
    cmd.extend([a for a in extra_args.split() if a])
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    logger.info("[%s] 调用 MinerU: %s", trace_id, " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(f"MinerU 解析超时（>{timeout_seconds}s）") from exc
    except FileNotFoundError as exc:
        raise RuntimeError(f"找不到 MinerU 命令: {binary}") from exc
    log = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, log


# ---------------------------------------------------------------- 输出归一化
def _find_content_list(output_dir: Path) -> Path | None:
    for pattern in ("*_content_list.json", "content_list.json", "*_middle.json"):
        matches = sorted(output_dir.rglob(pattern))
        if matches:
            return matches[0]
    return None


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("读取 MinerU 产物失败 %s: %s", path, exc)
        return None


def _middle_bboxes(output_dir: Path) -> dict[int, list[list[float]]]:
    """从 middle.json 收集每页的版面框，失败则返回空。"""
    boxes: dict[int, list[list[float]]] = {}
    for path in sorted(output_dir.rglob("*_middle.json")):
        data = _load_json(path)
        if not isinstance(data, dict):
            continue
        for page_no, page in (data.get("pdf_info") or {}).items():
            try:
                page_idx = int(page_no)
            except (TypeError, ValueError):
                continue
            items: list[list[float]] = []
            for block in page.get("para_blocks") or []:
                bbox = block.get("bbox")
                if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
                    items.append([float(v) for v in bbox])
            if items:
                boxes.setdefault(page_idx, []).extend(items)
    return boxes


def normalize_mineru_output(
    document_id: str, output_dir: Path, content_list: Path | None = None
) -> ParsedDocument:
    """把 MinerU 产物归一化为 ParsedDocument。"""
    parsed = ParsedDocument(document_id=document_id, engine="mineru", raw_dir=str(output_dir))
    content_list = content_list or _find_content_list(output_dir)
    if content_list is None:
        raise RuntimeError(f"MinerU 未产出 content_list.json（输出目录：{output_dir}）")

    raw = _load_json(content_list)
    if not isinstance(raw, list):
        raise RuntimeError(f"MinerU content_list.json 格式异常：{content_list}")

    page_counter: dict[int, int] = {}
    headings: list[str] = []
    section_stack: list[tuple[int, str]] = []
    image_order = 0
    block_index = 0

    for item in raw:
        if not isinstance(item, dict):
            continue
        itype = str(item.get("type", "text"))
        page_idx = int(item.get("page_idx", 0) or 0)
        page = page_idx + 1

        if itype == "text":
            text = (item.get("text") or "").strip()
            if not text:
                continue
            level = int(item.get("text_level", 0) or 0)
            if level and len(text) <= 120:
                # 维护标题层级，用于章节路径
                while section_stack and section_stack[-1][0] >= level:
                    section_stack.pop()
                section_stack.append((level, text))
                headings.append(text)
            section = " / ".join(t for _, t in section_stack)
            idx = page_counter.get(page, 0)
            page_counter[page] = idx + 1
            parsed.text_blocks.append(
                TextBlock(
                    block_id=parsed.make_block_id(page, block_index, text),
                    text=text,
                    page=page,
                    block_index=block_index,
                    kind="text",
                    caption="",
                    section_path=section,
                    source="mineru",
                )
            )
            block_index += 1
        elif itype == "equation":
            text = (item.get("text") or "").strip()
            if not text:
                continue
            idx = page_counter.get(page, 0)
            page_counter[page] = idx + 1
            parsed.text_blocks.append(
                TextBlock(
                    block_id=parsed.make_block_id(page, block_index, text),
                    text=text,
                    page=page,
                    block_index=block_index,
                    kind="equation",
                    source="mineru",
                )
            )
            block_index += 1
        elif itype == "table":
            body = (item.get("table_body") or "").strip()
            captions = item.get("table_caption") or []
            caption = " ".join(str(c) for c in captions).strip()
            text = (caption + "\n" + body).strip() if caption else body
            if not text:
                continue
            idx = page_counter.get(page, 0)
            page_counter[page] = idx + 1
            parsed.text_blocks.append(
                TextBlock(
                    block_id=parsed.make_block_id(page, block_index, text),
                    text=text,
                    page=page,
                    block_index=block_index,
                    kind="table",
                    caption=caption,
                    source="mineru",
                )
            )
            block_index += 1
        elif itype == "image":
            img_path = str(item.get("img_path") or "")
            captions = item.get("image_caption") or []
            caption = " ".join(str(c) for c in captions).strip()
            footnotes = item.get("image_footnote") or []
            footnote = " ".join(str(c) for c in footnotes).strip()
            image_id = parsed.make_image_id(page, image_order, img_path or caption)
            asset = ImageAsset(
                image_id=image_id,
                filename=Path(img_path).name if img_path else f"{image_id}.png",
                source_path=img_path,
                page=page,
                caption=caption,
                ocr_text=caption,
                description=footnote,
                order=image_order,
            )
            parsed.images.append(asset)
            image_order += 1

    # 图片落盘：MinerU 的 images/ 目录通常在 output_dir 或其子目录
    parsed.images = _materialize_images(parsed, output_dir)
    parsed.page_count = max(parsed.page_count, (max((b.page for b in parsed.text_blocks), default=1)))
    for asset in parsed.images:
        parsed.page_count = max(parsed.page_count, asset.page)
    return parsed



def _materialize_images(parsed: ParsedDocument, output_dir: Path) -> list[ImageAsset]:
    """把 MinerU 抽取的图片复制到统一目录，并补全尺寸。"""
    images_dir = output_dir / "images"
    if not images_dir.is_dir():
        # 有些版本把图片放在 output_dir/<name>/images 下
        candidates = [p for p in output_dir.rglob("images") if p.is_dir()]
        images_dir = candidates[0] if candidates else images_dir

    target_dir = output_dir / "_extracted"
    target_dir.mkdir(parents=True, exist_ok=True)

    for asset in parsed.images:
        src = output_dir / asset.source_path if asset.source_path else None
        if src is None or not src.is_file():
            # 按文件名在 images 目录里兜底查找
            if asset.filename:
                src = images_dir / asset.filename
        if src is None or not src.is_file():
            continue
        suffix = src.suffix or ".png"
        dest = target_dir / f"{asset.image_id}{suffix}"
        try:
            shutil.copy2(src, dest)
        except OSError as exc:
            logger.warning("复制图片失败 %s: %s", src, exc)
            continue
        asset.stored_path = str(dest)
        asset.filename = dest.name
        _fill_image_size(asset)
    return [a for a in parsed.images if a.stored_path]


def _fill_image_size(asset: ImageAsset) -> None:
    try:
        from PIL import Image

        with Image.open(asset.stored_path) as img:
            asset.width, asset.height = img.size
    except Exception:  # noqa: BLE001
        pass