"""解析产物统一模型（设计文档 §7.1）。

无论来自 MinerU 还是兜底解析器，都归一化为同一结构，
使后续「分块 → 元数据 → 索引 → 引用」链路完全一致。
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any


def _short_hash(*parts: str) -> str:
    raw = "|".join(str(p) for p in parts if p)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


@dataclass
class TextBlock:
    """一个可检索、可引用的文本片段。"""

    block_id: str
    text: str
    page: int                                   # 1-based 页码
    bbox: tuple[float, float, float, float] | None = None
    block_index: int = 0
    kind: str = "text"                           # text | table | equation | caption
    caption: str = ""
    section_path: str = ""                       # 标题层级路径
    source: str = "mineru"                       # mineru | fallback

    def to_dict(self) -> dict[str, Any]:
        return {
            "block_id": self.block_id,
            "text": self.text,
            "page": self.page,
            "bbox": list(self.bbox) if self.bbox else None,
            "block_index": self.block_index,
            "kind": self.kind,
            "caption": self.caption,
            "section_path": self.section_path,
            "source": self.source,
        }


@dataclass
class ImageAsset:
    """抽取出的图片（含页码与版面坐标，支持引用定位）。"""

    image_id: str
    filename: str
    source_path: str = ""                        # MinerU 原始输出中的相对路径
    stored_path: str = ""                        # 落盘后的绝对路径
    page: int = 1
    bbox: tuple[float, float, float, float] | None = None
    ocr_text: str = ""
    caption: str = ""
    description: str = ""
    width: int = 0
    height: int = 0
    order: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "image_id": self.image_id,
            "filename": self.filename,
            "source_path": self.source_path,
            "stored_path": self.stored_path,
            "page": self.page,
            "bbox": list(self.bbox) if self.bbox else None,
            "ocr_text": self.ocr_text,
            "caption": self.caption,
            "description": self.description,
            "width": self.width,
            "height": self.height,
            "order": self.order,
        }


@dataclass
class ParsedDocument:
    document_id: str
    page_count: int = 0
    text_blocks: list[TextBlock] = field(default_factory=list)
    images: list[ImageAsset] = field(default_factory=list)
    engine: str = "mineru"
    engine_version: str = ""
    raw_dir: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def make_block_id(self, page: int, index: int, text: str) -> str:
        return f"tb_{_short_hash(self.document_id, page, index, text[:120])}"

    def make_image_id(self, page: int, index: int, name: str) -> str:
        return f"img_{_short_hash(self.document_id, page, index, name)}"