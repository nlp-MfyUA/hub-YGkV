"""文本分块（设计文档 §3.2 步骤 7）。

长段落按字符数切分并保留重叠，表格/公式类短块不切分。
切分后仍然保留页码与版面坐标，保证引用可定位。
"""
from __future__ import annotations

import re
from typing import Iterable

from ..core.logging_setup import get_logger
from .models import ParsedDocument, TextBlock

logger = get_logger(__name__)

_SENTENCE_END = re.compile(r"(?<=[。！？!?；;\n])")


def split_text(text: str, chunk_size: int = 600, overlap: int = 80) -> list[str]:
    """按句子边界切分文本，带重叠窗口。"""
    text = text.strip()
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]

    sentences = [s for s in _SENTENCE_END.split(text) if s and s.strip()]
    if not sentences:
        sentences = [text]

    chunks: list[str] = []
    buffer = ""
    for sentence in sentences:
        while len(sentence) > chunk_size:
            # 超长句（无标点）直接硬切
            if buffer:
                chunks.append(buffer.strip())
                buffer = ""
            chunks.append(sentence[:chunk_size])
            sentence = sentence[chunk_size:]
        if not buffer:
            buffer = sentence
        elif len(buffer) + len(sentence) <= chunk_size:
            buffer += sentence
        else:
            chunks.append(buffer.strip())
            tail = buffer[-overlap:] if overlap > 0 else ""
            buffer = tail + sentence
    if buffer.strip():
        chunks.append(buffer.strip())
    return [c for c in chunks if c]


def chunk_document(
    parsed: ParsedDocument, chunk_size: int = 600, overlap: int = 80
) -> list[TextBlock]:
    """把解析结果切分为可检索文本块。"""
    result: list[TextBlock] = []
    index = 0
    for block in parsed.text_blocks:
        if block.kind in {"table", "equation"} or len(block.text) <= chunk_size:
            result.append(
                TextBlock(
                    block_id=parsed.make_block_id(block.page, index, block.text),
                    text=block.text,
                    page=block.page,
                    bbox=block.bbox,
                    block_index=index,
                    kind=block.kind,
                    caption=block.caption,
                    section_path=block.section_path,
                    source=block.source,
                )
            )
            index += 1
            continue

        for piece in split_text(block.text, chunk_size, overlap):
            result.append(
                TextBlock(
                    block_id=parsed.make_block_id(block.page, index, piece),
                    text=piece,
                    page=block.page,
                    bbox=block.bbox,
                    block_index=index,
                    kind=block.kind,
                    caption=block.caption,
                    section_path=block.section_path,
                    source=block.source,
                )
            )
            index += 1
    logger.info("分块完成 doc_id=%s 块数=%s", parsed.document_id, len(result))
    return result