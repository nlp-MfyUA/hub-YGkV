"""本地持久化队列（Kafka 的降级实现）。

语义对齐设计文档 §4：
- 一个 PDF 一条消息；
- Key = 文档 ID，先进先出保证同一文档顺序；
- 手动提交（消费成功后才置 done），失败也提交，避免阻塞；
- 消费失败消息不自动重投，由用户手动重试生成新消息。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

from ..core.logging_setup import get_logger
from .base import TaskMessage

logger = get_logger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS queue_messages (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    topic       TEXT NOT NULL,
    msg_key     TEXT NOT NULL,
    payload     TEXT NOT NULL,
    state       TEXT NOT NULL DEFAULT 'ready',
    created_at  REAL NOT NULL,
    consumed_at REAL
);
CREATE INDEX IF NOT EXISTS idx_queue_state ON queue_messages(state, seq);
"""


class LocalTaskQueue:
    """基于 SQLite 的可靠队列，进程重启不丢任务。"""

    name = "local-sqlite"

    def __init__(self, db_path: str | Path, topic: str) -> None:
        self.topic = topic
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._local = threading.local()
        with self._lock:
            self._conn.executescript(SCHEMA)

    @property
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.db_path), timeout=30, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=30000")
            self._local.conn = conn
        return conn

    # ------------------------------------------------------------------
    def publish(self, message: TaskMessage) -> None:
        payload = message.to_dict()
        payload["topic"] = self.topic
        with self._lock:
            self._conn.execute(
                "INSERT INTO queue_messages (topic, msg_key, payload, state, created_at) VALUES (?,?,?,?,?)",
                (self.topic, message.key, json.dumps(payload, ensure_ascii=False), "ready", time.time()),
            )
        logger.info("本地队列投递任务 doc_id=%s task_id=%s", message.document_id, message.task_id)

    def poll(self, timeout: float = 1.0) -> TaskMessage | None:
        deadline = time.time() + max(timeout, 0.1)
        while True:
            with self._lock:
                row = self._conn.execute(
                    "SELECT seq, payload FROM queue_messages WHERE state='ready' AND topic=? ORDER BY seq LIMIT 1",
                    (self.topic,),
                ).fetchone()
                if row is not None:
                    self._conn.execute(
                        "UPDATE queue_messages SET state='claimed' WHERE seq=?", (row["seq"],)
                    )
                    return TaskMessage.from_dict(json.loads(row["payload"]))
            if time.time() >= deadline:
                return None
            time.sleep(0.05)

    def commit(self, message: TaskMessage) -> None:
        """提交消费位点。失败也提交（对应设计文档：失败记录后提交，不阻塞队列）。"""
        with self._lock:
            self._conn.execute(
                "UPDATE queue_messages SET state='done', consumed_at=? WHERE payload LIKE ?",
                (time.time(), f'%"task_id": "{message.task_id}"%'),
            )

    def backlog(self) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) AS c FROM queue_messages WHERE state IN ('ready','claimed') AND topic=?",
            (self.topic,),
        ).fetchone()
        return int(row["c"]) if row else 0

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None