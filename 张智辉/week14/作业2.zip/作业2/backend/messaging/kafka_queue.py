"""Kafka 解析任务队列（设计文档 §4 的真实实现）。

- Topic：pdf-parse-task（可配置）
- Key：文档 ID → 同一文档的消息进入同一分区，保持顺序
- 消费者组：pdf-parse-worker
- 手动提交：处理成功提交；失败也提交（记录失败状态后提交，避免阻塞）
- 不做无限自动重投；重试由用户手动触发
"""
from __future__ import annotations

import json
from typing import Any

from ..core.logging_setup import get_logger
from .base import TaskMessage

logger = get_logger(__name__)


class KafkaTaskQueue:
    """kafka-python / kafka-python-ng 实现。"""

    name = "kafka"

    def __init__(
        self,
        bootstrap_servers: str,
        topic: str,
        group_id: str,
        client_id: str = "multimodal-rag",
        connect_timeout: float = 5.0,
        max_poll_records: int = 1,
        producer_only: bool = False,
    ) -> None:
        from kafka import KafkaConsumer, KafkaProducer  # 延迟导入，缺失时给出清晰提示

        self.topic = topic
        self.bootstrap_servers = bootstrap_servers
        self.group_id = group_id
        self.max_poll_records = max_poll_records
        self._producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            client_id=client_id,
            key_serializer=lambda k: k.encode("utf-8") if isinstance(k, str) else k,
            value_serializer=lambda v: v.encode("utf-8") if isinstance(v, str) else v,
            acks="all",
            retries=3,
            linger_ms=5,
            max_block_ms=max(int(connect_timeout * 1000), 1000),
        )
        self._consumer = None if producer_only else KafkaConsumer(
            topic,
            bootstrap_servers=bootstrap_servers,
            group_id=group_id,
            client_id=f"{client_id}-worker",
            enable_auto_commit=False,          # 手动提交
            auto_offset_reset="earliest",
            max_poll_records=max_poll_records,
            consumer_timeout_ms=1000,
            session_timeout_ms=30000,
            heartbeat_interval_ms=10000,
            api_version_auto_timeout_ms=int(connect_timeout * 1000),
        )
        logger.info(
            "Kafka 队列就绪 topic=%s brokers=%s group=%s role=%s",
            topic, bootstrap_servers, group_id, "producer" if producer_only else "worker",
        )

    # ------------------------------------------------------------------
    def publish(self, message: TaskMessage) -> None:
        payload = message.to_dict()
        payload["topic"] = self.topic
        future = self._producer.send(self.topic, key=message.key, value=json.dumps(payload, ensure_ascii=False))
        future.get(timeout=30)
        logger.info("Kafka 投递任务 doc_id=%s task_id=%s key=%s", message.document_id, message.task_id, message.key)

    def poll(self, timeout: float = 1.0) -> TaskMessage | None:
        if self._consumer is None:
            import time

            time.sleep(max(timeout, 0.1))
            return None
        batches = self._consumer.poll(timeout_ms=max(int(timeout * 1000), 100), max_records=self.max_poll_records)
        for _tp, records in batches.items():
            for record in records:
                raw = record.value
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                try:
                    return TaskMessage.from_dict(json.loads(raw))
                except (json.JSONDecodeError, TypeError):
                    logger.error("解析 Kafka 消息失败，丢弃: %r", raw)
        return None

    def commit(self, message: TaskMessage) -> None:
        if self._consumer is None:
            return
        try:
            self._consumer.commit()
        except Exception as exc:  # noqa: BLE001 - 提交失败不应中断业务
            logger.warning("Kafka 提交位点失败: %s", exc)

    def backlog(self) -> int:
        if self._consumer is None:
            return 0
        try:
            assignment = self._consumer.assignment()
            if not assignment:
                return 0
            total = 0
            for tp in assignment:
                position = self._consumer.position(tp)
                end = self._consumer.end_offsets([tp])[tp]
                total += max(end - position, 0)
            return total
        except Exception as exc:  # noqa: BLE001
            logger.debug("读取 Kafka 积压失败: %s", exc)
            return 0

    def close(self) -> None:
        for obj in (self._consumer, self._producer):
            if obj is None:
                continue
            try:
                obj.close()
            except Exception:  # noqa: BLE001
                pass