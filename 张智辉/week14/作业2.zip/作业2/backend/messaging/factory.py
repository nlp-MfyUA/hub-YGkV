"""队列工厂：优先使用真实 Kafka，不可用时按配置退化为本地持久化队列。"""
from __future__ import annotations

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from .base import TaskQueue
from .local_queue import LocalTaskQueue

logger = get_logger(__name__)


def create_task_queue(config: Config = CONFIG, producer_only: bool = False) -> TaskQueue:
    if not config.kafka_enabled:
        logger.warning("Kafka 已禁用，使用本地持久化队列")
        return _local_queue(config)

    try:
        from .kafka_queue import KafkaTaskQueue

        queue = KafkaTaskQueue(
            bootstrap_servers=config.kafka_bootstrap_servers,
            topic=config.kafka_topic,
            group_id=config.kafka_group_id,
            client_id=config.kafka_client_id,
            connect_timeout=config.kafka_connect_timeout,
            max_poll_records=config.kafka_max_poll_records,
            producer_only=producer_only,
        )
        logger.info("使用 Kafka 队列 topic=%s", config.kafka_topic)
        return queue
    except Exception as exc:  # noqa: BLE001
        if not config.kafka_fallback_local:
            logger.error("Kafka 不可用且未开启降级：%s", exc)
            raise
        logger.warning(
            "Kafka 不可用（%s），降级为本地持久化队列。生产环境请启动 Kafka：%s",
            exc, config.kafka_bootstrap_servers,
        )
        return _local_queue(config)


def _local_queue(config: Config) -> LocalTaskQueue:
    from pathlib import Path

    path = Path(config.storage_root) / "state" / "local_queue.db"
    return LocalTaskQueue(path, config.kafka_topic)