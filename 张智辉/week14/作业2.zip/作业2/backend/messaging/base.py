"""解析任务消息模型与队列抽象。

消息字段遵循设计文档 §4：schema 版本、任务 ID、文档 ID、用户 ID、原文件路径、
文件名、文件大小、页数、重试次数、提交时间、追踪 ID。
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol

SCHEMA_VERSION = "1.0"


@dataclass
class TaskMessage:
    schema_version: str = SCHEMA_VERSION
    task_id: str = ""
    document_id: str = ""
    user_id: str = "local"
    source_path: str = ""
    file_name: str = ""
    file_size: int = 0
    page_count: int = 0
    retry_count: int = 0
    submitted_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="milliseconds"))
    trace_id: str = ""
    topic: str = ""

    @property
    def key(self) -> str:
        """分区键：文档 ID，保证同一文档的消息有序。"""
        return self.document_id

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TaskMessage":
        allowed = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in allowed})


class TaskQueue(Protocol):
    """解析任务队列。Kafka 与本地持久化队列实现同一接口。"""

    name: str

    def publish(self, message: TaskMessage) -> None: ...
    def poll(self, timeout: float = 1.0) -> TaskMessage | None: ...
    def commit(self, message: TaskMessage) -> None: ...
    def backlog(self) -> int: ...
    def close(self) -> None: ...