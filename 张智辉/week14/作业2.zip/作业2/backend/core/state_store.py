"""状态库（设计文档 §6.1 / §5 状态机）。

SQLite + WAL：后端 API 与解析 Worker 分进程读写，WAL 允许并发读。
所有写入走事务，保证“状态更新 + 任务投递”可回溯。
"""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .logging_setup import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------- 状态机常量
STATUS_PENDING = "pending"      # 待解析
STATUS_PARSING = "parsing"      # 解析中
STATUS_COMPLETED = "completed"  # 解析完成
STATUS_FAILED = "failed"        # 解析失败
STATUS_DELETED = "deleted"      # 已删除（软标记，便于索引清理幂等）

STATUS_LABELS = {
    STATUS_PENDING: "待解析",
    STATUS_PARSING: "解析中",
    STATUS_COMPLETED: "解析完成",
    STATUS_FAILED: "解析失败",
    STATUS_DELETED: "已删除",
}

# 允许的状态迁移（设计文档 §5）
ALLOWED_TRANSITIONS = {
    STATUS_PENDING: {STATUS_PARSING, STATUS_FAILED, STATUS_DELETED},
    STATUS_PARSING: {STATUS_COMPLETED, STATUS_FAILED, STATUS_DELETED},
    STATUS_FAILED: {STATUS_PENDING, STATUS_DELETED},
    STATUS_COMPLETED: {STATUS_PENDING, STATUS_DELETED},
    STATUS_DELETED: set(),
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    doc_id            TEXT PRIMARY KEY,
    file_name         TEXT NOT NULL,
    file_size         INTEGER NOT NULL DEFAULT 0,
    file_hash         TEXT,
    page_count        INTEGER NOT NULL DEFAULT 0,
    status            TEXT NOT NULL,
    status_label      TEXT NOT NULL,
    retry_count       INTEGER NOT NULL DEFAULT 0,
    error_message     TEXT,
    trace_id          TEXT,
    task_id           TEXT,
    uploaded_at       TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    parse_started_at  TEXT,
    parse_finished_at TEXT,
    parse_duration_ms INTEGER,
    parser_engine     TEXT,
    mineru_version    TEXT,
    user_id           TEXT NOT NULL DEFAULT 'local'
);

CREATE TABLE IF NOT EXISTS tasks (
    task_id       TEXT PRIMARY KEY,
    doc_id        TEXT NOT NULL,
    trace_id      TEXT,
    state         TEXT NOT NULL,
    retry_count   INTEGER NOT NULL DEFAULT 0,
    submitted_at  TEXT NOT NULL,
    finished_at   TEXT,
    error         TEXT,
    payload       TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_doc ON tasks(doc_id);

CREATE TABLE IF NOT EXISTS failures (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id     TEXT NOT NULL,
    task_id    TEXT,
    trace_id   TEXT,
    message    TEXT NOT NULL,
    detail     TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_failures_doc ON failures(doc_id);

CREATE TABLE IF NOT EXISTS conversations (
    conv_id    TEXT PRIMARY KEY,
    title      TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
    msg_id        TEXT PRIMARY KEY,
    conv_id       TEXT NOT NULL,
    role          TEXT NOT NULL,
    content       TEXT NOT NULL,
    citations     TEXT,
    images        TEXT,
    doc_scope     TEXT,
    elapsed_ms    INTEGER,
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conv_id, created_at);
"""


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class StateStore:
    """线程安全的 SQLite 状态库封装。"""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._local = threading.local()
        self._init_schema()

    # ------------------------------------------------------------------ 连接
    @property
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.db_path), timeout=30, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=30000")
            self._local.conn = conn
        return conn

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            conn = self._conn
            conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except Exception:
                conn.execute("ROLLBACK")
                raise
            else:
                conn.execute("COMMIT")

    def _init_schema(self) -> None:
        with self._lock:
            self._conn.executescript(SCHEMA)

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None

    # ------------------------------------------------------------------ 文档
    def create_document(
        self,
        doc_id: str,
        file_name: str,
        file_size: int,
        file_hash: str | None = None,
        page_count: int = 0,
        trace_id: str | None = None,
        task_id: str | None = None,
        user_id: str = "local",
    ) -> None:
        now = utcnow()
        with self._tx() as conn:
            conn.execute(
                """INSERT INTO documents
                   (doc_id, file_name, file_size, file_hash, page_count, status, status_label,
                    retry_count, trace_id, task_id, uploaded_at, updated_at, user_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    doc_id, file_name, file_size, file_hash, page_count,
                    STATUS_PENDING, STATUS_LABELS[STATUS_PENDING],
                    0, trace_id, task_id, now, now, user_id,
                ),
            )

    def get_document(self, doc_id: str) -> dict[str, Any] | None:
        row = self._conn.execute("SELECT * FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
        return dict(row) if row else None

    def list_documents(self, user_id: str | None = None, include_deleted: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT * FROM documents WHERE 1=1"
        args: list[Any] = []
        if user_id:
            sql += " AND user_id=?"
            args.append(user_id)
        if not include_deleted:
            sql += " AND status != ?"
            args.append(STATUS_DELETED)
        sql += " ORDER BY uploaded_at DESC"
        return [dict(r) for r in self._conn.execute(sql, args).fetchall()]

    def list_statuses(self, doc_ids: list[str] | None = None) -> list[dict[str, Any]]:
        """批量状态查询，供前端轮询。"""
        if doc_ids:
            marks = ",".join("?" * len(doc_ids))
            rows = self._conn.execute(
                f"SELECT * FROM documents WHERE doc_id IN ({marks})", doc_ids
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM documents WHERE status != ?", (STATUS_DELETED,)
            ).fetchall()
        return [dict(r) for r in rows]

    def transition(
        self,
        doc_id: str,
        new_status: str,
        *,
        error_message: str | None = None,
        task_id: str | None = None,
        enforce: bool = True,
        extra: dict[str, Any] | None = None,
    ) -> bool:
        """按状态机迁移文档状态。返回是否成功。"""
        with self._tx() as conn:
            row = conn.execute("SELECT status, retry_count FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
            if row is None:
                return False
            current = row["status"]
            if enforce and new_status not in ALLOWED_TRANSITIONS.get(current, set()):
                logger.warning("非法状态迁移 %s: %s -> %s", doc_id, current, new_status)
                return False
            fields = ["status=?", "status_label=?", "updated_at=?"]
            args: list[Any] = [new_status, STATUS_LABELS.get(new_status, new_status), utcnow()]
            if error_message is not None:
                fields.append("error_message=?")
                args.append(error_message[:2000])
            elif new_status != STATUS_FAILED:
                fields.append("error_message=NULL")
            if task_id is not None:
                fields.append("task_id=?")
                args.append(task_id)
            for key, value in (extra or {}).items():
                if key in {
                    "retry_count", "parse_started_at", "parse_finished_at",
                    "parse_duration_ms", "parser_engine", "mineru_version", "page_count",
                }:
                    fields.append(f"{key}=?")
                    args.append(value)
            args.append(doc_id)
            conn.execute(f"UPDATE documents SET {', '.join(fields)} WHERE doc_id=?", args)
            return True

    def increment_retry(self, doc_id: str) -> int:
        with self._tx() as conn:
            conn.execute(
                "UPDATE documents SET retry_count = retry_count + 1, updated_at=? WHERE doc_id=?",
                (utcnow(), doc_id),
            )
            row = conn.execute("SELECT retry_count FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
            return int(row["retry_count"]) if row else 0

    def set_retry_count(self, doc_id: str, count: int) -> None:
        with self._tx() as conn:
            conn.execute(
                "UPDATE documents SET retry_count=?, updated_at=? WHERE doc_id=?",
                (count, utcnow(), doc_id),
            )

    def mark_deleted(self, doc_id: str) -> None:
        with self._tx() as conn:
            conn.execute(
                "UPDATE documents SET status=?, status_label=?, updated_at=? WHERE doc_id=?",
                (STATUS_DELETED, STATUS_LABELS[STATUS_DELETED], utcnow(), doc_id),
            )

    def hard_delete(self, doc_id: str) -> None:
        with self._tx() as conn:
            conn.execute("DELETE FROM documents WHERE doc_id=?", (doc_id,))
            conn.execute("DELETE FROM tasks WHERE doc_id=?", (doc_id,))
            conn.execute("DELETE FROM failures WHERE doc_id=?", (doc_id,))

    def record_failure(
        self, doc_id: str, message: str, task_id: str | None = None,
        trace_id: str | None = None, detail: str | None = None,
    ) -> None:
        with self._tx() as conn:
            conn.execute(
                "INSERT INTO failures (doc_id, task_id, trace_id, message, detail, created_at) VALUES (?,?,?,?,?,?)",
                (doc_id, task_id, trace_id, message[:2000], detail, utcnow()),
            )

    def list_failures(self, doc_id: str, limit: int = 20) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM failures WHERE doc_id=? ORDER BY id DESC LIMIT ?", (doc_id, limit)
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ 任务
    def create_task(
        self,
        doc_id: str,
        retry_count: int,
        payload: dict[str, Any],
        trace_id: str | None = None,
        task_id: str | None = None,
    ) -> str:
        task_id = task_id or uuid.uuid4().hex
        with self._tx() as conn:
            conn.execute(
                """INSERT INTO tasks (task_id, doc_id, trace_id, state, retry_count, submitted_at, payload)
                   VALUES (?,?,?,?,?,?,?)""",
                (task_id, doc_id, trace_id, "queued", retry_count, utcnow(), json.dumps(payload, ensure_ascii=False)),
            )
        return task_id

    def finish_task(self, task_id: str, state: str, error: str | None = None) -> None:
        with self._tx() as conn:
            conn.execute(
                "UPDATE tasks SET state=?, finished_at=?, error=? WHERE task_id=?",
                (state, utcnow(), error, task_id),
            )

    def get_task(self, task_id: str) -> dict[str, Any] | None:
        row = self._conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
        return dict(row) if row else None

    def pending_tasks(self) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE state='queued' ORDER BY submitted_at"
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ 会话
    def create_conversation(self, title: str = "新会话") -> str:
        conv_id = uuid.uuid4().hex
        now = utcnow()
        with self._tx() as conn:
            conn.execute(
                "INSERT INTO conversations (conv_id, title, created_at, updated_at) VALUES (?,?,?,?)",
                (conv_id, title, now, now),
            )
        return conv_id

    def get_conversation(self, conv_id: str) -> dict[str, Any] | None:
        row = self._conn.execute("SELECT * FROM conversations WHERE conv_id=?", (conv_id,)).fetchone()
        return dict(row) if row else None

    def list_conversations(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM conversations ORDER BY updated_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    def add_message(
        self,
        conv_id: str,
        role: str,
        content: str,
        citations: list[dict] | None = None,
        images: list[dict] | None = None,
        doc_scope: list[str] | None = None,
        elapsed_ms: int | None = None,
    ) -> str:
        msg_id = uuid.uuid4().hex
        now = utcnow()
        with self._tx() as conn:
            conn.execute(
                """INSERT INTO messages
                   (msg_id, conv_id, role, content, citations, images, doc_scope, elapsed_ms, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    msg_id, conv_id, role, content,
                    json.dumps(citations or [], ensure_ascii=False),
                    json.dumps(images or [], ensure_ascii=False),
                    json.dumps(doc_scope or [], ensure_ascii=False),
                    elapsed_ms, now,
                ),
            )
            conn.execute("UPDATE conversations SET updated_at=? WHERE conv_id=?", (now, conv_id))
        return msg_id

    def delete_conversation(self, conv_id: str) -> None:
        with self._tx() as conn:
            conn.execute("DELETE FROM messages WHERE conv_id=?", (conv_id,))
            conn.execute("DELETE FROM conversations WHERE conv_id=?", (conv_id,))

    def get_messages(self, conv_id: str, limit: int = 200) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM messages WHERE conv_id=? ORDER BY created_at LIMIT ?", (conv_id, limit)
        ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            for key in ("citations", "images", "doc_scope"):
                try:
                    item[key] = json.loads(item[key] or "[]")
                except json.JSONDecodeError:
                    item[key] = []
            out.append(item)
        return out