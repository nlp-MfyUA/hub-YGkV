"""统一日志配置：控制台 + 文件，附带追踪 ID。"""
from __future__ import annotations

import logging
import logging.handlers
import sys
import uuid
from pathlib import Path

from ..config import CONFIG

_CONFIGURED = False
_FMT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"


def setup_logging(level: str | None = None) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    level = (level or CONFIG.log_level).upper()
    root = logging.getLogger()
    root.setLevel(level)

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(logging.Formatter(_FMT))
    root.addHandler(console)

    try:
        log_dir = Path(CONFIG.storage_root) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            log_dir / "app.log", maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
        )
        file_handler.setFormatter(logging.Formatter(_FMT))
        root.addHandler(file_handler)
    except OSError:
        pass

    for noisy in ("urllib3", "httpx", "httpcore", "kafka"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    setup_logging()
    return logging.getLogger(name)


def new_trace_id() -> str:
    return uuid.uuid4().hex[:16]