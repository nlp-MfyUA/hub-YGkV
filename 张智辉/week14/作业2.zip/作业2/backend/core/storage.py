"""本地存储布局（设计文档 §6.1）。

data/
├── documents/{doc_id}/
│   ├── original.pdf            原文件
│   ├── mineru/                 MinerU 原始输出（全量保留）
│   ├── images/                 抽取图片
│   ├── metadata.json           元数据
│   ├── parse.log               解析日志
│   └── failures.jsonl          失败记录
├── index/index.db              文本索引 + 图片索引
├── state/state.db              状态库
├── conversations/              会话历史
└── tmp/uploads/                用户临时图片（当轮问答后清理）
"""
from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..config import CONFIG


@dataclass(frozen=True)
class DocPaths:
    root: Path

    @property
    def original(self) -> Path:
        return self.root / "original.pdf"

    @property
    def mineru_dir(self) -> Path:
        return self.root / "mineru"

    @property
    def images_dir(self) -> Path:
        return self.root / "images"

    @property
    def metadata(self) -> Path:
        return self.root / "metadata.json"

    @property
    def parse_log(self) -> Path:
        return self.root / "parse.log"

    @property
    def failures(self) -> Path:
        return self.root / "failures.jsonl"


class Storage:
    """所有本地路径的唯一出口，禁止业务代码拼接路径。"""

    def __init__(self, config=CONFIG) -> None:
        self.config = config
        self.root = Path(config.storage_root)

    # ------------------------------------------------------------------
    def ensure_layout(self) -> None:
        for path in (
            self.root,
            self.root / "documents",
            self.root / "index",
            self.root / "state",
            self.root / "conversations",
            self.root / "tmp" / "uploads",
        ):
            path.mkdir(parents=True, exist_ok=True)

    def doc_paths(self, doc_id: str) -> DocPaths:
        return DocPaths(self.root / "documents" / doc_id)

    def create_document_dir(self, doc_id: str) -> DocPaths:
        paths = self.doc_paths(doc_id)
        paths.root.mkdir(parents=True, exist_ok=True)
        paths.images_dir.mkdir(parents=True, exist_ok=True)
        paths.mineru_dir.mkdir(parents=True, exist_ok=True)
        return paths

    def document_exists(self, doc_id: str) -> bool:
        return self.doc_paths(doc_id).root.is_dir()

    # ------------------------------------------------------------------
    def save_original(self, doc_id: str, source: Path, filename: str) -> Path:
        paths = self.create_document_dir(doc_id)
        target = paths.original
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        return target

    def write_metadata(self, doc_id: str, metadata: dict[str, Any]) -> Path:
        paths = self.doc_paths(doc_id)
        paths.root.mkdir(parents=True, exist_ok=True)
        tmp = paths.metadata.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, paths.metadata)
        return paths.metadata

    def read_metadata(self, doc_id: str) -> dict[str, Any] | None:
        path = self.doc_paths(doc_id).metadata
        if not path.is_file():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

    def append_log(self, doc_id: str, line: str) -> None:
        paths = self.doc_paths(doc_id)
        paths.root.mkdir(parents=True, exist_ok=True)
        with paths.parse_log.open("a", encoding="utf-8") as handle:
            handle.write(line.rstrip() + "\n")

    def append_failure(self, doc_id: str, record: dict[str, Any]) -> None:
        paths = self.doc_paths(doc_id)
        paths.root.mkdir(parents=True, exist_ok=True)
        with paths.failures.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def read_failures(self, doc_id: str) -> list[dict[str, Any]]:
        path = self.doc_paths(doc_id).failures
        if not path.is_file():
            return []
        out: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return out

    # ------------------------------------------------------------------
    def temp_dir(self) -> Path:
        path = self.root / "tmp" / "uploads"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def cleanup_temp_images(self, paths: list[str | Path]) -> None:
        """问答结束后清理用户临时图片（设计文档 §6.4）。"""
        for raw in paths:
            if not raw:
                continue
            target = Path(raw)
            try:
                resolved = target.resolve()
                allowed = (self.root / "tmp").resolve()
                if allowed not in resolved.parents and resolved != allowed:
                    continue
                if resolved.is_file():
                    resolved.unlink()
            except OSError:
                continue

    def purge_temp_images(self) -> int:
        """清理过期的临时图片目录。"""
        temp = self.root / "tmp" / "uploads"
        if not temp.is_dir():
            return 0
        removed = 0
        for item in temp.iterdir():
            try:
                if item.is_file():
                    item.unlink()
                    removed += 1
                elif item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                    removed += 1
            except OSError:
                continue
        return removed

    # ------------------------------------------------------------------
    def delete_document(self, doc_id: str) -> bool:
        """删除文档的本地文件（原文件 / MinerU 输出 / 抽取图片 / 元数据）。"""
        paths = self.doc_paths(doc_id)
        if not paths.root.exists():
            return False
        shutil.rmtree(paths.root, ignore_errors=True)
        return True

    def clear_parsed_artifacts(self, doc_id: str) -> None:
        """重新解析前清理旧的 MinerU 输出与抽取图片（设计文档 §3.6）。"""
        paths = self.doc_paths(doc_id)
        for target in (paths.mineru_dir, paths.images_dir):
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
        target.mkdir(parents=True, exist_ok=True)

    def build_result_bundle(self, doc_id: str) -> Path | None:
        """把解析结果打包为 zip，供 /result 接口下载。"""
        import zipfile

        paths = self.doc_paths(doc_id)
        if not paths.root.exists():
            return None
        out_dir = self.root / "exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        archive = out_dir / f"{doc_id}_result.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
            for item in paths.root.rglob("*"):
                if item.is_file():
                    zf.write(item, item.relative_to(paths.root.parent))
        return archive