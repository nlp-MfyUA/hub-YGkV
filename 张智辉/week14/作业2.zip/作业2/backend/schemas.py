"""接口数据模型（设计文档 §8）。"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class UploadedFileResult(BaseModel):
    doc_id: str
    file_name: str
    file_size: int
    page_count: int
    status: str
    status_label: str
    task_id: str | None = None
    trace_id: str | None = None
    error: str | None = None


class UploadResponse(BaseModel):
    files: list[UploadedFileResult]
    rejected: list[dict[str, Any]] = Field(default_factory=list)


class DocumentSummary(BaseModel):
    doc_id: str
    file_name: str
    file_size: int
    page_count: int
    status: str
    status_label: str
    retry_count: int
    max_retries: int
    error_message: str | None = None
    uploaded_at: str
    updated_at: str
    parse_duration_ms: int | None = None
    parser_engine: str | None = None
    mineru_version: str | None = None
    trace_id: str | None = None


class DocumentListResponse(BaseModel):
    documents: list[DocumentSummary]
    total: int


class StatusResponse(BaseModel):
    documents: list[DocumentSummary]
    server_time: str


class ActionResponse(BaseModel):
    ok: bool
    doc_id: str
    status: str
    status_label: str
    message: str = ""
    task_id: str | None = None
    retry_count: int | None = None


class QARequest(BaseModel):
    question: str = Field(..., description="用户问题")
    doc_scope: list[str] | None = Field(default=None, description="限定文档范围（文档 ID 列表），为空表示全部已解析完成的文档")
    conversation_id: str | None = Field(default=None, description="会话 ID，缺省则新建会话")
    images: list[str] | None = Field(default=None, description="用户本轮上传的临时图片（base64 或文件名标记）")


class Citation(BaseModel):
    marker: str
    kind: str
    doc_id: str
    doc_name: str
    page: int
    item_id: str
    text: str = ""
    bbox: list[float] | None = None
    kind_label: str = "text"
    image_url: str = ""
    pdf_url: str = ""
    section_path: str = ""


class QAResponse(BaseModel):
    conversation_id: str
    answer: str
    citations: list[Citation] = Field(default_factory=list)
    images: list[dict[str, Any]] = Field(default_factory=list)
    elapsed_ms: int = 0
    mode: str = "llm"
    model: str = ""
    retrieved_count: int = 0
    used_markers: list[str] = Field(default_factory=list)
    invalid_markers: list[str] = Field(default_factory=list)
    error: str | None = None


class ConversationSummary(BaseModel):
    conversation_id: str
    title: str
    created_at: str
    updated_at: str
    message_count: int = 0


class MessageItem(BaseModel):
    msg_id: str
    role: str
    content: str
    citations: list[dict[str, Any]] = Field(default_factory=list)
    images: list[dict[str, Any]] = Field(default_factory=list)
    doc_scope: list[str] = Field(default_factory=list)
    elapsed_ms: int | None = None
    created_at: str


class ConversationDetail(BaseModel):
    conversation: ConversationSummary
    messages: list[MessageItem] = Field(default_factory=list)


class ApiError(BaseModel):
    detail: str
    code: str = "error"