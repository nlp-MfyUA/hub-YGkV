"""集中式配置。

优先级：环境变量 > 项目根目录 .env > 本文件默认值。
所有可调项与《多模态RAG问答系统设计文档》第 11.2 节“主要配置项”一一对应。
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """极简 .env 解析器，避免为两行代码引入额外依赖。"""
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _env(key: str, default: Any = None) -> Any:
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool) -> bool:
    raw = os.environ.get(key)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(key: str, default: int) -> int:
    raw = os.environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_float(key: str, default: float) -> float:
    raw = os.environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


@dataclass
class Config:
    # ---------- 通用 ----------
    app_name: str = "多模态RAG问答系统"
    host: str = "127.0.0.1"
    port: int = 8600
    storage_root: Path = BASE_DIR / "data"
    log_level: str = "INFO"

    # ---------- Kafka ----------
    kafka_enabled: bool = True
    kafka_bootstrap_servers: str = "127.0.0.1:9092"
    kafka_topic: str = "pdf-parse-task"
    kafka_group_id: str = "pdf-parse-worker"
    kafka_client_id: str = "multimodal-rag"
    kafka_connect_timeout: float = 5.0
    # Kafka 不可用时是否退化为本地持久化队列（单机 Demo 默认开启，保证开箱即用）
    kafka_fallback_local: bool = True
    kafka_max_poll_records: int = 1

    # ---------- 上传限制（设计文档 §10） ----------
    max_files_per_upload: int = 10
    max_file_size_mb: int = 50
    max_total_size_mb: int = 200
    max_pdf_pages: int = 300

    # ---------- 解析 ----------
    parse_timeout_seconds: int = 1800          # 单 PDF 30 分钟
    mineru_command: str = ""                    # 留空则自动探测 mineru / magic-pdf
    mineru_extra_args: str = "-m auto"
    mineru_version: str = "auto"
    # MinerU 不可用时的兜底解析器（PyMuPDF），保证 Demo 可运行
    parser_fallback_enabled: bool = True
    chunk_size: int = 600
    chunk_overlap: int = 80

    # ---------- 状态与重试 ----------
    max_retries: int = 3                       # 初始解析 + 最多 3 次手动重试
    poll_interval_seconds: float = 2.5

    # ---------- 检索 ----------
    retrieval_text_top_k: int = 8
    retrieval_image_top_k: int = 4
    retrieval_final_top_k: int = 10
    bm25_k1: float = 1.5
    bm25_b: float = 0.75
    max_context_chars: int = 12000
    max_context_images: int = 6

    # ---------- 嵌入模型 ----------
    embedding_provider: str = "auto"           # auto | openai | hash
    embedding_base_url: str = ""
    embedding_api_key: str = ""
    embedding_model: str = "BAAI/bge-m3"
    embedding_dim: int = 1024
    embedding_batch_size: int = 16
    # 图片多模态嵌入（CLIP 类）；未配置时回退到图片 OCR/描述的文本向量
    image_embedding_model: str = "OpenAI/clip-vit-base-patch32"

    # ---------- 多模态 LLM ----------
    llm_base_url: str = ""
    llm_api_key: str = ""
    llm_model: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    llm_timeout_seconds: int = 60
    llm_max_tokens: int = 2048
    llm_temperature: float = 0.2
    # 无 LLM 密钥时退化为“抽取式回答”，仍保留完整引用链路
    llm_fallback_extractive: bool = True
    llm_vision_enabled: bool = True

    # ---------- 图片描述 ----------
    image_caption_enabled: bool = True
    image_caption_max: int = 30

    # ---------- 会话 ----------
    conversation_history_turns: int = 6
    temp_image_ttl_seconds: int = 1800

    # ---------- 运行时 ----------
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    @property
    def documents_dir(self) -> Path:
        return self.storage_root / "documents"

    @property
    def index_dir(self) -> Path:
        return self.storage_root / "index"

    @property
    def state_db_path(self) -> Path:
        return self.storage_root / "state" / "state.db"

    @property
    def tmp_dir(self) -> Path:
        return self.storage_root / "tmp"

    @property
    def conversations_dir(self) -> Path:
        return self.storage_root / "conversations"

    def ensure_dirs(self) -> None:
        for path in (
            self.storage_root,
            self.documents_dir,
            self.index_dir,
            self.state_db_path.parent,
            self.tmp_dir,
            self.conversations_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)

    def public_dict(self) -> dict:
        data = asdict(self)
        data["storage_root"] = str(self.storage_root)
        data.pop("extra", None)
        # 脱敏
        for key in ("embedding_api_key", "llm_api_key"):
            if data.get(key):
                data[key] = "***"
        return data


def load_config() -> Config:
    _load_dotenv(BASE_DIR / ".env")

    storage_root = Path(_env("STORAGE_ROOT", str(BASE_DIR / "data"))).expanduser()

    cfg = Config(
        app_name=_env("APP_NAME", "多模态RAG问答系统"),
        host=_env("HOST", "127.0.0.1"),
        port=_env_int("PORT", 8600),
        storage_root=storage_root,
        log_level=_env("LOG_LEVEL", "INFO"),
        kafka_enabled=_env_bool("KAFKA_ENABLED", True),
        kafka_bootstrap_servers=_env("KAFKA_BOOTSTRAP_SERVERS", "127.0.0.1:9092"),
        kafka_topic=_env("KAFKA_TOPIC", "pdf-parse-task"),
        kafka_group_id=_env("KAFKA_GROUP_ID", "pdf-parse-worker"),
        kafka_client_id=_env("KAFKA_CLIENT_ID", "multimodal-rag"),
        kafka_connect_timeout=_env_float("KAFKA_CONNECT_TIMEOUT", 5.0),
        kafka_fallback_local=_env_bool("KAFKA_FALLBACK_LOCAL", True),
        kafka_max_poll_records=_env_int("KAFKA_MAX_POLL_RECORDS", 1),
        max_files_per_upload=_env_int("MAX_FILES_PER_UPLOAD", 10),
        max_file_size_mb=_env_int("MAX_FILE_SIZE_MB", 50),
        max_total_size_mb=_env_int("MAX_TOTAL_SIZE_MB", 200),
        max_pdf_pages=_env_int("MAX_PDF_PAGES", 300),
        parse_timeout_seconds=_env_int("PARSE_TIMEOUT_SECONDS", 1800),
        mineru_command=_env("MINERU_COMMAND", ""),
        mineru_extra_args=_env("MINERU_EXTRA_ARGS", "-m auto"),
        mineru_version=_env("MINERU_VERSION", "auto"),
        parser_fallback_enabled=_env_bool("PARSER_FALLBACK_ENABLED", True),
        chunk_size=_env_int("CHUNK_SIZE", 600),
        chunk_overlap=_env_int("CHUNK_OVERLAP", 80),
        max_retries=_env_int("MAX_RETRIES", 3),
        poll_interval_seconds=_env_float("POLL_INTERVAL_SECONDS", 2.5),
        retrieval_text_top_k=_env_int("RETRIEVAL_TEXT_TOP_K", 8),
        retrieval_image_top_k=_env_int("RETRIEVAL_IMAGE_TOP_K", 4),
        retrieval_final_top_k=_env_int("RETRIEVAL_FINAL_TOP_K", 10),
        bm25_k1=_env_float("BM25_K1", 1.5),
        bm25_b=_env_float("BM25_B", 0.75),
        max_context_chars=_env_int("MAX_CONTEXT_CHARS", 12000),
        max_context_images=_env_int("MAX_CONTEXT_IMAGES", 6),
        embedding_provider=_env("EMBEDDING_PROVIDER", "auto"),
        embedding_base_url=_env("EMBEDDING_BASE_URL", ""),
        embedding_api_key=_env("EMBEDDING_API_KEY", ""),
        embedding_model=_env("EMBEDDING_MODEL", "BAAI/bge-m3"),
        embedding_dim=_env_int("EMBEDDING_DIM", 1024),
        embedding_batch_size=_env_int("EMBEDDING_BATCH_SIZE", 16),
        image_embedding_model=_env("IMAGE_EMBEDDING_MODEL", "OpenAI/clip-vit-base-patch32"),
        llm_base_url=_env("LLM_BASE_URL", ""),
        llm_api_key=_env("LLM_API_KEY", ""),
        llm_model=_env("LLM_MODEL", "Qwen/Qwen2.5-VL-7B-Instruct"),
        llm_timeout_seconds=_env_int("LLM_TIMEOUT_SECONDS", 60),
        llm_max_tokens=_env_int("LLM_MAX_TOKETS", 2048),
        llm_temperature=_env_float("LLM_TEMPERATURE", 0.2),
        llm_fallback_extractive=_env_bool("LLM_FALLBACK_EXTRACTIVE", True),
        llm_vision_enabled=_env_bool("LLM_VISION_ENABLED", True),
        image_caption_enabled=_env_bool("IMAGE_CAPTION_ENABLED", True),
        image_caption_max=_env_int("IMAGE_CAPTION_MAX", 30),
        conversation_history_turns=_env_int("CONVERSATION_HISTORY_TURNS", 6),
        temp_image_ttl_seconds=_env_int("TEMP_IMAGE_TTL_SECONDS", 1800),
    )
    cfg.ensure_dirs()
    return cfg


CONFIG = load_config()