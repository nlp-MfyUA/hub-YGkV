"""嵌入模型（可插拔）。

设计文档 §11.2 要求「嵌入模型」可配置。本实现提供三种后端：

1. ``openai``  —— 任何 OpenAI 兼容的 /embeddings 服务
   （OpenAI / SiliconFlow / DashScope / 自建 vLLM、TEI 等）。
2. ``local``   —— sentence-transformers 本地模型（若已安装）。
3. ``hash``    —— 离线确定性字符 n-gram 哈希向量。
   无网络、无模型文件时使用，保证单机 Demo 的检索链路依然可用。

``auto`` 策略：优先 openai → local → hash。
"""
from __future__ import annotations

import base64
import hashlib
import math
import mimetypes
import re
from collections import Counter
from pathlib import Path
from typing import Sequence

import numpy as np

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger

logger = get_logger(__name__)

_CJK = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")
_LATIN = re.compile(r"[A-Za-z0-9_]+")
_STOP = {
    "的", "了", "和", "是", "在", "有", "与", "及", "或", "为", "对", "从", "到", "上", "下",
    "这", "那", "一个", "我们", "你们", "他们", "以及", "并且", "因此", "所以", "如果", "可以",
    "the", "a", "an", "of", "and", "or", "to", "in", "is", "are", "for", "on", "with",
}


def tokenize(text: str) -> list[str]:
    """中英文混合分词：中文取单字 + 二元组，英文取词，附带数字。"""
    if not text:
        return []
    text = text.lower()
    tokens: list[str] = []
    for match in _CJK.finditer(text):
        ch = match.group()
        if ch in _STOP:
            continue
        tokens.append(ch)
    cjk_chars = [c for c in text if _CJK.match(c)]
    for i in range(len(cjk_chars) - 1):
        bigram = cjk_chars[i] + cjk_chars[i + 1]
        if bigram not in _STOP:
            tokens.append(bigram)
    for match in _LATIN.finditer(text):
        word = match.group()
        if word in _STOP or len(word) < 2:
            continue
        tokens.append(word)
    return tokens


class HashEmbedder:
    """离线确定性嵌入：符号哈希 + 亚线性 TF + L2 归一化。"""

    name = "hash"

    def __init__(self, dim: int = 1024) -> None:
        self.dim = dim

    def embed(self, texts: Sequence[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, text in enumerate(texts):
            counts = Counter(tokenize(text))
            if not counts:
                continue
            for token, freq in counts.items():
                weight = 1.0 + math.log(freq)
                digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
                idx = int.from_bytes(digest[:4], "big") % self.dim
                sign = 1.0 if digest[4] % 2 == 0 else -1.0
                out[i, idx] += sign * weight
            norm = float(np.linalg.norm(out[i]))
            if norm > 0:
                out[i] /= norm
        return out


class OpenAICompatEmbedder:
    """OpenAI 兼容 /embeddings 客户端（支持图片的多模态 embedding）。"""

    name = "openai"

    def __init__(self, base_url: str, api_key: str, model: str, timeout: float = 60.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self._client = None

    def _http(self):
        if self._client is None:
            import httpx

            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            self._client = httpx.Client(timeout=self.timeout, headers=headers)
        return self._client

    def embed(self, texts: Sequence[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, 0), dtype=np.float32)
        payload = {"model": self.model, "input": list(texts), "encoding_format": "float"}
        resp = self._http().post(f"{self.base_url}/embeddings", json=payload)
        resp.raise_for_status()
        data = resp.json().get("data", [])
        vectors = [item.get("embedding", []) for item in data]
        if not vectors:
            raise RuntimeError("嵌入服务返回空结果")
        arr = np.asarray(vectors, dtype=np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return arr / norms

    def embed_images(self, paths: Sequence[str], model: str) -> np.ndarray:
        """CLIP 类多模态 embedding（服务需支持图片输入）。"""
        inputs = [_data_url(p) for p in paths]
        if not inputs:
            return np.zeros((0, 0), dtype=np.float32)
        payload = {"model": model, "input": inputs, "encoding_format": "float"}
        resp = self._http().post(f"{self.base_url}/embeddings", json=payload)
        resp.raise_for_status()
        data = resp.json().get("data", [])
        vectors = [item.get("embedding", []) for item in data]
        if not vectors:
            raise RuntimeError("图片嵌入服务返回空结果")
        arr = np.asarray(vectors, dtype=np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return arr / norms


def _data_url(path: str) -> str:
    mime, _ = mimetypes.guess_type(path)
    mime = mime or "image/png"
    with open(path, "rb") as handle:
        payload = base64.b64encode(handle.read()).decode("ascii")
    return f"data:{mime};base64,{payload}"


class Embedder:
    """对外统一入口：embed_texts / embed_query / embed_image_paths。"""

    def __init__(self, config: Config = CONFIG) -> None:
        self.config = config
        self.backend = self._select_backend()
        self.dim = config.embedding_dim
        logger.info("嵌入后端=%s 模型=%s", self.backend.name, getattr(self.backend, "model", "-"))

    def _select_backend(self):
        provider = (self.config.embedding_provider or "auto").lower()
        if provider == "openai":
            if not self.config.embedding_base_url or not self.config.embedding_api_key:
                raise RuntimeError("EMBEDDING_PROVIDER=openai 需要同时配置 EMBEDDING_BASE_URL 与 EMBEDDING_API_KEY")
            return OpenAICompatEmbedder(
                self.config.embedding_base_url,
                self.config.embedding_api_key,
                self.config.embedding_model,
            )
        if provider == "hash":
            return HashEmbedder(self.config.embedding_dim)
        # auto
        if self.config.embedding_base_url and self.config.embedding_api_key:
            try:
                return OpenAICompatEmbedder(
                    self.config.embedding_base_url,
                    self.config.embedding_api_key,
                    self.config.embedding_model,
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("嵌入服务不可用，回退到本地哈希向量: %s", exc)
        return HashEmbedder(self.config.embedding_dim)

    # ------------------------------------------------------------------
    def embed_texts(self, texts: Sequence[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dim), dtype=np.float32)
        if isinstance(self.backend, HashEmbedder):
            self.dim = self.backend.dim
            return self.backend.embed(texts)
        arr = self.backend.embed(texts)
        self.dim = arr.shape[1]
        return arr

    def embed_query(self, text: str) -> np.ndarray:
        return self.embed_texts([text])[0]

    def embed_image_paths(self, paths: Sequence[str]) -> np.ndarray | None:
        """图片多模态向量；不可用时返回 None（调用方回退到文本向量）。"""
        if not paths:
            return None
        if isinstance(self.backend, OpenAICompatEmbedder):
            try:
                arr = self.backend.embed_images(paths, self.config.image_embedding_model)
                self.dim = arr.shape[1]
                return arr
            except Exception as exc:  # noqa: BLE001
                logger.warning("图片多模态嵌入失败，回退到文本向量: %s", exc)
                return None
        return None