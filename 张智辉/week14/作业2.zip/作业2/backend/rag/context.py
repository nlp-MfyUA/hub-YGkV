"""上下文构造（设计文档 §7.4）。

- 文本片段：原文 + 文档名 + 页码 + 段落位置
- 图片：原图/抽取图 + 描述/OCR + 页码 + 版面坐标
- 用户临时图片：仅当轮作为多模态输入，不写入检索库
- 会话历史：历史问答文本与引用
"""
from __future__ import annotations

import base64
import io
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from .retriever import RetrievedItem

logger = get_logger(__name__)

SYSTEM_PROMPT = """你是「多模态 RAG 问答系统」的问答助手。

必须遵守以下规则：
1. 严格基于 <检索上下文> 中给出的资料回答，禁止编造上下文之外的信息。
2. 每个结论后面必须标注来源标记：文本来源用 [S1]、[S2]，图片来源用 [I1]、[I2]。
   只允许引用 <检索上下文> 中真实存在的标记。
3. 如果检索上下文不足以回答问题，直接回答「未找到依据」，并说明缺少哪部分信息。
4. 使用 Markdown 组织答案；需要说明图片时用「![说明](图片URL)」形式做图文混排，
   图片 URL 取自上下文给出的图片地址。
5. 使用与用户提问相同的语言作答；表述简洁、结构清晰。
6. 不要输出 <检索上下文> 之外的片段内容。
"""


@dataclass
class ContextBundle:
    text: str = ""
    images: list[dict[str, Any]] = field(default_factory=list)   # 检索到的图片（可作为附件）
    sources: list[RetrievedItem] = field(default_factory=list)

    def image_data_urls(self, limit: int | None = None) -> list[tuple[str, str]]:
        """返回 (marker, data_url) 列表，用于多模态输入。"""
        out: list[tuple[str, str]] = []
        for item in self.images:
            if not item.get("stored_path"):
                continue
            data_url = _to_data_url(item["stored_path"], self.max_side)
            if data_url:
                out.append((item.get("marker", ""), data_url))
            if limit and len(out) >= limit:
                break
        return out

    max_side: int = 1024


def _to_data_url(path: str, max_side: int = 1024) -> str | None:
    file_path = Path(path)
    if not file_path.is_file():
        return None
    try:
        from PIL import Image

        with Image.open(file_path) as img:
            img = img.convert("RGB")
            width, height = img.size
            scale = max_side / max(width, height, 1)
            if scale < 1:
                img = img.resize((max(int(width * scale), 1), max(int(height * scale), 1)))
            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=82)
        payload = base64.b64encode(buffer.getvalue()).decode("ascii")
        return f"data:image/jpeg;base64,{payload}"
    except Exception as exc:  # noqa: BLE001
        logger.warning("图片编码失败 %s: %s", path, exc)
        return None


def build_context(
    items: Sequence[RetrievedItem],
    config: Config = CONFIG,
    user_images: Sequence[str] | None = None,
) -> ContextBundle:
    """把检索结果组织成上下文文本与图片附件。"""
    bundle = ContextBundle()
    bundle.sources = list(items)

    parts: list[str] = []
    char_budget = config.max_context_chars
    used = 0

    text_items = [i for i in items if i.kind == "text"]
    image_items = [i for i in items if i.kind == "image"]

    for item in text_items:
        header = f"[{item.marker}] 文档：{item.doc_name} | 页码：第 {item.page} 页"
        if item.section_path:
            header += f" | 章节：{item.section_path}"
        if item.kind_label and item.kind_label != "text":
            header += f" | 类型：{item.kind_label}"
        snippet = item.text.strip()
        block = f"{header}\n{snippet}"
        if used + len(block) > char_budget:
            remaining = char_budget - used
            if remaining > 200:
                parts.append(block[:remaining] + "…")
                used = char_budget
            break
        parts.append(block)
        used += len(block)

    for item in image_items:
        header = f"[{item.marker}] 图片 | 文档：{item.doc_name} | 页码：第 {item.page} 页"
        details = " ".join(
            filter(None, [item.caption, item.ocr_text, item.description])
        ).strip()
        if details:
            header += f" | 说明：{details}"
        header += f" | 图片地址：{item.image_url}"
        parts.append(header)
        used += len(header)

    if user_images:
        parts.append(f"（用户本轮额外提供了 {len(user_images)} 张临时图片，已作为多模态输入一并提供）")

    bundle.text = "\n\n".join(parts) if parts else "（无检索结果）"
    bundle.images = [item.to_dict() for item in image_items]
    bundle.max_side = 1024
    return bundle


def format_history(messages: Sequence[dict[str, Any]]) -> list[dict[str, str]]:
    """把会话历史整理为多轮对话。"""
    history: list[dict[str, str]] = []
    for msg in messages:
        role = msg.get("role")
        content = (msg.get("content") or "").strip()
        if not content:
            continue
        if role == "user":
            history.append({"role": "user", "content": content})
        elif role == "assistant":
            history.append({"role": "assistant", "content": content})
    return history