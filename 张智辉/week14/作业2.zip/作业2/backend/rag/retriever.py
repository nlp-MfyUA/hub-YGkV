"""文本 + 图片联合检索与融合重排（设计文档 §7.3）。

流程：
1. 问题 → 查询向量；
2. 文本块向量召回 TopK；
3. 图片向量 / OCR / 描述召回 TopK；
4. BM25 关键词辅助召回；
5. RRF 融合去重 + 重排；
6. 统一结果结构，便于后续上下文构造与引用组装。
"""
from __future__ import annotations

import json
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Sequence

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from .embedder import Embedder, tokenize
from .index_store import IndexStore

logger = get_logger(__name__)

RRF_K = 60


@dataclass
class RetrievedItem:
    kind: str                                  # text | image
    doc_id: str = ""
    doc_name: str = ""
    page: int = 1
    item_id: str = ""
    text: str = ""
    score: float = 0.0
    bbox: list[float] | None = None
    kind_label: str = "text"                  # text | table | equation
    caption: str = ""
    ocr_text: str = ""
    description: str = ""
    image_url: str = ""
    stored_path: str = ""
    section_path: str = ""
    rank: int = 0
    marker: str = ""                           # S1 / I1
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "doc_id": self.doc_id,
            "doc_name": self.doc_name,
            "page": self.page,
            "item_id": self.item_id,
            "text": self.text,
            "score": round(self.score, 6),
            "bbox": self.bbox,
            "kind_label": self.kind_label,
            "caption": self.caption,
            "ocr_text": self.ocr_text,
            "description": self.description,
            "image_url": self.image_url,
            "section_path": self.section_path,
            "rank": self.rank,
            "marker": self.marker,
        }


def bm25_scores(query: str, documents: Sequence[str], k1: float, b: float) -> list[float]:
    """标准 BM25（对当前候选集实时计算，Demo 规模足够）。"""
    if not documents:
        return []
    tokenized = [tokenize(doc) for doc in documents]
    lengths = [len(t) for t in tokenized]
    avgdl = (sum(lengths) / len(lengths)) or 1.0
    n_docs = len(documents)

    df: Counter = Counter()
    for tokens in tokenized:
        df.update(set(tokens))

    query_tokens = tokenize(query)
    if not query_tokens:
        return [0.0] * n_docs
    query_counts = Counter(query_tokens)

    scores: list[float] = []
    for tokens, length in zip(tokenized, lengths):
        counts = Counter(tokens)
        score = 0.0
        for term, qtf in query_counts.items():
            tf = counts.get(term, 0)
            if tf == 0:
                continue
            df_t = df.get(term, 0)
            idf = math.log(1.0 + (n_docs - df_t + 0.5) / (df_t + 0.5))
            denom = tf + k1 * (1.0 - b + b * length / avgdl)
            score += idf * (tf * (k1 + 1.0)) / (denom + 1e-9)
        scores.append(score)
    return scores


def _rrf(ranked_lists: Sequence[Sequence[str]]) -> dict[str, float]:
    """Reciprocal Rank Fusion。"""
    fused: dict[str, float] = {}
    for ranking in ranked_lists:
        for rank, key in enumerate(ranking, start=1):
            fused[key] = fused.get(key, 0.0) + 1.0 / (RRF_K + rank)
    return fused


class Retriever:
    def __init__(
        self,
        index: IndexStore,
        embedder: Embedder | None = None,
        config: Config = CONFIG,
    ) -> None:
        self.index = index
        self.embedder = embedder or index.embedder
        self.config = config

    # ------------------------------------------------------------------
    def retrieve(
        self,
        query: str,
        doc_scope: Sequence[str] | None = None,
        doc_names: dict[str, str] | None = None,
        top_k: int | None = None,
    ) -> list[RetrievedItem]:
        top_k = top_k or self.config.retrieval_final_top_k
        query = (query or "").strip()
        if not query:
            return []
        doc_names = doc_names or {}

        query_vec = self.embedder.embed_query(query)

        # ---------- 文本 ----------
        text_hits = self.index.search_text(query_vec, doc_scope, top_k=self.config.retrieval_text_top_k * 3)
        text_candidates = self.index.keyword_candidates(doc_scope, kind="text")
        text_bm25 = bm25_scores(
            query, [r["text"] for r in text_candidates], self.config.bm25_k1, self.config.bm25_b
        )
        bm25_rank = sorted(
            range(len(text_candidates)),
            key=lambda i: text_bm25[i],
            reverse=True,
        )[: max(self.config.retrieval_text_top_k * 3, 10)]
        bm25_ids = {text_candidates[i]["block_id"]: rank for rank, i in enumerate(bm25_rank, start=1)}

        vector_rank = {hit["block_id"]: rank for rank, hit in enumerate(text_hits, start=1)}
        fused_text = _rrf([[h["block_id"] for h in text_hits], list(bm25_ids.keys())])
        by_id = {r["block_id"]: r for r in text_candidates}

        text_items: list[RetrievedItem] = []
        for block_id, score in fused_text.items():
            row = by_id.get(block_id)
            if row is None:
                continue
            text_items.append(
                RetrievedItem(
                    kind="text",
                    doc_id=row["doc_id"],
                    doc_name=doc_names.get(row["doc_id"], row["doc_id"]),
                    page=int(row["page"]),
                    item_id=row["block_id"],
                    text=row["text"],
                    score=score,
                    bbox=json.loads(row["bbox"]) if row["bbox"] else None,
                    kind_label=row["kind"] or "text",
                    caption=row["caption"] or "",
                    section_path=row["section_path"] or "",
                    meta={"vector_score": vector_rank.get(block_id), "bm25_rank": bm25_ids.get(block_id)},
                )
            )
        text_items.sort(key=lambda x: x.score, reverse=True)
        text_items = text_items[: self.config.retrieval_text_top_k]

        # ---------- 图片 ----------
        image_hits = self.index.search_images(query_vec, doc_scope, top_k=self.config.retrieval_image_top_k * 3)
        image_candidates = self.index.keyword_candidates(doc_scope, kind="images")
        image_texts = [
            " ".join(filter(None, [r["caption"], r["ocr_text"], r["description"]])) for r in image_candidates
        ]
        image_bm25 = bm25_scores(query, image_texts, self.config.bm25_k1, self.config.bm25_b)
        image_bm25_rank = sorted(range(len(image_candidates)), key=lambda i: image_bm25[i], reverse=True)[
            : max(self.config.retrieval_image_top_k * 3, 10)
        ]
        image_bm25_ids = {image_candidates[i]["image_id"]: rank for rank, i in enumerate(image_bm25_rank, start=1)}

        fused_images = _rrf([[h["image_id"] for h in image_hits], list(image_bm25_ids.keys())])
        image_by_id = {r["image_id"]: r for r in image_candidates}

        image_items: list[RetrievedItem] = []
        for image_id, score in fused_images.items():
            row = image_by_id.get(image_id)
            if row is None:
                continue
            image_items.append(
                RetrievedItem(
                    kind="image",
                    doc_id=row["doc_id"],
                    doc_name=doc_names.get(row["doc_id"], row["doc_id"]),
                    page=int(row["page"]),
                    item_id=row["image_id"],
                    text=" ".join(filter(None, [row["caption"], row["ocr_text"], row["description"]])).strip(),
                    score=score,
                    bbox=json.loads(row["bbox"]) if row["bbox"] else None,
                    caption=row["caption"] or "",
                    ocr_text=row["ocr_text"] or "",
                    description=row["description"] or "",
                    image_url=f"/api/documents/{row['doc_id']}/images/{row['image_id']}",
                    stored_path=row["stored_path"] or "",
                    meta={"bm25_rank": image_bm25_ids.get(image_id)},
                )
            )
        image_items.sort(key=lambda x: x.score, reverse=True)
        image_items = image_items[: self.config.retrieval_image_top_k]

        # ---------- 融合 ----------
        merged = text_items + image_items
        merged.sort(key=lambda x: x.score, reverse=True)
        merged = merged[:top_k]

        text_counter = 0
        image_counter = 0
        for rank, item in enumerate(merged, start=1):
            item.rank = rank
            if item.kind == "text":
                text_counter += 1
                item.marker = f"S{text_counter}"
            else:
                image_counter += 1
                item.marker = f"I{image_counter}"
        logger.info(
            "检索完成 query=%s 文本=%s 图片=%s 命中=%s",
            query[:40], len(text_items), len(image_items), len(merged),
        )
        return merged


