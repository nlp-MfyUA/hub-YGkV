"""检索索引（设计文档 §6.3）。

文本索引：文本块向量 + 关键词字段 + 文档 ID + 页码 + 段落位置
图片索引：图片向量/描述向量 + OCR 文本 + 文档 ID + 图片 ID + 页码 + 版面坐标

后端使用 SQLite（data/index/index.db）：
- 向量以 float32 BLOB 存储，删除文档时可事务化清理；
- 进程内缓存整矩阵（Demo 规模足够），写操作递增版本号使缓存失效。
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from ..parsing.models import ImageAsset, TextBlock
from .embedder import Embedder

logger = get_logger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS text_blocks (
    block_id      TEXT NOT NULL,
    doc_id        TEXT NOT NULL,
    page          INTEGER NOT NULL,
    bbox          TEXT,
    kind          TEXT,
    caption       TEXT,
    section_path  TEXT,
    block_index   INTEGER,
    text          TEXT NOT NULL,
    vector        BLOB,
    dim           INTEGER,
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_text_doc ON text_blocks(doc_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_text_pk ON text_blocks(doc_id, block_id);

CREATE TABLE IF NOT EXISTS images (
    image_id    TEXT NOT NULL,
    doc_id      TEXT NOT NULL,
    page        INTEGER NOT NULL,
    bbox        TEXT,
    filename    TEXT,
    stored_path TEXT,
    ocr_text    TEXT,
    caption     TEXT,
    description TEXT,
    width       INTEGER,
    height      INTEGER,
    ord         INTEGER,
    vector      BLOB,
    dim         INTEGER,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_images_doc ON images(doc_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_images_pk ON images(doc_id, image_id);

CREATE TABLE IF NOT EXISTS index_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


class IndexStore:
    def __init__(self, db_path: str | Path, embedder: Embedder | None = None, config: Config = CONFIG) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.embedder = embedder or Embedder(config)
        self.config = config
        self._lock = threading.RLock()
        self._local = threading.local()
        self._cache: dict[str, Any] = {}
        self._cache_version = -1
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._ensure_compatible_schema()

    def _ensure_compatible_schema(self) -> None:
        """主键结构变化时重建索引表（开发期兼容旧库）。"""
        try:
            rows = self._conn.execute("PRAGMA index_list(text_blocks)").fetchall()
            has_composite = any(r["name"] == "idx_text_pk" for r in rows)
            if not has_composite:
                self._conn.executescript(
                    "DROP TABLE IF EXISTS text_blocks; DROP TABLE IF EXISTS images;"
                )
                self._conn.executescript(SCHEMA)
        except Exception as exc:  # noqa: BLE001
            self._conn.rollback()
            logger.warning("索引表兼容性检查失败: %s", exc)

    # ------------------------------------------------------------------ 连接
    @property
    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.db_path), timeout=30, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=30000")
            self._local.conn = conn
        return conn

    # ------------------------------------------------------------------ 版本
    def _get_version(self) -> int:
        row = self._conn.execute("SELECT value FROM index_meta WHERE key='version'").fetchone()
        return int(row["value"]) if row else 0

    def _bump_version(self, conn: sqlite3.Connection) -> None:
        version = self._get_version() + 1
        conn.execute(
            "INSERT INTO index_meta(key,value) VALUES('version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (str(version),),
        )

    # ------------------------------------------------------------------ 写入
    def upsert_document(
        self, doc_id: str, blocks: Sequence[TextBlock], images: Sequence[ImageAsset]
    ) -> dict[str, Any]:
        """写入/覆盖某文档的文本与图片索引。"""
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat(timespec="milliseconds")

        texts = [b.text for b in blocks]
        text_vectors = self.embedder.embed_texts(texts) if texts else np.zeros((0, 1), dtype=np.float32)

        image_records: list[tuple[ImageAsset, np.ndarray | None]] = []
        if images:
            paths = [i.stored_path for i in images if i.stored_path]
            multi_vectors: np.ndarray | None = None
            if paths:
                multi_vectors = self.embedder.embed_image_paths(paths)
            cursor = 0
            for asset in images:
                vec = None
                if multi_vectors is not None and asset.stored_path:
                    vec = multi_vectors[cursor]
                    cursor += 1
                image_records.append((asset, vec))

        with self._lock:
            conn = self._conn
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute("DELETE FROM text_blocks WHERE doc_id=?", (doc_id,))
                conn.execute("DELETE FROM images WHERE doc_id=?", (doc_id,))
                for block, vector in zip(blocks, text_vectors):
                    conn.execute(
                        """INSERT INTO text_blocks
                           (block_id, doc_id, page, bbox, kind, caption, section_path,
                            block_index, text, vector, dim, created_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            block.block_id, doc_id, block.page,
                            json.dumps(list(block.bbox)) if block.bbox else None,
                            block.kind, block.caption, block.section_path, block.block_index,
                            block.text, vector.tobytes(), int(vector.shape[0]), now,
                        ),
                    )
                for asset, vector in image_records:
                    text_vec = None
                    if vector is None:
                        # 无多模态向量时，用图片 OCR/描述的文本向量兜底
                        caption_text = " ".join(filter(None, [asset.caption, asset.ocr_text, asset.description]))
                        if caption_text:
                            text_vec = self.embedder.embed_texts([caption_text])[0]
                    stored = vector if vector is not None else text_vec
                    if stored is None:
                        # 无 OCR/描述且无多模态向量：写入零向量以保持索引维度一致
                        stored = np.zeros(self.embedder.dim, dtype=np.float32)
                    conn.execute(
                        """INSERT INTO images
                           (image_id, doc_id, page, bbox, filename, stored_path, ocr_text,
                            caption, description, width, height, ord, vector, dim, created_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            asset.image_id, doc_id, asset.page,
                            json.dumps(list(asset.bbox)) if asset.bbox else None,
                            asset.filename, asset.stored_path, asset.ocr_text, asset.caption,
                            asset.description, asset.width, asset.height, asset.order,
                            stored.tobytes() if stored is not None else None,
                            int(stored.shape[0]) if stored is not None else None, now,
                        ),
                    )
                self._bump_version(conn)
            except Exception:
                conn.execute("ROLLBACK")
                raise
            else:
                conn.execute("COMMIT")
        self._cache.clear()
        logger.info("索引写入完成 doc_id=%s 文本块=%s 图片=%s", doc_id, len(blocks), len(images))
        return {"text_blocks": len(blocks), "images": len(images)}

    def delete_document(self, doc_id: str) -> None:
        with self._lock:
            conn = self._conn
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute("DELETE FROM text_blocks WHERE doc_id=?", (doc_id,))
                conn.execute("DELETE FROM images WHERE doc_id=?", (doc_id,))
                self._bump_version(conn)
            except Exception:
                conn.execute("ROLLBACK")
                raise
            else:
                conn.execute("COMMIT")
        self._cache.clear()
        logger.info("索引已清理 doc_id=%s", doc_id)

    # ------------------------------------------------------------------ 读取
    def _load_cache(self) -> dict[str, Any]:
        version = self._get_version()
        if self._cache and self._cache_version == version:
            return self._cache

        text_rows = self._conn.execute(
            "SELECT * FROM text_blocks"
        ).fetchall()
        image_rows = self._conn.execute("SELECT * FROM images ORDER BY doc_id, ord").fetchall()

        def to_matrix(rows: Sequence[sqlite3.Row]) -> np.ndarray:
            dims = {len(row["vector"]) // 4 for row in rows if row["vector"]}
            if not dims:
                return np.zeros((len(rows), 1), dtype=np.float32)
            dim = max(dims)
            matrix = np.zeros((len(rows), dim), dtype=np.float32)
            for i, row in enumerate(rows):
                blob = row["vector"]
                if not blob:
                    continue
                count = min(dim, len(blob) // 4)
                matrix[i, :count] = np.frombuffer(blob, dtype=np.float32, count=count)
            return matrix

        self._cache = {
            "text": {"rows": [dict(r) for r in text_rows], "matrix": to_matrix(text_rows)},
            "images": {"rows": [dict(r) for r in image_rows], "matrix": to_matrix(image_rows)},
        }
        self._cache_version = version
        return self._cache

    def _filter_rows(
        self, rows: Sequence[dict[str, Any]], matrix: np.ndarray, doc_scope: Sequence[str] | None
    ) -> tuple[list[dict[str, Any]], np.ndarray]:
        if not doc_scope:
            return list(rows), matrix
        allowed = set(doc_scope)
        indices = [i for i, row in enumerate(rows) if row["doc_id"] in allowed]
        if not indices:
            return [], np.zeros((0, matrix.shape[1] if matrix.ndim == 2 else 1), dtype=np.float32)
        return [rows[i] for i in indices], matrix[indices]

    def _align_query(self, query_vector: np.ndarray, matrix: np.ndarray) -> np.ndarray | None:
        """把查询向量对齐到索引维度；维度不一致时降级为全 0 得分并告警。"""
        if matrix.ndim != 2 or matrix.shape[0] == 0:
            return None
        dim = matrix.shape[1]
        query = query_vector.astype(np.float32).ravel()
        if query.shape[0] != dim:
            logger.warning(
                "索引维度(%s)与查询向量维度(%s)不一致，已降级为关键词检索；建议重建索引",
                dim, query.shape[0],
            )
            return np.zeros(dim, dtype=np.float32)
        return query

    def search_text(
        self, query_vector: np.ndarray, doc_scope: Sequence[str] | None = None, top_k: int = 20
    ) -> list[dict[str, Any]]:
        cache = self._load_cache()["text"]
        rows, matrix = self._filter_rows(cache["rows"], cache["matrix"], doc_scope)
        if not rows or matrix.size == 0:
            return []
        query = self._align_query(query_vector, matrix)
        if query is None:
            return []
        scores = matrix @ query
        order = np.argsort(-scores)[: max(top_k * 3, top_k)]
        out: list[dict[str, Any]] = []
        for idx in order:
            row = dict(rows[idx])
            row["vector_score"] = float(scores[idx])
            out.append(row)
        return out

    def search_images(
        self, query_vector: np.ndarray, doc_scope: Sequence[str] | None = None, top_k: int = 10
    ) -> list[dict[str, Any]]:
        cache = self._load_cache()["images"]
        rows, matrix = self._filter_rows(cache["rows"], cache["matrix"], doc_scope)
        if not rows or matrix.size == 0:
            return []
        query = self._align_query(query_vector, matrix)
        if query is None:
            return []
        scores = matrix @ query
        order = np.argsort(-scores)[: max(top_k * 3, top_k)]
        out: list[dict[str, Any]] = []
        for idx in order:
            row = dict(rows[idx])
            row["vector_score"] = float(scores[idx])
            out.append(row)
        return out

    def keyword_candidates(
        self, doc_scope: Sequence[str] | None = None, kind: str = "text"
    ) -> list[dict[str, Any]]:
        cache = self._load_cache()[kind]
        rows = cache["rows"]
        if doc_scope:
            allowed = set(doc_scope)
            rows = [r for r in rows if r["doc_id"] in allowed]
        return list(rows)

    def stats(self, doc_id: str | None = None) -> dict[str, Any]:
        cache = self._load_cache()
        text_rows = cache["text"]["rows"]
        image_rows = cache["images"]["rows"]
        if doc_id:
            text_rows = [r for r in text_rows if r["doc_id"] == doc_id]
            image_rows = [r for r in image_rows if r["doc_id"] == doc_id]
        return {
            "text_blocks": len(text_rows),
            "images": len(image_rows),
            "documents": len({r["doc_id"] for r in text_rows} | {r["doc_id"] for r in image_rows}),
        }

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None