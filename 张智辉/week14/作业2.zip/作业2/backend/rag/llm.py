"""多模态 LLM 接入与引用校验（设计文档 §7.5 / §13）。

- 使用任何 OpenAI 兼容的 chat/completions 接口（支持 image_url 多模态内容块）。
- 输入：系统提示 + 检索上下文 + 会话历史 + 用户文字 + 用户临时图片 + 检索到的图片。
- 输出：图文混排答案 + 引用标记；后端校验标记合法性，防止引用幻觉。
- 未配置 LLM 时退化为「抽取式回答」，保留完整引用链路，便于本地演示。
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Sequence

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from .context import ContextBundle, SYSTEM_PROMPT

logger = get_logger(__name__)

MARKER_RE = re.compile(r"\[([SI]\d+)\]")


@dataclass
class LLMResult:
    text: str
    mode: str = "llm"                 # llm | extractive
    elapsed_ms: int = 0
    used_markers: list[str] = field(default_factory=list)
    invalid_markers: list[str] = field(default_factory=list)
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    error: str | None = None


class MultimodalLLM:
    """多模态 LLM 客户端（OpenAI 兼容协议）。"""

    def __init__(self, config: Config = CONFIG) -> None:
        self.config = config
        self.base_url = (config.llm_base_url or "").rstrip("/")
        self.api_key = config.llm_api_key or ""
        self.model = config.llm_model
        self.available = bool(self.base_url and self.api_key)

    # ------------------------------------------------------------------
    def answer(
        self,
        question: str,
        bundle: ContextBundle,
        history: Sequence[dict[str, str]] = (),
        user_images: Sequence[str] = (),
    ) -> LLMResult:
        if not self.available:
            if not self.config.llm_fallback_extractive:
                return LLMResult(text="未配置多模态 LLM，无法生成回答。", mode="disabled", error="llm_not_configured")
            return self._extractive(question, bundle)

        start = time.perf_counter()
        try:
            text, usage = self._chat(question, bundle, history, user_images)
        except Exception as exc:  # noqa: BLE001
            elapsed = int((time.perf_counter() - start) * 1000)
            logger.error("LLM 调用失败: %s", exc)
            if self.config.llm_fallback_extractive:
                result = self._extractive(question, bundle)
                result.elapsed_ms = elapsed
                result.error = str(exc)
                result.mode = "extractive-fallback"
                return result
            return LLMResult(text=f"调用多模态 LLM 失败：{exc}", mode="error", elapsed_ms=elapsed, error=str(exc))

        elapsed = int((time.perf_counter() - start) * 1000)
        used, invalid = validate_markers(text, bundle)
        logger.info("LLM 回答完成 mode=llm 耗时=%sms 引用=%s", elapsed, used)
        return LLMResult(
            text=text,
            mode="llm",
            elapsed_ms=elapsed,
            used_markers=used,
            invalid_markers=invalid,
            model=self.model,
            prompt_tokens=int(usage.get("prompt_tokens", 0)),
            completion_tokens=int(usage.get("completion_tokens", 0)),
        )

    # ------------------------------------------------------------------
    def _chat(
        self,
        question: str,
        bundle: ContextBundle,
        history: Sequence[dict[str, str]],
        user_images: Sequence[str],
    ) -> tuple[str, dict[str, Any]]:
        import httpx

        messages: list[dict[str, Any]] = [{"role": "system", "content": SYSTEM_PROMPT}]
        for turn in history:
            messages.append({"role": turn["role"], "content": turn["content"]})

        content_parts: list[dict[str, Any]] = [
            {"type": "text", "text": f"<检索上下文>\n{bundle.text}\n</检索上下文>"}
        ]

        # 检索到的图片（受 max_context_images 限制）
        for marker, data_url in bundle.image_data_urls(limit=self.config.max_context_images):
            content_parts.append({"type": "text", "text": f"图片 {marker}："})
            content_parts.append({"type": "image_url", "image_url": {"url": data_url}})

        # 用户本轮上传的临时图片（仅当轮）
        if user_images and self.config.llm_vision_enabled:
            for path in user_images:
                from .context import _to_data_url

                data_url = _to_data_url(path)
                if data_url:
                    content_parts.append({"type": "image_url", "image_url": {"url": data_url}})

        content_parts.append({"type": "text", "text": f"\n问题：{question}"})
        messages.append({"role": "user", "content": content_parts})

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.config.llm_temperature,
            "max_tokens": self.config.llm_max_tokens,
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        with httpx.Client(timeout=self.config.llm_timeout_seconds, headers=headers) as client:
            resp = client.post(f"{self.base_url}/chat/completions", json=payload)
            resp.raise_for_status()
            data = resp.json()

        choices = data.get("choices") or []
        if not choices:
            raise RuntimeError("LLM 返回缺少 choices")
        message = choices[0].get("message") or {}
        content = message.get("content")
        if isinstance(content, list):  # 兼容部分网关的多段内容
            content = "\n".join(part.get("text", "") for part in content if isinstance(part, dict))
        return str(content or ""), data.get("usage") or {}

    # ------------------------------------------------------------------
    def describe_image(self, image_path: str, prompt: str) -> str:
        """为抽取图片生成一句话描述（用于图片检索的语义召回）。"""
        if not self.available or not self.config.llm_vision_enabled:
            return ""
        import httpx

        from .context import _to_data_url

        data_url = _to_data_url(image_path)
        if not data_url:
            return ""
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }
            ],
            "temperature": 0.1,
            "max_tokens": 200,
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        with httpx.Client(timeout=self.config.llm_timeout_seconds, headers=headers) as client:
            resp = client.post(f"{self.base_url}/chat/completions", json=payload)
            resp.raise_for_status()
            data = resp.json()
        choices = data.get("choices") or []
        if not choices:
            return ""
        content = (choices[0].get("message") or {}).get("content") or ""
        if isinstance(content, list):
            content = " ".join(part.get("text", "") for part in content if isinstance(part, dict))
        return str(content).strip()

    # ------------------------------------------------------------------
    def _extractive(self, question: str, bundle: ContextBundle) -> LLMResult:
        """无 LLM 时的抽取式回答：只复述检索到的原文片段，不做生成。"""
        start = time.perf_counter()
        text_items = [s for s in bundle.sources if s.kind == "text"]
        image_items = [s for s in bundle.sources if s.kind == "image"]
        lines = [
            "> 当前未配置多模态 LLM 服务，以下为**抽取式回答**（直接引用检索到的原文片段，不做生成式改写）。",
            "",
        ]
        if not text_items and not image_items:
            lines.append("未找到依据：检索库中没有与该问题相关的内容。")
        else:
            lines.append(f"针对「{question}」，检索到 {len(text_items)} 段相关文本、{len(image_items)} 张相关图片：")
            lines.append("")
            for item in text_items[:6]:
                snippet = item.text.strip()
                if len(snippet) > 600:
                    snippet = snippet[:600] + "…"
                lines.append(f"**[{item.marker}] {item.doc_name} · 第 {item.page} 页**")
                lines.append("")
                lines.append(snippet)
                lines.append("")
            if image_items:
                lines.append("**相关图片**")
                lines.append("")
                for item in image_items:
                    desc = item.caption or item.description or item.ocr_text or "（无描述）"
                    lines.append(f"- [{item.marker}] {item.doc_name} · 第 {item.page} 页 — {desc}")
        elapsed = int((time.perf_counter() - start) * 1000)
        used, invalid = validate_markers("\n".join(lines), bundle)
        return LLMResult(text="\n".join(lines), mode="extractive", elapsed_ms=elapsed, used_markers=used, invalid_markers=invalid)


def validate_markers(text: str, bundle: ContextBundle) -> tuple[list[str], list[str]]:
    """校验 LLM 输出的引用标记，返回 (合法标记, 非法标记)。"""
    valid = {item.marker for item in bundle.sources if item.marker}
    found = MARKER_RE.findall(text or "")
    used: list[str] = []
    invalid: list[str] = []
    for marker in found:
        if marker in valid:
            if marker not in used:
                used.append(marker)
        elif marker not in invalid:
            invalid.append(marker)
    return used, invalid


def build_citations(
    bundle: ContextBundle, used_markers: Sequence[str], doc_names: dict[str, str] | None = None
) -> list[dict[str, Any]]:
    """把引用标记组装成前端可渲染的引用列表。"""
    marker_set = set(used_markers or [])
    citations: list[dict[str, Any]] = []
    for item in bundle.sources:
        if marker_set and item.marker not in marker_set:
            continue
        citation = {
            "marker": item.marker,
            "kind": item.kind,
            "doc_id": item.doc_id,
            "doc_name": doc_names.get(item.doc_id, item.doc_name) if doc_names else item.doc_name,
            "page": item.page,
            "item_id": item.item_id,
            "text": (item.text or "")[:800],
            "bbox": item.bbox,
            "kind_label": item.kind_label,
            "image_url": item.image_url,
            "pdf_url": f"/api/documents/{item.doc_id}/pdf#page={item.page}",
            "section_path": item.section_path,
        }
        citations.append(citation)
    return citations