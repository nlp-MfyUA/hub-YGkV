"""问答服务（设计文档 §3.5）。

同步 HTTP，60 秒超时，不经过 Kafka，不流式。
流程：校验 → 保存临时图片 → 限定文档范围 → 检索 → 构造上下文
→ 多模态 LLM → 校验引用 → 组装引用列表 → 存会话 → 清理临时图片。
"""
from __future__ import annotations

import base64
import binascii
import time
import uuid
from pathlib import Path
from typing import Any, Sequence

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from ..core.state_store import StateStore, STATUS_COMPLETED
from ..core.storage import Storage
from ..rag.context import build_context, format_history
from ..rag.llm import MultimodalLLM, build_citations
from ..rag.retriever import Retriever

logger = get_logger(__name__)

MAX_QUESTION_CHARS = 2000
ALLOWED_IMAGE_SUFFIX = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}


class QAService:
    def __init__(
        self,
        storage: Storage,
        state: StateStore,
        retriever: Retriever,
        llm: MultimodalLLM,
        config: Config = CONFIG,
    ) -> None:
        self.storage = storage
        self.state = state
        self.retriever = retriever
        self.llm = llm
        self.config = config

    # ------------------------------------------------------------------
    def ask(
        self,
        question: str,
        doc_scope: Sequence[str] | None = None,
        conversation_id: str | None = None,
        user_images: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        question = (question or "").strip()
        if not question:
            raise ValueError("问题不能为空")
        if len(question) > MAX_QUESTION_CHARS:
            raise ValueError(f"问题过长（最多 {MAX_QUESTION_CHARS} 字）")

        # ---------- 会话 ----------
        if conversation_id and self.state.get_conversation(conversation_id):
            conv_id = conversation_id
        else:
            conv_id = self.state.create_conversation(title=question[:40])

        # ---------- 临时图片（仅当轮） ----------
        temp_files = self._save_temp_images(conv_id, user_images or [])
        try:
            # ---------- 检索范围 ----------
            scope = self._resolve_scope(doc_scope)
            doc_names = {row["doc_id"]: row["file_name"] for row in self.state.list_documents()}

            items = self.retriever.retrieve(question, doc_scope=scope, doc_names=doc_names)
            bundle = build_context(items, self.config, user_images=[str(p) for p in temp_files])

            history_msgs = self.state.get_messages(conv_id, limit=self.config.conversation_history_turns * 2)
            history = format_history(history_msgs[-self.config.conversation_history_turns * 2 :])

            result = self.llm.answer(question, bundle, history=history, user_images=[str(p) for p in temp_files])

            citations = build_citations(bundle, result.used_markers, doc_names)
            images = [
                {
                    "marker": item.get("marker"),
                    "image_url": item.get("image_url"),
                    "doc_id": item.get("doc_id"),
                    "doc_name": item.get("doc_name"),
                    "page": item.get("page"),
                    "bbox": item.get("bbox"),
                    "caption": item.get("caption"),
                    "description": item.get("description"),
                    "ocr_text": item.get("ocr_text"),
                }
                for item in bundle.images
            ]

            elapsed = int((time.perf_counter() - started) * 1000)
            self.state.add_message(
                conv_id, "user", question, doc_scope=list(scope) if scope else [], elapsed_ms=None
            )
            self.state.add_message(
                conv_id,
                "assistant",
                result.text,
                citations=citations,
                images=images,
                doc_scope=list(scope) if scope else [],
                elapsed_ms=elapsed,
            )

            logger.info(
                "问答完成 conv=%s 命中=%s 引用=%s 耗时=%sms mode=%s",
                conv_id, len(items), len(citations), elapsed, result.mode,
            )
            return {
                "conversation_id": conv_id,
                "answer": result.text,
                "citations": citations,
                "images": images,
                "elapsed_ms": elapsed,
                "mode": result.mode,
                "model": result.model,
                "retrieved_count": len(items),
                "used_markers": result.used_markers,
                "invalid_markers": result.invalid_markers,
                "error": result.error,
            }
        finally:
            # 问答完成后清理用户临时图片（设计文档 §6.4）
            self.storage.cleanup_temp_images([str(p) for p in temp_files])

    # ------------------------------------------------------------------
    def _resolve_scope(self, doc_scope: Sequence[str] | None) -> list[str] | None:
        """限定文档范围；None 表示全部「解析完成」的文档。"""
        completed = [
            row["doc_id"]
            for row in self.state.list_documents()
            if row["status"] == STATUS_COMPLETED
        ]
        if not doc_scope:
            return completed or None
        wanted = set(doc_scope)
        allowed = [doc_id for doc_id in completed if doc_id in wanted]
        return allowed or None

    def _save_temp_images(self, conv_id: str, images: Sequence[str]) -> list[Path]:
        """把用户上传的临时图片落盘到 tmp 目录，仅本轮可见。"""
        if not images:
            return []
        target_dir = self.storage.temp_dir() / conv_id
        target_dir.mkdir(parents=True, exist_ok=True)
        saved: list[Path] = []
        for raw in images:
            try:
                path = self._decode_image(raw, target_dir)
            except Exception as exc:  # noqa: BLE001
                logger.warning("临时图片保存失败: %s", exc)
                continue
            if path:
                saved.append(path)
        return saved

    def _decode_image(self, raw: str, target_dir: Path) -> Path | None:
        """支持 data URL、base64 裸串与已有的临时文件名。"""
        if not raw:
            return None
        payload = raw
        suffix = ".png"
        if raw.startswith("data:"):
            header, _, body = raw.partition(",")
            if "base64" not in header.lower():
                return None
            suffix = _suffix_from_mime(header) or ".png"
            payload = body
        else:
            candidate = Path(raw)
            if candidate.is_file() and candidate.suffix.lower() in ALLOWED_IMAGE_SUFFIX:
                dest = target_dir / f"{uuid.uuid4().hex}{candidate.suffix.lower()}"
                dest.write_bytes(candidate.read_bytes())
                return dest
        try:
            data = base64.b64decode(payload, validate=False)
        except (binascii.Error, ValueError) as exc:
            raise ValueError(f"图片 base64 解码失败: {exc}") from exc
        if not data:
            return None
        if len(data) > 10 * 1024 * 1024:
            raise ValueError("图片过大（最多 10MB）")
        dest = target_dir / f"{uuid.uuid4().hex}{suffix}"
        dest.write_bytes(data)
        return dest


def _suffix_from_mime(header: str) -> str | None:
    mime = header.split(":", 1)[-1].split(";", 1)[0].strip().lower()
    mapping = {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/jpg": ".jpg",
        "image/webp": ".webp",
        "image/gif": ".gif",
        "image/bmp": ".bmp",
    }
    return mapping.get(mime)