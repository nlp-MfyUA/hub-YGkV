"""文档服务：上传、状态、重试、重新解析、删除、下载（设计文档 §3.1 / §3.4 / §3.6）。"""
from __future__ import annotations

import hashlib
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from ..config import CONFIG, Config
from ..core.logging_setup import get_logger
from ..core.state_store import StateStore, STATUS_COMPLETED, STATUS_FAILED, STATUS_PARSING, STATUS_PENDING
from ..core.storage import Storage
from ..messaging.base import TaskMessage
from ..rag.index_store import IndexStore

logger = get_logger(__name__)

PDF_MAGIC = b"%PDF-"


class ValidationError(Exception):
    """上传校验失败。"""


class DocumentService:
    def __init__(
        self,
        storage: Storage,
        state: StateStore,
        queue,
        index: IndexStore,
        config: Config = CONFIG,
    ) -> None:
        self.storage = storage
        self.state = state
        self.queue = queue
        self.index = index
        self.config = config

    # ------------------------------------------------------------------ 上传
    def upload(self, uploads: Iterable[Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """接收多个上传文件。

        uploads 元素为 (文件名, 文件内容 bytes) 二元组，
        也兼容具备 .filename / .read() 的对象（如 FastAPI UploadFile）。
        返回 (成功列表, 拒绝列表)。
        """
        normalized: list[tuple[str, bytes]] = []
        for item in uploads:
            if isinstance(item, (tuple, list)) and len(item) == 2:
                normalized.append((item[0], item[1]))
            else:
                normalized.append((getattr(item, "filename", "unnamed.pdf"), item.read()))
        uploads = normalized
        accepted: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []

        if len(uploads) > self.config.max_files_per_upload:
            raise ValidationError(f"单次最多上传 {self.config.max_files_per_upload} 个文件，本次收到 {len(uploads)} 个")

        staged: list[tuple[str, Path, int, int]] = []   # filename, tmp path, size, page_count
        total_size = 0
        max_bytes = self.config.max_file_size_mb * 1024 * 1024
        total_max = self.config.max_total_size_mb * 1024 * 1024

        tmp_dir = self.storage.temp_dir()
        for upload_name, data in uploads:
            filename = Path(upload_name or "unnamed.pdf").name
            if not isinstance(data, (bytes, bytearray)):
                rejected.append({"file_name": filename, "reason": "文件内容无效"})
                continue
            data = bytes(data)
            size = len(data)
            if size == 0:
                rejected.append({"file_name": filename, "reason": "文件为空"})
                continue
            if size > max_bytes:
                rejected.append(
                    {"file_name": filename, "reason": f"单文件超过 {self.config.max_file_size_mb}MB"}
                )
                continue
            if total_size + size > total_max:
                rejected.append(
                    {"file_name": filename, "reason": f"本次总大小超过 {self.config.max_total_size_mb}MB"}
                )
                continue
            if not filename.lower().endswith(".pdf") or not data.startswith(PDF_MAGIC):
                rejected.append({"file_name": filename, "reason": "不是有效的 PDF 文件"})
                continue

            tmp_path = tmp_dir / f"upload_{uuid.uuid4().hex}.pdf"
            tmp_path.write_bytes(data)
            page_count = self._count_pages(tmp_path)
            if page_count is None:
                tmp_path.unlink(missing_ok=True)
                rejected.append({"file_name": filename, "reason": "PDF 无法解析（可能已损坏）"})
                continue
            if page_count > self.config.max_pdf_pages:
                tmp_path.unlink(missing_ok=True)
                rejected.append(
                    {"file_name": filename, "reason": f"页数 {page_count} 超过上限 {self.config.max_pdf_pages}"}
                )
                continue

            total_size += size
            staged.append((filename, tmp_path, size, page_count))

        for filename, tmp_path, size, page_count in staged:
            try:
                result = self._register(filename, tmp_path, size, page_count)
                accepted.append(result)
            except Exception as exc:  # noqa: BLE001
                logger.exception("登记文档失败 %s", filename)
                rejected.append({"file_name": filename, "reason": f"登记失败：{exc}"})
            finally:
                tmp_path.unlink(missing_ok=True)

        return accepted, rejected

    def _register(self, filename: str, tmp_path: Path, size: int, page_count: int) -> dict[str, Any]:
        doc_id = uuid.uuid4().hex
        task_id = uuid.uuid4().hex
        trace_id = uuid.uuid4().hex[:16]

        self.storage.create_document_dir(doc_id)
        self.storage.save_original(doc_id, tmp_path, filename)

        digest = hashlib.sha256(tmp_path.read_bytes()).hexdigest()
        self.state.create_document(
            doc_id=doc_id,
            file_name=filename,
            file_size=size,
            file_hash=digest,
            page_count=page_count,
            trace_id=trace_id,
            task_id=task_id,
        )

        message = TaskMessage(
            task_id=task_id,
            document_id=doc_id,
            user_id="local",
            source_path=str(self.storage.doc_paths(doc_id).original),
            file_name=filename,
            file_size=size,
            page_count=page_count,
            retry_count=0,
            trace_id=trace_id,
            topic=self.config.kafka_topic,
        )
        self.state.create_task(
            doc_id, 0, message.to_dict(), trace_id=trace_id, task_id=task_id
        )
        self.queue.publish(message)

        doc = self.state.get_document(doc_id) or {}
        logger.info("上传完成 doc_id=%s file=%s size=%s pages=%s", doc_id, filename, size, page_count)
        return {
            "doc_id": doc_id,
            "file_name": filename,
            "file_size": size,
            "page_count": page_count,
            "status": doc.get("status", STATUS_PENDING),
            "status_label": doc.get("status_label", "待解析"),
            "task_id": task_id,
            "trace_id": trace_id,
            "error": None,
        }

    def _count_pages(self, pdf_path: Path) -> int | None:
        try:
            import pymupdf

            with pymupdf.open(str(pdf_path)) as doc:
                return doc.page_count
        except Exception as exc:  # noqa: BLE001
            logger.warning("读取 PDF 页数失败: %s", exc)
            return None

    # ------------------------------------------------------------------ 查询
    def list_documents(self) -> list[dict[str, Any]]:
        return [self._to_summary(row) for row in self.state.list_documents()]

    def statuses(self, doc_ids: list[str] | None = None) -> list[dict[str, Any]]:
        return [self._to_summary(row) for row in self.state.list_statuses(doc_ids)]

    def _to_summary(self, row: dict[str, Any]) -> dict[str, Any]:
        return {
            "doc_id": row["doc_id"],
            "file_name": row["file_name"],
            "file_size": row["file_size"],
            "page_count": row["page_count"],
            "status": row["status"],
            "status_label": row["status_label"],
            "retry_count": row["retry_count"],
            "max_retries": self.config.max_retries,
            "error_message": row.get("error_message"),
            "uploaded_at": row["uploaded_at"],
            "updated_at": row["updated_at"],
            "parse_duration_ms": row.get("parse_duration_ms"),
            "parser_engine": row.get("parser_engine"),
            "mineru_version": row.get("mineru_version"),
            "trace_id": row.get("trace_id"),
        }

    # ------------------------------------------------------------------ 重试
    def retry(self, doc_id: str) -> dict[str, Any]:
        doc = self.state.get_document(doc_id)
        if doc is None:
            raise ValidationError("文档不存在")
        if doc["status"] != STATUS_FAILED:
            raise ValidationError(f"只有解析失败的文档可以重试（当前状态：{doc['status_label']}）")
        if doc["retry_count"] >= self.config.max_retries:
            raise ValidationError(f"已达到重试上限（{self.config.max_retries} 次），请删除后重新上传")

        retry_count = self.state.increment_retry(doc_id)
        task_id = uuid.uuid4().hex
        trace_id = doc.get("trace_id") or uuid.uuid4().hex[:16]

        message = TaskMessage(
            task_id=task_id,
            document_id=doc_id,
            user_id=doc.get("user_id", "local"),
            source_path=str(self.storage.doc_paths(doc_id).original),
            file_name=doc["file_name"],
            file_size=doc["file_size"],
            page_count=doc["page_count"],
            retry_count=retry_count,
            trace_id=trace_id,
            topic=self.config.kafka_topic,
        )
        self.state.create_task(doc_id, retry_count, message.to_dict(), trace_id=trace_id, task_id=task_id)
        self.state.transition(doc_id, STATUS_PENDING, task_id=task_id)
        self.queue.publish(message)
        logger.info("重试投递 doc_id=%s retry=%s task_id=%s", doc_id, retry_count, task_id)
        return {
            "ok": True,
            "doc_id": doc_id,
            "status": STATUS_PENDING,
            "status_label": "待解析",
            "message": f"已重新投递解析任务（第 {retry_count} 次重试）",
            "task_id": task_id,
            "retry_count": retry_count,
        }

    # ------------------------------------------------------------------ 重新解析
    def reparse(self, doc_id: str) -> dict[str, Any]:
        doc = self.state.get_document(doc_id)
        if doc is None:
            raise ValidationError("文档不存在")
        if doc["status"] == STATUS_PARSING:
            raise ValidationError("文档正在解析中，请稍候")

        self.index.delete_document(doc_id)
        self.storage.clear_parsed_artifacts(doc_id)

        task_id = uuid.uuid4().hex
        trace_id = uuid.uuid4().hex[:16]
        message = TaskMessage(
            task_id=task_id,
            document_id=doc_id,
            user_id=doc.get("user_id", "local"),
            source_path=str(self.storage.doc_paths(doc_id).original),
            file_name=doc["file_name"],
            file_size=doc["file_size"],
            page_count=doc["page_count"],
            retry_count=doc["retry_count"],
            trace_id=trace_id,
            topic=self.config.kafka_topic,
        )
        self.state.create_task(doc_id, doc["retry_count"], message.to_dict(), trace_id=trace_id, task_id=task_id)
        self.state.transition(doc_id, STATUS_PENDING, task_id=task_id, enforce=False)
        self.queue.publish(message)
        logger.info("重新解析投递 doc_id=%s task_id=%s", doc_id, task_id)
        return {
            "ok": True,
            "doc_id": doc_id,
            "status": STATUS_PENDING,
            "status_label": "待解析",
            "message": "已清理旧索引并重新投递解析任务",
            "task_id": task_id,
            "retry_count": doc["retry_count"],
        }

    # ------------------------------------------------------------------ 删除
    def delete(self, doc_id: str) -> dict[str, Any]:
        doc = self.state.get_document(doc_id)
        if doc is None:
            raise ValidationError("文档不存在")
        self.index.delete_document(doc_id)
        self.storage.delete_document(doc_id)
        self.state.mark_deleted(doc_id)
        self.state.hard_delete(doc_id)
        logger.info("文档已删除 doc_id=%s", doc_id)
        return {"ok": True, "doc_id": doc_id, "status": "deleted", "status_label": "已删除", "message": "文档及其索引、原文件、图片已清理"}

    # ------------------------------------------------------------------ 资源
    def result_bundle(self, doc_id: str) -> Path:
        if not self.storage.document_exists(doc_id):
            raise ValidationError("文档不存在")
        archive = self.storage.build_result_bundle(doc_id)
        if archive is None:
            raise ValidationError("解析结果不存在")
        return archive

    def image_path(self, doc_id: str, image_id: str) -> Path:
        """按图片 ID 定位文件（防目录穿越）。"""
        if not image_id.isalnum() and "_" not in image_id:
            raise ValidationError("非法图片 ID")
        images_dir = (self.storage.doc_paths(doc_id).images_dir).resolve()
        if not images_dir.is_dir():
            raise ValidationError("图片不存在")
        for candidate in images_dir.iterdir():
            if candidate.stem == image_id or candidate.name == image_id:
                return candidate
        raise ValidationError("图片不存在")

    def pdf_path(self, doc_id: str) -> Path:
        path = self.storage.doc_paths(doc_id).original
        if not path.is_file():
            raise ValidationError("原文件不存在")
        return path

    def metadata(self, doc_id: str) -> dict[str, Any] | None:
        return self.storage.read_metadata(doc_id)