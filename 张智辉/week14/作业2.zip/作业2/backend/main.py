"""后端 API 服务入口（设计文档 §2.2 组件 2）。

职责：上传接收、文件校验、落盘、生成 Kafka 消息、状态查询、文档管理、问答同步接口。
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .api import documents as documents_router
from .api import qa as qa_router
from .config import CONFIG, Config
from .core.logging_setup import get_logger, setup_logging
from .core.state_store import StateStore
from .core.storage import Storage
from .messaging.factory import create_task_queue
from .rag.embedder import Embedder
from .rag.index_store import IndexStore
from .rag.llm import MultimodalLLM
from .rag.retriever import Retriever
from .services.document_service import DocumentService
from .services.qa_service import QAService

logger = get_logger(__name__)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


class ServiceContainer:
    """进程内共享的服务实例。"""

    def __init__(self, config: Config = CONFIG) -> None:
        self.config = config
        self.storage = Storage(config)
        self.storage.ensure_layout()
        self.state = StateStore(config.state_db_path)
        self.embedder = Embedder(config)
        self.index = IndexStore(config.index_dir / "index.db", self.embedder, config)
        self.retriever = Retriever(self.index, self.embedder, config)
        self.llm = MultimodalLLM(config)
        self.queue = create_task_queue(config, producer_only=True)
        self.documents = DocumentService(self.storage, self.state, self.queue, self.index, config)
        self.qa = QAService(self.storage, self.state, self.retriever, self.llm, config)
        self.started_at = time.time()

    def close(self) -> None:
        try:
            self.queue.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.index.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.state.close()
        except Exception:  # noqa: BLE001
            pass

    def health(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "uptime_seconds": int(time.time() - self.started_at),
            "queue": {
                "backend": self.queue.name,
                "topic": self.config.kafka_topic,
                "backlog": self.queue.backlog(),
            },
            "index": self.index.stats(),
            "embedder": {
                "backend": self.embedder.backend.name,
                "model": getattr(self.embedder.backend, "model", "hash"),
                "dim": self.embedder.dim,
            },
            "llm": {
                "available": self.llm.available,
                "model": self.llm.model,
                "base_url": self.llm.base_url,
            },
            "documents": len(self.state.list_documents()),
        }


def create_app(config: Config = CONFIG) -> FastAPI:
    setup_logging(config.log_level)
    container = ServiceContainer(config)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.services = container
        logger.info("服务启动完成：http://%s:%s", config.host, config.port)
        logger.info("队列后端=%s 嵌入=%s LLM=%s",
                    container.queue.name, container.embedder.backend.name,
                    container.llm.model if container.llm.available else "未配置(抽取式)")
        yield
        container.close()

    app = FastAPI(
        title=config.app_name,
        version="1.0.0",
        description="基于 Kafka 的多模态 RAG 问答系统（本地单用户 Demo）",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(documents_router.router)
    app.include_router(qa_router.router)

    @app.get("/api/health", tags=["system"], summary="健康检查与运行指标")
    async def health(request: Request) -> dict[str, Any]:
        return request.app.state.services.health()

    @app.get("/api/config", tags=["system"], summary="当前配置（脱敏）")
    async def runtime_config(request: Request) -> dict[str, Any]:
        return request.app.state.services.config.public_dict()

    if FRONTEND_DIR.is_dir():
        app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")

        @app.get("/", include_in_schema=False)
        async def index_page() -> FileResponse:
            return FileResponse(FRONTEND_DIR / "index.html")

        @app.get("/app.js", include_in_schema=False)
        async def app_js() -> FileResponse:
            return FileResponse(FRONTEND_DIR / "app.js", media_type="application/javascript")

        @app.get("/styles.css", include_in_schema=False)
        async def styles_css() -> FileResponse:
            return FileResponse(FRONTEND_DIR / "styles.css", media_type="text/css")

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    return app


app = create_app()