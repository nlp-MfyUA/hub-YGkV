"""测试夹具：使用临时目录与独立的本地队列，避免污染真实数据。"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.config import Config
from backend.core.state_store import StateStore
from backend.core.storage import Storage
from backend.messaging.local_queue import LocalTaskQueue
from backend.parsing.models import ImageAsset, TextBlock
from backend.rag.embedder import Embedder
from backend.rag.index_store import IndexStore


@pytest.fixture()
def cfg(tmp_path) -> Config:
    config = Config(storage_root=tmp_path / "data")
    config.embedding_provider = "hash"
    config.kafka_enabled = False
    config.llm_base_url = ""
    config.llm_api_key = ""
    config.embedding_dim = 256
    config.ensure_dirs()
    return config


@pytest.fixture()
def state(cfg) -> StateStore:
    return StateStore(cfg.state_db_path)


@pytest.fixture()
def storage(cfg) -> Storage:
    store = Storage(cfg)
    store.ensure_layout()
    return store


@pytest.fixture()
def queue(cfg) -> LocalTaskQueue:
    return LocalTaskQueue(cfg.storage_root / "state" / "q.db", cfg.kafka_topic)


@pytest.fixture()
def index(cfg) -> IndexStore:
    embedder = Embedder(cfg)
    return IndexStore(cfg.index_dir / "index.db", embedder, cfg)


@pytest.fixture()
def sample_blocks():
    return [
        TextBlock(block_id="tb1", text="向量检索使用余弦相似度计算语义相关性。", page=1, block_index=0),
        TextBlock(block_id="tb2", text="BM25 关键词检索擅长匹配精确术语与型号。", page=2, block_index=1),
        TextBlock(block_id="tb3", text="RRF 融合把多路召回结果合并重排。", page=3, block_index=2),
    ]


@pytest.fixture()
def sample_images():
    return [
        ImageAsset(image_id="img1", filename="img1.png", page=2, caption="检索流程图", ocr_text="上传 解析 索引 问答", order=0),
    ]