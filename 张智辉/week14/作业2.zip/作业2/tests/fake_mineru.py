"""模拟 MinerU CLI 的假实现，用于测试 MinerU 分支。

用法：python fake_mineru.py -p <pdf> -o <outdir> -m auto
产出与 MinerU 2.x 相同的目录结构与 content_list.json 格式。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pymupdf


def main() -> int:
    args = sys.argv[1:]
    pdf = out = None
    for i, token in enumerate(args):
        if token == "-p":
            pdf = Path(args[i + 1])
        elif token == "-o":
            out = Path(args[i + 1])
    if pdf is None or out is None:
        print("usage: fake_mineru.py -p <pdf> -o <out>")
        return 2

    doc = pymupdf.open(str(pdf))
    stem = pdf.stem
    work = out / stem
    images_dir = work / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    content = []
    for page_index in range(doc.page_count):
        page = doc.load_page(page_index)
        text = page.get_text("text").strip()
        if text:
            for line in [l.strip() for l in text.splitlines() if l.strip()]:
                content.append({"type": "text", "text": line, "page_idx": page_index})
        for info in page.get_images(full=True):
            xref = info[0]
            extracted = doc.extract_image(xref)
            name = f"{stem}_p{page_index}_{xref}.{extracted.get('ext', 'png')}"
            (images_dir / name).write_bytes(extracted["image"])
            content.append(
                {
                    "type": "image",
                    "img_path": f"images/{name}",
                    "image_caption": [f"{stem} 第 {page_index + 1} 页插图"],
                    "image_footnote": [],
                    "page_idx": page_index,
                }
            )

    (work / f"{stem}_content_list.json").write_text(
        json.dumps(content, ensure_ascii=False), encoding="utf-8"
    )
    doc.close()
    print(f"fake-mineru done: {work}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())