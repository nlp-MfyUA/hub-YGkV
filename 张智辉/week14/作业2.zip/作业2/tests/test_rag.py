"""检索链路测试：嵌入、索引、融合检索、引用校验。"""
from __future__ import annotations

import numpy as np

from backend.rag.context import build_context
from backend.rag.embedder import Embedder, HashEmbedder, tokenize
from backend.rag.llm import build_citations, validate_markers
from backend.rag.retriever import Retriever, bm25_scores


def test_tokenize_handles_chinese_and_english():
    tokens = tokenize("向量检索 Vector Retrieval")
    assert "向" in tokens
    assert "向量" in tokens
    assert "vector" in tokens


def test_hash_embedder_is_deterministic_and_normalized():
    emb = HashEmbedder(dim=128)
    a = emb.embed(["向量检索"])
    b = emb.embed(["向量检索"])
    assert np.allclose(a, b)
    assert abs(float(np.linalg.norm(a[0])) - 1.0) < 1e-5


def test_bm25_ranks_matching_document_first():
    docs = [
        "本文介绍向量检索与余弦相似度。",
        "本文介绍分布式系统的副本机制。",
        "BM25 是经典关键词检索算法。",
    ]
    scores = bm25_scores("向量检索", docs, k1=1.5, b=0.75)
    assert scores[0] > scores[1]
    assert scores[0] > scores[2]


def test_index_upsert_and_delete(index, sample_blocks, sample_images):
    stats = index.upsert_document("docA", sample_blocks, sample_images)
    assert stats["text_blocks"] == 3
    assert stats["images"] == 1
    assert index.stats("docA")["text_blocks"] == 3

    index.delete_document("docA")
    assert index.stats("docA")["text_blocks"] == 0


def test_retriever_finds_relevant_block(index, sample_blocks, sample_images):
    index.upsert_document("docA", sample_blocks, sample_images)
    embedder = index.embedder
    retriever = Retriever(index, embedder)
    items = retriever.retrieve("BM25 关键词检索", doc_names={"docA": "论文.pdf"})
    assert items
    assert items[0].kind == "text"
    assert items[0].doc_name == "论文.pdf"
    assert items[0].marker.startswith("S")


def test_retriever_respects_doc_scope(index, sample_blocks):
    index.upsert_document("docA", sample_blocks, [])
    index.upsert_document("docB", [sample_blocks[0]], [])
    retriever = Retriever(index, index.embedder)
    items = retriever.retrieve("向量检索", doc_scope=["docB"], doc_names={"docB": "B.pdf"})
    assert items and all(i.doc_id == "docB" for i in items)


def test_build_context_marks_sources(index, sample_blocks, sample_images):
    index.upsert_document("docA", sample_blocks, sample_images)
    retriever = Retriever(index, index.embedder)
    items = retriever.retrieve("BM25 关键词检索", doc_names={"docA": "论文.pdf"})
    bundle = build_context(items)
    assert "[S1]" in bundle.text
    assert "论文.pdf" in bundle.text
    assert bundle.images and bundle.images[0]["marker"].startswith("I")


def test_validate_markers_flags_hallucination(index, sample_blocks, sample_images):
    index.upsert_document("docA", sample_blocks, sample_images)
    retriever = Retriever(index, index.embedder)
    items = retriever.retrieve("向量检索", doc_names={"docA": "论文.pdf"})
    bundle = build_context(items)
    used, invalid = validate_markers("答案 [S1] 与伪造的 [S99]", bundle)
    assert "S1" in used
    assert "S99" in invalid


def test_build_citations_only_contains_used(index, sample_blocks, sample_images):
    index.upsert_document("docA", sample_blocks, sample_images)
    retriever = Retriever(index, index.embedder)
    items = retriever.retrieve("向量检索", doc_names={"docA": "论文.pdf"})
    bundle = build_context(items)
    citations = build_citations(bundle, ["S1"])
    assert citations and citations[0]["marker"] == "S1"
    assert citations[0]["pdf_url"].startswith("/api/documents/docA/pdf")