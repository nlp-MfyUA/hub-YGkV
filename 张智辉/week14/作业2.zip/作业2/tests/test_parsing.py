"""解析相关测试：分块、兜底解析器、MinerU 产物归一化。"""
from __future__ import annotations

from pathlib import Path

import pytest

from backend.parsing import fallback_parser, mineru_adapter
from backend.parsing.chunker import chunk_document, split_text
from backend.parsing.models import ParsedDocument, TextBlock


def test_split_text_respects_chunk_size():
    text = "这是一个很长的句子。" * 200
    chunks = split_text(text, chunk_size=200, overlap=20)
    assert len(chunks) > 1
    assert all(len(c) <= 260 for c in chunks)
    assert "".join(chunks)


def test_chunk_document_keeps_page_and_bbox():
    parsed = ParsedDocument(document_id="d1")
    parsed.text_blocks.append(
        TextBlock(block_id="b0", text="短文本", page=3, bbox=(1.0, 2.0, 3.0, 4.0), block_index=0)
    )
    chunks = chunk_document(parsed, chunk_size=600, overlap=80)
    assert len(chunks) == 1
    assert chunks[0].page == 3
    assert chunks[0].bbox == (1.0, 2.0, 3.0, 4.0)


def test_chunk_document_splits_long_text():
    parsed = ParsedDocument(document_id="d2")
    parsed.text_blocks.append(TextBlock(block_id="b0", text="内容。" * 500, page=1, block_index=0))
    chunks = chunk_document(parsed, chunk_size=300, overlap=30)
    assert len(chunks) > 1
    assert all(c.page == 1 for c in chunks)


def test_fallback_parser_extracts_text_and_images(tmp_path: Path):
    pdf_path = tmp_path / "sample.pdf"
    doc = __import__("pymupdf").open()
    page = doc.new_page()
    page.insert_text((60, 80), "Hello RAG demo page one", fontsize=14)
    doc.save(str(pdf_path))
    doc.close()

    parsed = fallback_parser.parse_pdf_with_pymupdf("doc_x", pdf_path, tmp_path / "mineru")
    assert parsed.page_count == 1
    assert parsed.engine == "pymupdf-fallback"
    assert any("Hello RAG" in b.text for b in parsed.text_blocks)
    assert parsed.text_blocks[0].page == 1


def test_mineru_normalize_from_content_list(tmp_path: Path):
    out = tmp_path / "mineru"
    (out / "images").mkdir(parents=True)
    content = [
        {"type": "text", "text": "标题一", "text_level": 1, "page_idx": 0},
        {"type": "text", "text": "正文段落", "page_idx": 0},
        {"type": "table", "table_body": "<table><tr><td>单元格</td></tr></table>", "page_idx": 1},
        {"type": "equation", "text": "$E=mc^2$", "page_idx": 1},
    ]
    (out / "demo_content_list.json").write_text(
        __import__("json").dumps(content), encoding="utf-8"
    )
    parsed = mineru_adapter.normalize_mineru_output("doc_y", out)
    kinds = [b.kind for b in parsed.text_blocks]
    assert "table" in kinds and "equation" in kinds
    assert any(b.section_path == "标题一" for b in parsed.text_blocks)


def test_mineru_normalize_without_output_raises(tmp_path: Path):
    with pytest.raises(RuntimeError):
        mineru_adapter.normalize_mineru_output("doc_z", tmp_path / "empty")