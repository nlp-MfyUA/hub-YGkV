"""状态机与状态库测试（设计文档 §5）。"""
from __future__ import annotations

from backend.core.state_store import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PARSING,
    STATUS_PENDING,
    StateStore,
)


def create_doc(state: StateStore, doc_id: str = "doc1") -> None:
    state.create_document(doc_id=doc_id, file_name="a.pdf", file_size=100, page_count=3)


def test_initial_status_is_pending(state: StateStore):
    create_doc(state)
    doc = state.get_document("doc1")
    assert doc["status"] == STATUS_PENDING
    assert doc["status_label"] == "待解析"
    assert doc["retry_count"] == 0


def test_legal_transitions(state: StateStore):
    create_doc(state)
    assert state.transition("doc1", STATUS_PARSING) is True
    assert state.transition("doc1", STATUS_COMPLETED) is True
    assert state.get_document("doc1")["status"] == STATUS_COMPLETED


def test_illegal_transition_rejected(state: StateStore):
    create_doc(state)
    # 待解析 不能直接到 解析完成
    assert state.transition("doc1", STATUS_COMPLETED) is False
    assert state.get_document("doc1")["status"] == STATUS_PENDING


def test_failed_to_pending_requires_pending_first(state: StateStore):
    create_doc(state)
    state.transition("doc1", STATUS_PARSING)
    state.transition("doc1", STATUS_FAILED, error_message="boom")
    assert state.transition("doc1", STATUS_COMPLETED) is False
    assert state.transition("doc1", STATUS_PENDING) is True
    assert state.transition("doc1", STATUS_PARSING) is True


def test_retry_counter(state: StateStore):
    create_doc(state)
    assert state.increment_retry("doc1") == 1
    assert state.increment_retry("doc1") == 2
    assert state.get_document("doc1")["retry_count"] == 2


def test_conversation_messages(state: StateStore):
    conv = state.create_conversation("测试会话")
    state.add_message(conv, "user", "你好")
    state.add_message(conv, "assistant", "回答", citations=[{"marker": "S1"}])
    msgs = state.get_messages(conv)
    assert len(msgs) == 2
    assert msgs[1]["citations"][0]["marker"] == "S1"


def test_delete_conversation(state: StateStore):
    conv = state.create_conversation("待删除")
    state.add_message(conv, "user", "x")
    state.delete_conversation(conv)
    assert state.get_conversation(conv) is None
    assert state.get_messages(conv) == []