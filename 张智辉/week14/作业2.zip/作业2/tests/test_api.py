"""接口端到端测试（设计文档 §8 / §12 验收映射）。"""
from __future__ import annotations

from pathlib import Path

import pymupdf
import pytest
from fastapi.testclient import TestClient

from backend.main import create_app
from backend.parsing.pipeline import ParsePipeline


@pytest.fixture()
def client(cfg):
    app = create_app(cfg)
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture()
def sample_pdf(tmp_path: Path) -> bytes:
    path = tmp_path / "sample.pdf"
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((60, 80), "RAG system uses hybrid retrieval.", fontsize=14)
    page.insert_text((60, 110), "BM25 keyword retrieval works well.", fontsize=14)
    page.insert_text((60, 140), "RRF merges vector and keyword results.", fontsize=14)
    doc.save(str(path))
    doc.close()
    return path.read_bytes()


def upload(client: TestClient, pdf_bytes: bytes, name: str = "sample.pdf"):
    return client.post("/api/documents/upload", files=[("files", (name, pdf_bytes, "application/pdf"))])


def test_health_endpoint(client: TestClient):
    res = client.get("/api/health")
    assert res.status_code == 200
    body = res.json()
    assert body["status"] == "ok"
    assert "queue" in body and "index" in body


def test_upload_creates_pending_document(client: TestClient, sample_pdf: bytes):
    res = upload(client, sample_pdf)
    assert res.status_code == 200
    body = res.json()
    assert len(body["files"]) == 1
    item = body["files"][0]
    assert item["status"] == "pending"
    assert item["page_count"] == 1

    listing = client.get("/api/documents").json()
    assert listing["total"] == 1
    assert listing["documents"][0]["status_label"] == "待解析"


def test_upload_rejects_non_pdf(client: TestClient):
    res = client.post("/api/documents/upload", files=[("files", ("a.txt", b"hello", "text/plain"))])
    assert res.status_code == 200
    body = res.json()
    assert body["files"] == []
    assert body["rejected"][0]["reason"]


def test_upload_rejects_too_many_files(client: TestClient, sample_pdf: bytes):
    files = [("files", (f"f{i}.pdf", sample_pdf, "application/pdf")) for i in range(11)]
    res = client.post("/api/documents/upload", files=files)
    assert res.status_code == 400


def test_parse_then_query_flow(client: TestClient, sample_pdf: bytes, cfg):
    """上传 → 解析 → 检索 → 问答 → 引用 → 删除 的完整链路。"""
    res = upload(client, sample_pdf)
    doc_id = res.json()["files"][0]["doc_id"]

    services = client.app.state.services
    message = services.queue.poll(timeout=2.0)
    assert message is not None
    pipeline = ParsePipeline(services.storage, services.state, services.index, cfg)
    pipeline.run(message)

    status = client.get("/api/documents/status", params={"doc_ids": [doc_id]}).json()
    assert status["documents"][0]["status"] == "completed"

    # 原 PDF 与图片可访问
    assert client.get(f"/api/documents/{doc_id}/pdf").status_code == 200
    meta = client.get(f"/api/documents/{doc_id}/metadata").json()
    assert meta["page_count"] == 1
    assert meta["text_blocks"]

    # 问答
    qa = client.post("/api/qa", json={"question": "BM25 关键词检索是怎么做的？"})
    assert qa.status_code == 200
    body = qa.json()
    assert body["conversation_id"]
    assert body["retrieved_count"] > 0
    assert body["citations"], "应当返回引用来源"
    cite = body["citations"][0]
    assert cite["doc_name"] == "sample.pdf"
    assert cite["page"] >= 1
    assert cite["pdf_url"].startswith("/api/documents/")

    # 会话历史
    conv = client.get(f"/api/conversations/{body['conversation_id']}").json()
    assert len(conv["messages"]) == 2

    # 删除后数据清理
    assert client.delete(f"/api/documents/{doc_id}").status_code == 200
    assert client.get("/api/documents").json()["total"] == 0
    assert client.get(f"/api/documents/{doc_id}/pdf").status_code == 404


def test_retry_and_limit(client: TestClient, sample_pdf: bytes):
    res = upload(client, sample_pdf)
    doc_id = res.json()["files"][0]["doc_id"]
    services = client.app.state.services

    # 人为置为失败
    services.state.transition(doc_id, "parsing")
    services.state.transition(doc_id, "failed", error_message="模拟失败")

    retry = client.post(f"/api/documents/{doc_id}/retry")
    assert retry.status_code == 200
    assert retry.json()["status"] == "pending"
    assert retry.json()["retry_count"] == 1

    # 重试上限
    services.state.transition(doc_id, "parsing")
    services.state.transition(doc_id, "failed", error_message="再次失败")
    for _ in range(3):
        services.state.increment_retry(doc_id)
    services.state.transition(doc_id, "pending")
    services.state.transition(doc_id, "parsing")
    services.state.transition(doc_id, "failed", error_message="超限")
    over = client.post(f"/api/documents/{doc_id}/retry")
    assert over.status_code == 400
    assert "重试上限" in over.json()["detail"]


def test_reparse_clears_index(client: TestClient, sample_pdf: bytes, cfg):
    res = upload(client, sample_pdf)
    doc_id = res.json()["files"][0]["doc_id"]
    services = client.app.state.services
    message = services.queue.poll(timeout=2.0)
    ParsePipeline(services.storage, services.state, services.index, cfg).run(message)
    assert services.index.stats(doc_id)["text_blocks"] > 0

    reparse = client.post(f"/api/documents/{doc_id}/reparse")
    assert reparse.status_code == 200
    assert services.index.stats(doc_id)["text_blocks"] == 0
    assert services.state.get_document(doc_id)["status"] == "pending"


def test_qa_with_scope_and_temp_image(client: TestClient, sample_pdf: bytes, cfg):
    res = upload(client, sample_pdf)
    doc_id = res.json()["files"][0]["doc_id"]
    services = client.app.state.services
    message = services.queue.poll(timeout=2.0)
    ParsePipeline(services.storage, services.state, services.index, cfg).run(message)

    # 1x1 png
    import base64

    png = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )
    data_url = "data:image/png;base64," + base64.b64encode(png).decode()

    qa = client.post(
        "/api/qa",
        json={"question": "RRF 融合的作用是什么？", "doc_scope": [doc_id], "images": [data_url]},
    )
    assert qa.status_code == 200
    body = qa.json()
    assert body["citations"]

    # 临时图片不入库，问答后清理
    tmp_dir = services.storage.temp_dir()
    leftovers = [p for p in tmp_dir.rglob("*") if p.is_file()]
    assert not leftovers, f"临时图片应被清理，残留：{leftovers}"


def test_conversation_listing(client: TestClient):
    client.post("/api/qa", json={"question": "测试会话创建"})
    convs = client.get("/api/conversations").json()
    assert len(convs) >= 1
    assert convs[0]["message_count"] >= 2