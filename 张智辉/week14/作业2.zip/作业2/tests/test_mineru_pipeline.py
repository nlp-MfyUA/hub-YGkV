"""验证 MinerU 分支：用假 MinerU CLI 驱动完整解析流水线。"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

import pymupdf
import pytest

from backend.parsing import mineru_adapter
from backend.parsing.pipeline import ParsePipeline
from backend.messaging.base import TaskMessage

FAKE_MINERU = Path(__file__).resolve().parent / "fake_mineru.py"


def make_binary(tmp_path: Path) -> str:
    """生成一个可执行的假 mineru 命令（Windows 用 .bat，POSIX 用 .sh）。"""
    if os.name == "nt":
        bat = tmp_path / "mineru.bat"
        bat.write_text(f'@echo off\r\n"{sys.executable}" "{FAKE_MINERU}" %*\r\n', encoding="utf-8")
        return str(bat)
    script = tmp_path / "mineru"
    script.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{FAKE_MINERU}" "$@"\n', encoding="utf-8")
    script.chmod(0o755)
    return str(script)


@pytest.fixture()
def pdf_bytes(tmp_path: Path) -> bytes:
    path = tmp_path / "input.pdf"
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((60, 80), "MinerU pipeline validation text", fontsize=14)
    doc.save(str(path))
    doc.close()
    return path.read_bytes()


def test_mineru_branch_produces_blocks_and_images(cfg, storage, state, index, pdf_bytes, tmp_path):
    binary = make_binary(tmp_path)
    cfg.mineru_command = binary
    cfg.parser_fallback_enabled = False     # 强制走 MinerU 分支

    doc_id = "doc_mineru"
    storage.create_document_dir(doc_id)
    source = storage.doc_paths(doc_id).original
    source.write_bytes(pdf_bytes)
    state.create_document(doc_id=doc_id, file_name="input.pdf", file_size=len(pdf_bytes), page_count=1)

    message = TaskMessage(
        task_id="t1", document_id=doc_id, source_path=str(source),
        file_name="input.pdf", file_size=len(pdf_bytes), page_count=1,
    )
    pipeline = ParsePipeline(storage, state, index, cfg)
    result = pipeline.run(message)

    assert result["engine"] == "mineru"
    assert result["text_blocks"] > 0
    assert state.get_document(doc_id)["status"] == "completed"

    metadata = storage.read_metadata(doc_id)
    assert metadata["parser_engine"] == "mineru"
    assert metadata["text_blocks"]

    # MinerU 原始产物被完整保留（目录名随原文件名变化）
    raw_dir = storage.doc_paths(doc_id).mineru_dir
    assert list(raw_dir.rglob("*_content_list.json")), "MinerU 原始产物应被保留"


def test_mineru_failure_marks_document_failed(cfg, storage, state, index, pdf_bytes, tmp_path):
    """MinerU 失败且禁用兜底时，应进入解析失败并记录原因。"""
    bad = tmp_path / "broken_mineru"
    if os.name == "nt":
        bad = tmp_path / "broken_mineru.bat"
        bad.write_text("@echo off\r\nexit /b 3\r\n", encoding="utf-8")
    else:
        bad.write_text("#!/bin/sh\nexit 3\n", encoding="utf-8")
        bad.chmod(0o755)

    cfg.mineru_command = str(bad)
    cfg.parser_fallback_enabled = False

    doc_id = "doc_broken"
    storage.create_document_dir(doc_id)
    source = storage.doc_paths(doc_id).original
    source.write_bytes(pdf_bytes)
    state.create_document(doc_id=doc_id, file_name="input.pdf", file_size=len(pdf_bytes), page_count=1)

    message = TaskMessage(task_id="t2", document_id=doc_id, source_path=str(source), file_name="input.pdf")
    pipeline = ParsePipeline(storage, state, index, cfg)
    with pytest.raises(RuntimeError):
        pipeline.run(message)

    doc = state.get_document(doc_id)
    assert doc["status"] == "failed"
    assert doc["error_message"]
    assert state.list_failures(doc_id)


def test_find_mineru_binary_returns_configured(cfg):
    assert mineru_adapter.find_mineru_binary("custom-cmd") == "custom-cmd"
    assert mineru_adapter.find_mineru_binary("") in (None, "mineru", "magic-pdf")