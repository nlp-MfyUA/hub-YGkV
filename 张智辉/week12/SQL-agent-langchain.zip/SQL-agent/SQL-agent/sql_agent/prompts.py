"""
提示词模板 —— LangChain 的 `ChatPromptTemplate`。

每个阶段一组模板，统一用 `ChatPromptTemplate.from_messages([...])` 声明，
变量用 `{name}` 占位；结构化输出用 Pydantic 模型描述（LangChain 会把它
转成 function calling 的参数 schema）。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field


# ==================================================================== 结构化输出 schema
class TableSelection(BaseModel):
    """选表阶段的结构化输出。"""

    tables: list[str] = Field(description="回答该问题需要用到的表名列表")
    reason: str = Field(description="为什么需要这些表，一句话说明")


class GeneratedSQL(BaseModel):
    """SQL 生成阶段的结构化输出。"""

    sql: str = Field(description="生成的 SQL 查询语句，只是一条 SELECT")
    explanation: str = Field(description="这条 SQL 如何回答用户的问题")
    tables_used: list[str] = Field(default_factory=list, description="SQL 中实际用到的表名")


class RewrittenSQL(BaseModel):
    """SQL 改写阶段的结构化输出。"""

    sql: str = Field(description="修正后的 SQL 查询语句")
    change_reason: str = Field(description="修改了什么、为什么改，一句话说明")


class QuerySummary(BaseModel):
    """结果汇总阶段的结构化输出。"""

    answer: str = Field(description="直接回答用户问题的结论")
    key_findings: list[str] = Field(default_factory=list, description="2-4 条关键发现，每条一句话")
    suggestions: list[str] = Field(default_factory=list, description="后续分析建议，没有就返回空数组")


# ==================================================================== 提示词模板
TABLE_SELECT_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """你是一个数据库选表专家。用户会提出一个自然语言的数据问题，
你需要判断：回答这个问题需要用到数据库里的哪些表。

工作流程：
1. 库表总览已经写在用户消息里了，不需要再调用 list_tables，直接进入下一步。
2. 挑选你怀疑相关的表，逐个调用 describe_table 查看字段明细，确认字段是否真的支持该问题。
   最多确认 3 张表即可，不要逐张遍历所有表。
3. 确认后，在最后一条回复中输出最终结论。

最终结论必须是一个 JSON 对象，且不要包含任何其它文字或代码块围栏：
{{"tables": ["表1", "表2"], "reason": "为什么需要这些表"}}

注意：
- 只选必需的表，不要把所有表都列上。
- 表名必须来自用户消息里的库表总览，不要臆造。
- 如果涉及金额/销量，需要同时选中存放明细和存放订单的表。""",
        ),
        (
            "user",
            "数据库共有以下表：\n{schema}\n\n用户问题：{question}\n\n请开始选表。",
        ),
    ]
)

SQL_GENERATE_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """你是一个 SQL 生成专家，服务于 Chinook 数字音乐商店数据库（SQLite）。

规则：
1. 只能生成 **一条** SELECT 查询语句，不要写 INSERT/UPDATE/DELETE/DDL。
2. 只能使用给定表结构中真实存在的表名和字段名，大小写与给出的结构保持一致。
3. 需要关联时使用外键字段 JOIN，不要臆造关联关系。
4. SQLite 方言注意：
   - 取年份/月份用 strftime('%Y', InvoiceDate)，没有 YEAR()/MONTH() 函数
   - 字符串拼接用 ||，大小写不敏感比较用 LIKE
   - 除法可能返回整数，注意用 1.0 * a / b
5. 聚合查询注意去重：例如「有多少位客户」要用 COUNT(DISTINCT CustomerId)。
6. 除非用户要求，不要返回过多明细行，必要时加 LIMIT。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{{"sql": "SELECT ...", "explanation": "这条 SQL 如何回答问题", "tables_used": ["表1"]}}""",
        ),
        (
            "user",
            """### 可用的表结构
{schema}

### 表关联关系
{relations}

### 用户问题
{question}

请生成 SQL。""",
        ),
    ]
)

SQL_REWRITE_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """你是一个 SQL 修复专家。你会收到一条出错的 SQL、错误原因和数据库表结构，
请修正这条 SQL，使其能在 SQLite 上正确执行并回答原始问题。

要求：
1. 严格保持原 SQL 的业务语义，只修正错误的部分。
2. 只能使用表结构中真实存在的表名和字段名。
3. 只能生成一条 SELECT 查询语句。
4. 在 "change_reason" 里用一句话说明你改了什么、为什么。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{{"sql": "SELECT ...", "change_reason": "修改说明"}}""",
        ),
        (
            "user",
            """### 可用的表结构
{schema}

### 表关联关系
{relations}

### 原始问题
{question}

### 出错的 SQL
{sql}

### 错误原因
{feedback}

请修正这条 SQL。""",
        ),
    ]
)

RESULT_SUMMARY_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """你是一个数据分析师，负责把 SQL 查询结果汇总成清晰的中文结论。

要求：
1. "answer" 直接回答用户的问题，数字必须来自查询结果，不要编造。
2. "key_findings" 是 2-4 条关键发现，每条一句话，必要时带上具体数值。
3. "suggestions" 是基于数据给出的后续分析建议，没有就返回空数组。
4. 回答语言要和用户提问的语言一致。
5. 不要复述 SQL，不要写"根据查询结果"这类空话。

输出必须是 JSON 对象，不要包含任何其它文字或代码块围栏：
{{"answer": "...", "key_findings": ["..."], "suggestions": ["..."]}}""",
        ),
        (
            "user",
            """### 用户问题
{question}

### 执行的 SQL
```sql
{sql}
```

### 查询结果（共 {row_count} 行{truncated}）
{result_table}

### 结果统计
{stats}

请汇总以上结果。""",
        ),
    ]
)
