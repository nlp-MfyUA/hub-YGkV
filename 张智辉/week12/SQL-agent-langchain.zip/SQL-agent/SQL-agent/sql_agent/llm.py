"""
LLM 客户端封装 —— 基于 LangChain。

底层用 `langchain_openai.ChatOpenAI` 走 OpenAI 兼容协议，
因此 MiniMax / DeepSeek / OpenRouter 都可以直接复用。

对外仍然只暴露三个能力，调用方（stages.py）无需感知底层框架：
    chat()        —— 普通对话
    chat_json()   —— 结构化 JSON 输出（带一次自动修复重试）
    run_tools()   —— 工具调用循环（Agent 的最小实现）
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Callable

from langchain.agents import create_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.tools import BaseTool
from langchain_openai import ChatOpenAI
from pydantic import BaseModel

from .config import LLMConfig
from .utils import extract_json, strip_think


@dataclass
class ToolCallRecord:
    """一次工具调用的记录，用于展示 Agent 的执行轨迹。"""

    turn: int
    name: str
    arguments: str
    result_preview: str


@dataclass
class ToolLoopResult:
    """工具调用循环的结果。"""

    final_text: str
    calls: list[ToolCallRecord] = field(default_factory=list)
    turns: int = 0


class LLMClient:
    """
    对 OpenAI 兼容接口的薄封装，内部用 LangChain 的 ChatOpenAI。

    注意（MiniMax-M3 兼容性）：MiniMax 的 OpenAI 兼容层**不支持**
    `response_format={"type": "json_object"}`（经 langchain-openai 转发会抛
    `AttributeError: 'CompletionsWithRawResponse' object has no attribute 'parse'`），
    但**支持 function calling**。因此结构化输出统一走
    `with_structured_output(method="function_calling")`。
    """

    def __init__(self, cfg: LLMConfig = LLMConfig()) -> None:
        api_key = os.getenv(cfg.api_key_env)
        base_url = os.getenv(cfg.base_url_env)
        if not api_key:
            raise RuntimeError(
                f"未找到环境变量 {cfg.api_key_env}，请确认 .env 已加载"
            )

        self.cfg = cfg
        self.llm: BaseChatModel = ChatOpenAI(
            model=cfg.model,
            api_key=api_key,
            base_url=base_url,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
            request_timeout=cfg.timeout,
            max_retries=2,
            # MiniMax 专有：把思维链从 content 中拆到 reasoning_details
            extra_body={"reasoning_split": True} if cfg.reasoning_split else None,
        )
        self._extra_body_supported = cfg.reasoning_split

    # ------------------------------------------------------------ 基础调用
    def chat(
        self,
        messages: list[BaseMessage] | list[dict],
        *,
        tools: list[BaseTool] | list[dict] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AIMessage:
        """
        发一次对话请求，返回 LangChain 的 AIMessage。

        messages 可以是 LangChain 的消息对象，也可以是 {"role": ..., "content": ...}
        形式的 dict（LangChain 会自动转换）。
        """
        kwargs: dict[str, Any] = {}
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if tools:
            kwargs["tools"] = tools

        try:
            return self.llm.invoke(messages, **kwargs)
        except Exception:
            if self._extra_body_supported:
                # 该服务不认 reasoning_split，去掉后重试一次
                self._extra_body_supported = False
                self.llm = self._rebuild_llm()
                return self.llm.invoke(messages, **kwargs)
            raise

    def _rebuild_llm(self) -> BaseChatModel:
        """去掉 extra_body 后重建模型实例。"""
        cfg = self.cfg
        return ChatOpenAI(
            model=cfg.model,
            api_key=os.getenv(cfg.api_key_env),
            base_url=os.getenv(cfg.base_url_env),
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
            request_timeout=cfg.timeout,
            max_retries=2,
        )

    def chat_text(self, messages: list[BaseMessage] | list[dict], **kwargs) -> str:
        """发一次对话请求，返回去掉思维链的正文。"""
        response = self.chat(messages, **kwargs)
        return strip_think(response.content or "")

    def chat_json(
        self,
        messages: list[BaseMessage] | list[dict],
        *,
        schema: type[BaseModel] | None = None,
        repair_hint: str | None = None,
    ) -> dict:
        """
        发一次对话请求并期望返回 JSON 对象。

        - 传了 schema：走 LangChain 的 `with_structured_output(method="function_calling")`，
          由模型以函数调用的方式填 schema，LangChain 负责解析与校验。
        - 没传 schema：退回「提示词要求输出 JSON + 从正文抠 JSON」的宽松模式。

        解析失败时会追加一条「只要 JSON」的纠正消息再试一次；
        仍然失败则抛出异常，由上层决定是重试整条链路还是走兜底逻辑。
        """
        if schema is not None:
            return self._chat_json_structured(messages, schema, repair_hint=repair_hint)

        response = self.chat(messages)
        data = extract_json(response.content or "")
        if data is not None:
            return data

        # —— 第一次没拿到 JSON，做一次修复重试 ——
        repair_messages = list(messages) + [
            AIMessage(content=response.content or ""),
            HumanMessage(
                content=repair_hint
                or "上一次回复不是合法 JSON。请只输出一个 JSON 对象，不要包含任何解释文字或代码块围栏。"
            ),
        ]
        response = self.chat(repair_messages)
        data = extract_json(response.content or "")
        if data is None:
            raise ValueError(
                f"模型未能返回合法 JSON：{strip_think(response.content or '')[:300]}"
            )
        return data

    def _chat_json_structured(
        self,
        messages: list[BaseMessage] | list[dict],
        schema: type[BaseModel],
        *,
        repair_hint: str | None = None,
    ) -> dict:
        """
        用 function calling 做结构化输出（MiniMax 兼容路径）。

        LangChain 的 `with_structured_output` 会把 schema 变成一个工具给模型调用，
        再把返回的参数解析成 schema 实例 —— 这条路径 MiniMax 支持良好。
        """
        structured = self.llm.with_structured_output(schema, method="function_calling")
        try:
            result = structured.invoke(messages)
        except Exception as exc:
            # 结构化解析失败 -> 退回到宽松模式再试一次
            fallback = self.chat_json(messages, repair_hint=repair_hint)
            return fallback

        if isinstance(result, BaseModel):
            return result.model_dump()
        if isinstance(result, dict):
            return result
        return {"value": result}

    # ------------------------------------------------------------ 工具调用循环
    def run_tools(
        self,
        messages: list[BaseMessage] | list[dict],
        tools: list[BaseTool],
        handler: Callable[[str, dict], str],
        *,
        max_turns: int | None = None,
        system_prompt: str | None = None,
        response_format: type[BaseModel] | None = None,
    ) -> ToolLoopResult:
        """
        Agent 的最小实现：模型 -> 工具 -> 结果回填 -> 模型 …… 直到模型不再请求工具。

        底层用 LangChain 的 `create_agent`（LangChain 1.x 内置 Agent，基于 LangGraph），
        tools 传 LangChain 的 `@tool` 对象，handler 用于把工具执行结果回填给模型，
        并记录工具调用轨迹。

        handler(tool_name, arguments) 返回工具执行结果字符串。
        """
        max_turns = max_turns or self.cfg.max_tool_turns
        records: list[ToolCallRecord] = []
        counter = {"turn": 0}

        def _make_tool(base: BaseTool) -> BaseTool:
            """把 handler 包到工具实现里，保留工具的 schema 与描述。"""
            original = base.func

            def _wrapper(**kwargs) -> str:
                counter["turn"] += 1
                try:
                    result = handler(base.name, kwargs)
                except Exception as exc:  # 工具出错不应该让整个 Agent 挂掉
                    result = f"ERROR: {type(exc).__name__}: {exc}"
                records.append(
                    ToolCallRecord(
                        turn=counter["turn"],
                        name=base.name,
                        arguments=json.dumps(kwargs, ensure_ascii=False),
                        result_preview=str(result)[:200],
                    )
                )
                return result

            return base.copy(update={"func": _wrapper})

        wrapped = [_make_tool(t) for t in tools]

        # create_agent 自己会拼一条 system 提示，所以把 messages 里的 SystemMessage
        # 抽出来交给 system_prompt，避免系统提示重复两遍。
        system_parts: list[str] = []
        conversation: list[BaseMessage] = []
        for message in messages:
            if isinstance(message, SystemMessage):
                system_parts.append(str(message.content))
            else:
                conversation.append(message)
        if system_prompt:
            system_parts.insert(0, system_prompt)
        final_system_prompt = "\n\n".join(p for p in system_parts if p) or None

        agent = create_agent(
            model=self.llm,
            tools=wrapped,
            system_prompt=final_system_prompt,
            response_format=response_format,
        )

        result = agent.invoke(
            {"messages": conversation},
            config={"recursion_limit": max_turns * 2 + 4},
        )

        history = result.get("messages", [])
        final_text = ""
        for message in reversed(history):
            if isinstance(message, AIMessage) and not message.tool_calls:
                final_text = strip_think(message.content or "")
                break

        if response_format is not None:
            structured = result.get("structured_response")
            if structured is not None:
                final_text = json.dumps(
                    structured.model_dump() if isinstance(structured, BaseModel) else structured,
                    ensure_ascii=False,
                )

        return ToolLoopResult(final_text=final_text, calls=records, turns=counter["turn"])


def wait_backoff(attempt: int, base: float = 1.0) -> float:
    """简单的指数退避等待。"""
    import time

    time.sleep(base * (2 ** max(0, attempt - 1)))
    return base * (2 ** max(0, attempt - 1))
