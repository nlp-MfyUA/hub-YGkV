"""
工作流各阶段实现。

每个 Stage 都是「输入 -> 输出」的独立单元，方便单独调试和替换：
    TableSelector     table 选择（LangChain Agent + @tool 工具调用）
    SQLGenerator      sql 生成
    SQLValidator      sql 校验
    SQLRewriter       sql 改写
    SQLExecutor       sql 执行
    ResultSummarizer  结果汇总

LangChain 框架的落点：
    - 提示词      -> ChatPromptTemplate（见 prompts.py）
    - 工具        -> @tool 装饰（见 tools.py）
    - 结构化输出  -> Pydantic schema + with_structured_output(function_calling)
    - Agent      -> create_agent（LangChain 1.x 内置，基于 LangGraph）
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import pandas as pd

from .db_parser import BUSINESS_KEYWORDS, DBParser, QueryResult
from .llm import LLMClient
from .prompts import (
    RESULT_SUMMARY_PROMPT,
    SQL_GENERATE_PROMPT,
    SQL_REWRITE_PROMPT,
    TABLE_SELECT_PROMPT,
    GeneratedSQL,
    QuerySummary,
    RewrittenSQL,
    TableSelection,
)
from .tools import build_tools
from .utils import clean_sql, extract_json


# ==================================================================== 数据结构
@dataclass
class TableSelectionResult:
    tables: list[str]
    reason: str = ""
    source: str = "llm"            # llm | fallback
    tool_calls: list[dict] = field(default_factory=list)


@dataclass
class GeneratedSQLResult:
    sql: str
    explanation: str = ""
    tables_used: list[str] = field(default_factory=list)
    change_reason: str = ""


@dataclass
class ValidationResult:
    ok: bool
    reason: str


@dataclass
class ExecutionResult:
    ok: bool
    result: QueryResult | None = None
    error: str = ""


@dataclass
class Summary:
    answer: str
    key_findings: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


# ==================================================================== 阶段 2
class TableSelector:
    """
    table 选择 —— LangChain Agent + 工具调用。

    Agent 先 list_tables 摸清全貌，再用 describe_table 逐个确认候选表，
    最后通过结构化输出给出选中的表。模型不配合时降级为「中文业务词 -> 表」的兜底打分。
    """

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm
        self.tools = build_tools(parser)

    def run(self, question: str) -> TableSelectionResult:
        messages = TABLE_SELECT_PROMPT.invoke(
            {"schema": self.parser.schema_digest(), "question": question}
        ).to_messages()

        def handler(name: str, arguments: dict) -> str:
            if name == "list_tables":
                return self.parser.schema_digest()
            if name == "describe_table":
                table = str(arguments.get("table_name") or "").strip()
                return self.parser.describe_table(table)
            return f"未知工具：{name}"

        try:
            loop = self.llm.run_tools(
                messages,
                self.tools,
                handler,
                response_format=TableSelection,
            )
        except Exception as exc:
            fallback = self._fallback(question)
            fallback.reason = f"选表 Agent 调用失败（{type(exc).__name__}: {exc}），改用规则兜底"
            return fallback

        tool_calls = [
            {"name": c.name, "arguments": c.arguments, "result_preview": c.result_preview}
            for c in loop.calls
        ]

        tables = self._parse_tables(loop.final_text)
        if tables:
            return TableSelectionResult(
                tables=tables,
                reason=self._parse_reason(loop.final_text),
                source="llm",
                tool_calls=tool_calls,
            )

        fallback = self._fallback(question)
        fallback.tool_calls = tool_calls
        fallback.reason = "选表 Agent 未给出可解析的 JSON，改用规则兜底"
        return fallback

    # ---------------------------------------------------------- 内部工具方法
    def _parse_tables(self, text: str) -> list[str]:
        """从模型最终回复里解析表名列表。"""
        data = extract_json(text) or {}
        candidates = data.get("tables") or []
        if isinstance(candidates, str):
            candidates = [c.strip() for c in re.split(r"[,，\s]+", candidates) if c.strip()]

        valid = [t for t in candidates if t in self.parser.table_names]
        if valid:
            return list(dict.fromkeys(valid))

        # JSON 解析失败时，退而求其次：正文里出现过的表名
        mentioned = [t for t in self.parser.table_names if re.search(rf"\b{re.escape(t)}\b", text)]
        return list(dict.fromkeys(mentioned))

    @staticmethod
    def _parse_reason(text: str) -> str:
        data = extract_json(text) or {}
        return str(data.get("reason") or "")[:500]

    def _fallback(self, question: str) -> TableSelectionResult:
        """中文业务词打分兜底：把问题里的业务词映射到候选表。"""
        scores: dict[str, float] = {}
        for keyword, tables in BUSINESS_KEYWORDS.items():
            if keyword in question:
                for table in tables:
                    scores[table] = scores.get(table, 0) + 2.0

        # 表名/字段名里直接出现英文词也算命中
        lowered = question.lower()
        for table in self.parser.table_names:
            if table.lower() in lowered:
                scores[table] = scores.get(table, 0) + 3.0
            for column in self.parser.get_table_fields(table)["name"]:
                if len(column) > 3 and column.lower() in lowered:
                    scores[table] = scores.get(table, 0) + 1.0

        if not scores:
            # 完全没有线索时，按「最核心的三张业务表」兜底
            scores = {"invoices": 1.0, "tracks": 1.0, "customers": 1.0}

        from .config import RunConfig

        top = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        tables = [t for t, _ in top[: RunConfig().fallback_top_tables]]
        return TableSelectionResult(
            tables=tables, reason="基于业务关键词的规则兜底选表", source="fallback"
        )


# ==================================================================== 阶段 3
class SQLGenerator:
    """sql 生成 —— 依据选中的表结构和用户问题产出 SQL。"""

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm

    def run(self, question: str, tables: list[str]) -> GeneratedSQLResult:
        prompt = SQL_GENERATE_PROMPT.invoke(
            {
                "schema": self.parser.describe_tables(tables),
                "relations": self.parser.relations_digest(tables),
                "question": question,
            }
        ).to_messages()

        data = self.llm.chat_json(prompt, schema=GeneratedSQL)
        return self._to_generated(data)

    @staticmethod
    def _to_generated(data: dict) -> GeneratedSQLResult:
        sql = clean_sql(str(data.get("sql") or ""))
        used = data.get("tables_used") or []
        if isinstance(used, str):
            used = [used]
        return GeneratedSQLResult(
            sql=sql,
            explanation=str(data.get("explanation") or ""),
            tables_used=[str(t) for t in used],
        )


# ==================================================================== 阶段 4
class SQLValidator:
    """sql 校验 —— 只读白名单 + 单语句 + EXPLAIN 语法/表/列校验。"""

    def __init__(self, parser: DBParser) -> None:
        self.parser = parser

    def run(self, sql: str) -> ValidationResult:
        ok, reason = self.parser.check_sql(sql)
        return ValidationResult(ok=ok, reason=reason)


# ==================================================================== 阶段 5
class SQLRewriter:
    """
    sql 改写 —— 校验失败或执行报错时，把「原始问题 + 当前 SQL + 错误原因 + 表结构」
    一起交给模型重新生成一条正确的 SQL。

    表结构必须带上：改写时模型需要重新对齐表名/字段名，缺少 schema 很容易改出新错。
    """

    def __init__(self, parser: DBParser, llm: LLMClient) -> None:
        self.parser = parser
        self.llm = llm

    def run(self, question: str, sql: str, feedback: str, tables: list[str]) -> GeneratedSQLResult:
        prompt = SQL_REWRITE_PROMPT.invoke(
            {
                "schema": self.parser.describe_tables(tables),
                "relations": self.parser.relations_digest(tables),
                "question": question,
                "sql": sql,
                "feedback": feedback,
            }
        ).to_messages()

        data = self.llm.chat_json(prompt, schema=RewrittenSQL)
        generated = SQLGenerator._to_generated(data)
        generated.change_reason = str(data.get("change_reason") or "")
        return generated


# ==================================================================== 阶段 6
class SQLExecutor:
    """sql 执行 —— 只读连接执行，限制返回行数。"""

    def __init__(self, parser: DBParser, row_limit: int = 5000) -> None:
        self.parser = parser
        self.row_limit = row_limit

    def run(self, sql: str) -> ExecutionResult:
        try:
            result = self.parser.execute_sql(sql, limit=self.row_limit)
            return ExecutionResult(ok=True, result=result)
        except Exception as exc:
            return ExecutionResult(ok=False, error=f"{type(exc).__name__}: {exc}")


# ==================================================================== 阶段 7
class ResultSummarizer:
    """结果汇总 —— 把查询结果翻译成自然语言答案。"""

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    def run(self, question: str, sql: str, result: QueryResult, max_rows: int = 50) -> Summary:
        table_md = result.to_markdown(max_rows=max_rows)
        stats = describe_result_frame(result.frame)

        prompt = RESULT_SUMMARY_PROMPT.invoke(
            {
                "question": question,
                "sql": sql,
                "row_count": result.row_count,
                "truncated": "，已截断" if result.truncated else "",
                "result_table": table_md,
                "stats": stats,
            }
        ).to_messages()

        data = self.llm.chat_json(prompt, schema=QuerySummary)
        findings = data.get("key_findings") or []
        suggestions = data.get("suggestions") or []
        if isinstance(findings, str):
            findings = [findings]
        if isinstance(suggestions, str):
            suggestions = [suggestions]
        return Summary(
            answer=str(data.get("answer") or "").strip(),
            key_findings=[str(f) for f in findings],
            suggestions=[str(s) for s in suggestions],
        )


# ==================================================================== 辅助
def describe_result_frame(frame: pd.DataFrame) -> str:
    """
    生成结果的统计摘要。

    只给 LLM 看前 N 行时，它很容易把「前 50 行的平均值」误当成整体结论，
    所以这里把数值列的 count/sum/min/max/mean 明确算出来喂给它。
    """
    if frame is None or frame.empty:
        return "(无数据)"

    lines: list[str] = []
    numeric = frame.select_dtypes(include="number")
    for column in numeric.columns:
        series = numeric[column].dropna()
        if series.empty:
            continue
        lines.append(
            f"- `{column}`：count={len(series)} sum={series.sum():.4f} "
            f"min={series.min():.4f} max={series.max():.4f} mean={series.mean():.4f}"
        )

    for column in frame.columns:
        if column in numeric.columns:
            continue
        series = frame[column].dropna()
        if series.empty:
            continue
        top = series.value_counts().head(3)
        detail = ", ".join(f"{value}({count}次)" for value, count in top.items())
        lines.append(f"- `{column}`：非空 {len(series)} 行，出现最多的值：{detail}")

    return "\n".join(lines) if lines else "(无可统计列)"
