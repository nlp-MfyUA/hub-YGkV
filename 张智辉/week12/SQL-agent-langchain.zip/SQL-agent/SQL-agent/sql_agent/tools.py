"""
LangChain 工具定义 —— 把数据库探查能力包装成 Agent 可调用的工具。

用 `@tool` 装饰器声明，LangChain 会自动从中提取：
    - 函数名       -> 工具名
    - docstring    -> 工具描述（给模型看，决定它要不要调这个工具）
    - 类型注解     -> 参数 schema（function calling 的 parameters）
"""

from __future__ import annotations

from typing import Annotated

from langchain_core.tools import BaseTool, tool

from .db_parser import DBParser


def build_tools(parser: DBParser) -> list[BaseTool]:
    """基于 DBParser 构造选表 Agent 可用的工具集。"""

    @tool
    def list_tables() -> str:
        """列出数据库中所有表的用途说明和字段列表。"""
        return parser.schema_digest()

    @tool
    def describe_table(table_name: Annotated[str, "要查看的表名，例如 invoices"]) -> str:
        """查看某个表的完整字段明细（类型、主键、缺失值、取值范围、样例值）和样例数据行。"""
        return parser.describe_table(table_name)

    return [list_tables, describe_table]
