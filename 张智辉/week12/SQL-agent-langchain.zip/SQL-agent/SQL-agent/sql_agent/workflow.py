"""
SQL Agent Workflow —— 基于 LangGraph 的状态图编排。

    1. 数据库解析 -> 2. table 选择 -> 3. sql 生成 -> 4. sql 校验
    -> 5. sql 改写 -> 6. sql 执行 -> 7. 结果汇总

其中 4/5/6 构成了一个「生成-校验-改写-执行」的闭环：
校验不通过就改写后重校验，执行报错就改写后重跑，各自都有次数上限，
避免模型在错误里反复打转。

在 LangGraph 里，这个闭环由**条件边**表达：
    validate_sql --(通过)--> execute_sql
    validate_sql --(不通过)--> rewrite_sql --> validate_sql   （受 max_validate_rounds 限制）
    execute_sql  --(失败)--> rewrite_sql --> validate_sql      （受 max_exec_retries 限制）
"""

from __future__ import annotations

import operator
import time
from dataclasses import dataclass, field
from typing import Annotated, Callable, TypedDict

from langgraph.graph import END, START, StateGraph

from .config import RunConfig
from .db_parser import DBParser
from .llm import LLMClient
from .stages import (
    ExecutionResult,
    GeneratedSQLResult,
    ResultSummarizer,
    SQLExecutor,
    SQLGenerator,
    SQLRewriter,
    SQLValidator,
    Summary,
    TableSelectionResult,
    TableSelector,
)


@dataclass
class StageTrace:
    """单个阶段的执行记录，用于展示 Agent 的工作轨迹。"""

    index: int
    name: str
    ok: bool
    detail: str
    elapsed_ms: float
    data: dict = field(default_factory=dict)


@dataclass
class WorkflowResult:
    """一次完整问答的结果。"""

    question: str
    success: bool = False
    tables: list[str] = field(default_factory=list)
    sql: str = ""
    sql_history: list[tuple[str, str]] = field(default_factory=list)  # (SQL, 说明)
    columns: list[str] = field(default_factory=list)
    rows: list[tuple] = field(default_factory=list)
    row_count: int = 0
    summary: Summary | None = None
    error: str = ""
    trace: list[StageTrace] = field(default_factory=list)


class SQLAgentState(TypedDict):
    """
    LangGraph 的状态。

    标量字段由后写的节点覆盖；list 字段用 operator.add 累加器追加。
    """

    # 问题
    question: str

    # 阶段 2：选表
    tables: list[str]
    table_reason: str
    table_source: str
    tool_calls: list[dict]

    # 阶段 3/5：SQL 与演进历史
    sql: str
    sql_explanation: str
    sql_history: Annotated[list[dict], operator.add]

    # 阶段 4：校验
    validation_ok: bool
    validation_reason: str
    rewrite_count: int
    exec_retry_count: int
    rewrite_mode: str  # validation | execution —— 决定改写后往哪个分支走

    # 阶段 6：执行
    columns: list[str]
    rows: list[tuple]
    row_count: int
    exec_error: str

    # 阶段 7：汇总
    summary: dict | None

    # 终态
    error: str
    success: bool
    trace: Annotated[list[StageTrace], operator.add]


class SQLAgentWorkflow:
    """完整 SQL Agent 工作流（LangGraph 状态图）。"""

    def __init__(
        self,
        parser: DBParser | None = None,
        llm: LLMClient | None = None,
        run_config: RunConfig | None = None,
        on_stage: Callable[[StageTrace], None] | None = None,
    ) -> None:
        self.run_config = run_config or RunConfig()
        self.parser = parser or DBParser()
        self.llm = llm or LLMClient()
        self.on_stage = on_stage

        self.selector = TableSelector(self.parser, self.llm)
        self.generator = SQLGenerator(self.parser, self.llm)
        self.validator = SQLValidator(self.parser)
        self.rewriter = SQLRewriter(self.parser, self.llm)
        self.executor = SQLExecutor(self.parser, row_limit=self.run_config.exec_row_limit)
        self.summarizer = ResultSummarizer(self.llm)

        self.graph = self._build_graph()

    # ------------------------------------------------------------ 图定义
    def _build_graph(self):
        builder = StateGraph(SQLAgentState)

        builder.add_node("parse_db", self._node_parse_db)
        builder.add_node("select_tables", self._node_select_tables)
        builder.add_node("generate_sql", self._node_generate_sql)
        builder.add_node("validate_sql", self._node_validate_sql)
        builder.add_node("rewrite_sql", self._node_rewrite_sql)
        builder.add_node("execute_sql", self._node_execute_sql)
        builder.add_node("summarize", self._node_summarize)

        builder.add_edge(START, "parse_db")
        builder.add_edge("parse_db", "select_tables")

        # 选表失败 -> 直接结束
        builder.add_conditional_edges(
            "select_tables", self._route_after_select, {"continue": "generate_sql", "end": END}
        )

        builder.add_edge("generate_sql", "validate_sql")

        # 校验闭环：��过 -> 执行；不通过 -> 改写（次数上限内）-> 回到校验
        builder.add_conditional_edges(
            "validate_sql",
            self._route_after_validate,
            {"execute": "execute_sql", "rewrite": "rewrite_sql", "end": END},
        )

        # 改写后一律回到校验（校验通过才会去执行）
        builder.add_edge("rewrite_sql", "validate_sql")

        # 执行失败 -> 改写重跑；成功 -> 汇总
        builder.add_conditional_edges(
            "execute_sql",
            self._route_after_execute,
            {"summarize": "summarize", "rewrite": "rewrite_sql", "end": END},
        )

        builder.add_edge("summarize", END)

        return builder.compile()

    # ------------------------------------------------------------ 条件边
    def _route_after_select(self, state: SQLAgentState) -> str:
        return "continue" if state.get("tables") else "end"

    def _route_after_validate(self, state: SQLAgentState) -> str:
        if state.get("validation_ok"):
            return "execute"
        # 改写后仍然不合法：如果是「执行失败触发的改写」，按原逻辑直接放弃
        if state.get("rewrite_mode") == "execution":
            return "end"
        if state.get("rewrite_count", 0) < self.run_config.max_validate_rounds:
            return "rewrite"
        return "end"

    def _route_after_execute(self, state: SQLAgentState) -> str:
        # 执行成功（没有 exec_error）-> 去汇总；失败 -> 改写重跑（受次数上限限制）
        if not state.get("exec_error"):
            return "summarize"
        if state.get("exec_retry_count", 0) <= self.run_config.max_exec_retries:
            return "rewrite"
        return "end"

    # ------------------------------------------------------------ 节点
    def _node_parse_db(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        table_count = len(self.parser.table_names)
        field_count = sum(
            len(self.parser.inspector.get_columns(t)) for t in self.parser.table_names
        )
        trace = self._record(
            "数据库解析",
            True,
            f"解析到 {table_count} 张表 / {field_count} 个字段 / "
            f"{len(self.parser.foreign_keys)} 条外键关系",
            time.perf_counter() - started,
            {"tables": self.parser.table_names},
        )
        return {
            "trace": [trace],
            "rewrite_count": 0,
            "exec_retry_count": 0,
            "rewrite_mode": "",
            "error": "",
            "success": False,
        }

    def _node_select_tables(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        selection: TableSelectionResult = self.selector.run(state["question"])
        trace = self._record(
            "table 选择",
            bool(selection.tables),
            f"选中表：{', '.join(selection.tables) or '（无）'}　|　{selection.reason}",
            time.perf_counter() - started,
            {"selection": selection},
        )
        update = {
            "tables": selection.tables,
            "table_reason": selection.reason,
            "table_source": selection.source,
            "tool_calls": selection.tool_calls,
            "trace": [trace],
        }
        if not selection.tables:
            update["error"] = "未能选出任何表"
        return update

    def _node_generate_sql(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        generated: GeneratedSQLResult = self.generator.run(state["question"], state["tables"])
        trace = self._record(
            "sql 生成",
            bool(generated.sql),
            f"{generated.sql}\n    {generated.explanation}",
            time.perf_counter() - started,
            {"generated": generated},
        )
        return {
            "sql": generated.sql,
            "sql_explanation": generated.explanation,
            "sql_history": [{"sql": generated.sql, "reason": "初次生成"}],
            "trace": [trace],
        }

    def _node_validate_sql(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        validation = self.validator.run(state.get("sql", ""))
        trace = self._record(
            "sql 校验",
            validation.ok,
            validation.reason if validation.ok else f"校验未通过：{validation.reason}",
            time.perf_counter() - started,
            {"validation": validation},
        )
        update = {
            "validation_ok": validation.ok,
            "validation_reason": validation.reason,
            "trace": [trace],
        }
        if not validation.ok:
            # 校验未通过且改写次数已用尽 -> 终态错误
            if (
                state.get("rewrite_mode") != "execution"
                and state.get("rewrite_count", 0) >= self.run_config.max_validate_rounds
            ):
                update["error"] = f"SQL 校验始终未通过：{validation.reason}"
            elif state.get("rewrite_mode") == "execution":
                update["error"] = f"改写后的 SQL 仍不合法：{validation.reason}"
        return update

    def _node_rewrite_sql(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        mode = state.get("rewrite_mode") or "validation"
        feedback = (
            state.get("validation_reason", "")
            if mode == "validation"
            else state.get("exec_error", "")
        )
        generated = self.rewriter.run(
            state["question"], state.get("sql", ""), feedback, state["tables"]
        )
        trace = self._record(
            "sql 改写",
            bool(generated.sql),
            f"{generated.sql}\n    {generated.change_reason}",
            time.perf_counter() - started,
            {"generated": generated},
        )
        update: dict = {
            "sql": generated.sql,
            "sql_history": [
                {
                    "sql": generated.sql,
                    "reason": generated.change_reason
                    or ("校验失败改写" if mode == "validation" else "执行失败改写"),
                }
            ],
            "rewrite_mode": mode,
            "trace": [trace],
        }
        if mode == "validation":
            update["rewrite_count"] = state.get("rewrite_count", 0) + 1
        return update

    def _node_execute_sql(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        execution: ExecutionResult = self.executor.run(state.get("sql", ""))
        if execution.ok:
            trace = self._record(
                "sql 执行",
                True,
                f"返回 {execution.result.row_count} 行",
                time.perf_counter() - started,
                {"execution": execution},
            )
            return {
                "columns": execution.result.columns,
                "rows": execution.result.rows,
                "row_count": execution.result.row_count,
                "exec_error": "",
                "error": "",
                "trace": [trace],
            }

        trace = self._record(
            "sql 执行",
            False,
            f"执行失败：{execution.error}　-> 触发改写重跑",
            time.perf_counter() - started,
            {"execution": execution},
        )
        return {
            "exec_error": execution.error,
            "exec_retry_count": state.get("exec_retry_count", 0) + 1,
            "rewrite_mode": "execution",
            "error": f"SQL 执行失败：{execution.error}",
            "trace": [trace],
        }

    def _node_summarize(self, state: SQLAgentState) -> dict:
        started = time.perf_counter()
        from .db_parser import QueryResult

        query_result = QueryResult(
            columns=state.get("columns", []),
            rows=state.get("rows", []),
            row_count=state.get("row_count", 0),
            truncated=False,
        )
        try:
            summary = self.summarizer.run(
                state["question"],
                state.get("sql", ""),
                query_result,
                max_rows=self.run_config.result_rows_to_llm,
            )
        except Exception as exc:
            trace = self._record(
                "结果汇总",
                False,
                f"汇总失败：{type(exc).__name__}: {exc}",
                time.perf_counter() - started,
            )
            return {"error": f"结果汇总失败：{exc}", "success": False, "trace": [trace]}

        trace = self._record(
            "结果汇总",
            True,
            summary.answer,
            time.perf_counter() - started,
            {"summary": summary},
        )
        return {
            "summary": {
                "answer": summary.answer,
                "key_findings": summary.key_findings,
                "suggestions": summary.suggestions,
            },
            "success": True,
            "error": "",
            "trace": [trace],
        }

    # ------------------------------------------------------------ 轨迹记录
    def _record(
        self,
        name: str,
        ok: bool,
        detail: str,
        elapsed: float,
        data: dict | None = None,
    ) -> StageTrace:
        trace = StageTrace(
            index=len(getattr(self, "_trace_buffer", [])) + 1,
            name=name,
            ok=ok,
            detail=detail,
            elapsed_ms=round(elapsed * 1000, 1),
            data=data or {},
        )
        if not hasattr(self, "_trace_buffer"):
            self._trace_buffer = []
        self._trace_buffer.append(trace)
        if self.on_stage:
            self.on_stage(trace)
        return trace

    # ------------------------------------------------------------ 主流程
    def run(self, question: str) -> WorkflowResult:
        self._trace_buffer = []
        final_state = self.graph.invoke(
            {
                "question": question,
                "tables": [],
                "table_reason": "",
                "table_source": "",
                "tool_calls": [],
                "sql": "",
                "sql_explanation": "",
                "sql_history": [],
                "validation_ok": False,
                "validation_reason": "",
                "rewrite_count": 0,
                "exec_retry_count": 0,
                "rewrite_mode": "",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "exec_error": "",
                "summary": None,
                "error": "",
                "success": False,
                "trace": [],
            }
        )

        summary_dict = final_state.get("summary")
        summary = (
            Summary(
                answer=summary_dict.get("answer", ""),
                key_findings=summary_dict.get("key_findings", []),
                suggestions=summary_dict.get("suggestions", []),
            )
            if summary_dict
            else None
        )

        return WorkflowResult(
            question=question,
            success=bool(final_state.get("success")),
            tables=list(final_state.get("tables") or []),
            sql=final_state.get("sql", ""),
            sql_history=[
                (item.get("sql", ""), item.get("reason", ""))
                for item in (final_state.get("sql_history") or [])
            ],
            columns=list(final_state.get("columns") or []),
            rows=list(final_state.get("rows") or []),
            row_count=int(final_state.get("row_count") or 0),
            summary=summary,
            error=final_state.get("error", ""),
            trace=list(final_state.get("trace") or []),
        )
