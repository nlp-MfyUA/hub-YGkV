# Chinook SQL Agent Workflow（LangChain / LangGraph 版）

基于 `chinook.db`（Chinook 数字音乐商店销售数据，SQLite）的完整 SQL Agent 工作流实现，
对标 `sql-agent.ipynb` 作业要求：

```
数据库解析 → table 选择 → sql 生成 → sql 校验 → sql 改写 → sql 执行 → 结果汇总
```

**本版本用 LangChain / LangGraph 框架重写**（原版是手写 OpenAI SDK 调用）：

| 原手写实现 | LangChain 版 |
|-----------|------------|
| `openai.OpenAI` 客户端 | `langchain_openai.ChatOpenAI` |
| `dict` 消息 + 手拼 `response_format` | `langchain_core.messages` + `ChatPromptTemplate` |
| 自己解析模型输出的 JSON | Pydantic schema + `with_structured_output(method="function_calling")` |
| 自己实现工具调用循环 `run_tools` | `langchain_core.tools.@tool` + `langchain.agents.create_agent` |
| `if/while` 串起 7 个阶段 | `langgraph.graph.StateGraph` + 条件边 |

模型使用 **MiniMax-M3**，通过 `.env` 中的 `OPENAI_BASE_URL` / `OPENAI_API_KEY` 以
OpenAI 兼容协议接入。代码不绑定 MiniMax —— 换成 DeepSeek / OpenRouter 只需改两处配置。

---

## 一、运行

```bash
# 单次问答
python main.py "总销售额是多少"

# 交互式问答（exit / quit 退出）
python main.py

# 打印每个阶段的中间产物
python main.py "消费金额最高的5位客户是谁" --verbose

# 把完整工作流轨迹写成 JSON，便于复盘 / 做效果评测
python main.py "最贵的10首歌曲" --trace trace.json

# 只看生成的 SQL，跳过结果汇总
python main.py "每个国家有多少客户" --sql-only
```

### 依赖

```bash
pip install -r requirements.txt
```

> **关于 MiniMax 与 `json_object` 模式**：MiniMax 的 OpenAI 兼容层不支持
> `response_format={"type": "json_object"}` —— 经 `langchain-openai` 转发会抛
> `AttributeError: 'CompletionsWithRawResponse' object has no attribute 'parse'`。
> 但它**支持 function calling**，所以本项目所有结构化输出统一走
> `with_structured_output(method="function_calling")`。
>
> **关于 `openai-agents`**：课程 notebook `04_SQL-Code-Agent-Demo/sql-agent.ipynb` 里用到了
> `agents` SDK（`Agent` / `Runner` / `function_tool`）。该 SDK 要求 `openai>=2.45`，
> 而当前环境装的是 `openai 1.59.9`，直接 `import agents` 会报
> `ModuleNotFoundError: No module named 'openai.types.shared.reasoning'`。
>
> 本版本改用 LangChain 的 `create_agent`（LangChain 1.x 内置 Agent，底层基于 LangGraph），
> 同样能做工具调用循环，且不需要升级任何包。

---

## 二、目录结构

```
SQL-agent/
├── chinook.db                 # 数据库（课程原件在 04_SQL-Code-Agent-Demo/，此处为副本，保证本目录可独立运行）
├── main.py                    # 命令行入口
├── README.md
├── requirements.txt
└── sql_agent/
    ├── config.py              # 模型 / API / 路径 / 运行参数
    ├── utils.py               # Markdown 表格、思维链剥离、JSON 提取
    ├── llm.py                 # LangChain 封装：ChatOpenAI + 结构化输出 + Agent 工具循环
    ├── prompts.py             # ChatPromptTemplate + Pydantic 结构化输出 schema
    ├── tools.py               # @tool 工具：list_tables / describe_table
    ├── db_parser.py           # 数据库解析 + SQL 校验 + SQL 执行
    ├── stages.py              # 6 个业务阶段的具体实现
    └── workflow.py            # LangGraph 状态图编排 + 轨迹记录
```

> 课程原始 notebook（`sql-agent.ipynb` / `code-agent.ipynb`）仍留在
> `Week11/04_SQL-Code-Agent-Demo/`，是本实现的参考来源。

---

## 三、七个阶段

| # | 阶段 | 实现位置 | 说明 |
|---|------|----------|------|
| 1 | 数据库解析 | `db_parser.DBParser` | SQLAlchemy Inspector 拿到表清单、字段明细、外键关系；再对每个字段统计 distinct / 缺失值 / 极值 / 众数 / 样例值；并补上人工整理的「表用途 + 字段含义」说明 |
| 2 | table 选择 | `stages.TableSelector` | LangChain Agent（`create_agent`）+ `@tool` 工具：`describe_table` 逐张确认候选表，最后用 `response_format=TableSelection` 输出 `{"tables": [...], "reason": "..."}`；模型不配合时降级为「中文业务词 → 表」的规则打分 |
| 3 | sql 生成 | `stages.SQLGenerator` | `ChatPromptTemplate` 带上选中表的完整 schema + 外键关系 + 样例数据，提示 SQLite 方言（`strftime` 而非 `YEAR()` 等），用 `GeneratedSQL` schema 结构化输出 |
| 4 | sql 校验 | `stages.SQLValidator` | ① 只允许 `SELECT`/`WITH`；② 只允许单语句；③ 禁止 `INSERT/UPDATE/DROP/...` 等写操作关键字；④ `EXPLAIN` 预编译 —— 一次性验证语法、表名、列名 |
| 5 | sql 改写 | `stages.SQLRewriter` | 校验失败 / 执行报错时，把「原始问题 + 当前 SQL + 错误原因 + 表结构」一起交给模型重新生成。**改写必须带 schema** —— 否则模型会改出新的字段错误 |
| 6 | sql 执行 | `stages.SQLExecutor` | 只读连接执行，限制返回行数 |
| 7 | 结果汇总 | `stages.ResultSummarizer` | 把结果表 + 结果统计（数值列 count/sum/min/max/mean、文本列高频值）一起给模型，用 `QuerySummary` schema 产出自然语言答案 + 关键发现 + 后续建议 |

### 阶段 4/5/6 构成的闭环

```
生成 SQL ─→ 校验 ──┬─(通过)─→ 执行 ──┬─(成功)─→ 汇总
                   │                  │
                   └─(不通过)─→ 改写─┘   └─(报错)─→ 改写 ─→ 重新校验 ─→ 重跑
```

改写与重跑都有次数上限（`RunConfig.max_validate_rounds` / `max_exec_retries`），
避免模型在错误里反复打转。

---

## 四、LangChain / LangGraph 的落点

### 1. 状态图编排（`workflow.py`）

7 个阶段是 LangGraph 的 7 个节点，「校验失败 → 改写 → 重校验」是**条件边**：

```python
builder.add_conditional_edges(
    "validate_sql", self._route_after_validate,
    {"execute": "execute_sql", "rewrite": "rewrite_sql", "end": END},
)
builder.add_edge("rewrite_sql", "validate_sql")
```

状态用 `TypedDict` 描述；`trace` / `sql_history` 两个累加列表用
`Annotated[list, operator.add]` 声明，节点只返回增量，LangGraph 自动合并。

`workflow.graph.get_graph().draw_mermaid()` 可以直接导出流程图。

### 2. 工具（`tools.py`）

```python
@tool
def describe_table(table_name: Annotated[str, "要查看的表名，例如 invoices"]) -> str:
    """查看某个表的完整字段明细（类型、主键、缺失值、取值范围、样例值）和样例数据行。"""
    return parser.describe_table(table_name)
```

`@tool` 装饰器自动从 docstring 和类型注解里提取工具描述与参数 schema，
模型据此决定调用哪个工具、传什么参数。

### 3. 结构化输出（`prompts.py`）

每个 JSON 阶段配一个 Pydantic 模型：

```python
class GeneratedSQL(BaseModel):
    sql: str = Field(description="生成的 SQL 查询语句，只是一条 SELECT")
    explanation: str = Field(description="这条 SQL 如何回答用户的问题")
    tables_used: list[str] = Field(default_factory=list, description="SQL 中实际用到的表名")
```

调用时交给 LangChain，由它把 schema 转成 function calling 的参数定义并解析结果：

```python
structured = self.llm.with_structured_output(schema, method="function_calling")
```

### 4. Agent（`llm.py`）

`create_agent` 接管工具调用循环：模型决定调哪个工具 → LangChain 执行 → 结果回填给模型 → 直到模型给出结论。
`run_tools` 把工具包了一层，用来在保留工具 schema 的同时记录调用轨迹。

---

## 五、设计要点

### 1. 安全：两层只读保护

- **数据库层**：整条链路使用 SQLite 的 `mode=ro` URI 连接，
  `sqlite:///file:<path>?mode=ro&uri=true`。即使模型生成了 `DELETE`，数据库层面也无法落盘。
- **SQL 层**：`check_sql` 做关键字白名单 + 单语句检查，写操作语句在执行前就被拦下。

### 2. 容错：每一步都有兜底

| 失败点 | 兜底策略 |
|--------|----------|
| 选表 Agent 调用异常 | 降级为中文业务词规则打分 |
| 选表 Agent 输出无法解析成 JSON | 从正文里正则捞表名；再失败则规则打分 |
| 模型 JSON 输出格式错误 | `chat_json` 自动追加一条纠正消息重试一次 |
| 模型输出带 `<think>` 思维链 / ```` ``` ```` 围栏 | `strip_think` / `clean_sql` 统一清洗 |
| 模型用错字段名或表名 | 校验阶段发现 → 改写阶段修复 |
| 改写后仍不合法 | 放弃本次执行并如实报错，不会拿未校验的 SQL 去跑 |

### 3. 可观测：全流程轨迹

每个阶段都会产生一条 `StageTrace`（序号、名称、耗时、详情、是否通过），
`--trace` 可以把整条链路连同 SQL 演进过程导出成 JSON。

`sql_history` 记录了 SQL 的每一次改写及改写原因，方便复盘「模型为什么走偏了」。

### 4. 中文数据的编码处理

Windows 控制台默认 GBK，而 Chinook 的地址字段里存在非 GBK 字符（如 `São Paulo`），
`main.py` 启动时会强制 `sys.stdout.reconfigure(encoding="utf-8")`，
避免 `UnicodeEncodeError`。

---

## 六、切换模型

改 `sql_agent/config.py` 里的 `LLMConfig` 即可：

```python
@dataclass(frozen=True)
class LLMConfig:
    model: str = "MiniMax-M3"
    api_key_env: str = "OPENAI_API_KEY"
    base_url_env: str = "OPENAI_BASE_URL"
```

换成 DeepSeek：

```python
model: str = "deepseek-chat"
api_key_env: str = "DEEPSEEK_API_KEY"
base_url_env: str = "DEEPSEEK_API_URL"   # 注意末尾要补 /v1
```

换成 OpenRouter 则是 `OPENROUTE_API_KEY` + `OPENROUTE_API_URL`（末尾补 `/v1`）。

> **前提**：目标模型必须支持 **function calling**。
> 结构化输出依赖 `with_structured_output(method="function_calling")`，
> 不支持 function calling 的模型需要改用 `PydanticOutputParser` 的文本解析路径。

> `.env` 里的 key 建议不要提交到版本库；本仓库的 `.env` 已在 `.gitignore` 中。

---

## 七、参考问题

```bash
python main.py "总销售额是多少"
python main.py "消费金额最高的5位客户是谁？列出姓名、国家和消费总额"
python main.py "每位销售代表一共卖出了多少销售额？只列出销售额超过10的"
python main.py "Rock 流派有哪些专辑？按发行数量排序"
python main.py "数据库里一共有多少首歌曲"
python main.py "最贵的10首歌曲"
```

---

## 八、已知限制

- **延迟**：MiniMax-M3 是推理模型，选表阶段（多次工具调用往返）耗时在 5s~50s 之间波动。
  生产环境建议把选表阶段换成「一次调用直接给表名 + 缓存 schema 摘要」。
- **兜底词表有限**：`db_parser.BUSINESS_KEYWORDS` 是人工整理的中文业务词映射，
  换业务库时需要重新维护。
- **只读**：本实现刻意不支持写操作（`UPDATE` / `INSERT` / DDL）。要做数据分析师类
  「查完顺手改」的 Agent，需要额外加白名单表和审计日志。
- **统计口径**：`invoices.Total` 是订单总金额，`invoice_items` 里是明细金额，
  两者口径不同（前者已含税、后者按单价×数量）。问「销售额」时默认用 `invoices.Total`。
- **依赖 `json_object` 的模型不兼容**：见上文「关于 MiniMax 与 `json_object` 模式」。
