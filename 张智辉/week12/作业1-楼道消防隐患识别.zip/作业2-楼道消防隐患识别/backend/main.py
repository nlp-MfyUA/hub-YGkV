"""楼道消防隐患识别 —— 后端 API 服务

启动：
    cd backend && uvicorn main:app --reload --port 8000
"""
import os
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

# 统一加载课程根目录的 .env（逐级向上查找）
for _p in [BASE_DIR, *BASE_DIR.parents]:
    if (_p / ".env").exists():
        load_dotenv(_p / ".env")
        break

sys.path.insert(0, str(Path(__file__).resolve().parent))

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from analyzer import analyze_image
from risk_levels import RISK_LEVELS, VALID_LEVELS

FRONTEND_DIR = BASE_DIR / "frontend"

app = FastAPI(
    title="楼道消防隐患识别系统",
    description="上传楼道照片，调用 MiniMax-M3 多模态模型实时评估消防安全隐患等级",
    version="1.0.0",
)

# 前后端分离部署时放开跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health():
    """健康检查，顺便确认配置是否就绪"""
    return {
        "status": "ok",
        "model": os.getenv("MODEL_NAME", "MiniMax-M3"),
        "api_key_configured": bool(os.getenv("OPENAI_API_KEY")),
        "api_url": os.getenv("OPENAI_API_URL", ""),
    }


@app.get("/api/levels")
async def levels():
    """返回风险等级字典，前端用于渲染说明"""
    return {
        "levels": [
            {"name": name, "color": info["color"], "desc": info["desc"]}
            for name, info in RISK_LEVELS.items()
        ]
    }


@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    """上传图片，识别楼道消防隐患等级"""
    # 校验文件类型
    allowed = {"image/jpeg", "image/jpg", "image/png", "image/webp", "image/bmp", "image/gif"}
    if file.content_type and file.content_type.lower() not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"不支持的文件类型：{file.content_type}，请上传图片文件",
        )

    image_bytes = await file.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="上传的文件为空")
    if len(image_bytes) > 20 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="图片过大，请上传小于 20MB 的图片")

    start = time.time()
    try:
        result = analyze_image(image_bytes)
    except ValueError as e:
        # 模型输出解析失败 / 图片处理失败
        raise HTTPException(status_code=502, detail=str(e)) from e
    except RuntimeError as e:
        # 配置缺失
        raise HTTPException(status_code=500, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"模型调用失败：{e}") from e

    result["elapsed_ms"] = int((time.time() - start) * 1000)
    result["filename"] = file.filename
    return result


# 静态前端（放在最后，避免覆盖 /api 路由）
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/")
    async def index():
        return FileResponse(FRONTEND_DIR / "index.html")
