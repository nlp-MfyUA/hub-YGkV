"""调用 MiniMax-M3 进行楼道消防隐患识别"""
import base64
import io
import json
import os
import re
import time

from openai import OpenAI
from PIL import Image

from risk_levels import (
    RISK_LEVELS,
    SYSTEM_PROMPT,
    build_user_prompt,
    normalize_level,
)

# 图片最大边长，超出则等比缩放（节省 token 与推理时间）
MAX_IMAGE_SIZE = 1280
# base64 后允许的最大体积（约 8MB）
MAX_BASE64_BYTES = 8 * 1024 * 1024

# 上游 API 偶发失败时的重试次数与退避间隔（秒）
MAX_RETRIES = 2
RETRY_BACKOFF = 1.5

_client = None


def get_client() -> OpenAI:
    """惰性创建客户端，读取环境变量"""
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_API_URL", "")
        if not api_key:
            raise RuntimeError("未配置 OPENAI_API_KEY，请在 .env 中设置")
        if not base_url:
            raise RuntimeError("未配置 OPENAI_API_URL，请在 .env 中设置")
        _client = OpenAI(api_key=api_key, base_url=base_url)
    return _client


def encode_image(image_bytes: bytes) -> str:
    """图片字节 -> base64 data URL（自动缩放 + 格式转换）"""
    img = Image.open(io.BytesIO(image_bytes))
    img = img.convert("RGB")

    # 等比缩放
    w, h = img.size
    if max(w, h) > MAX_IMAGE_SIZE:
        scale = MAX_IMAGE_SIZE / max(w, h)
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    data = buf.getvalue()

    if len(data) > MAX_BASE64_BYTES:
        raise ValueError(f"图片过大（{len(data) / 1024 / 1024:.1f}MB），请上传小于 8MB 的图片")

    return "data:image/jpeg;base64," + base64.b64encode(data).decode("utf-8")


def extract_json(raw: str) -> dict:
    """从模型原始输出中抠出 JSON 并解析（容错：思考链 / markdown 代码块）"""
    cleaned = re.sub(r"<think>.*?</think>", "", raw or "", flags=re.DOTALL)

    # 优先取 ```json ... ``` 代码块
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", cleaned, flags=re.DOTALL)
    if m:
        cleaned = m.group(1)
    else:
        # 否则取第一个 {...} 子串
        m = re.search(r"\{.*?\}", cleaned, flags=re.DOTALL)
        if m:
            cleaned = m.group(0)

    try:
        return json.loads(cleaned)
    except Exception as e:
        raise ValueError(f"模型输出不是合法 JSON: {raw[:300]}... ({e})") from e


def analyze_image(image_bytes: bytes) -> dict:
    """
    识别楼道消防隐患。

    返回结构：
    {
      "level": "高风险",
      "level_desc": "...",
      "color": "#dc2626",
      "confidence": 0.9,
      "reason": "...",
      "evidence": ["..."],
      "suggestions": ["..."],
      "raw_output": "模型原始输出"
    }
    """
    data_url = encode_image(image_bytes)

    last_error: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            response = get_client().chat.completions.create(
                model=os.getenv("MODEL_NAME", "MiniMax-M3"),
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": build_user_prompt()},
                            {"type": "image_url", "image_url": {"url": data_url}},
                        ],
                    },
                ],
                max_tokens=1024,
                temperature=0.2,
                # 关闭推理模型的思考过程，保证输出纯 JSON
                extra_body={"thinking": {"type": "disabled"}},
            )
            break
        except Exception as e:
            last_error = e
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_BACKOFF * (attempt + 1))
    else:
        raise last_error

    raw = response.choices[0].message.content or ""
    data = extract_json(raw)

    level = normalize_level(data.get("level", ""))
    level_info = RISK_LEVELS[level]

    # 解析置信度
    try:
        confidence = float(data.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))

    def to_list(value) -> list:
        if isinstance(value, list):
            return [str(v) for v in value if str(v).strip()]
        if value and str(value).strip():
            return [str(value).strip()]
        return []

    return {
        "level": level,
        "level_desc": level_info["desc"],
        "color": level_info["color"],
        "confidence": round(confidence, 2),
        "reason": str(data.get("reason", "")).strip(),
        "evidence": to_list(data.get("evidence")),
        "suggestions": to_list(data.get("suggestions")),
        "raw_output": raw,
    }
