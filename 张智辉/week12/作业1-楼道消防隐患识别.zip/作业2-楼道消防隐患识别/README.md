# 楼道消防隐患识别系统

基于 **MiniMax-M3** 多模态大模型 + FastAPI + 原生前端，实现居民楼楼道照片的实时消防隐患识别。

上传楼道监控照片，AI 自动判断场景是否存在消防安全隐患，并给出**风险等级、判定理由、隐患元素清单和整改建议**。

## 风险等级标准

| 等级 | 判定标准 | 颜色 |
|------|---------|------|
| **高风险** | 楼道中出现电动车、电瓶、飞线充电等可能起火的元素 | 🔴 红 |
| **中风险** | 大量堆积物严重影响通行，或堆放纸箱、木质家具等易燃堵塞物 | 🟠 橙 |
| **低风险** | 存在楼道堆物现象但不严重 | 🟡 黄 |
| **无风险** | 楼道干净，无堆放物品 | 🟢 绿 |
| **非楼道** | 与楼道无关的图片 | ⚪ 灰 |

## 项目结构

```
03-项目案例-楼道消防隐患识别/
├── backend/
│   ├── main.py           # FastAPI 服务，路由 + 静态资源挂载
│   ├── analyzer.py       # MiniMax-M3 调用、图片编码、JSON 容错解析
│   └── risk_levels.py    # 风险等级定义 + 系统提示词 + 等级归一化
├── frontend/
│   ├── index.html        # 页面结构
│   ├── style.css         # 样式
│   └── app.js            # 上传、请求、结果渲染
├── .env                  # API Key / URL 配置
├── requirements.txt
└── start.sh              # 一键启动
```

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置 `.env`

API Key 统一使用**课程根目录**的 `.env`（本项目无需另建）：

```
/Users/annishark/Desktop/AI大模型课程/.env
```

其中需要的变量：

```bash
OPENAI_API_KEY=...              # MiniMax 的 key
OPENAI_API_URL=https://api.minimaxi.com/v1
MODEL_NAME=MiniMax-M3           # 可选，默认 MiniMax-M3
```

后端启动时会从项目目录逐级向上查找 `.env` 并自动加载。

### 3. 启动

```bash
./start.sh
# 或
cd backend && uvicorn main:app --reload --port 8000
```

### 4. 访问

浏览器打开 **http://localhost:8000**

## API 说明

### POST `/api/analyze`

上传图片，返回识别结果。

```bash
curl -X POST http://localhost:8000/api/analyze -F "file=@corridor.jpg"
```

响应示例：

```json
{
  "level": "高风险",
  "level_desc": "楼道中出现电动车、电瓶、飞线充电等可能起火的元素",
  "color": "#dc2626",
  "confidence": 0.93,
  "reason": "画面中楼道内停放了电动车及配套电瓶，并可见从墙面插座引出的充电线缆……",
  "evidence": ["电动车停放于楼道内", "可见电瓶", "墙面引出充电线缆（疑似飞线充电）"],
  "suggestions": ["立即将电动车及电瓶移出楼道……", "立即拔除并剪断飞线充电线缆……"],
  "elapsed_ms": 3210,
  "filename": "monitor.jpg"
}
```

### 其他接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查，返回模型名和配置状态 |
| GET | `/api/levels` | 返回风险等级字典（含颜色） |
| POST | `/api/analyze` | 上传图片识别隐患 |

## 实现要点

### 1. 多模态调用

图片以 base64 data URL 形式随 Chat Completions 请求发送：

```python
{
    "role": "user",
    "content": [
        {"type": "text", "text": "请识别这张图片中的场景……"},
        {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}},
    ]
}
```

### 2. 关闭思考过程

MiniMax-M3 是推理模型，默认会输出 `<think>...</think>` 思考链，干扰 JSON 解析。通过 `extra_body` 透传参数关闭：

```python
extra_body={"thinking": {"type": "disabled"}}
```

### 3. JSON 容错解析

模型可能返回带 ```json 代码块或多余文本的内容，`extract_json()` 做了三级兜底：
去掉 `<think>` 链 → 提取 markdown 代码块 → 提取第一个 `{...}` 子串。

### 4. 等级归一化

`normalize_level()` 兼容模型的多种写法（"高风险（严重）"、"HIGH"、"高" 等），统一归一到 5 个标准等级。

### 5. 图片预处理

超过 1280px 的图片等比缩放、转为 JPEG（quality=85），既节省 token 也加快响应。

## 调优建议

- **换模型**：改 `.env` 的 `MODEL_NAME` 即可（如 `MiniMax-Text-01`）
- **调整判定松紧**：改 `backend/risk_levels.py` 的 `SYSTEM_PROMPT`
- **新增等级**：在 `RISK_LEVELS` 字典加一项 + 在 `normalize_level()` 加同义词映射
- **接入真实监控流**：把 `/api/analyze` 改成接收摄像头 RTSP 推流即可
