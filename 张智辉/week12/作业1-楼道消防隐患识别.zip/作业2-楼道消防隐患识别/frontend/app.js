// 楼道消防隐患识别 —— 前端交互
const $ = (id) => document.getElementById(id);

const dropzone = $("dropzone");
const fileInput = $("fileInput");
const previewWrap = $("previewWrap");
const previewImg = $("previewImg");
const removeBtn = $("removeBtn");
const analyzeBtn = $("analyzeBtn");
const errorBox = $("errorBox");
const emptyState = $("emptyState");
const resultContent = $("resultContent");
const levelsGrid = $("levelsGrid");

let currentFile = null;

/* ---------- 加载等级说明 ---------- */
async function loadLevels() {
    try {
        const res = await fetch("/api/levels");
        const data = await res.json();
        levelsGrid.innerHTML = data.levels.map(l => `
            <div class="level-card" style="border-left-color:${l.color}">
                <div class="level-name" style="color:${l.color}">${l.name}</div>
                <div class="level-desc">${l.desc}</div>
            </div>
        `).join("");
    } catch (e) {
        console.error("加载等级说明失败", e);
    }
}

/* ---------- 健康检查 ---------- */
async function checkHealth() {
    try {
        const res = await fetch("/api/health");
        const data = await res.json();
        if (data.model) $("modelTag").textContent = data.model;
        if (!data.api_key_configured) {
            showError("后端未配置 OPENAI_API_KEY，请检查 .env 文件");
        }
    } catch (e) {
        console.error("健康检查失败", e);
    }
}

/* ---------- 错误提示 ---------- */
function showError(msg) {
    errorBox.textContent = msg;
    errorBox.hidden = false;
}
function clearError() {
    errorBox.hidden = true;
    errorBox.textContent = "";
}

/* ---------- 文件选择 ---------- */
dropzone.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (e) => {
    if (e.target.files.length) handleFile(e.target.files[0]);
});

["dragenter", "dragover"].forEach(evt => {
    dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });
});
["dragleave", "drop"].forEach(evt => {
    dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
    });
});
dropzone.addEventListener("drop", (e) => {
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
});

function handleFile(file) {
    clearError();
    if (!file.type.startsWith("image/")) {
        showError("请选择图片文件");
        return;
    }
    if (file.size > 20 * 1024 * 1024) {
        showError("图片过大，请上传小于 20MB 的图片");
        return;
    }
    currentFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        previewWrap.hidden = false;
        dropzone.style.display = "none";
        analyzeBtn.disabled = false;
    };
    reader.readAsDataURL(file);
}

removeBtn.addEventListener("click", () => {
    currentFile = null;
    fileInput.value = "";
    previewImg.src = "";
    previewWrap.hidden = true;
    dropzone.style.display = "";
    analyzeBtn.disabled = true;
    clearError();
});

/* ---------- 调用识别接口 ---------- */
analyzeBtn.addEventListener("click", async () => {
    if (!currentFile) return;
    clearError();

    const btnText = analyzeBtn.querySelector(".btn-text");
    const spinner = analyzeBtn.querySelector(".spinner");
    analyzeBtn.disabled = true;
    btnText.textContent = "识别中...";
    spinner.hidden = false;
    emptyState.hidden = true;
    resultContent.hidden = true;

    const formData = new FormData();
    formData.append("file", currentFile);

    try {
        const res = await fetch("/api/analyze", { method: "POST", body: formData });
        const data = await res.json();

        if (!res.ok) {
            throw new Error(data.detail || `请求失败（${res.status}）`);
        }
        renderResult(data);
    } catch (err) {
        showError(err.message || "识别失败，请重试");
        emptyState.hidden = false;
    } finally {
        analyzeBtn.disabled = false;
        btnText.textContent = "开始识别";
        spinner.hidden = true;
    }
});

/* ---------- 渲染结果 ---------- */
function renderResult(d) {
    $("riskBadge").textContent = d.level;
    $("riskDesc").textContent = d.level_desc || "";
    $("riskConfidence").textContent = d.confidence !== undefined ? `${(d.confidence * 100).toFixed(0)}%` : "--";
    $("riskReason").textContent = d.reason || "（模型未给出理由）";

    // 按等级着色
    const card = $("riskCard");
    card.style.background = `linear-gradient(135deg, ${d.color}, ${shade(d.color, -18)})`;

    // 隐患元素
    const ev = $("evidenceList");
    ev.innerHTML = (d.evidence && d.evidence.length)
        ? d.evidence.map(e => `<li>${escapeHtml(e)}</li>`).join("")
        : `<li class="empty">未发现明显隐患元素</li>`;

    // 整改建议
    const sg = $("suggestionList");
    sg.innerHTML = (d.suggestions && d.suggestions.length)
        ? d.suggestions.map(s => `<li>${escapeHtml(s)}</li>`).join("")
        : `<li class="empty">无需整改</li>`;

    // 元信息
    const meta = [];
    if (d.filename) meta.push(`文件：${d.filename}`);
    if (d.elapsed_ms !== undefined) meta.push(`耗时：${(d.elapsed_ms / 1000).toFixed(1)}s`);
    $("metaLine").innerHTML = meta.map(m => `<span>${escapeHtml(m)}</span>`).join("");

    emptyState.hidden = true;
    resultContent.hidden = false;
}

/* ---------- 工具函数 ---------- */
function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
}

// 颜色加深/变浅
function shade(hex, percent) {
    const num = parseInt(hex.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const r = Math.min(255, Math.max(0, (num >> 16) + amt));
    const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amt));
    const b = Math.min(255, Math.max(0, (num & 0x0000FF) + amt));
    return "#" + ((r << 16) + (g << 8) + b).toString(16).padStart(6, "0");
}

/* ---------- 初始化 ---------- */
loadLevels();
checkHealth();
