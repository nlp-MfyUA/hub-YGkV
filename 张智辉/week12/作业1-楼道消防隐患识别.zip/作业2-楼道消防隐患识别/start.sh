#!/bin/bash
# 启动楼道消防隐患识别系统
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE_DIR/backend"

echo "=========================================="
echo " 楼道消防隐患识别系统"
echo "=========================================="
echo " 访问地址: http://localhost:8000"
echo " 按 Ctrl+C 停止"
echo ""

exec python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 "$@"
