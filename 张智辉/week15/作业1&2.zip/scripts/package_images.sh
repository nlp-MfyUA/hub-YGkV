#!/usr/bin/env bash
# Package all emotion-* images into a single portable .tar archive.
# Usage: bash scripts/package_images.sh [output-dir]
#   output-dir defaults to ./dist
set -euo pipefail

OUT_DIR="${1:-dist}"
mkdir -p "$OUT_DIR"
ARCHIVE="$OUT_DIR/emotion-assistant-images.tar"

IMAGES=(
  emotion-gateway:latest
  emotion-sentiment-langgraph:latest
  emotion-sentiment-agents:latest
  emotion-respond-langgraph:latest
  emotion-respond-agents:latest
  emotion-frontend:latest
)

echo "== 校验镜像 =="
for img in "${IMAGES[@]}"; do
  if ! docker image inspect "$img" >/dev/null 2>&1; then
    echo "缺少镜像 $img，请先执行 bash scripts/build_images.sh" >&2
    exit 1
  fi
  echo "  ok $img"
done

echo "== 打包镜像到 $ARCHIVE =="
docker save -o "$ARCHIVE" "${IMAGES[@]}"

SIZE=$(du -h "$ARCHIVE" | cut -f1)
echo "完成：$ARCHIVE ($SIZE)"
echo "它包含 $(docker image ls --format '{{.Repository}}:{{.Tag}}' | grep -c '^emotion-') 个 emotion 镜像。"
echo
echo "其它机器加载： docker load -i $ARCHIVE"
echo "或解压查看：   tar -tf $ARCHIVE | head"
