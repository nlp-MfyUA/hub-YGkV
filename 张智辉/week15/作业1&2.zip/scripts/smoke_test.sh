#!/usr/bin/env bash
set -euo pipefail

echo "== 1. 前端 =="
curl -fsS -o /dev/null -w "frontend  HTTP %{http_code}\n" http://localhost:8080/

echo "== 2. 各进程健康检查 =="
for spec in \
  "gateway:8100" \
  "sentiment-langgraph:8001" \
  "sentiment-agents:8011" \
  "respond-langgraph:8002" \
  "respond-agents:8012"; do
  name="${spec%%:*}"
  port="${spec##*:}"
  curl -fsS -o /dev/null -w "$name HTTP %{http_code}\n" "http://localhost:$port/health"
done

echo "== 3. 可选框架 =="
curl -fsS http://localhost:8100/api/frameworks; echo

echo "== 4. 端到端 /api/chat（默认框架）=="
for text in "这次考试终于过了，太开心了！" "最近工作压力好大，感觉很焦虑。" "今天不开心了怎么办" "今天天气还不错。"; do
  echo "输入: $text"
  curl -fsS -X POST http://localhost:8100/api/chat \
    -H 'Content-Type: application/json' \
    -d "{\"text\": \"$text\"}"
  echo
done

echo "== 5. 请求级框架切换 =="
for fw in langgraph openai_agents; do
  echo "framework=$fw"
  curl -fsS -X POST http://localhost:8100/api/chat \
    -H 'Content-Type: application/json' \
    -d "{\"text\": \"今天不开心了怎么办\", \"framework\": \"$fw\"}"
  echo
done

echo "冒烟测试完成。"
