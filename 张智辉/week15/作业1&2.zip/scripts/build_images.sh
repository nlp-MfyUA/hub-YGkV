#!/usr/bin/env bash
# Build every image directly with a fixed tag, then `docker compose up -d`.
# Useful when `docker compose build` fails because of a BuildKit/bake issue.
set -euo pipefail

for spec in \
  "gateway:emotion-gateway" \
  "sentiment_langgraph:emotion-sentiment-langgraph" \
  "sentiment_agents:emotion-sentiment-agents" \
  "respond_langgraph:emotion-respond-langgraph" \
  "respond_agents:emotion-respond-agents" \
  "frontend:emotion-frontend"; do
  dir="${spec%%:*}"
  tag="${spec##*:}"
  echo "=== building $dir -> $tag ==="
  docker build -f "$dir/Dockerfile" -t "$tag:latest" .
done

echo "镜像构建完成。运行：docker compose up -d"
