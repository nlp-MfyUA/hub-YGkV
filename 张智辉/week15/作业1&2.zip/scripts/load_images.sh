#!/usr/bin/env bash
# Load a previously packaged image archive, then show what is available.
# Usage: bash scripts/load_images.sh [archive.tar]
#   archive defaults to ./dist/emotion-assistant-images.tar
set -euo pipefail

ARCHIVE="${1:-dist/emotion-assistant-images.tar}"

if [ ! -f "$ARCHIVE" ]; then
  echo "找不到镜像包 $ARCHIVE" >&2
  echo "请先执行 bash scripts/package_images.sh 生成。" >&2
  exit 1
fi

echo "== 从 $ARCHIVE 加载镜像 =="
docker load -i "$ARCHIVE"

echo
echo "== 当前 emotion 镜像 =="
docker image ls --format '{{.Repository}}:{{.Tag}}\t{{.ID}}\t{{.Size}}' | grep '^emotion-' | sort

echo
echo "加载完成。启动：cp .env.example .env（填好 DEEPSEEK_API_KEY）后 docker compose up -d"
