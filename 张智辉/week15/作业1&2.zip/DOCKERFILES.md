# Dockerfile 说明

本项目共 6 个镜像，每个服务一个独立 Dockerfile，构建上下文均为仓库根目录（`.`），因为都要 `COPY common/`（共享的 pydantic 契约与 LLM 适配层）。

## 统一设计

Python 服务镜像结构一致：

```dockerfile
FROM python:3.12-slim
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/app PIP_NO_CACHE_DIR=1
WORKDIR /app
COPY common/ ./common/                 # 共享契约 + LLM 适配
COPY <service>/requirements.txt ./requirements.txt
RUN pip install -r requirements.txt    # 依赖在代码 COPY 之前，利于层缓存
COPY <service>/ ./<service>/           # 服务代码
EXPOSE <port>
CMD ["uvicorn", "<service>.app:app", "--host", "0.0.0.0", "--port", "<port>"]
```

- `PYTHONPATH=/app` 让 `from common...` 与 `from <service>...` 都能导入。
- 依赖安装放在代码 COPY 之前：代码改动不会触发 `pip install` 重跑。
- 前端镜像基于 `nginx:1.27-alpine`，并把 `index.html` / `nginx.conf` 权限设为 644（避免 403）。

## 六个镜像一览

| 镜像名 | Dockerfile | 基础镜像 | 容器内端口 | 主要依赖 |
|---|---|---|---|---|
| `emotion-gateway:latest` | `gateway/Dockerfile` | python:3.12-slim | 8000 | fastapi, uvicorn, httpx, pydantic |
| `emotion-sentiment-langgraph:latest` | `sentiment_langgraph/Dockerfile` | python:3.12-slim | 8001 | + langgraph, langchain-openai, openai |
| `emotion-sentiment-agents:latest` | `sentiment_agents/Dockerfile` | python:3.12-slim | 8011 | + openai-agents, openai |
| `emotion-respond-langgraph:latest` | `respond_langgraph/Dockerfile` | python:3.12-slim | 8002 | + langgraph, langchain-openai, openai |
| `emotion-respond-agents:latest` | `respond_agents/Dockerfile` | python:3.12-slim | 8012 | + openai-agents, openai |
| `emotion-frontend:latest` | `frontend/Dockerfile` | nginx:1.27-alpine | 80 | 静态 HTML + nginx 反向代理 |

## 构建方式

```bash
# 常规（本机 Docker 支持 BuildKit bake 时）
docker compose up -d --build

# 回退方案（本机 build 报 sharedkey gRPC 错误时）：逐镜像构建
bash scripts/build_images.sh
docker compose up -d
```

`docker-compose.yml` 已为每个服务固定 `image: emotion-*:latest`，因此上述两种方式产出的镜像名完全一致，可互相替换。

## 打包 / 迁移

```bash
bash scripts/package_images.sh   # 生成 dist/emotion-assistant-images.tar（含全部 6 个镜像）
bash scripts/load_images.sh      # 在目标机加载
```

镜像内不存储任何密钥；`DEEPSEEK_API_KEY` 通过 `.env` 在运行时注入（见 `docker-compose.yml` 的 `x-llm-env`）。打包时不包含 `.env`（`.dockerignore` 已排除）。
