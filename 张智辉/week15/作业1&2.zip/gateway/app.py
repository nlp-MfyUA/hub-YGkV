"""Backend gateway - the only process the frontend talks to.

It serialises the two workers: POST /api/chat -> process 1 (/sentiment) ->
process 2 (/respond) -> aggregated JSON. Both frameworks expose the same
contract; FRAMEWORK decides which pair of URLs is used.
"""
import asyncio
import os
import uuid

import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from common.models import ChatRequest, ChatResponse

FRAMEWORK = os.getenv("FRAMEWORK", "langgraph").strip().lower()


def _endpoint(custom: str, path: str, default_base: str) -> str:
    """Accept either a base URL or a full endpoint URL from the env override."""
    base = (custom or default_base).strip().rstrip("/") or default_base
    return base if base.endswith(path) else base + path


_DEFAULT_BASES = {
    "langgraph": (
        "http://sentiment-langgraph:8001",
        "http://respond-langgraph:8002",
    ),
    "openai_agents": (
        "http://sentiment-agents:8011",
        "http://respond-agents:8012",
    ),
}

_VALID_FRAMEWORKS = tuple(_DEFAULT_BASES.keys())


def _resolve_urls(framework: str | None) -> tuple[str, str, str]:
    """Resolve (framework, sentiment_url, respond_url) for one request.

    The request-level `framework` wins when valid; otherwise the FRAMEWORK env
    var (the startup default) is used. SENTIMENT_URL / RESPOND_URL overrides
    only apply to the startup default framework, so switching frameworks in
    the frontend never accidentally inherits the other pair's URL.
    """
    fw = framework.strip().lower() if framework else FRAMEWORK
    if fw not in _DEFAULT_BASES:
        fw = FRAMEWORK
    sentiment_base, respond_base = _DEFAULT_BASES[fw]
    if fw == FRAMEWORK:
        sentiment_base = (os.getenv("SENTIMENT_URL") or sentiment_base).strip() or sentiment_base
        respond_base = (os.getenv("RESPOND_URL") or respond_base).strip() or respond_base
    return (
        fw,
        _endpoint(None, "/sentiment", sentiment_base),
        _endpoint(None, "/respond", respond_base),
    )


# Startup defaults (used by /health); each request resolves its own URLs.
_, SENTIMENT_URL, RESPOND_URL = _resolve_urls(None)

FALLBACK_REPLY = "谢谢你愿意告诉我。我在这儿听你说，愿意的话可以多讲一点。"
REQUEST_TIMEOUT = 10.0

app = FastAPI(title="Sentiment Assistant - Gateway")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


async def _post_json(client: httpx.AsyncClient, url: str, payload: dict) -> dict:
    """One retry on transient network / 429 / 5xx failures."""
    last_error = None
    for attempt in range(2):
        try:
            response = await client.post(url, json=payload)
            if response.status_code == 429 or response.status_code >= 500:
                last_error = RuntimeError(f"upstream {url} -> HTTP {response.status_code}")
                if attempt == 0:
                    await asyncio.sleep(0.3)
                    continue
                raise last_error
            response.raise_for_status()
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            last_error = exc
            if attempt == 0:
                await asyncio.sleep(0.3)
                continue
    raise last_error or RuntimeError("upstream call failed")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "framework": FRAMEWORK,
        "frameworks": list(_VALID_FRAMEWORKS),
        "sentiment_url": SENTIMENT_URL,
        "respond_url": RESPOND_URL,
    }


@app.get("/api/frameworks")
async def frameworks():
    """Let the frontend discover selectable frameworks and the default one."""
    return {"frameworks": list(_VALID_FRAMEWORKS), "default": FRAMEWORK}


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    request_id = str(uuid.uuid4())
    framework, sentiment_url, respond_url = _resolve_urls(req.framework)
    timeout = httpx.Timeout(REQUEST_TIMEOUT)
    async with httpx.AsyncClient(timeout=timeout) as client:
        # Process 1
        try:
            sentiment = await _post_json(
                client,
                sentiment_url,
                {"text": req.text, "request_id": request_id},
            )
            label = sentiment.get("label", "neutral")
            if label not in ("positive", "negative", "neutral"):
                label = "neutral"
            confidence = float(sentiment.get("confidence", 0.0))
        except Exception:
            return ChatResponse(
                request_id=request_id,
                label="neutral",
                confidence=0.0,
                reply=FALLBACK_REPLY,
                degraded=True,
                framework=framework,
            )

        # Process 2
        try:
            generated = await _post_json(
                client,
                respond_url,
                {
                    "text": req.text,
                    "label": label,
                    "confidence": confidence,
                    "request_id": request_id,
                },
            )
            reply = str(generated.get("reply", "")).strip()
            if not reply:
                raise ValueError("empty reply")
        except Exception:
            reply = FALLBACK_REPLY
            degraded = True
        else:
            degraded = False

    return ChatResponse(
        request_id=request_id,
        label=label,
        confidence=round(max(0.0, min(1.0, confidence)), 2),
        reply=reply,
        degraded=degraded,
        framework=framework,
    )
