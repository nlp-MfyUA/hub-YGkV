"""Process 1 - Sentiment recognition, OpenAI Agents SDK implementation.

The user's text is ALWAYS passed to the SentimentAgent. The agent performs
intent recognition through a model call (real DeepSeek or the local
OpenAI-compatible mock endpoint). No keyword shortcut in this service.
"""
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from common.config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
from common.llm import CLASSIFY_SYSTEM, _parse_json
from common.models import SentimentRequest, SentimentResponse

try:
    from agents import Agent, Runner, set_default_openai_api, set_default_openai_client
except ImportError as exc:  # pragma: no cover - install openai-agents in the image
    Agent = Runner = None  # type: ignore
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


class AgentSentiment(BaseModel):
    label: Literal["positive", "negative", "neutral"]
    confidence: float = Field(..., ge=0.0, le=1.0)


def _configure_sdk() -> None:
    """Point the Agents SDK at the configured Chat Completions endpoint."""
    if _IMPORT_ERROR is not None:
        return
    from openai import AsyncOpenAI

    try:
        set_default_openai_api("chat_completions")
    except Exception:
        pass
    set_default_openai_client(
        AsyncOpenAI(
            api_key=LLM_API_KEY,
            base_url=LLM_BASE_URL,
            timeout=30.0,
        )
    )


_configure_sdk()

_sdk_agent = None
if _IMPORT_ERROR is None:
    # NOTE: do not use Agents SDK `output_type` here — it sends a
    # `response_format` that DeepSeek does not support. Ask for JSON in the
    # instructions and parse the plain text reply ourselves instead.
    _sdk_agent = Agent(
        name="SentimentAgent",
        instructions=CLASSIFY_SYSTEM,
        model=LLM_MODEL,
    )

app = FastAPI(title="Process 1 - Sentiment (OpenAI Agents)")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "framework": "openai_agents",
        "sdk_available": _IMPORT_ERROR is None,
        "model_endpoint": LLM_BASE_URL,
    }


@app.post("/sentiment", response_model=SentimentResponse)
async def sentiment(req: SentimentRequest):
    if _sdk_agent is None or Runner is None:
        raise HTTPException(status_code=500, detail="OpenAI Agents SDK unavailable")

    try:
        # The raw user text goes into the agent; intent recognition happens here.
        run_result = await Runner.run(_sdk_agent, req.text)
        output = AgentSentiment.model_validate(_parse_json(str(run_result.final_output)))
        return SentimentResponse(
            request_id=req.request_id,
            label=output.label,
            confidence=output.confidence,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"agent classify failed: {exc}")
