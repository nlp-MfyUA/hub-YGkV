# 心绪回应助手 · LangGraph / OpenAI Agents 双实现

依据 `系统设计方案.md` 实现的四进程系统，全部本地 Docker 部署：

```
用户输入(frontend) → 网关(gateway) → 进程1(sentiment) → 进程2(respond) → 网关 → 前端展示
```

- 进程1：情感识别，输出 `positive / negative / neutral` + 置信度
- 进程2：确定性分支（不做二次模型判断）——正向鼓励 / 负面排解 / 中性倾听
- 后端网关：唯一对外入口 `/api/chat`，串行调用两个进程
- 前端：原生 HTML/JS，nginx 反向代理 `/api/` 到网关，无跨域问题

进程1和进程2各有 **LangGraph** 与 **OpenAI Agents SDK** 两种实现，接口完全一致，通过环境变量 `FRAMEWORK` 一键切换。

---

## 1. 快速启动（真实 DeepSeek 模型）

在 `.env` 填入 DeepSeek 密钥（系统固定走真实模型，无 Mock 模式）：

```env
DEEPSEEK_API_KEY=sk-你的密钥
DEEPSEEK_BASE_URL=https://api.deepseek.com/v1
DEEPSEEK_MODEL=deepseek-chat
```

首次启动：

```bash
cd "第15周：Reasoning、Sanbox和ClaudeCode Codex应用(1)/作业1"
cp .env.example .env      # 已创建则跳过，再填入密钥
docker compose up -d --build
docker compose ps
```

打开浏览器访问 **http://localhost:8080** 输入任意内容即可看到效果。顶部可随时切换 LangGraph / OpenAI Agents 框架。

> 意图识别链路：`用户输入 → agent/图 → 真实模型调用`。LangGraph 端在 `classify` 节点调用模型；OpenAI Agents 端把原文传给 `SentimentAgent`，模型按提示词输出 JSON、由代码解析出 label/confidence。适配层不做任何关键词判定。

冒烟测试（可选）：

```bash
bash scripts/smoke_test.sh
```

---

## 2. 模型配置说明

所有服务共享 `common/config.py` 中的 `LLM_API_KEY / LLM_BASE_URL / LLM_MODEL`，均由 `.env` 的三个 `DEEPSEEK_*` 变量注入。修改密钥或模型后 `docker compose up -d` 重建容器环境变量即可生效。

> DeepSeek 提供 OpenAI 兼容的 Chat Completions 接口。LangGraph 服务直接走 `common/llm.py` 的 Chat Completions 调用；OpenAI Agents 服务在启动时调用 `set_default_openai_api("chat_completions")` 并注入指向 DeepSeek 的 `AsyncOpenAI` 客户端，因此同样可用。若 SDK 版本较旧不支持该开关，请升级 `openai-agents` 到较新版本。
>
> **两个必须显式处理的兼容点（已在代码中修好）：**
> 1. **模型名**：Agents SDK 默认用 `gpt-4.1`，DeepSeek 不接受。必须给每个 `Agent(..., model=LLM_MODEL)` 显式传入 `deepseek-chat`。
> 2. **结构化输出**：Agents SDK 的 `output_type=` 会发送 `response_format` 参数，DeepSeek 不支持（报 `This response_format type is unavailable now`）。因此情感识别 Agent 不使用 `output_type`，改为在提示词里要求输出 JSON、由宿主代码用 `_parse_json` 解析纯文本回复。

---

## 3. 切换框架

在 `.env` 中设置：

```env
FRAMEWORK=langgraph        # 或 openai_agents
```

这是**默认框架**，决定页面首次打开时选中哪一项。改完 `docker compose up -d` 即可（无需重建镜像）。

**运行时切换（推荐）**：页面右上角「实现框架」可随时在 LangGraph / OpenAI Agents 之间切换，无需重启任何服务。前端每次请求会把 `framework` 字段带给网关，网关据此按请求动态路由到对应的进程对；响应里也会回显实际使用的框架。

也可直接用 API 验证：

```bash
curl -s -X POST http://localhost:8100/api/chat \
  -H 'Content-Type: application/json' \
  -d '{"text":"今天不开心了怎么办","framework":"openai_agents"}'
```

`framework` 省略或非法时会回落到 `.env` 里的默认 `FRAMEWORK`。`GET /api/frameworks` 可查询可选框架与默认值。

| framework | 进程1容器 | 进程2容器 | 端口 |
|---|---|---|---|
| `langgraph`（默认） | sentiment-langgraph | respond-langgraph | 8001 / 8002 |
| `openai_agents` | sentiment-agents | respond-agents | 8011 / 8012 |

也可以通过 `SENTIMENT_URL` / `RESPOND_URL` 显式覆盖上游地址（填完整 URL 或基础地址均可）。

---

## 4. 服务与端口

| 服务 | 容器端口 | 主机端口 | 说明 |
|---|---|---|---|
| frontend | 80 | 8080 | 页面 + `/api/` 反向代理 |
| gateway | 8000 | 8100 | `POST /api/chat`、`GET /health` |
| sentiment-langgraph | 8001 | 8001 | `POST /sentiment` |
| sentiment-agents | 8011 | 8011 | `POST /sentiment` |
| respond-langgraph | 8002 | 8002 | `POST /respond` |
| respond-agents | 8012 | 8012 | `POST /respond` |

每个服务都有 `GET /health` 便于检查。

---

## 5. API 契约

请求 `POST /api/chat`：

```json
{ "text": "这次考试终于过了，太开心了！" }
```

响应：

```json
{
  "request_id": "uuid",
  "label": "positive",
  "confidence": 0.79,
  "reply": "听你这么说真替你高兴！……",
  "degraded": false
}
```

`degraded=true` 表示某个上游不可用、网关已返回降级回应，不影响整体可用性。

进程间契约见 `common/models.py`，与设计方案第 5 章的数据契约一致。

---

## 6. 目录结构

```
.
├── docker-compose.yml
├── .env.example
├── common/                 # 共享契约、配置、LLM 适配层
│   ├── config.py
│   ├── models.py
│   └── llm.py
├── gateway/                # 后端进程：串联 P1/P2
├── sentiment_langgraph/    # 进程1 · LangGraph
├── sentiment_agents/       # 进程1 · OpenAI Agents
├── respond_langgraph/      # 进程2 · LangGraph
├── respond_agents/         # 进程2 · OpenAI Agents
├── frontend/               # 前端进程：HTML + nginx
├── scripts/smoke_test.sh
├── 系统设计方案.md
├── 系统架构图.html
└── 请求时序图.html
```

---

## 7. 常见操作

```bash
# 查看日志
docker compose logs -f gateway
docker compose logs -f sentiment-langgraph

# 只重建某个服务
docker compose up -d --build gateway

# 停止并清理
docker compose down
```

常见问题：

1. **页面打开但没有回应**：先看 `docker compose logs gateway`，确认 FRAMEWORK 对应的两个上游容器健康。
2. **模型报 401 / 400**：检查 `DEEPSEEK_API_KEY` 是否写入 `.env`，随后 `docker compose up -d` 重建容器环境变量。
3. **Agents SDK 导入失败**：确认镜像已安装 `openai-agents`（`docker compose build --no-cache sentiment-agents respond-agents`）。
4. **`docker compose build` 报 `failed to dial gRPC ... sharedkey`**：这是部分本地 Docker/Desktop 环境的 BuildKit bake 兼容问题，与代码无关。改用脚本逐镜像构建（镜像名已在 compose 中固定），再启动即可：

   ```bash
   bash scripts/build_images.sh
   docker compose up -d
   ```

5. **8100 端口被占用**：本机的 8000 端口常被其它服务占用，因此网关对外映射为 8100（容器内仍为 8000）。如需改回，编辑 `docker-compose.yml` 里 gateway 的 `ports` 并同步修改 `scripts/smoke_test.sh`。

---

## 8. 镜像打包与迁移

所有 Python 服务各有独立 Dockerfile（见 `DOCKERFILES.md` 说明），`docker-compose.yml` 中每个服务用固定镜像名 `emotion-*:latest`，因此可把镜像导出成一个 tar 包，拷到其它机器直接加载运行，无需重新 build 或联网装依赖。

```bash
# 1) 打包（会生成 dist/emotion-assistant-images.tar，约 118MB，含 6 个镜像）
bash scripts/package_images.sh

# 2) 在目标机器加载
bash scripts/load_images.sh
# 或：docker load -i dist/emotion-assistant-images.tar

# 3) 填好 .env 的 DEEPSEEK_API_KEY 后启动（无需 --build）
cp .env.example .env
docker compose up -d
```

> 注意：`.env`（含 API Key）**不包含**在镜像包里，需在目标机器单独配置；`dist/` 已在 `.dockerignore` 中排除，不会污染构建上下文。

---

## 9. 关键设计取舍

- **分支确定性路由**：进程2 根据进程1 的 `label` 直接走条件边 / 专用 agent，不额外调用模型判断，省一次调用且可测试。
- **双框架接口统一**：所有服务共享 `common/models.py`，网关无需感知框架差异。
- **意图识别必须在 agent 内**：用户原文送进 LangGraph 图 / OpenAI Agents 的 `SentimentAgent`，由真实 DeepSeek 模型调用输出 `label/confidence`；适配层不做关键词判定。
- **网关降级**：上游超时（10s）/ 429 / 5xx 会重试一次；仍失败则返回中性标签与降级回复，保证前端永远有结果。
