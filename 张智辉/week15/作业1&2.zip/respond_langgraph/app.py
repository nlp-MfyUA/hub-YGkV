"""Process 2 - Reply generation, LangGraph implementation.

The branch is a deterministic conditional edge driven by the `label` received
from process 1 (via the gateway). Only one generation node runs per request.
"""
from typing import TypedDict

from fastapi import FastAPI, HTTPException
from langgraph.graph import END, StateGraph

from common.llm import generate
from common.models import RespondRequest, RespondResponse

BRANCHES = ("positive", "negative", "neutral")


class State(TypedDict):
    text: str
    label: str
    confidence: float
    request_id: str
    branch_taken: str
    reply: str
    error: str
    status: str


def route(state: State) -> dict:
    """Pure routing node - no LLM call here."""
    label = state.get("label") if state.get("label") in BRANCHES else "neutral"
    return {"branch_taken": label}


async def encourage(state: State) -> dict:
    try:
        return {"reply": await generate(state["text"], "positive")}
    except Exception as exc:
        return {"error": f"encourage failed: {exc}"}


async def comfort(state: State) -> dict:
    try:
        return {"reply": await generate(state["text"], "negative")}
    except Exception as exc:
        return {"error": f"comfort failed: {exc}"}


async def listen(state: State) -> dict:
    try:
        return {"reply": await generate(state["text"], "neutral")}
    except Exception as exc:
        return {"error": f"listen failed: {exc}"}


def finalize(state: State) -> dict:
    if state.get("error") or not (state.get("reply") or "").strip():
        return {"status": "error"}
    return {"status": "ok"}


def build_graph():
    builder = StateGraph(State)
    builder.add_node("route", route)
    builder.add_node("encourage", encourage)
    builder.add_node("comfort", comfort)
    builder.add_node("listen", listen)
    builder.add_node("finalize", finalize)

    builder.set_entry_point("route")
    builder.add_conditional_edges(
        "route",
        lambda state: state["branch_taken"],
        {"positive": "encourage", "negative": "comfort", "neutral": "listen"},
    )
    for node in ("encourage", "comfort", "listen"):
        builder.add_edge(node, "finalize")
    builder.add_edge("finalize", END)
    return builder.compile()


graph = build_graph()
app = FastAPI(title="Process 2 - Reply (LangGraph)")


@app.get("/health")
async def health():
    return {"status": "ok", "framework": "langgraph"}


@app.post("/respond", response_model=RespondResponse)
async def respond(req: RespondRequest):
    result = await graph.ainvoke(
        {
            "text": req.text,
            "label": req.label,
            "confidence": req.confidence,
            "request_id": req.request_id,
            "branch_taken": "",
            "reply": "",
            "error": "",
            "status": "",
        }
    )
    if result.get("status") == "error":
        raise HTTPException(
            status_code=502,
            detail=result.get("error") or "reply generation failed",
        )
    return RespondResponse(request_id=req.request_id, reply=result["reply"])
