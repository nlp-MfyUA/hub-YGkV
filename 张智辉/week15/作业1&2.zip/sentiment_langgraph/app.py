"""Process 1 - Sentiment recognition, LangGraph implementation.

Graph: START -> build_prompt -> classify -> validate -> (ok|error) -> END
"""
from typing import List, TypedDict

from fastapi import FastAPI, HTTPException
from langgraph.graph import END, StateGraph

from common.llm import CLASSIFY_SYSTEM, classify
from common.models import SentimentRequest, SentimentResponse


class State(TypedDict):
    text: str
    request_id: str
    messages: List[dict]
    label: str
    confidence: float
    error: str
    status: str


def build_prompt(state: State) -> dict:
    """Node 1: assemble the classification prompt into the state."""
    return {
        "messages": [
            {"role": "system", "content": CLASSIFY_SYSTEM},
            {"role": "user", "content": state["text"]},
        ]
    }


async def classify_node(state: State) -> dict:
    """Node 2: call DeepSeek (or the local mock) through the shared adapter."""
    try:
        result = await classify(state["text"], state.get("messages"))
        return {"label": result.label, "confidence": result.confidence}
    except Exception as exc:  # gateway will degrade on 502
        return {"error": f"classify failed: {exc}"}


def validate(state: State) -> dict:
    """Node 3: enforce the output contract."""
    if state.get("error"):
        return {}
    if state.get("label") not in ("positive", "negative", "neutral"):
        return {"error": "invalid sentiment label"}
    if not 0.0 <= float(state.get("confidence", -1)) <= 1.0:
        return {"error": "invalid confidence"}
    return {}


def after_validate(state: State) -> str:
    return "error" if state.get("error") else "ok"


def _ok(state: State) -> dict:
    return {"status": "ok"}


def _error(state: State) -> dict:
    return {"status": "error"}


def build_graph():
    builder = StateGraph(State)
    builder.add_node("build_prompt", build_prompt)
    builder.add_node("classify", classify_node)
    builder.add_node("validate", validate)
    builder.add_node("mark_ok", _ok)
    builder.add_node("mark_error", _error)

    builder.set_entry_point("build_prompt")
    builder.add_edge("build_prompt", "classify")
    builder.add_edge("classify", "validate")
    builder.add_conditional_edges(
        "validate", after_validate, {"ok": "mark_ok", "error": "mark_error"}
    )
    builder.add_edge("mark_ok", END)
    builder.add_edge("mark_error", END)
    return builder.compile()


graph = build_graph()
app = FastAPI(title="Process 1 - Sentiment (LangGraph)")


@app.get("/health")
async def health():
    return {"status": "ok", "framework": "langgraph"}


@app.post("/sentiment", response_model=SentimentResponse)
async def sentiment(req: SentimentRequest):
    result = await graph.ainvoke(
        {
            "text": req.text,
            "request_id": req.request_id,
            "messages": [],
            "label": "",
            "confidence": 0.0,
            "error": "",
            "status": "",
        }
    )
    if result.get("status") == "error":
        raise HTTPException(status_code=502, detail=result.get("error", "classify failed"))
    return SentimentResponse(
        request_id=req.request_id,
        label=result["label"],
        confidence=float(result["confidence"]),
    )
