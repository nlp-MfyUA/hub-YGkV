"""Process 2 - Reply generation, OpenAI Agents SDK implementation.

Three specialised agents. The branch decision is made by host code from the
`label` supplied by process 1 (deterministic routing), not by a triage model.
Each reply is produced by the agent through a model call. No keyword shortcut.
"""
from fastapi import FastAPI, HTTPException

from common.config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
from common.llm import BRANCH_SYSTEM
from common.models import RespondRequest, RespondResponse

try:
    from agents import Agent, Runner, set_default_openai_api, set_default_openai_client
except ImportError as exc:  # pragma: no cover
    Agent = Runner = None  # type: ignore
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None


def _configure_sdk() -> None:
    if _IMPORT_ERROR is not None:
        return
    from openai import AsyncOpenAI

    try:
        set_default_openai_api("chat_completions")
    except Exception:
        pass
    set_default_openai_client(
        AsyncOpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL, timeout=30.0)
    )


_configure_sdk()

_AGENTS = {}
if _IMPORT_ERROR is None:
    _AGENTS = {
        "positive": Agent(
            name="EncouragerAgent", instructions=BRANCH_SYSTEM["positive"], model=LLM_MODEL
        ),
        "negative": Agent(
            name="ComforterAgent", instructions=BRANCH_SYSTEM["negative"], model=LLM_MODEL
        ),
        "neutral": Agent(
            name="ListenerAgent", instructions=BRANCH_SYSTEM["neutral"], model=LLM_MODEL
        ),
    }

app = FastAPI(title="Process 2 - Reply (OpenAI Agents)")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "framework": "openai_agents",
        "sdk_available": _IMPORT_ERROR is None,
        "model_endpoint": LLM_BASE_URL,
    }


@app.post("/respond", response_model=RespondResponse)
async def respond(req: RespondRequest):
    label = req.label if req.label in ("positive", "negative", "neutral") else "neutral"
    agent = _AGENTS.get(label)
    if agent is None or Runner is None:
        raise HTTPException(status_code=500, detail="OpenAI Agents SDK unavailable")

    try:
        run_result = await Runner.run(agent, req.text)
        reply = str(run_result.final_output).strip()
        if not reply:
            raise ValueError("empty reply from agent")
        return RespondResponse(request_id=req.request_id, reply=reply)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"agent reply failed: {exc}")
