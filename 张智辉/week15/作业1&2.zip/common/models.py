"""The single source of truth for every inter-process JSON contract."""
from typing import Literal

from pydantic import BaseModel, Field

SentimentLabel = Literal["positive", "negative", "neutral"]


class SentimentRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000)
    request_id: str = ""


class SentimentResult(BaseModel):
    label: SentimentLabel
    confidence: float = Field(..., ge=0.0, le=1.0)


class SentimentResponse(BaseModel):
    request_id: str
    label: SentimentLabel
    confidence: float


class RespondRequest(BaseModel):
    text: str
    label: SentimentLabel
    confidence: float = 0.0
    request_id: str = ""


class RespondResponse(BaseModel):
    request_id: str
    reply: str


class ChatRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000)
    # Optional: per-request framework override. Falls back to the gateway's
    # FRAMEWORK env var when omitted or invalid.
    framework: str | None = None


class ChatResponse(BaseModel):
    request_id: str
    label: SentimentLabel
    confidence: float
    reply: str
    degraded: bool = False
    framework: str = ""


class ErrorResponse(BaseModel):
    request_id: str
    error: dict
