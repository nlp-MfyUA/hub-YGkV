"""Runtime configuration.

All agents/graphs call the real DeepSeek OpenAI-compatible Chat Completions
endpoint. The user's text is always passed into the agent/graph, where a model
call performs intent recognition; there is no keyword shortcut in the adapter.
"""
import os

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_BASE_URL = os.getenv(
    "DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1"
).strip()
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat").strip()

# Names consumed by the LLM adapter and both agent services.
LLM_BASE_URL = DEEPSEEK_BASE_URL
LLM_API_KEY = DEEPSEEK_API_KEY
LLM_MODEL = DEEPSEEK_MODEL
