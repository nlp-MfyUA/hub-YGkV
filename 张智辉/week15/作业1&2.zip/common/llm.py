"""LLM adapter shared by process 1 and process 2.

The user's text ALWAYS goes through the agent/graph, and a MODEL CALL performs
intent recognition. This adapter targets the real DeepSeek OpenAI-compatible
Chat Completions endpoint; there is no keyword shortcut anywhere in the chain.
"""
import json
from typing import List, Optional

from .config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
from .models import SentimentResult

CLASSIFY_SYSTEM = (
    "你是情感分类器。只判断用户文本的情感倾向，输出 JSON："
    '{"label": "positive"|"negative"|"neutral", "confidence": 0~1}。'
    "positive=正向/开心/顺利，negative=负面/低落/焦虑，neutral=中性。不要输出其它文字。"
)

BRANCH_SYSTEM = {
    "positive": (
        "你是温暖的鼓励者。针对用户分享的好消息，先具体肯定他做得好的地方，"
        "再表达真诚的祝贺，最后鼓励他继续保持。用中文，2~3 句话，不要口号。"
    ),
    "negative": (
        "你是善意的倾听者与排解者。先共情并接纳用户的情绪，不评判、不说教，"
        "再给出温和的疏导或一个小而具体的建议。用中文，2~4 句话。"
    ),
    "neutral": (
        "你是温和的陪伴者。用户情绪不明显时，先轻量回应，再用一个开放式问题"
        "引导他多说一点。用中文，1~3 句话。"
    ),
}

_client = None


def _get_client():
    """Lazily create the OpenAI-compatible client (keeps gateway dependency-free)."""
    global _client
    if _client is None:
        from openai import AsyncOpenAI

        _client = AsyncOpenAI(
            api_key=LLM_API_KEY,
            base_url=LLM_BASE_URL,
            timeout=30.0,
        )
    return _client


def _parse_json(raw: str) -> dict:
    """Tolerate ```json fences or surrounding prose from the model."""
    raw = (raw or "").strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    start, end = raw.find("{"), raw.rfind("}")
    if start != -1 and end != -1:
        raw = raw[start : end + 1]
    return json.loads(raw)


async def classify(text: str, messages: Optional[List[dict]] = None) -> SentimentResult:
    """Process 1 core: classify text by calling the model endpoint.

    No keyword shortcut here: the agent/graph always reaches this model call.
    """
    payload = messages or [
        {"role": "system", "content": CLASSIFY_SYSTEM},
        {"role": "user", "content": text},
    ]
    response = await _get_client().chat.completions.create(
        model=LLM_MODEL,
        temperature=0,
        messages=payload,
        response_format={"type": "json_object"},
    )
    data = _parse_json(response.choices[0].message.content or "{}")
    label = data.get("label")
    if label not in ("positive", "negative", "neutral"):
        label = "neutral"
    try:
        confidence = float(data.get("confidence", 0.5))
    except (TypeError, ValueError):
        confidence = 0.5
    confidence = max(0.0, min(1.0, confidence))
    return SentimentResult(label=label, confidence=round(confidence, 2))


async def generate(text: str, label: str) -> str:
    """Process 2 core: generate a reply by calling the model endpoint."""
    if label not in BRANCH_SYSTEM:
        label = "neutral"

    response = await _get_client().chat.completions.create(
        model=LLM_MODEL,
        temperature=0.7,
        max_tokens=300,
        messages=[
            {"role": "system", "content": BRANCH_SYSTEM[label]},
            {"role": "user", "content": text},
        ],
    )
    return (response.choices[0].message.content or "").strip()
