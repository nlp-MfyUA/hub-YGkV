"""Shared contracts, configuration and LLM adapters for all four processes."""
