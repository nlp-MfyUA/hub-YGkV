"""
全局配置：模型、API、数据库路径、运行参数。

模型走 OpenAI 兼容协议，因此 .env 里任意一组
（OPENAI_BASE_URL/OPENAI_API_KEY、DEEPSEEK_*、OPENROUTE_*）都能直接替换，
不需要改代码 —— 只要改 config.llm 里的 model 名字即可。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

# ------------------------------------------------------------------ 路径
PACKAGE_DIR = Path(__file__).resolve().parent          # sql_agent/
PROJECT_DIR = PACKAGE_DIR.parent                       # SQL-agent/
DB_PATH = PROJECT_DIR / "chinook.db"


def find_env_file(start: Path) -> Path | None:
    """从 start 开始逐级向上查找 .env（课程仓库把 .env 放在最外层目录）。"""
    for path in [start, *start.parents]:
        candidate = path / ".env"
        if candidate.is_file():
            return candidate
    return None


ENV_FILE = find_env_file(PROJECT_DIR)
if ENV_FILE is not None:
    from dotenv import load_dotenv

    load_dotenv(ENV_FILE, override=True)

# 课程根目录 .env 里写的变量名是 OPENAI_API_URL，这里映射成 SDK 认的 OPENAI_BASE_URL
if not os.getenv("OPENAI_BASE_URL") and os.getenv("OPENAI_API_URL"):
    os.environ["OPENAI_BASE_URL"] = os.getenv("OPENAI_API_URL", "")


# ------------------------------------------------------------------ LLM
@dataclass(frozen=True)
class LLMConfig:
    """模型接入配置。"""

    model: str = "MiniMax-M3"
    api_key_env: str = "OPENAI_API_KEY"
    base_url_env: str = "OPENAI_BASE_URL"
    temperature: float = 0.2
    max_tokens: int = 4096
    timeout: float = 120.0
    max_tool_turns: int = 6
    # MiniMax 专有：把思维链从 content 中拆到 reasoning_details
    reasoning_split: bool = True


# ------------------------------------------------------------------ 运行参数
@dataclass(frozen=True)
class RunConfig:
    """工作流运行参数。"""

    max_validate_rounds: int = 3    # 校验不通过时最多「改写」几次
    max_exec_retries: int = 2       # 执行报错时最多「改写 + 重跑」几次
    exec_row_limit: int = 5000      # 单次执行最多取多少行
    result_rows_to_llm: int = 50    # 送给 LLM 做汇总的最大行数
    fallback_top_tables: int = 3    # 选表失败时兜底保留几张表
    max_graph_steps: int = 50       # LangGraph 图的步数上限（防死循环的最后一道保险）


# ------------------------------------------------------------------ 便捷读取
def llm_settings() -> dict:
    """返回当前生效的 LLM 连接信息（api_key 只做脱敏）。"""
    key = os.getenv(LLMConfig.api_key_env, "") or ""
    return {
        "model": LLMConfig.model,
        "base_url": os.getenv(LLMConfig.base_url_env, ""),
        "api_key": f"{key[:6]}...{key[-4:]}" if len(key) > 12 else "(未配置)",
    }
