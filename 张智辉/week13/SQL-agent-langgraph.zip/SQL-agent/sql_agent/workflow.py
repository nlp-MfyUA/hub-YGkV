"""
SQL Agent 工作流 —— LangGraph 实现。

与手写版（workflow_manual.py）的差别只在于**编排层**：
    手写版：一条直线 + 两段 while 循环
    本版  ：声明一张状态图，节点 = 阶段，边 = 流转，环 = 条件边

图结构：

        START
          │
     ┌────▼────┐
     │ parse_db│  1. 数据库解析
     └────┬────┘
          │
     ┌────▼──────┐
     │select_tbls│ 2. table 选择（带工具调用的 Agent）
     └──┬──────┬──┘
        │      │ (没选出表)
        │  ┌───▼───┐
        │  │ fail  │
        │  └───┬───┘
   ┌────▼──────▼─┐
   │  generate_sql│ 3. sql 生成
   └────┬──────┬─┘
        │      │
   ┌────▼────┐ │
   │ validate│ │ 4. sql 校验 ──(不通过)──→ rewrite ──┐
   └────┬────┘ │                                    │
        │      │  ┌──────────────┐                 │
        │      └─→│   rewrite    │←────────────────┘
        │        │ 5. sql 改写   │
        │        └──────┬───────┘
        │               │ (改写后回到校验)
        │        ┌──────▼───────┐
        │        │   validate   │
        │        └──────┬───────┘
        │               │ (通过)
   ┌────▼────────────────▼──┐
   │      execute_sql       │ 6. sql 执行 ──(报错)──→ rewrite
   └────┬───────────────────┘
        │ (成功)
   ┌────▼──────┐
   │ summarize │ 7. 结果汇总
   └────┬──────┘
        ▼
       END
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable

from langgraph.graph import END, START, StateGraph

from .config import RunConfig
from .db_parser import DBParser, QueryResult
from .llm import LLMClient
from .stages import (
    ResultSummarizer,
    SQLExecutor,
    SQLGenerator,
    SQLRewriter,
    SQLValidator,
    Summary,
    TableSelector,
)
from .state import SQLAgentState


# ==================================================================== 数据结构
@dataclass
class StageTrace:
    """单个阶段的执行记录，用于展示 Agent 的工作轨迹。"""

    index: int
    name: str
    ok: bool
    detail: str
    elapsed_ms: float
    data: dict = field(default_factory=dict)


@dataclass
class WorkflowResult:
    """一次完整问答的结果。"""

    question: str
    success: bool = False
    tables: list[str] = field(default_factory=list)
    sql: str = ""
    sql_history: list[tuple[str, str]] = field(default_factory=list)  # (SQL, 说明)
    columns: list[str] = field(default_factory=list)
    rows: list[tuple] = field(default_factory=list)
    row_count: int = 0
    summary: Summary | None = None
    error: str = ""
    trace: list[StageTrace] = field(default_factory=list)


# ==================================================================== 工作流
class SQLAgentWorkflow:
    """
    完整 SQL Agent 工作流（LangGraph 版）。

    对外接口与手写版完全一致：run(question) -> WorkflowResult，
    所以 main.py 无需任何改动。
    """

    def __init__(
        self,
        parser: DBParser | None = None,
        llm: LLMClient | None = None,
        run_config: RunConfig | None = None,
        on_stage: Callable[[StageTrace], None] | None = None,
    ) -> None:
        self.run_config = run_config or RunConfig()
        self.parser = parser or DBParser()
        self.llm = llm or LLMClient()
        self.on_stage = on_stage

        self.selector = TableSelector(self.parser, self.llm)
        self.generator = SQLGenerator(self.parser, self.llm)
        self.validator = SQLValidator(self.parser)
        self.rewriter = SQLRewriter(self.parser, self.llm)
        self.executor = SQLExecutor(self.parser, row_limit=self.run_config.exec_row_limit)
        self.summarizer = ResultSummarizer(self.llm)

        self.graph = self._build_graph()

    # ------------------------------------------------------------- 建图
    def _build_graph(self):
        g = StateGraph(SQLAgentState)

        # ---- 节点 = 阶段 ----
        g.add_node("parse_db", self._node_parse_db)
        g.add_node("select_tables", self._node_select_tables)
        g.add_node("generate_sql", self._node_generate_sql)
        g.add_node("validate_sql", self._node_validate_sql)
        g.add_node("rewrite_sql", self._node_rewrite_sql)
        g.add_node("execute_sql", self._node_execute_sql)
        g.add_node("summarize", self._node_summarize)
        g.add_node("fail", self._node_fail)

        # ---- 边 = 流转 ----
        g.add_edge(START, "parse_db")
        g.add_edge("parse_db", "select_tables")

        g.add_conditional_edges(
            "select_tables",
            self._route_after_select,
            {"generate_sql": "generate_sql", "fail": "fail"},
        )

        g.add_edge("generate_sql", "validate_sql")

        g.add_conditional_edges(
            "validate_sql",
            self._route_after_validate,
            {"execute_sql": "execute_sql", "rewrite_sql": "rewrite_sql", "fail": "fail"},
        )

        g.add_conditional_edges(
            "rewrite_sql",
            self._route_after_rewrite,
            {"validate_sql": "validate_sql", "fail": "fail"},
        )

        g.add_conditional_edges(
            "execute_sql",
            self._route_after_execute,
            {"summarize": "summarize", "rewrite_sql": "rewrite_sql", "fail": "fail"},
        )

        g.add_edge("summarize", END)
        g.add_edge("fail", END)

        return g.compile()

    # ------------------------------------------------------------- 轨迹记录
    def _trace(
        self,
        state: SQLAgentState,
        name: str,
        ok: bool,
        detail: str,
        started: float,
        data: dict | None = None,
    ) -> dict:
        """构造一条轨迹记录，同时实时回调 on_stage。"""
        item = {
            "index": len(state.get("trace") or []) + 1,
            "name": name,
            "ok": ok,
            "detail": detail,
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
            "data": data or {},
        }
        if self.on_stage:
            self.on_stage(StageTrace(**item))
        return item

    # ============================================================== 节点实现
    def _node_parse_db(self, state: SQLAgentState) -> dict:
        """1. 数据库解析"""
        started = time.perf_counter()
        table_count = len(self.parser.table_names)
        field_count = sum(
            len(self.parser.inspector.get_columns(t)) for t in self.parser.table_names
        )
        detail = (
            f"解析到 {table_count} 张表 / {field_count} 个字段 / "
            f"{len(self.parser.foreign_keys)} 条外键关系"
        )
        return {
            "db_summary": detail,
            "trace": [
                self._trace(
                    state, "数据库解析", True, detail, started, {"tables": self.parser.table_names}
                )
            ],
        }

    def _node_select_tables(self, state: SQLAgentState) -> dict:
        """2. table 选择"""
        started = time.perf_counter()
        selection = self.selector.run(state["question"])
        detail = f"选中表：{', '.join(selection.tables) or '（无）'}　|　{selection.reason}"
        return {
            "tables": selection.tables,
            "table_reason": selection.reason,
            "table_source": selection.source,
            "tool_calls": selection.tool_calls,
            "trace": [
                self._trace(
                    state, "table 选择", bool(selection.tables), detail, started, {"selection": selection}
                )
            ],
        }

    def _node_generate_sql(self, state: SQLAgentState) -> dict:
        """3. sql 生成"""
        started = time.perf_counter()
        generated = self.generator.run(state["question"], state["tables"])
        detail = f"{generated.sql}\n    {generated.explanation}"
        return {
            "sql": generated.sql,
            "sql_explanation": generated.explanation,
            "sql_history": [{"sql": generated.sql, "reason": "初次生成"}],
            "trace": [
                self._trace(state, "sql 生成", bool(generated.sql), detail, started, {"generated": generated})
            ],
        }

    def _node_validate_sql(self, state: SQLAgentState) -> dict:
        """4. sql 校验"""
        started = time.perf_counter()
        validation = self.validator.run(state["sql"])
        detail = validation.reason if validation.ok else f"校验未通过：{validation.reason}"
        update: dict[str, Any] = {
            "validation_ok": validation.ok,
            "validation_reason": validation.reason,
            "trace": [
                self._trace(state, "sql 校验", validation.ok, detail, started, {"validation": validation})
            ],
        }
        if not validation.ok:
            # 校验不通过 -> 把失败原因交给改写节点
            update["feedback"] = validation.reason
            update["feedback_type"] = "validate"
        return update

    def _node_rewrite_sql(self, state: SQLAgentState) -> dict:
        """5. sql 改写（校验失败 / 执行报错都走这里）"""
        started = time.perf_counter()
        feedback = state.get("feedback", "")
        feedback_type = state.get("feedback_type", "validate")

        generated = self.rewriter.run(
            state["question"], state["sql"], feedback, state["tables"]
        )
        default_reason = "校验失败改写" if feedback_type == "validate" else "执行失败改写"
        reason = generated.change_reason or default_reason
        detail = f"{generated.sql}\n    {generated.change_reason}"

        update: dict[str, Any] = {
            "sql": generated.sql,
            "sql_history": [{"sql": generated.sql, "reason": reason}],
            "trace": [
                self._trace(state, "sql 改写", bool(generated.sql), detail, started, {"generated": generated})
            ],
        }
        # 改写次数分别计数，两个上限互不干扰
        if feedback_type == "validate":
            update["validate_rounds"] = state.get("validate_rounds", 0) + 1
        else:
            update["exec_retries"] = state.get("exec_retries", 0) + 1
        return update

    def _node_execute_sql(self, state: SQLAgentState) -> dict:
        """6. sql 执行"""
        started = time.perf_counter()
        execution = self.executor.run(state["sql"])

        if execution.ok and execution.result is not None:
            detail = f"返回 {execution.result.row_count} 行"
            update: dict[str, Any] = {
                "exec_ok": True,
                "exec_error": "",
                "columns": execution.result.columns,
                "rows": execution.result.rows,
                "row_count": execution.result.row_count,
            }
        else:
            detail = f"执行失败：{execution.error}"
            update = {
                "exec_ok": False,
                "exec_error": execution.error,
                # 执行报错 -> 把报错信息交给改写节点
                "feedback": execution.error,
                "feedback_type": "execute",
            }

        update["trace"] = [
            self._trace(state, "sql 执行", execution.ok, detail, started, {"execution": execution})
        ]
        return update

    def _node_summarize(self, state: SQLAgentState) -> dict:
        """7. 结果汇总"""
        started = time.perf_counter()
        query_result = QueryResult(
            columns=state.get("columns", []),
            rows=state.get("rows", []),
            row_count=state.get("row_count", 0),
            truncated=False,
        )
        try:
            summary = self.summarizer.run(
                state["question"],
                state["sql"],
                query_result,
                max_rows=self.run_config.result_rows_to_llm,
            )
        except Exception as exc:
            error = f"结果汇总失败：{exc}"
            return {
                "success": False,
                "error": error,
                "trace": [
                    self._trace(state, "结果汇总", False, error, started)
                ],
            }

        return {
            "success": True,
            "error": "",
            "summary": {
                "answer": summary.answer,
                "key_findings": summary.key_findings,
                "suggestions": summary.suggestions,
            },
            "trace": [
                self._trace(state, "结果汇总", True, summary.answer, started, {"summary": summary})
            ],
        }

    def _node_fail(self, state: SQLAgentState) -> dict:
        """统一收口：把失败原因写进 state 并结束。"""
        started = time.perf_counter()
        if not state.get("tables"):
            error = "未能选出任何表"
        elif state.get("feedback_type") == "validate" and not state.get("validation_ok"):
            error = f"SQL 校验始终未通过：{state.get('validation_reason', '')}"
        elif not state.get("exec_ok"):
            error = f"SQL 执行失败：{state.get('exec_error', '')}"
        else:
            error = state.get("error") or "工作流未能完成"
        return {
            "success": False,
            "error": error,
            "trace": [self._trace(state, "流程终止", False, error, started)],
        }

    # ============================================================== 条件边路由
    def _route_after_select(self, state: SQLAgentState) -> str:
        """选表后：选到表就生成 SQL，没选到就终止。"""
        return "generate_sql" if state.get("tables") else "fail"

    def _route_after_validate(self, state: SQLAgentState) -> str:
        """校验后：通过就执行；不通过就改写（超过上限则终止）。"""
        if state.get("validation_ok"):
            return "execute_sql"
        if state.get("validate_rounds", 0) >= self.run_config.max_validate_rounds:
            return "fail"
        return "rewrite_sql"

    def _route_after_rewrite(self, state: SQLAgentState) -> str:
        """改写后：回到校验节点重新校验；改写不出 SQL 就终止。"""
        if not state.get("sql"):
            return "fail"
        return "validate_sql"

    def _route_after_execute(self, state: SQLAgentState) -> str:
        """执行后：成功就汇总；报错就改写重跑（超过上限则终止）。"""
        if state.get("exec_ok"):
            return "summarize"
        if state.get("exec_retries", 0) >= self.run_config.max_exec_retries:
            return "fail"
        return "rewrite_sql"

    # ============================================================== 主流程
    def run(self, question: str) -> WorkflowResult:
        initial = self._initial_state(question)

        try:
            final = self.graph.invoke(
                initial, config={"recursion_limit": self.run_config.max_graph_steps}
            )
        except Exception as exc:
            return WorkflowResult(
                question=question,
                success=False,
                error=f"工作流异常：{type(exc).__name__}: {exc}",
            )

        return self._to_result(question, final)

    # ============================================================== 流式主流程
    def run_stream(self, question: str):
        """
        流式执行工作流，边跑边 yield 事件，供 Web 前端实时展示。

        事件类型：
            {"type": "stage", "data": {...}}   某个阶段完成（序号/名称/耗时/详情）
            {"type": "sql",   "data": {...}}   当前 SQL 与改写历史已更新
            {"type": "final", "data": {...}}   全部结束，返回最终结果
            {"type": "error", "data": {...}}   出错
        """
        initial = self._initial_state(question)
        last_sql_signature = None

        try:
            for mode, chunk in self.graph.stream(
                initial,
                stream_mode=["updates", "values"],
                config={"recursion_limit": self.run_config.max_graph_steps},
            ):
                if mode == "updates":
                    for node_name, update in chunk.items():
                        for trace_item in (update or {}).get("trace") or []:
                            # 只发前端用得到的字段，data 里的 dataclass 序列化后很长且用不上
                            yield {
                                "type": "stage",
                                "data": {
                                    "index": trace_item.get("index"),
                                    "name": trace_item.get("name"),
                                    "ok": trace_item.get("ok"),
                                    "detail": trace_item.get("detail"),
                                    "elapsed_ms": trace_item.get("elapsed_ms"),
                                },
                            }
                else:
                    # values 模式给出累积后的完整 state
                    sql = chunk.get("sql") or ""
                    history = chunk.get("sql_history") or []
                    # SQL 或改写历史没变就不重复推送
                    signature = (sql, len(history))
                    if (sql or history) and signature != last_sql_signature:
                        last_sql_signature = signature
                        yield {
                            "type": "sql",
                            "data": {
                                "sql": sql,
                                "sql_history": [
                                    {"sql": h.get("sql", ""), "reason": h.get("reason", "")}
                                    for h in history
                                ],
                            },
                        }
                    final_state = chunk
        except Exception as exc:
            yield {
                "type": "error",
                "data": {"message": f"工作流异常：{type(exc).__name__}: {exc}"},
            }
            return

        result = self._to_result(question, final_state)
        yield {"type": "final", "data": self._result_to_dict(result)}

    @staticmethod
    def _initial_state(question: str) -> SQLAgentState:
        return {
            "question": question,
            "tables": [],
            "sql": "",
            "sql_history": [],
            "trace": [],
            "validate_rounds": 0,
            "exec_retries": 0,
            "success": False,
            "error": "",
        }

    @staticmethod
    def _result_to_dict(result: WorkflowResult) -> dict:
        """把结果转成可直接 JSON 序列化的结构。"""
        return {
            "question": result.question,
            "success": result.success,
            "error": result.error,
            "tables": result.tables,
            "sql": result.sql,
            "sql_history": [{"sql": s, "reason": r} for s, r in result.sql_history],
            "columns": result.columns,
            "rows": [list(r) for r in result.rows],
            "row_count": result.row_count,
            "summary": (
                {
                    "answer": result.summary.answer,
                    "key_findings": result.summary.key_findings,
                    "suggestions": result.summary.suggestions,
                }
                if result.summary
                else None
            ),
            "trace": [
                {
                    "index": t.index,
                    "name": t.name,
                    "ok": t.ok,
                    "detail": t.detail,
                    "elapsed_ms": t.elapsed_ms,
                }
                for t in result.trace
            ],
        }

    @staticmethod
    def _to_result(question: str, state: SQLAgentState) -> WorkflowResult:
        """把图最终的 state 还原成 WorkflowResult。"""
        result = WorkflowResult(question=question)
        result.success = bool(state.get("success"))
        result.error = state.get("error", "")
        result.tables = state.get("tables", [])
        result.sql = state.get("sql", "")
        result.sql_history = [
            (item.get("sql", ""), item.get("reason", "")) for item in state.get("sql_history", [])
        ]
        result.columns = state.get("columns", [])
        result.rows = state.get("rows", [])
        result.row_count = state.get("row_count", 0)

        summary = state.get("summary")
        if summary:
            result.summary = Summary(
                answer=summary.get("answer", ""),
                key_findings=summary.get("key_findings", []),
                suggestions=summary.get("suggestions", []),
            )

        result.trace = [StageTrace(**item) for item in state.get("trace", [])]
        return result
