"""
LangGraph 状态定义。

工作流的每个节点都读写同一个 State（一个 TypedDict）：
    - 普通字段：节点返回时被**覆盖**
    - Annotated[..., operator.add] 字段：节点返回时被**追加**

`sql_history` 和 `trace` 用追加语义，因为「改写」和「节点执行」本质上都是
往同一条流水线上追加记录，而不是替换。
"""

from __future__ import annotations

import operator
from typing import Annotated, TypedDict


class SQLAgentState(TypedDict, total=False):
    """SQL Agent 图的全局状态。"""

    # ------------------------------------------------------------ 输入
    question: str

    # ------------------------------------------------------------ 1. 数据库解析
    db_summary: str

    # ------------------------------------------------------------ 2. table 选择
    tables: list[str]
    table_reason: str
    table_source: str          # llm | fallback
    tool_calls: list[dict]

    # ------------------------------------------------------------ 3. sql 生成
    sql: str
    sql_explanation: str

    # ------------------------------------------------------------ 4/5. 校验 + 改写
    validation_ok: bool
    validation_reason: str
    feedback: str              # 触发改写的原因（校验失败原因 / 执行报错信息）
    feedback_type: str         # validate | execute
    validate_rounds: int       # 因校验失败而改写的次数
    exec_retries: int          # 因执行报错而改写的次数

    # ------------------------------------------------------------ 6. sql 执行
    exec_ok: bool
    exec_error: str
    columns: list[str]
    rows: list[tuple]
    row_count: int

    # ------------------------------------------------------------ 7. 结果汇总
    summary: dict              # {answer, key_findings, suggestions}

    # ------------------------------------------------------------ 全局
    success: bool
    error: str

    # ------------------------------------------------------------ 追加型字段
    sql_history: Annotated[list, operator.add]   # [{"sql": ..., "reason": ...}]
    trace: Annotated[list, operator.add]         # 每个节点产出一条轨迹记录
