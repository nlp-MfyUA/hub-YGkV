"""
SQL Agent Web 服务 —— FastAPI + SSE。

启动：
    python web/app.py
    # 或
    uvicorn web.app:app --host 0.0.0.0 --port 8000

接口：
    GET  /                    前端页面
    GET  /api/schema          数据库表结构概览
    GET  /api/examples        示例问题
    POST /api/chat            对话式查询（SSE 流式返回工作流过程与结果）
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import AsyncGenerator

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from dotenv import load_dotenv

# 统一加载课程根目录的 .env
for _p in [PROJECT_DIR, *PROJECT_DIR.parents]:
    if (_p / ".env").exists():
        load_dotenv(_p / ".env")
        break

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from sql_agent import DBParser, LLMClient, RunConfig, SQLAgentWorkflow
from sql_agent.db_parser import TABLE_DESCRIPTIONS

app = FastAPI(title="Chinook SQL Agent", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = Path(__file__).resolve().parent / "static"

# ------------------------------------------------------------------ 全局单例
# 工作流和数据库解析都比较重，全局复用一份（尤其 DBParser 会缓存表结构统计）
_workflow: SQLAgentWorkflow | None = None
_parser: DBParser | None = None


def get_parser() -> DBParser:
    global _parser
    if _parser is None:
        _parser = DBParser()
    return _parser


def get_workflow() -> SQLAgentWorkflow:
    global _workflow
    if _workflow is None:
        _workflow = SQLAgentWorkflow(
            parser=get_parser(),
            llm=LLMClient(),
            run_config=RunConfig(),
        )
    return _workflow


# ------------------------------------------------------------------ 数据模型
class ChatRequest(BaseModel):
    question: str


# ------------------------------------------------------------------ 接口
@app.get("/api/schema")
async def schema():
    """数据库表结构概览，供前端展示。"""
    parser = get_parser()
    tables = []
    for name in parser.table_names:
        fields = parser.get_table_fields(name)
        tables.append(
            {
                "name": name,
                "description": TABLE_DESCRIPTIONS.get(name, ""),
                "row_count": int(parser._row_count(name)),
                "columns": fields["name"].tolist(),
            }
        )
    return {"database": "Chinook（数字音乐商店销售数据）", "tables": tables}


@app.get("/api/examples")
async def examples():
    """示例问题。"""
    return {
        "examples": [
            "总销售额是多少",
            "消费金额最高的5位客户是谁？列出姓名、国家和消费总额",
            "每位销售代表一共卖出了多少销售额？只列出销售额超过10的",
            "Rock 流派有哪些专辑？按发行数量排序",
            "最贵的10首歌曲",
            "每个国家有多少客户",
            "数据库里一共有多少首歌曲",
        ]
    }


@app.post("/api/chat")
async def chat(req: ChatRequest):
    """对话式查询，SSE 流式返回工作流过程与最终结果。"""
    question = (req.question or "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="问题不能为空")

    workflow = get_workflow()

    async def event_generator() -> AsyncGenerator[str, None]:
        queue: asyncio.Queue = asyncio.Queue()
        loop = asyncio.get_running_loop()

        def produce():
            """在同步线程里跑同步的工作流，避免阻塞事件循环。"""
            try:
                for event in workflow.run_stream(question):
                    loop.call_soon_threadsafe(queue.put_nowait, event)
            except Exception as exc:  # 兜底，防止整个连接挂死
                loop.call_soon_threadsafe(
                    queue.put_nowait,
                    {"type": "error", "data": {"message": f"{type(exc).__name__}: {exc}"}},
                )
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        task = asyncio.create_task(asyncio.to_thread(produce))

        try:
            while True:
                event = await queue.get()
                if event is None:
                    break
                payload = json.dumps(event["data"], ensure_ascii=False, default=str)
                yield f"event: {event['type']}\ndata: {payload}\n\n"
        finally:
            await task

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # 关掉 nginx 缓冲，否则前端收不到流
        },
    )


# ------------------------------------------------------------------ 静态资源
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/")
    async def index():
        return FileResponse(STATIC_DIR / "index.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
