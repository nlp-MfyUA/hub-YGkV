"""用 Chrome DevTools Protocol 驱动无头浏览器：真实等待 SSE 完成后再截图。

直接连接 page target 的 websocket（不走 Target.* 会话协议），更简单可靠。

用法：python3 _cdp_shot.py <url> <输出png> <等待秒>
"""
import asyncio
import base64
import json
import subprocess
import sys
import time
import urllib.request

import websockets

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
PORT = 9334


async def main(url: str, out: str, wait: float) -> None:
    proc = subprocess.Popen(
        [
            CHROME, "--headless", "--disable-gpu", "--no-sandbox",
            f"--remote-debugging-port={PORT}",
            "--window-size=1600,1000", "--hide-scrollbars",
            "--user-data-dir=/tmp/cdp_profile2",
            "about:blank",
        ],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )

    try:
        # 等调试端口就绪，并拿到 page target 的 ws 地址
        page_ws = None
        for _ in range(60):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/list", timeout=1) as r:
                    targets = json.load(r)
                for t in targets:
                    if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                        page_ws = t["webSocketDebuggerUrl"]
                        break
                if page_ws:
                    break
            except Exception:
                pass
            time.sleep(0.5)

        if not page_ws:
            raise SystemExit("拿不到 page target")

        async with websockets.connect(page_ws, max_size=200 * 1024 * 1024) as ws:
            msg_id = 0

            async def call(method: str, params=None):
                nonlocal msg_id
                msg_id += 1
                this_id = msg_id
                await ws.send(json.dumps({"id": this_id, "method": method, "params": params or {}}))
                deadline = time.time() + 60
                while time.time() < deadline:
                    raw = await asyncio.wait_for(ws.recv(), timeout=60)
                    data = json.loads(raw)
                    if data.get("id") == this_id:
                        return data.get("result", {})
                raise SystemExit(f"{method} 超时")

            await call("Page.enable")
            await call("Runtime.enable")
            await call("Page.navigate", {"url": url})

            print(f"真实等待 {wait:.0f} 秒…", flush=True)
            await asyncio.sleep(wait)

            # 顺便看看页面里有多少个 stage 卡片，确认流真的推完了
            try:
                probe = await call("Runtime.evaluate", {
                    "expression": "JSON.stringify({stages: document.querySelectorAll('.stage-item').length, msgs: document.querySelectorAll('.msg').length})",
                    "returnByValue": True,
                })
                print("页面状态:", probe.get("result", {}).get("value"), flush=True)
            except Exception as e:
                print("探测失败:", e, flush=True)

            shot = await call("Page.captureScreenshot", {"format": "png"})
            with open(out, "wb") as f:
                f.write(base64.b64decode(shot["data"]))
            print(f"截图已保存：{out}", flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
