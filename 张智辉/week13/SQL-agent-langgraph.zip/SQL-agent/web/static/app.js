// Chinook SQL Agent 前端 —— SSE 流式交互
const $ = (id) => document.getElementById(id);

const messages = $("messages");
const input = $("input");
const sendBtn = $("sendBtn");
const stageList = $("stageList");

let busy = false;
let lastSchema = null;   // 缓存表结构，供「清空对话」后重绘概览卡片

/* ================================================================== 工具 */
function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
}

/** 数值型单元格右对齐 */
function isNumeric(v) {
    return typeof v === "number" || (typeof v === "string" && v !== "" && !isNaN(Number(v)));
}

function fmtCell(v) {
    if (v === null || v === undefined) return "<span style='color:#94a3b8'>NULL</span>";
    return escapeHtml(v);
}

/* ================================================================== 消息 */
function addMessage(role, html) {
    const wrap = document.createElement("div");
    wrap.className = `msg msg-${role}`;
    wrap.innerHTML = `
        <div class="avatar">${role === "user" ? "👤" : "🤖"}</div>
        <div class="bubble">${html}</div>
    `;
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
    return wrap.querySelector(".bubble");
}

function addTyping() {
    const wrap = document.createElement("div");
    wrap.className = "msg msg-bot";
    wrap.id = "typingIndicator";
    wrap.innerHTML = `
        <div class="avatar">🤖</div>
        <div class="bubble"><div class="typing"><i></i><i></i><i></i></div></div>
    `;
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
    return wrap;
}

function removeTyping() {
    const el = $("typingIndicator");
    if (el) el.remove();
}

/* ================================================================== 右侧面板 */
function resetSidePanels() {
    stageList.innerHTML = "";
    $("workflowEmpty").hidden = false;
    $("sqlEmpty").hidden = false;
    $("sqlContent").hidden = true;
    $("historyBlock").hidden = true;
    $("dataEmpty").hidden = false;
    $("dataContent").hidden = true;
}

function renderStage(stage) {
    $("workflowEmpty").hidden = true;
    const li = document.createElement("li");
    li.className = `stage-item ${stage.ok ? "ok" : "err"}`;
    li.innerHTML = `
        <div class="stage-icon">${stage.ok ? "✓" : "✕"}</div>
        <div class="stage-body">
            <div class="stage-name">
                <span>${escapeHtml(stage.name)}</span>
                <span class="stage-time">${Math.round(stage.elapsed_ms)}ms</span>
            </div>
            <div class="stage-detail">${escapeHtml(stage.detail)}</div>
        </div>
    `;
    stageList.appendChild(li);
}

function renderSql(data) {
    if (!data.sql) return;
    $("sqlEmpty").hidden = true;
    $("sqlContent").hidden = false;
    $("currentSql").textContent = data.sql;

    const history = data.sql_history || [];
    if (history.length > 1) {
        $("historyBlock").hidden = false;
        $("sqlHistory").innerHTML = history.map((h, i) => `
            <div class="history-item">
                <div class="history-reason">${i + 1}. ${escapeHtml(h.reason)}</div>
                <div class="history-sql">${escapeHtml(h.sql)}</div>
            </div>
        `).join("");
    }
}

function renderData(result) {
    if (!result.columns || !result.columns.length) return;
    $("dataEmpty").hidden = true;
    $("dataContent").hidden = false;
    $("dataTitle").textContent = `查询结果（${result.row_count} 行）`;

    const head = `<thead><tr>${result.columns.map(c => `<th>${escapeHtml(c)}</th>`).join("")}</tr></thead>`;
    const body = `<tbody>${(result.rows || []).map(row =>
        `<tr>${row.map(v => `<td class="${isNumeric(v) ? "num" : ""}">${fmtCell(v)}</td>`).join("")}</tr>`
    ).join("")}</tbody>`;

    $("resultTable").innerHTML = head + body;
}

/* ================================================================== 结果渲染 */
function renderFinal(bubble, result) {
    if (!result.success) {
        bubble.innerHTML = `<p class="error-text">❌ 查询失败：${escapeHtml(result.error || "未知错误")}</p>`;
        return;
    }

    const summary = result.summary || {};
    let html = `<p>${escapeHtml(summary.answer || "")}</p>`;

    if (summary.key_findings && summary.key_findings.length) {
        html += `<div class="summary-label">关键发现</div>
                 <ul class="finding-list">${summary.key_findings.map(f => `<li>${escapeHtml(f)}</li>`).join("")}</ul>`;
    }
    if (summary.suggestions && summary.suggestions.length) {
        html += `<div class="summary-label">后续建议</div>
                 <ul class="finding-list">${summary.suggestions.map(s => `<li>${escapeHtml(s)}</li>`).join("")}</ul>`;
    }
    if (result.sql) {
        html += `<div class="summary-label">执行的 SQL</div>
                 <div class="sql-inline">${escapeHtml(result.sql)}</div>`;
    }

    const meta = [];
    if (result.tables && result.tables.length) meta.push(`表：${result.tables.join(", ")}`);
    if (result.row_count !== undefined) meta.push(`${result.row_count} 行`);
    if (meta.length) html += `<div class="meta-inline">${escapeHtml(meta.join("  ·  "))}</div>`;

    bubble.innerHTML = html;
}

/* ================================================================== SSE 请求 */
async function ask(question) {
    if (busy || !question.trim()) return;

    busy = true;
    sendBtn.disabled = true;
    addMessage("user", escapeHtml(question));
    resetSidePanels();

    const typing = addTyping();
    const botWrap = typing;              // 整条 bot 消息
    const bubble = typing.querySelector(".bubble");

    /**
     * 把「打字动画」占位消息转成正式回复。
     * 注意：不能 removeTyping()——那会把承载答案的 bubble 一起从 DOM 删掉，
     * 之后再设置 innerHTML 就不会显示了。这里改为原地替换内容。
     */
    const finalize = (html) => {
        botWrap.removeAttribute("id");
        bubble.innerHTML = html;
        // 答案渲染后气泡变高，滚到底部让用户直接看到结论
        messages.scrollTop = messages.scrollHeight;
    };

    try {
        const res = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question }),
        });

        if (!res.ok) {
            let detail = `请求失败（${res.status}）`;
            try { detail = (await res.json()).detail || detail; } catch (e) { /* ignore */ }
            finalize(`<p class="error-text">❌ ${escapeHtml(detail)}</p>`);
            return;
        }

        // 解析 SSE
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let finished = false;

        while (!finished) {
            const { value, done } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });

            // SSE 以空行分隔事件
            const parts = buffer.split("\n\n");
            buffer = parts.pop();   // 最后一段可能不完整，留到下一轮

            for (const part of parts) {
                let eventType = "message";
                const dataLines = [];
                for (const line of part.split("\n")) {
                    if (line.startsWith("event:")) eventType = line.slice(6).trim();
                    else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
                }
                if (!dataLines.length) continue;

                let data;
                try { data = JSON.parse(dataLines.join("\n")); } catch (e) { continue; }

                switch (eventType) {
                    case "stage":
                        renderStage(data);
                        break;
                    case "sql":
                        renderSql(data);
                        break;
                    case "final":
                        renderFinal(bubble, data);
                        renderData(data);
                        botWrap.removeAttribute("id");
                        messages.scrollTop = messages.scrollHeight;
                        finished = true;
                        break;
                    case "error":
                        finalize(`<p class="error-text">❌ ${escapeHtml(data.message || "未知错误")}</p>`);
                        finished = true;
                        break;
                }
            }
        }

        // 流意外结束但没收到 final
        if (!finished && $("typingIndicator")) {
            finalize(`<p class="error-text">❌ 连接意外中断</p>`);
        }
    } catch (err) {
        finalize(`<p class="error-text">❌ ${escapeHtml(err.message || "网络错误")}</p>`);
    } finally {
        busy = false;
        sendBtn.disabled = false;
        input.focus();
    }
}

/* ================================================================== 交互绑定 */
sendBtn.addEventListener("click", () => {
    const q = input.value;
    input.value = "";
    autoGrow();
    ask(q);
});

input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendBtn.click();
    }
});

function autoGrow() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 160) + "px";
}
input.addEventListener("input", autoGrow);

$("clearBtn").addEventListener("click", () => {
    messages.innerHTML = "";
    resetSidePanels();
    addMessage("bot", `
        <p>对话已清空。试试这些问题：</p>
        <ul class="chip-list" id="exampleChips"></ul>
    `);
    // 概览卡片也要重新渲染（它在上一次渲染后被 innerHTML 清掉了）
    if (lastSchema) renderOverview(lastSchema);
    loadExamples();
});

/* 标签页切换 */
document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        document.querySelectorAll(".tab-body").forEach(b => b.classList.remove("active"));
        tab.classList.add("active");
        $("tab-" + tab.dataset.tab).classList.add("active");
    });
});

/* ================================================================== 初始化 */
async function loadExamples() {
    try {
        const res = await fetch("/api/examples");
        const data = await res.json();
        const chips = document.getElementById("exampleChips");
        if (!chips) return;
        chips.innerHTML = data.examples.map(q => `<li>${escapeHtml(q)}</li>`).join("");
        chips.querySelectorAll("li").forEach(li => {
            li.addEventListener("click", () => ask(li.textContent));
        });
    } catch (e) {
        console.error("加载示例失败", e);
    }
}

async function loadSchema() {
    try {
        const res = await fetch("/api/schema");
        const data = await res.json();
        lastSchema = data;
        $("schemaLoading").hidden = true;
        $("schemaList").classList.add("ready");
        $("schemaList").innerHTML = data.tables.map(t => `
            <div class="schema-item">
                <div class="schema-name">${escapeHtml(t.name)} <span style="color:#94a3b8;font-weight:400">(${t.row_count} 行)</span></div>
                <div class="schema-desc">${escapeHtml(t.description)}</div>
                <div class="schema-cols">${escapeHtml(t.columns.join(", "))}</div>
            </div>
        `).join("");

        renderOverview(data);
    } catch (e) {
        console.error("加载表结构失败", e);
        $("schemaLoading").textContent = "表结构加载失败，请检查后端服务";
    }
}

/** 首屏的数据库概览卡片 */
function renderOverview(data) {
    const tables = data.tables || [];
    const rows = tables.reduce((sum, t) => sum + (t.row_count || 0), 0);
    const fields = tables.reduce((sum, t) => sum + (t.columns || []).length, 0);

    $("dbOverview").innerHTML = `
        <div class="overview-card">
            <div class="overview-head">
                <span class="overview-icon">🎵</span>
                <div>
                    <div class="overview-title">${escapeHtml(data.database || "Chinook")}</div>
                    <div class="overview-sub">SQLite · 只读连接（mode=ro）</div>
                </div>
            </div>
            <div class="overview-stats">
                <div class="ov-stat"><span class="ov-num">${tables.length}</span><span class="ov-label">张表</span></div>
                <div class="ov-stat"><span class="ov-num">${fields}</span><span class="ov-label">个字段</span></div>
                <div class="ov-stat"><span class="ov-num">${rows.toLocaleString()}</span><span class="ov-label">行记录</span></div>
            </div>
            <div class="overview-tables">
                ${tables.slice(0, 8).map(t =>
                    `<span class="ov-table" title="${escapeHtml(t.description)}">${escapeHtml(t.name)}</span>`
                ).join("")}
                ${tables.length > 8 ? `<span class="ov-table ov-more">+${tables.length - 8}</span>` : ""}
            </div>
        </div>
    `;
}

loadExamples();
loadSchema();
input.focus();
