"""
LangGraph 图的三个回环场景测试：

  测试 1：校验失败 -> 改写 -> 重新校验 -> 执行       （闭环能跑通）
  测试 2：一直失败 -> 超过改写上限 -> 终止          （上限生效，不会死循环）
  测试 3：执行报错 -> 改写 -> 重跑 -> 成功          （执行回环能跑通）

跑法：python3 -u test_graph_loop.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sql_agent import SQLAgentWorkflow, RunConfig, DBParser, LLMClient
from sql_agent.stages import ExecutionResult, GeneratedSQL

REAL_GENERATOR_RUN = None


def build_workflow():
    wf = SQLAgentWorkflow(parser=DBParser(), llm=LLMClient(), run_config=RunConfig())
    return wf


def show_trace(result):
    for t in result.trace:
        status = "OK " if t.ok else "ERR"
        print(f"[{status}] {t.index}. {t.name} ({t.elapsed_ms:.0f}ms) — {t.detail[:66]}")


# ==================================================================== 测试 1
def test_validation_loop():
    print("=" * 70)
    print("测试 1：校验失败 -> 改写 -> 重新校验 -> 执行")
    print("=" * 70)
    wf = build_workflow()
    real_run = wf.generator.run
    calls = {"n": 0}

    def fake_run(question, tables):
        calls["n"] += 1
        if calls["n"] == 1:
            return GeneratedSQL(
                sql="SELECT SUM(NoSuchColumn) FROM invoices",
                explanation="故意造错：字段名不存在",
                tables_used=["invoices"],
            )
        return real_run(question, tables)

    wf.generator.run = fake_run
    result = wf.run("总销售额是多少")

    show_trace(result)
    validates = [t for t in result.trace if t.name == "sql 校验"]
    rewrites = [t for t in result.trace if t.name == "sql 改写"]
    print("\n--- 断言 ---")
    print("走通改写回环      :", len(rewrites) >= 1, f"({len(rewrites)} 次改写)")
    print("校验执行次数 = 2   :", len(validates) == 2, f"(实际 {len(validates)})")
    print("最终成功           :", result.success)
    print()
    return result


# ==================================================================== 测试 2
def test_rewrite_limit():
    print("=" * 70)
    print("测试 2：一直失败 -> 超过改写上限 -> 终止")
    print("=" * 70)
    wf = build_workflow()
    wf.run_config = RunConfig(max_validate_rounds=2)
    wf.graph = wf._build_graph()

    def always_bad_run(question, tables):
        return GeneratedSQL(
            sql="SELECT SUM(NoSuchColumn) FROM invoices",
            explanation="永远造错",
            tables_used=["invoices"],
        )

    wf.generator.run = always_bad_run
    # 改写也一直失败：用真实 rewriter，但把它的输出替换成坏的
    real_rewriter_run = wf.rewriter.run

    def bad_rewriter_run(question, sql, feedback, tables):
        generated = real_rewriter_run(question, sql, feedback, tables)
        generated.sql = "SELECT SUM(StillNoSuchColumn) FROM invoices"
        return generated

    wf.rewriter.run = bad_rewriter_run
    result = wf.run("总销售额是多少")

    show_trace(result)
    rewrites = [t for t in result.trace if t.name == "sql 改写"]
    print("\n--- 断言 ---")
    print("改写次数受上限约束 :", len(rewrites) == 2, f"(实际 {len(rewrites)}，上限 2)")
    print("未进入执行阶段      :", not any(t.name == "sql 执行" for t in result.trace))
    print("最终失败            :", not result.success)
    print("错误信息非空        :", bool(result.error), f"→ {result.error[:60]}")
    print()
    return result


# ==================================================================== 测试 3
def test_execution_loop():
    print("=" * 70)
    print("测试 3：执行报错 -> 改写 -> 重跑 -> 成功")
    print("=" * 70)
    wf = build_workflow()
    real_executor_run = wf.executor.run
    calls = {"n": 0}

    def flaky_run(sql):
        calls["n"] += 1
        if calls["n"] == 1:
            return ExecutionResult(ok=False, error="模拟执行错误：database is locked")
        return real_executor_run(sql)

    wf.executor.run = flaky_run
    result = wf.run("总销售额是多少")

    show_trace(result)
    rewrites = [t for t in result.trace if t.name == "sql 改写"]
    executes = [t for t in result.trace if t.name == "sql 执行"]
    print("\n--- 断言 ---")
    print("走通执行回环      :", len(rewrites) >= 1, f"({len(rewrites)} 次改写)")
    print("执行节点跑过 2 次  :", len(executes) == 2, f"(实际 {len(executes)})")
    print("最终成功          :", result.success)
    print()
    return result


if __name__ == "__main__":
    test_validation_loop()
    test_rewrite_limit()
    test_execution_loop()
    print("全部测试完成")
