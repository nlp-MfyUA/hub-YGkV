# Chinook SQL Agent Workflow（LangGraph 实现）

基于 `chinook.db`（Chinook 数字音乐商店销售数据，SQLite）的完整 SQL Agent 工作流，
**用 LangGraph 状态图编排**，对标 `sql-agent.ipynb` 作业要求：

```
数据库解析 → table 选择 → sql 生成 → sql 校验 → sql 改写 → sql 执行 → 结果汇总
```

模型使用 **MiniMax-M3**，通过课程根目录 `.env` 中的 `OPENAI_API_KEY` / `OPENAI_API_URL`
以 OpenAI 兼容协议接入。代码不绑定 MiniMax —— 换成 DeepSeek / OpenRouter 只需改两处配置。

> **本次改动**：把原来的「一条直线 + 两段 while 循环」手写编排，换成了 LangGraph 声明式状态图。
> 业务阶段（`stages.py`）一行没动，变的只有编排层。

---

## 一、运行

```bash
# 单次问答
python main.py "总销售额是多少"

# 交互式问答（exit / quit 退出）
python main.py

# 打印每个阶段的中间产物
python main.py "消费金额最高的5位客户是谁" --verbose

# 把完整工作流轨迹写成 JSON，便于复盘 / 做效果评测
python main.py "最贵的10首歌曲" --trace trace.json

# 只看生成的 SQL，跳过结果汇总
python main.py "每个国家有多少客户" --sql-only
```

### 依赖

```bash
pip install -r requirements.txt
# openai · SQLAlchemy · pandas · python-dotenv · langgraph
```

> **关于 `openai-agents`**：课程 notebook `04_SQL-Code-Agent-Demo/sql-agent.ipynb` 里用到了
> `agents` SDK（`Agent` / `Runner` / `function_tool`）。该 SDK 的 `openai-agents>=0.18` 要求
> `openai>=2.45`，而当前环境装的是 `openai 1.59.9`，直接 `import agents` 会报
> `ModuleNotFoundError: No module named 'openai.types.shared.reasoning'`。
>
> 因此本实现把「table 选择」阶段的 Agent 用 **OpenAI 兼容接口的 tool calling 循环**
> 直接实现（见 `sql_agent/llm.py: run_tools`），效果等价，且不依赖 `agents` SDK、
> 不需要升级任何包。

---

## 二、Web 前端

除了命令行，还提供了一个对话式 Web 界面：左边聊天，右边实时展示工作流过程。

```bash
cd SQL-agent
python3 web/app.py          # 或 uvicorn web.app:app --host 0.0.0.0 --port 8000
```

打开 **http://localhost:8000**

### 界面

```
┌──────────────────────────┬────────────────────────┐
│  对话区                   │  工作流 | SQL | 数据 | 表结构 │
│  ┌────────────────────┐  │                        │
│  │ 用户：总销售额是多少 │  │  ✅ 数据库解析      0ms   │
│  └────────────────────┘  │  ✅ table 选择   2938ms   │
│  ┌────────────────────┐  │  ✅ sql 生成    2889ms   │
│  │ 🤖 总销售额 2328.60 │  │  ✅ sql 校验       1ms   │
│  │    关键发现…        │  │  ✅ sql 执行       1ms   │
│  │    执行的 SQL…      │  │  ✅ 结果汇总    2540ms   │
│  └────────────────────┘  │                        │
├──────────────────────────┤                        │
│  [输入问题…]        [➤]  │                        │
└──────────────────────────┴────────────────────────┘
```

- **对话区**：问问题、看自然语言答案、关键发现、后续建议、执行的 SQL
- **工作流**：LangGraph 每个阶段的实时状态、耗时、详情（校验失败会标红）
- **SQL**：当前 SQL + 改写历史（每次改写的原因）
- **数据**：查询结果表格，数值列右对齐
- **表结构**：11 张表的用途、字段清单、行数

### 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/` | 前端页面 |
| GET | `/api/schema` | 数据库表结构概览 |
| GET | `/api/examples` | 示例问题 |
| POST | `/api/chat` | 对话式查询，**SSE 流式**返回 |

### SSE 事件

`POST /api/chat` 返回 `text/event-stream`，四种事件：

```
event: stage    每个阶段完成 {index, name, ok, detail, elapsed_ms}
event: sql      SQL 或改写历史更新 {sql, sql_history}
event: final    全部结束 {question, success, tables, sql, columns, rows, summary, trace}
event: error    出错 {message}
```

前端拿到 `stage` 事件就画一张阶段卡片，拿到 `final` 就填答案和结果表。

### 实现要点

- **流式来自 LangGraph 本身**：`workflow.run_stream()` 用 `graph.stream(stream_mode=["updates", "values"])`
  —— `updates` 拿每个节点的增量（用来画阶段卡片），`values` 拿累积后的完整 state（用来更新 SQL）。
- **不阻塞事件循环**：同步的工作流跑在 `asyncio.to_thread` 里，通过 `asyncio.Queue` 把事件送回事件循环。
- **工作流全局复用**：`DBParser` 会缓存表结构统计，`SQLAgentWorkflow` 也复用同一个实例，避免每次请求重新解析数据库。
- **`X-Accel-Buffering: no`**：关掉反向代理的缓冲，否则 Nginx 下前端收不到流式事件。

### 目录结构

```
web/
├── app.py                 # FastAPI 服务 + SSE 接口
├── screenshot.py          # 用 CDP 驱动无头 Chrome 截图（前端改动的回归验证用）
└── static/
    ├── index.html
    ├── style.css
    └── app.js
```

---

## 三、目录结构

```
SQL-agent/
├── chinook.db                 # 数据库（课程原件在 04_SQL-Code-Agent-Demo/，此处为副本，保证本目录可独立运行）
├── main.py                    # 命令行入口（LangGraph 版与手写版 API 完全一致，无需改动）
├── test_graph_loop.py         # 图的回环测试（校验回环 / 改写上限 / 执行回环）
├── web/                       # ★ Web 前端（对话 + 工作流可视化）
├── README.md
├── requirements.txt
└── sql_agent/
    ├── config.py              # 模型 / API / 路径 / 运行参数
    ├── utils.py               # Markdown 表格、思维链剥离、JSON 提取
    ├── llm.py                 # LLM 客户端：对话 / JSON 输出 / 工具调用循环
    ├── db_parser.py           # 数据库解析 + SQL 校验 + SQL 执行
    ├── stages.py              # 6 个业务阶段的具体实现（LangGraph 前后完全一致）
    ├── state.py               # ★ LangGraph 状态定义（TypedDict）
    ├── workflow.py            # ★ LangGraph 图定义 + SQLAgentWorkflow（对外 API 不变）
    └── workflow_manual.py     # 原来的手写编排版，保留作对照
```

---

## 四、LangGraph 图结构

### 4.1 图长什么样

```
        START
          │
     ┌────▼────┐
     │ parse_db│  1. 数据库解析
     └────┬────┘
          │
     ┌────▼──────┐
     │select_tbls│ 2. table 选择（带工具调用的 Agent）
     └──┬──────┬──┘
        │      │ (没选出表)
   ┌────▼──┐ ┌─▼────┐
   │generate│ │ fail │
   │  sql  │ └──┬───┘
   └──┬──┬─┘    │
      │  │      │
   ┌──▼──▼────┐ │
   │ validate │ │ 4. sql 校验 ──(不通过)──→ rewrite ──┐
   └──┬───┬───┘ │                                    │
      │   │     │  ┌──────────────┐                 │
      │   └─────┼─→│   rewrite    │←────────────────┘
      │         │  │ 5. sql 改写   │
      │         │  └──────┬───────┘
      │         │         │ (改写后回到校验)
      │  ┌──────▼──────┐  │
      │  │   validate   │  │
      │  └──────┬──────┘  │
      │         │ (通过)   │
   ┌──▼─────────▼──────┐  │
   │    execute_sql    │  │ 6. sql 执行 ──(报错)──→ rewrite
   └──┬────────────────┘  │
      │ (成功)            │
   ┌──▼──────┐           │
   │summarize│ 7. 结果汇总
   └──┬──────┘
      ▼
     END
```

### 4.2 LangGraph 的四个概念如何对应到这个项目

| LangGraph 概念 | 本项目里的东西 |
|----------------|----------------|
| **State**（`TypedDict`） | `sql_agent/state.py: SQLAgentState` —— 7 个阶段的全部输入输出 |
| **Node**（节点） | 7 个阶段函数 + 1 个 `fail` 收口节点 |
| **Edge**（普通边） | `parse_db → select_tables`、`generate_sql → validate_sql` 等固定流转 |
| **Conditional Edge**（条件边） | 4 个路由函数，决定「校验失败→改写」「执行报错→改写」「超上限→终止」 |

### 4.3 状态字段

```python
class SQLAgentState(TypedDict, total=False):
    question: str
    # 1. 数据库解析
    db_summary: str
    # 2. table 选择
    tables: list[str]; table_reason: str; table_source: str; tool_calls: list[dict]
    # 3. sql 生成
    sql: str; sql_explanation: str
    # 4/5. 校验 + 改写
    validation_ok: bool; validation_reason: str
    feedback: str          # 触发改写的原因
    feedback_type: str     # validate | execute
    validate_rounds: int   # 因校验失败而改写的次数
    exec_retries: int      # 因执行报错而改写的次数
    # 6. sql 执行
    exec_ok: bool; exec_error: str; columns: list[str]; rows: list[tuple]; row_count: int
    # 7. 结果汇总
    summary: dict
    # 全局
    success: bool; error: str
    # 追加型字段
    sql_history: Annotated[list, operator.add]
    trace: Annotated[list, operator.add]
```

**普通字段是覆盖语义，Annotated 字段是追加语义** —— `sql_history`（SQL 演进过程）和
`trace`（节点轨迹）本质上都是往同一条流水线上**追加**记录，所以用 `operator.add`。

### 4.4 回环怎么实现的

两个回环共用一个 `rewrite_sql` 节点，靠 state 里的 `feedback_type` 区分：

```python
def _route_after_validate(self, state):
    if state.get("validation_ok"):
        return "execute_sql"                              # 校验通过 → 执行
    if state.get("validate_rounds", 0) >= self.run_config.max_validate_rounds:
        return "fail"                                    # 超过改写上限 → 终止
    return "rewrite_sql"                                # 校验失败 → 改写

def _route_after_execute(self, state):
    if state.get("exec_ok"):
        return "summarize"                               # 执行成功 → 汇总
    if state.get("exec_retries", 0) >= self.run_config.max_exec_retries:
        return "fail"                                    # 超过重试上限 → 终止
    return "rewrite_sql"                                # 执行报错 → 改写重跑
```

改写节点根据 `feedback_type` 决定累加哪个计数器（校验轮次 / 执行轮次），两个上限互不干扰：

```python
if feedback_type == "validate":
    update["validate_rounds"] = state.get("validate_rounds", 0) + 1
else:
    update["exec_retries"] = state.get("exec_retries", 0) + 1
```

### 4.5 手写版 vs LangGraph 版

| | 手写版（`workflow_manual.py`） | LangGraph 版（`workflow.py`） |
|---|---|---|
| 流程定义 | 一条直线 + 两个 `while` 循环 | 声明节点和边，编译成图 |
| 回环控制 | 手写计数器 + `break` | 条件边 + state 里的计数器 |
| 新增分支 | 改 `if/else` 链，容易漏 | 加一个节点 + 一条边 |
| 终止条件 | 散落在各个 `return` | 统一收敛到 `fail` 节点 |
| 状态传递 | 靠局部变量 + 返回值 | 显式的 State，节点间共享 |
| 可视化 | 无 | `graph.get_graph().draw_mermaid()` 出流程图 |
| 断点/重放 | 难 | `invoke` 可传 checkpoint 断点续跑 |
| 副作用隔离 | 混在主流程里 | 每个节点独立，可单独测 |

两者对外 API 完全一致（`run(question) -> WorkflowResult`），`main.py` 一行没改。

### 4.6 看流程图

```python
from sql_agent import SQLAgentWorkflow
print(SQLAgentWorkflow().graph.get_graph().draw_mermaid())
```

---

## 五、七个阶段

| # | 阶段 | 实现位置 | 说明 |
|---|------|----------|------|
| 1 | 数据库解析 | `db_parser.DBParser` | SQLAlchemy Inspector 拿到表清单、字段明细、外键关系；再对每个字段统计 distinct / 缺失值 / 极值 / 众数 / 样例值；并补上人工整理的「表用途 + 字段含义」说明 |
| 2 | table 选择 | `stages.TableSelector` | 带工具调用的 Agent：`describe_table` 工具逐张确认候选表，最后输出 `{"tables": [...], "reason": "..."}`；模型不配合时降级为「中文业务词 → 表」的规则打分 |
| 3 | sql 生成 | `stages.SQLGenerator` | 带上选中表的完整 schema + 外键关系 + 样例数据，提示 SQLite 方言（`strftime` 而非 `YEAR()` 等），要求输出 JSON |
| 4 | sql 校验 | `stages.SQLValidator` | ① 只允许 `SELECT`/`WITH`；② 只允许单语句；③ 禁止 `INSERT/UPDATE/DROP/...` 等写操作关键字；④ `EXPLAIN` 预编译 —— 一次性验证语法、表名、列名 |
| 5 | sql 改写 | `stages.SQLRewriter` | 校验失败 / 执行报错时，把「原始问题 + 当前 SQL + 错误原因 + 表结构」一起交给模型重新生成。**改写必须带 schema** —— 否则模型会改出新的字段错误 |
| 6 | sql 执行 | `stages.SQLExecutor` | 只读连接执行，限制返回行数 |
| 7 | 结果汇总 | `stages.ResultSummarizer` | 把结果表 + 结果统计（数值列 count/sum/min/max/mean、文本列高频值）一起给模型，产出自然语言答案 + 关键发现 + 后续建议 |

---

## 六、设计要点

### 1. 安全：两层只读保护

- **数据库层**：整条链路使用 SQLite 的 `mode=ro` URI 连接，
  `sqlite:///file:<path>?mode=ro&uri=true`。即使模型生成了 `DELETE`，数据库层面也无法落盘。
- **SQL 层**：`check_sql` 做关键字白名单 + 单语句检查，写操作语句在执行前就被拦下。

### 2. 容错：每一步都有兜底

| 失败点 | 兜底策略 |
|--------|----------|
| 选表 Agent 调用异常 | 降级为中文业务词规则打分 |
| 选表 Agent 输出无法解析成 JSON | 从正文里正则捞表名；再失败则规则打分 |
| 模型 JSON 输出格式错误 | `chat_json` 自动追加一条纠正消息重试一次 |
| 模型输出带 `<think>` 思维链 / ```` ``` ```` 围栏 | `strip_think` / `clean_sql` 统一清洗 |
| 模型用错字段名或表名 | 校验阶段发现 → 改写阶段修复 |
| 改写后仍不合法 | 走 `fail` 节点终止，不会拿未校验的 SQL 去跑 |
| 图陷入死循环 | `max_graph_steps`（`recursion_limit`）兜底 |

### 3. 可观测：全流程轨迹

每个节点都会产生一条 `StageTrace`（序号、名称、耗时、详情、是否通过），
`--trace` 可以把整条链路连同 SQL 演进过程导出成 JSON。

`sql_history` 记录了 SQL 的每一次改写及改写原因，方便复盘「模型为什么走偏了」。

### 4. 中文数据的编码处理

Windows 控制台默认 GBK，而 Chinook 的地址字段里存在非 GBK 字符（如 `São Paulo`），
`main.py` 启动时会强制 `sys.stdout.reconfigure(encoding="utf-8")`，
避免 `UnicodeEncodeError`。

---

## 七、图的三种回环测试

`test_graph_loop.py` 用 mock 把某个阶段替换成「必定失败」的实现，
验证图的三条关键路径：

```bash
python3 -u test_graph_loop.py
```

| 测试 | 验证点 | 实测结果 |
|------|--------|---------|
| 测试 1 | 校验失败 → 改写 → 重校验 → 执行 | 校验跑 2 次、改写 1 次、最终成功 |
| 测试 2 | 一直失败 → 超过改写上限 → 终止 | 改写 2 次即停、未进入执行阶段、返回错误 |
| 测试 3 | 执行报错 → 改写 → 重跑 → 成功 | 执行跑 2 次、改写 1 次、最终成功 |

---

## 八、切换模型

改 `sql_agent/config.py` 里的 `LLMConfig` 即可：

```python
@dataclass(frozen=True)
class LLMConfig:
    model: str = "MiniMax-M3"
    api_key_env: str = "OPENAI_API_KEY"
    base_url_env: str = "OPENAI_BASE_URL"
```

换成 DeepSeek：

```python
model: str = "deepseek-chat"
api_key_env: str = "DEEPSEEK_API_KEY"
base_url_env: str = "DEEPSEEK_API_URL"   # 注意末尾要补 /v1
```

换成 OpenRouter 则是 `OPENROUTE_API_KEY` + `OPENROUTE_API_URL`（末尾补 `/v1`）。

> `.env` 统一放在课程根目录，`config.py` 会从项目目录逐级向上查找并自动加载。
> 根目录 `.env` 里写的是 `OPENAI_API_URL`，`config.py` 会自动映射成 SDK 认的 `OPENAI_BASE_URL`。

---

## 九、参考问题

```bash
python main.py "总销售额是多少"
python main.py "消费金额最高的5位客户是谁？列出姓名、国家和消费总额"
python main.py "每位销售代表一共卖出了多少销售额？只列出销售额超过10的"
python main.py "Rock 流派有哪些专辑？按发行数量排序"
python main.py "数据库里一共有多少首歌曲"
python main.py "最贵的10首歌曲"
```

---

## 十、已知限制

- **延迟**：MiniMax-M3 是推理模型，选表阶段（多次工具调用往返）耗时在 5s~50s 之间波动。
  生产环境建议把选表阶段换成「一次调用直接给表名 + 缓存 schema 摘要」。
- **兜底词表有限**：`db_parser.BUSINESS_KEYWORDS` 是人工整理的中文业务词映射，
  换业务库时需要重新维护。
- **只读**：本实现刻意不支持写操作（`UPDATE` / `INSERT` / DDL）。要做数据分析师类
  「查完顺手改」的 Agent，需要额外加白名单表和审计日志。
- **统计口径**：`invoices.Total` 是订单总金额，`invoice_items` 里是明细金额，
  两者口径不同（前者已含税、后者按单价×数量）。问「销售额」时默认用 `invoices.Total`。
- **未接持久化**：目前没有挂 LangGraph 的 checkpointer，进程重启后不会恢复中间状态。
  需要断点续跑可以用 `from langgraph.checkpoint.sqlite import SqliteSaver`。
