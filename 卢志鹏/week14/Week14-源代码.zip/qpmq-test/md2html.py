# -*- coding: utf-8 -*-
"""Convert a Markdown file (with raw HTML blocks, CJK text, badges) into a
print-ready HTML file, intended for Edge headless --print-to-pdf.

Usage: python md2html.py <input.md> <output.html> <title>
"""
import sys
from pathlib import Path

import markdown
from pygments.formatters import HtmlFormatter

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
title = sys.argv[3] if len(sys.argv) > 3 else src.stem

text = src.read_text(encoding="utf-8")

# Force <details> blocks open so hidden content (flowcharts) is included in the PDF,
# and tag them for md_in_html so the markdown images inside get rendered.
text = text.replace("<details>", '<details markdown="1" open>')

md = markdown.Markdown(
    extensions=["tables", "fenced_code", "codehilite", "md_in_html", "attr_list"],
    extension_configs={"codehilite": {"guess_lang": False}},
)
body = md.convert(text)
pyg_css = HtmlFormatter(style="default").get_style_defs(".codehilite")

css = """
@page { size: A4; margin: 15mm 13mm; }
* { box-sizing: border-box; }
body {
  font-family: 'Segoe UI', 'Microsoft YaHei', 'PingFang SC', 'Segoe UI Emoji', 'Segoe UI Symbol', sans-serif;
  font-size: 13.5px; line-height: 1.65; color: #1f2328; margin: 0; padding: 0;
  -webkit-print-color-adjust: exact; print-color-adjust: exact;
}
h1, h2 { border-bottom: 1px solid #d0d7de; padding-bottom: .3em; page-break-after: avoid; }
h1 { font-size: 1.9em; margin: .5em 0 .6em; }
h2 { font-size: 1.45em; margin: 1.4em 0 .6em; }
h3 { font-size: 1.2em; margin: 1.2em 0 .5em; page-break-after: avoid; }
h4 { font-size: 1.05em; margin: 1em 0 .4em; page-break-after: avoid; }
p { margin: .6em 0; }
a { color: #0969da; text-decoration: none; }
ul, ol { padding-left: 1.6em; margin: .5em 0; }
li { margin: .25em 0; page-break-inside: avoid; }
hr { border: 0; border-top: 1px solid #d0d7de; margin: 1.5em 0; }
blockquote { border-left: .3em solid #d0d7de; color: #59636e; padding: 0 .9em; margin: .8em 0; }
code {
  font-family: 'Cascadia Code', Consolas, 'Courier New', 'Microsoft YaHei', monospace;
  font-size: .88em; background: #f6f8fa; padding: .15em .35em; border-radius: 4px;
}
pre {
  background: #f6f8fa; border: 1px solid #d0d7de; border-radius: 6px;
  padding: .7em .9em; overflow-x: auto; page-break-inside: avoid; margin: .8em 0;
}
pre code { background: none; padding: 0; font-size: .85em; }
.codehilite pre { border: none; }
table { border-collapse: collapse; margin: 1em 0; width: auto; max-width: 100%; display: block; overflow-x: auto; }
th, td { border: 1px solid #d0d7de; padding: .35em .65em; text-align: left; vertical-align: top; }
th { background: #f6f8fa; }
tr { page-break-inside: avoid; }
img { max-width: 100%; height: auto; }
details {
  border: 1px solid #d0d7de; border-radius: 6px; padding: .5em .9em; margin: 1em 0;
  page-break-inside: avoid;
}
details summary { font-weight: 600; cursor: default; }
"""

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>{css}\n{pyg_css}</style>
</head>
<body>
{body}
</body>
</html>
"""

dst.write_text(html, encoding="utf-8")
print(f"OK: {dst} ({dst.stat().st_size} bytes)")
