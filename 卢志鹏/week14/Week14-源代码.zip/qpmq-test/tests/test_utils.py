# -*- coding: utf-8 -*-
"""docqa.utils 通用工具测试."""
import json
import tempfile
import unittest
from pathlib import Path

from docqa.utils import atomic_write_json, hard_split_bytes, new_doc_id, utf8len


class TestUtils(unittest.TestCase):
    def test_utf8len_counts_bytes_not_chars(self):
        self.assertEqual(utf8len("abc"), 3)
        self.assertEqual(utf8len("中文"), 6)

    def test_new_doc_id_sanitizes_stem(self):
        doc_id = new_doc_id("a b&中文 c.pdf")
        self.assertNotIn(" ", doc_id)
        self.assertNotIn("&", doc_id)
        self.assertRegex(doc_id, r"^[A-Za-z0-9_\-一-鿿]+$")  # 目录名安全字符

    def test_hard_split_bytes_respects_limit_and_no_loss(self):
        long_text = "".join(f"第{i}句话，内容各不相同。" for i in range(200))
        parts = hard_split_bytes(long_text, 512, 64)
        self.assertGreater(len(parts), 1)
        for p in parts:
            self.assertLessEqual(len(p.encode("utf-8")), 512)
        # overlap=0 时无损重组
        zero = hard_split_bytes(long_text, 512, 0)
        self.assertEqual("".join(zero), long_text)

    def test_hard_split_bytes_overlap_shared(self):
        long_text = "".join(f"第{i}句话，内容各不相同。" for i in range(100))
        parts = hard_split_bytes(long_text, 512, 64)
        for a, b in zip(parts, parts[1:]):
            tail = a[-24:]
            self.assertTrue(
                any(tail[-k:] in b[:32] for k in range(4, min(24, len(tail)) + 1)),
                msg=f"相邻块无重叠: tail={tail!r} head={b[:32]!r}",
            )

    def test_atomic_write_json_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.json"
            atomic_write_json(p, {"a": 1, "b": "中文"})
            self.assertEqual(json.loads(p.read_text("utf-8")), {"a": 1, "b": "中文"})
            self.assertFalse(list(Path(d).glob("*.tmp")))


if __name__ == "__main__":
    unittest.main()
