# -*- coding: utf-8 -*-
"""共享测试工具: Settings 构造 / 样例 content_list / MinerU·Kafka 替身 / 流水线装配."""
from __future__ import annotations

import tempfile
from pathlib import Path

from docqa.config import Settings
from docqa.mineru import MinerUError
from docqa.pipeline import ParsePipeline


def make_settings(**overrides) -> Settings:
    base = dict(
        mineru_token="t", llm_api_key="k", llm_base_url="http://x/v4",
        llm_model="m", llm_multi_model="mm",
        kafka_bootstrap="localhost:9092", kafka_topic="qpmq.doc.events",
        redis_host="localhost", redis_port=6379, redis_db=6,
        data_dir=Path(tempfile.mkdtemp()),
        chunk_size_bytes=512, chunk_overlap_bytes=64, heading_min_level=5,
        mineru_model_version="pipeline", mineru_language="ch",
        poll_interval_sec=5, parse_timeout_sec=900,
        llm_workers=2, image_max_side=1600, image_jpeg_quality=85,
        top_k=5, history_window=12,
    )
    base.update(overrides)
    return Settings(**base)


def sample_content_list() -> list[dict]:
    return [
        {"type": "text", "text": "前言内容第一段。", "page_idx": 0},
        {"type": "text", "text": "第一章 概述", "text_level": 1, "page_idx": 0},
        {"type": "text", "text": "1.1 背景", "text_level": 2, "page_idx": 1},
        {"type": "text", "text": "背景内容甲，说明来龙去脉。", "page_idx": 1},
        {"type": "image", "img_path": "images/fig1.jpg", "img_caption": ["图1 背景示意"], "page_idx": 1},
        {"type": "text", "text": "背景内容乙，补充细节。", "page_idx": 2},
        {"type": "text", "text": "1.1.1 深入分析", "text_level": 3, "page_idx": 2},
        {"type": "text", "text": "深层小节正文。", "page_idx": 2},
        {"type": "text", "text": "六级标题当正文处理", "text_level": 6, "page_idx": 2},
        {"type": "table", "table_body": "<table><tr><td>项目</td><td>数值</td></tr></table>",
         "table_caption": ["表1 数据"], "page_idx": 3},
    ]


class FakeMinerU:
    """不触网的 MinerU 替身: 控制上传失败/轮询瞬时错误/轮询结果."""

    def __init__(self, fail_upload_for=(), poll_errors=0, poll_results=None):
        self.fail_upload_for = set(fail_upload_for)
        self.poll_errors = poll_errors
        self.poll_results = poll_results or {}
        self.uploaded: list[str] = []

    def create_batch(self, files):
        return "batch-1", [f"put://{n}" for n, _ in files]

    def upload_file(self, put_url, pdf_path):
        name = put_url.replace("put://", "")
        if name in self.fail_upload_for:
            raise MinerUError(f"模拟上传失败: {name}")
        self.uploaded.append(name)

    def poll_batch(self, batch_id):
        if self.poll_errors > 0:
            self.poll_errors -= 1
            raise ConnectionError("模拟轮询瞬时网络错误")
        return self.poll_results.get(batch_id, [])

    def download_and_extract(self, zip_url, dest_dir):
        dest_dir.mkdir(parents=True, exist_ok=True)
        return dest_dir


class RecordingBus:
    def __init__(self):
        self.events: list[dict] = []

    def emit(self, **kw):
        self.events.append(kw)
        return kw


class FailingBus(RecordingBus):
    def __init__(self, fail_on: int = 2):
        super().__init__()
        self.fail_on, self.n = fail_on, 0

    def emit(self, **kw):
        self.n += 1
        if self.n >= self.fail_on:
            from kafka.errors import KafkaTimeoutError
            raise KafkaTimeoutError("模拟 broker 中途掉线")
        return super().emit(**kw)


def make_pdf(directory, name) -> Path:
    p = Path(directory) / name
    p.write_bytes(b"%PDF-1.4\n%% test")
    return p


def make_pipeline(bus=None, on_event=None, **fake_kwargs) -> tuple[ParsePipeline, FakeMinerU]:
    s = make_settings(poll_interval_sec=0, parse_timeout_sec=2)
    fake = FakeMinerU(**fake_kwargs)
    pipe = ParsePipeline(s, fake, bus or RecordingBus(), None, on_event=on_event)
    return pipe, fake
