# -*- coding: utf-8 -*-
"""docqa.pipeline 测试: 失败隔离/终态事件/快照映射/文档删除(MinerU·Kafka 用替身)."""
import tempfile
import unittest
from pathlib import Path

from docqa.constants import ST_DONE, ST_FAILED, ST_PARSING, ST_PENDING
from docqa.pipeline import DocRecord, remove_doc
from docqa.retrieval import BM25Index
from docqa.stores import DocStateStore
from tests.helpers import (FailingBus, RecordingBus, make_pdf, make_pipeline,
                           make_settings)
from tests.test_stores import _FakeRedisClient


class TestPipelineFailures(unittest.TestCase):
    def test_single_upload_failure_isolated(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = make_pdf(d, "a.pdf"), make_pdf(d, "b.pdf")
            pipe, _ = make_pipeline(
                fail_upload_for={"b.pdf"},
                poll_results={"batch-1": [{"file_name": "a.pdf", "state": "done",
                                           "full_zip_url": "z://a"}]})
            done = pipe.upload_and_track([a, b])
            self.assertEqual([x.file_name for x in done], ["a.pdf"])
            states = {x.file_name: x.state for x in pipe.docs}
            self.assertEqual(states["a.pdf"], ST_DONE)
            self.assertEqual(states["b.pdf"], ST_FAILED)
            self.assertTrue(any(e.get("state") == ST_FAILED and e.get("file_name") == "b.pdf"
                                for e in pipe.bus.events), msg="失败文档必须收到 FAILED 终态事件")

    def test_transient_poll_error_survives(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = make_pdf(d, "a.pdf"), make_pdf(d, "b.pdf")
            pipe, _ = make_pipeline(
                poll_errors=1,
                poll_results={"batch-1": [
                    {"file_name": "a.pdf", "state": "done", "full_zip_url": "z://a"},
                    {"file_name": "b.pdf", "state": "done", "full_zip_url": "z://b"}]})
            done = pipe.upload_and_track([a, b])
            self.assertEqual(len(done), 2)
            self.assertTrue(all(x.state == ST_DONE for x in pipe.docs))

    def test_duplicate_file_names_rejected(self):
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            a1, a2 = make_pdf(d1, "a.pdf"), make_pdf(d2, "a.pdf")
            pipe, _ = make_pipeline()
            from docqa.mineru import MinerUError
            with self.assertRaises(MinerUError):
                pipe.upload_and_track([a1, a2])

    def test_kafka_emit_failure_marks_docs_failed_and_reraises(self):
        from kafka.errors import KafkaError
        with tempfile.TemporaryDirectory() as d:
            a, b = make_pdf(d, "a.pdf"), make_pdf(d, "b.pdf")
            pipe, _ = make_pipeline(bus=FailingBus(fail_on=2))
            with self.assertRaises(KafkaError):
                pipe.upload_and_track([a, b])
            self.assertTrue(all(x.state == ST_FAILED for x in pipe.docs),
                            msg=f"broker 掉线后文档必须有终态: {[x.state for x in pipe.docs]}")


class TestDocRecordMapping(unittest.TestCase):
    def test_to_mapping_includes_doc_id(self):
        rec = DocRecord(doc_id="d1", file_name="a.pdf", pdf_path="x")
        m = rec.to_mapping()
        self.assertEqual(m["doc_id"], "d1")
        for key in ("file_name", "state", "stage", "created_at"):
            self.assertIn(key, m)


class TestRemoveDoc(unittest.TestCase):
    def _make_doc(self, data_dir, doc_id="d1"):
        base = data_dir / doc_id
        (base / "images").mkdir(parents=True)
        (base / "chunks.json").write_text("{}", encoding="utf-8")
        (base / "headings.json").write_text("{}", encoding="utf-8")
        (base / "images" / "a.jpg").write_bytes(b"x")
        return base

    def test_removes_data_dir_and_redis_record(self):
        s = make_settings()
        base = self._make_doc(s.data_dir, "d1")
        c = _FakeRedisClient()
        c._h["doc:d1"] = {"doc_id": "d1", "pdf_path": "C:/elsewhere/a.pdf"}
        rep = remove_doc("d1", s, DocStateStore(c))
        self.assertFalse(base.exists(), "data/{doc_id} 目录应被删除")
        self.assertTrue(rep["data_dir"])
        self.assertTrue(rep["redis"])
        self.assertIn("doc:d1", c.deleted)
        self.assertIn("d1", c.sremed)

    def test_without_store_skips_redis(self):
        s = make_settings()
        self._make_doc(s.data_dir, "d1")
        rep = remove_doc("d1", s, None)
        self.assertTrue(rep["data_dir"])
        self.assertFalse(rep["redis"])

    def test_clears_bm25_cache(self):
        s = make_settings()
        self._make_doc(s.data_dir, "d1")
        BM25Index._cache[frozenset(["d1"])] = object()
        BM25Index._cache[frozenset(["*"])] = object()
        try:
            remove_doc("d1", s, None)
            self.assertEqual(BM25Index._cache, {}, "删除后必须失效 BM25 进程缓存")
        finally:
            BM25Index._cache.clear()

    def test_deletes_staged_upload_copy_only_under_uploads(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            s = make_settings()
            self._make_doc(s.data_dir, "d1")
            uploads = root / "uploads"
            uploads.mkdir()
            staged = uploads / "abcd1234-a.pdf"
            staged.write_bytes(b"%PDF")
            original = root / "samples" / "a.pdf"
            original.parent.mkdir()
            original.write_bytes(b"%PDF")
            c = _FakeRedisClient()
            c._h["doc:d1"] = {"doc_id": "d1", "pdf_path": str(staged)}
            remove_doc("d1", s, DocStateStore(c), project_root=root)
            self.assertFalse(staged.exists(), "uploads/ 下的暂存副本应删除")
            c2 = _FakeRedisClient()
            c2._h["doc:d1"] = {"doc_id": "d1", "pdf_path": str(original)}
            self._make_doc(s.data_dir, "d1")
            remove_doc("d1", s, DocStateStore(c2), project_root=root)
            self.assertTrue(original.exists(), "用户原始 PDF(uploads 外)不许删")

    def test_unknown_doc_reports_not_found(self):
        s = make_settings()
        rep = remove_doc("ghost", s, None)
        self.assertFalse(rep["existed"])
        self.assertFalse(rep["data_dir"])


if __name__ == "__main__":
    unittest.main()


class TestOnEventCallback(unittest.TestCase):
    """on_event 进度回调: Web 附件解析现场刷 st.status 依赖它(与 bus 同序, 异常不影响主流程)."""

    def _done_results(self):
        return {"batch-1": [{"file_name": "a.pdf", "state": "done",
                             "full_zip_url": "z://a"}]}

    def test_callback_receives_every_event_in_order(self):
        with tempfile.TemporaryDirectory() as d:
            a = make_pdf(d, "a.pdf")
            seen: list[dict] = []
            pipe, _ = make_pipeline(on_event=seen.append,
                                    poll_results=self._done_results())
            done = pipe.upload_and_track([a])
            self.assertEqual(len(done), 1)
            self.assertEqual([e.get("state") for e in seen],
                             [ST_PENDING, ST_PARSING, ST_DONE],
                             msg=f"回调应按序收到全部事件: {[e.get('state') for e in seen]}")
            self.assertEqual(seen, pipe.bus.events,
                             msg="回调收到的事件应与 bus 收到的完全一致(同序同内容)")

    def test_callback_exception_does_not_break_pipeline(self):
        def boom(ev):
            raise RuntimeError("回调抛异常")
        with tempfile.TemporaryDirectory() as d:
            a = make_pdf(d, "a.pdf")
            pipe, _ = make_pipeline(on_event=boom, poll_results=self._done_results())
            done = pipe.upload_and_track([a])
            self.assertEqual(len(done), 1)
            self.assertEqual(done[0].state, ST_DONE,
                             msg="回调异常必须被吞掉, 解析流程照常完成")
