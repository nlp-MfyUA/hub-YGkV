# -*- coding: utf-8 -*-
"""docqa 纯逻辑单元测试包(不触网: MinerU/Kafka/Redis/LLM 由 check 与端到端验证覆盖).

运行(项目根): python -m unittest discover -s tests -t . -v
"""
