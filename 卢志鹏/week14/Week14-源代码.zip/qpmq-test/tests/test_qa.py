# -*- coding: utf-8 -*-
"""docqa.qa 测试: 回答图文拆分 / 问答消息组装(纯函数)."""
import unittest

from docqa.qa import _build_qa_messages, split_markdown_images


class TestSplitMarkdownImages(unittest.TestCase):
    def test_text_image_text(self):
        segs = split_markdown_images("前面说明\n\n![](data/d1/images/a.jpg)\n\n后面说明")
        self.assertEqual([s[0] for s in segs], ["text", "image", "text"])
        self.assertEqual(segs[1][1], "data/d1/images/a.jpg")
        self.assertIn("前面说明", segs[0][1])
        self.assertIn("后面说明", segs[2][1])

    def test_no_images(self):
        segs = split_markdown_images("纯文本回答, 没有图。")
        self.assertEqual(len(segs), 1)
        self.assertEqual(segs[0][0], "text")

    def test_image_with_alt_and_edges(self):
        segs = split_markdown_images("![架构](data/d2/images/b.png)结尾")
        self.assertEqual([s[0] for s in segs], ["image", "text"])
        self.assertEqual(segs[0][1], "data/d2/images/b.png")
        self.assertIn("结尾", segs[1][1])


class TestBuildQAMessages(unittest.TestCase):
    HISTORY = [{"role": "user", "content": "之前的问题"},
               {"role": "assistant", "content": "之前的回答"}]
    RETRIEVED = [{"heading_path_text": ["m.pdf", "第一章"], "doc_id": "d1",
                  "page_start": 2, "text": "资料内容A"}]
    IMAGES = [{"rel_path": "data/d1/images/a.jpg", "caption": "图1",
               "analysis": "架构图"}]

    def test_plain_messages(self):
        msgs = _build_qa_messages(self.HISTORY, self.RETRIEVED, self.IMAGES, "Q1")
        self.assertEqual(msgs[0]["role"], "system")
        self.assertEqual(msgs[-1]["role"], "user")
        self.assertIsInstance(msgs[-1]["content"], str)
        self.assertIn("Q1", msgs[-1]["content"])
        self.assertIn("资料内容A", msgs[-1]["content"])
        self.assertIn("data/d1/images/a.jpg", msgs[-1]["content"])
        self.assertEqual(msgs[1:3], self.HISTORY)

    def test_messages_with_attached_image(self):
        uri = "data:image/jpeg;base64,QUJD"
        msgs = _build_qa_messages([], self.RETRIEVED, self.IMAGES, "Q2",
                                  image_data_uri=uri)
        content = msgs[-1]["content"]
        self.assertIsInstance(content, list)
        kinds = {b["type"] for b in content}
        self.assertEqual(kinds, {"text", "image_url"})
        img_block = [b for b in content if b["type"] == "image_url"][0]
        self.assertEqual(img_block["image_url"]["url"], uri)
        text_block = [b for b in content if b["type"] == "text"][0]
        self.assertIn("Q2", text_block["text"])


if __name__ == "__main__":
    unittest.main()
