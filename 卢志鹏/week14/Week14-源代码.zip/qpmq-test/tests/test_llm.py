# -*- coding: utf-8 -*-
"""docqa.llm 测试: 图片压缩 / data URI(不触网, 只测本地图像处理)."""
import base64
import io
import tempfile
import unittest
from pathlib import Path

from docqa.llm import compress_image, make_data_uri


class TestCompressImage(unittest.TestCase):
    def test_compress_resize_and_jpeg(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "big.png"
            Image.new("RGB", (3000, 2000), (200, 30, 30)).save(p)
            data, mime = compress_image(p, max_side=1600, quality=85)
            self.assertEqual(mime, "image/jpeg")
            img = Image.open(io.BytesIO(data))
            self.assertLessEqual(max(img.size), 1600)


class TestMakeDataUri(unittest.TestCase):
    def test_local_image_to_data_uri(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.png"
            Image.new("RGB", (120, 80), (10, 200, 10)).save(p)
            uri = make_data_uri(p, max_side=64, quality=80)
            self.assertTrue(uri.startswith("data:image/jpeg;base64,"))
            raw = base64.b64decode(uri.split(",", 1)[1])
            self.assertEqual(raw[:3], b"\xff\xd8\xff")  # JPEG magic


if __name__ == "__main__":
    unittest.main()
