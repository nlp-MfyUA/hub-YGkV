# -*- coding: utf-8 -*-
"""docqa.mineru 测试: content_list 定位 + zip-slip 防护."""
import tempfile
import unittest
from pathlib import Path

from docqa.mineru import MinerUError, _check_zip_member_paths, find_content_list


class TestFindContentList(unittest.TestCase):
    """真实 MinerU v4 zip 里 content_list 带 batch 文件 UUID 前缀, 且伴随嵌套的 *_v2."""

    def test_prefers_exact_name(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            (base / "content_list.json").write_text("[]", encoding="utf-8")
            (base / "u1_content_list.json").write_text("[]", encoding="utf-8")
            self.assertEqual(find_content_list(base).name, "content_list.json")

    def test_uuid_prefixed_and_not_v2(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            (base / "u1_content_list_v2.json").write_text("[]", encoding="utf-8")
            (base / "u1_content_list.json").write_text("[]", encoding="utf-8")
            self.assertEqual(find_content_list(base).name, "u1_content_list.json")

    def test_missing_raises(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            (base / "full.md").write_text("# x", encoding="utf-8")
            with self.assertRaises(MinerUError):
                find_content_list(base)


class TestZipSlipProtection(unittest.TestCase):
    def test_rejects_parent_escape(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / "doc1"
            dest.mkdir()
            with self.assertRaises(MinerUError):
                _check_zip_member_paths(dest, ["full.md", "../escape.txt"])

    def test_rejects_prefix_collision(self):
        """doc1 与 doc1evil 的前缀碰撞: startswith 比较会放行, 必须拒绝."""
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / "doc1"
            dest.mkdir()
            with self.assertRaises(MinerUError):
                _check_zip_member_paths(dest, [f"../{dest.name}evil/x.txt"])

    def test_accepts_normal_members(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / "doc1"
            dest.mkdir()
            _check_zip_member_paths(dest, ["full.md", "images/a.jpg", "content_list.json"])


if __name__ == "__main__":
    unittest.main()
