# -*- coding: utf-8 -*-
"""Redis 手动操作演示脚本(触网, 不属于 unittest 自动套件).

注意: 文件名刻意不以 test 开头 — unittest discover 只收集 test*.py,
触网脚本混进自动套件会让 Redis 不可用时整个套件连带失败.

用法(项目根):
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/redis_demo.py status
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/redis_demo.py string|hash|list|set|zset
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/redis_demo.py keys
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/redis_demo.py clean
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/redis_demo.py all

操作说明(全部输出到控制台):
    status  连接诊断: ping / 服务器版本与内存 / 键总数 / 当前 DB 确认
    string  SET EX / GET / APPEND / INCR / TTL / DEL
    hash    HSET / HGET / HGETALL / HLEN / HDEL          — 项目 doc:{id} 快照同款类型
    list    RPUSH / LRANGE / LLEN / LPOP / LTRIM 滚动窗口 — 项目 chat:{session} 同款类型
    set     SADD / SMEMBERS / SISMEMBER / SCARD / SREM    — 项目 docs:index 同款类型
    zset    ZADD / ZRANGE WITHSCORES / ZRANK / ZREM
    keys    SCAN 遍历当前库真实键(只读: doc:*/chat:*/docs:index 等) + TYPE
    clean   立即删除本脚本产生的 demo:* 键(不碰任何真实键)
    all     依次执行以上全部演示

演示键统一 demo: 前缀且带 60s TTL 自动过期, 绝不触碰真实数据;
--db 可临时切库(仍受 Settings 约束: 必须 6, 用于对照其他库时改 .env 才是正路).
"""
from __future__ import annotations

import argparse
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # 项目根, 供 import docqa

from docqa.config import Settings                              # noqa: E402
from docqa.console import cprint                               # noqa: E402
from docqa.stores import make_redis                            # noqa: E402

DEMO_PREFIX = "demo:"          # 本脚本所有键的前缀(clean 只删这个前缀)
DEMO_TTL = 60                  # 演示键自动过期秒数


def _connect(s: Settings):
    """建连 + ping, 失败打印友好提示并返回 None."""
    try:
        rc = make_redis(s)
        rc.ping()
        return rc
    except Exception as e:
        cprint("错误", f"Redis 连接失败({s.redis_host}:{s.redis_port} DB{s.redis_db}): "
                      f"{str(e)[:120]}", "red")
        cprint("提示", "检查网络/Redis 服务是否启动; 配置来自 .env(REDIS_HOST/PORT/DB)", "yellow")
        return None


def _mark_demo(rc, key: str, ttl: int = DEMO_TTL) -> None:
    """给演示键打上过期时间, 60s 后自动消失, 方便事后 redis-cli 查看又不留垃圾."""
    rc.expire(key, ttl)


# ---------------------------------------------------------------- status
def op_status(rc, s: Settings) -> int:
    info = rc.info("server")
    mem = rc.info("memory")
    cprint("PING", "PONG — 连接正常", "green")
    cprint("服务器", f"redis {info.get('redis_version', '?')} / "
                    f"{info.get('os', '?')} / 运行 {int(info.get('uptime_in_seconds', 0)) // 3600}h+",
           "cyan")
    cprint("内存", f"used_memory_human={mem.get('used_memory_human', '?')} "
                  f"(峰值 {mem.get('used_memory_peak_human', '?')})", "cyan")
    cprint("当前库", f"DB{s.redis_db} 共 {rc.dbsize()} 个键(项目要求固定 DB6)", "cyan")
    return 0


# ---------------------------------------------------------------- string
def op_string(rc, s: Settings) -> int:
    k = f"{DEMO_PREFIX}str:{uuid.uuid4().hex[:6]}"
    rc.set(k, "hello redis", ex=DEMO_TTL)
    cprint("SET", f"{k} = 'hello redis' (带 EX {DEMO_TTL}s)", "cyan")
    cprint("GET", f"{k} → {rc.get(k)!r}", "cyan")
    rc.append(k, "!!!")
    cprint("APPEND", f"追加 '!!!' 后 GET → {rc.get(k)!r} (strlen={rc.strlen(k)})", "cyan")

    ck = f"{DEMO_PREFIX}counter:{uuid.uuid4().hex[:6]}"
    rc.set(ck, 1, ex=DEMO_TTL)
    rc.incr(ck); rc.incrby(ck, 10)
    cprint("INCR", f"{ck}: 1 → INCR → INCRBY 10 → 当前 {rc.get(ck)}", "cyan")

    cprint("TTL", f"{k} 剩余 {rc.ttl(k)}s 自动过期; 不存在的键 TTL={rc.ttl('demo:no-such-key')}"
                  "(-2), 无过期键=-1", "cyan")
    rc.delete(k, ck)
    cprint("DEL", f"已删除 {k} 与 {ck}, 再 GET → {rc.get(k)!r}(None)", "cyan")
    return 0


# ---------------------------------------------------------------- hash
def op_hash(rc, s: Settings) -> int:
    k = f"{DEMO_PREFIX}doc:{uuid.uuid4().hex[:6]}"     # 结构对齐项目真实键 doc:{doc_id}
    rc.hset(k, mapping={"file_name": "demo.pdf", "state": "DONE",
                        "chunks_count": 3, "err_msg": ""})
    _mark_demo(rc, k)
    cprint("HSET", f"{k} 一次写入 4 个字段(mapping)", "cyan")
    cprint("HGET", f"file_name → {rc.hget(k, 'file_name')!r}", "cyan")
    cprint("HGETALL", f"共 {rc.hlen(k)} 字段: {dict(rc.hgetall(k))}", "cyan")
    rc.hset(k, "state", "FAILED")
    cprint("HSET单字段", f"state 改为 FAILED 后 → {rc.hget(k, 'state')!r}", "cyan")
    rc.hdel(k, "err_msg")
    cprint("HDEL", f"删除 err_msg 后剩余字段: {sorted(rc.hkeys(k))}", "cyan")
    cprint("说明", "项目 DocStateStore 即此类型: doc:{doc_id} HASH + docs:index SET 索引", "yellow")
    return 0


# ---------------------------------------------------------------- list
def op_list(rc, s: Settings) -> int:
    k = f"{DEMO_PREFIX}chat:{uuid.uuid4().hex[:6]}"    # 结构对齐项目真实键 chat:{session}
    msgs = ["第一条: 你好", "第二条: 文档讲了什么?", "第三条: 回答引用了配图",
            "第四条: 还有别的吗", "第五条: 没有了"]
    rc.rpush(k, *msgs)
    _mark_demo(rc, k)
    cprint("RPUSH", f"{k} 从右侧推入 {len(msgs)} 条", "cyan")
    cprint("LRANGE", f"全部: {rc.lrange(k, 0, -1)}", "cyan")
    cprint("LLEN", f"长度 = {rc.llen(k)}", "cyan")
    cprint("LPOP", f"弹出最旧一条 → {rc.lpop(k)!r}, 剩 {rc.llen(k)} 条", "cyan")
    rc.ltrim(k, -3, -1)                                 # 只保留最近 3 条(滚动窗口)
    cprint("LTRIM", f"保留最近 3 条后: {rc.lrange(k, 0, -1)}", "cyan")
    cprint("说明", "项目 ChatHistoryStore 即此类型: RPUSH + LTRIM 滚动窗口存对话", "yellow")
    return 0


# ---------------------------------------------------------------- set
def op_set(rc, s: Settings) -> int:
    k = f"{DEMO_PREFIX}index:{uuid.uuid4().hex[:6]}"   # 结构对齐项目真实键 docs:index
    rc.sadd(k, "doc-a", "doc-b", "doc-c")
    _mark_demo(rc, k)
    cprint("SADD", f"{k} 加入 doc-a/doc-b/doc-c", "cyan")
    rc.sadd(k, "doc-a")                                 # 重复添加无效
    cprint("SCARD", f"重复 SADD doc-a 后成员数仍 = {rc.scard(k)}(去重)", "cyan")
    cprint("SMEMBERS", f"{sorted(rc.smembers(k))}", "cyan")
    cprint("SISMEMBER", f"doc-b → {rc.sismember(k, 'doc-b')}, doc-x → {rc.sismember(k, 'doc-x')}",
           "cyan")
    rc.srem(k, "doc-b")
    cprint("SREM", f"移除 doc-b 后: {sorted(rc.smembers(k))}", "cyan")
    cprint("说明", "项目 docs:index 即此类型: 全部 doc_id 清单(list_docs 的数据源)", "yellow")
    return 0


# ---------------------------------------------------------------- zset
def op_zset(rc, s: Settings) -> int:
    k = f"{DEMO_PREFIX}rank:{uuid.uuid4().hex[:6]}"
    rc.zadd(k, {"chunk-0001": 3.5, "chunk-0002": 8.2, "chunk-0003": 1.0})
    _mark_demo(rc, k)
    cprint("ZADD", f"{k} 加入 3 个成员(分数=BM25 得分示意)", "cyan")
    cprint("ZRANGE", f"升序 top2: {rc.zrange(k, 0, 1, withscores=True)}", "cyan")
    cprint("ZREVRANGE", f"降序 top2: {rc.zrange(k, 0, 1, desc=True, withscores=True)}", "cyan")
    cprint("ZRANK", f"chunk-0002 升序名次 = {rc.zrank(k, 'chunk-0002')}(0-based)", "cyan")
    rc.zrem(k, "chunk-0003")
    cprint("ZREM", f"移除 chunk-0003 后成员数 = {rc.zcard(k)}", "cyan")
    return 0


# ---------------------------------------------------------------- keys(只读)
def op_keys(rc, s: Settings) -> int:
    """SCAN 遍历当前库全部键(只读), 按 TYPE 分组统计 — 演示生产库里真实布局."""
    buckets: dict[str, list[str]] = {}
    n = 0
    for key in rc.scan_iter(match="*", count=100):
        n += 1
        buckets.setdefault(rc.type(key), []).append(key)
    cprint("SCAN", f"DB{s.redis_db} 共扫到 {n} 个键", "cyan")
    for t in sorted(buckets):
        keys = sorted(buckets[t])
        cprint(f"TYPE {t}", f"{len(keys)} 个: {keys[:8]}{' …' if len(keys) > 8 else ''}",
               "green" if t != "none" else "yellow")
    if not any(kk.startswith("doc:") or kk == "docs:index" for v in buckets.values() for kk in v):
        cprint("提示", "未见 doc:*/docs:index — 项目尚未上传过文档", "yellow")
    return 0


# ---------------------------------------------------------------- clean
def op_clean(rc, s: Settings) -> int:
    victims = list(rc.scan_iter(match=f"{DEMO_PREFIX}*", count=100))
    for key in victims:
        rc.delete(key)
    cprint("CLEAN", f"已删除 {len(victims)} 个 {DEMO_PREFIX}* 键"
                   f"({'/'.join(sorted(victims)[:6]) or '无'})", "green")
    return 0


OPS = {"status": op_status, "string": op_string, "hash": op_hash, "list": op_list,
       "set": op_set, "zset": op_zset, "keys": op_keys, "clean": op_clean}


def main() -> int:
    p = argparse.ArgumentParser(prog="redis_demo.py", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("op", choices=[*OPS, "all"], help="见文件头说明; all=依次全部执行")
    p.add_argument("--host", default="", help="覆盖 .env 的 REDIS_HOST:PORT(如 127.0.0.1:6379)")
    args = p.parse_args()

    s = Settings.load()
    if args.host:
        import dataclasses
        host, _, port = args.host.partition(":")
        s = dataclasses.replace(s, redis_host=host, redis_port=int(port or 6379))
    print(f"目标: {s.redis_host}:{s.redis_port} DB{s.redis_db}\n")

    rc = _connect(s)
    if rc is None:
        return 2
    try:
        names = list(OPS) if args.op == "all" else [args.op]
        code = 0
        for i, name in enumerate(names):
            if args.op == "all" and name != "status":
                print(f"\n— — —  [{i + 1}/{len(names)}] {name}  — — —")
                time.sleep(0.2)
            code = OPS[name](rc, s) or code
        if args.op == "all":
            print()
        return code
    finally:
        rc.close()


if __name__ == "__main__":
    raise SystemExit(main())
