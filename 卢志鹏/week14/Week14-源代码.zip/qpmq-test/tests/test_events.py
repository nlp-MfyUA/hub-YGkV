# -*- coding: utf-8 -*-
"""docqa.events 测试: 事件组装/格式化 + 消费者积压不丢单回归."""
import unittest

from docqa.events import ConsoleEventPrinter, build_event


class _FakeKafkaConsumer:
    """模拟 broker 行为: 分配完成的那次 poll 恰好同时带回积压记录."""

    def __init__(self, *topics, bootstrap_servers=None, group_id=None,
                 auto_offset_reset="latest", enable_auto_commit=True,
                 consumer_timeout_ms=None, **kw):
        self._polls = 0

    def assignment(self):
        return set() if self._polls == 0 else {"tp0"}

    def poll(self, timeout_ms=0):
        self._polls += 1
        if self._polls == 1:
            import json as _json
            rec = type("R", (), {"value": _json.dumps({
                "ts": "2026-11-11T17:09:40", "stage": "parse",
                "file_name": "a.pdf", "state": "DONE",
                "progress": None, "detail": "9 chunks"}).encode("utf-8")})
            return {"tp0": [rec]}
        return {}

    def close(self):
        pass


class TestPrinterKeepsBacklog(unittest.TestCase):
    """回归: 等分区分配期间 poll 到的积压记录不许丢弃(I4 修复引入的回归)."""

    def test_records_polled_during_assignment_wait_are_printed(self):
        import contextlib
        import io
        import threading
        import time as _time
        import kafka as kafka_mod

        orig = kafka_mod.KafkaConsumer
        kafka_mod.KafkaConsumer = _FakeKafkaConsumer
        try:
            stop, ready = threading.Event(), threading.Event()
            threading.Timer(0.4, stop.set).start()
            printer = ConsoleEventPrinter(
                "b:9092", "t", stop, ready, group_id="g", auto_offset_reset="earliest")
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                printer.run()
        finally:
            kafka_mod.KafkaConsumer = orig
        self.assertTrue(ready.is_set())
        self.assertIn("DONE", buf.getvalue(), "分配期间的积压事件被丢弃了")
        self.assertIn("a.pdf", buf.getvalue())


class TestEventAndFormat(unittest.TestCase):
    def test_build_event_schema(self):
        ev = build_event(
            doc_id="d1", file_name="a.pdf", stage="parse", state="PARSING",
            progress={"extracted_pages": 3, "total_pages": 10}, detail="")
        for key in ("event_id", "version", "ts", "doc_id", "file_name", "stage", "state", "progress", "detail"):
            self.assertIn(key, ev)
        self.assertEqual(ev["version"], 1)
        self.assertEqual(ev["progress"]["extracted_pages"], 3)

    def test_format_line_contains_progress(self):
        line = ConsoleEventPrinter.format_line(
            {"ts": "2026-11-11T14:30:00", "stage": "parse", "file_name": "a.pdf",
             "state": "PARSING", "progress": {"extracted_pages": 3, "total_pages": 10}})
        self.assertIn("a.pdf", line)
        self.assertIn("PARSING", line)
        self.assertIn("3/10", line)

    def test_format_line_without_progress(self):
        line = ConsoleEventPrinter.format_line(
            {"ts": "2026-11-11T14:30:00", "stage": "chunk", "file_name": "a.pdf",
             "state": "DONE", "progress": None, "detail": "52 chunks"})
        self.assertIn("DONE", line)
        self.assertNotIn("None", line)


if __name__ == "__main__":
    unittest.main()
