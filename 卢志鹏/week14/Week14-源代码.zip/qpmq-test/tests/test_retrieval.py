# -*- coding: utf-8 -*-
"""docqa.retrieval BM25 索引测试."""
import unittest

from docqa.retrieval import BM25Index


class TestBM25Index(unittest.TestCase):
    def _entries(self):
        return [
            {"search_text": "第一章 概述 背景 安装环境准备", "chunk": {"chunk_id": "c1", "text": "安装环境准备"}},
            {"search_text": "网络 配置 交换机 路由", "chunk": {"chunk_id": "c2", "text": "交换机路由配置"}},
            {"search_text": "财务 报销 流程 发票", "chunk": {"chunk_id": "c3", "text": "报销流程"}},
        ]

    def test_search_ranks_relevant_first(self):
        idx = BM25Index(self._entries())
        hits = idx.search("安装环境", top_k=2)
        self.assertTrue(hits)
        self.assertEqual(hits[0][1]["chunk_id"], "c1")

    def test_search_empty_query_returns_empty(self):
        idx = BM25Index(self._entries())
        self.assertEqual(idx.search("！！！??", top_k=2), [])

    def test_query_and_corpus_use_same_tokenizer(self):
        """自然提问(查询词被语料词包含)必须能召回: 查询与语料同用 lcut_for_search."""
        idx = BM25Index([
            {"search_text": "第一章 存储", "chunk": {"chunk_id": "s1", "text": "标题"}},
            {"search_text": "存储层用 Redis 保存会话 用 Kafka 传输事件",
             "chunk": {"chunk_id": "s2", "text": "存储层说明"}},
        ])
        hits = idx.search("存储层用了什么?", top_k=2)
        self.assertTrue(hits, "『存储层用了什么?』应召回含『存储层』的语料块")
        self.assertEqual(hits[0][1]["chunk_id"], "s2")


if __name__ == "__main__":
    unittest.main()
