# -*- coding: utf-8 -*-
"""docqa.stores 测试: DocStateStore 删除(用假 Redis 客户端, 不触网)."""
import unittest

from docqa.stores import DocStateStore


class _FakeRedisClient:
    def __init__(self):
        self.deleted: list[str] = []
        self.sremed: list[str] = []
        self._h: dict[str, dict] = {}

    def hgetall(self, key):
        return self._h.get(key, {})

    def delete(self, *keys):
        self.deleted.extend(keys)

    def srem(self, name, *values):
        self.sremed.extend(values)

    def pipeline(self):
        client = self

        class _Pipe:
            def delete(self, *keys):
                client.delete(*keys)

            def srem(self, name, *values):
                client.srem(name, *values)

            def execute(self):
                return []

        return _Pipe()


class TestDocStateStoreRemove(unittest.TestCase):
    def test_remove_drops_hash_and_index_member(self):
        c = _FakeRedisClient()
        c._h["doc:d1"] = {"doc_id": "d1", "state": "DONE"}
        DocStateStore(c).remove("d1")
        self.assertIn("doc:d1", c.deleted)
        self.assertIn("d1", c.sremed)


if __name__ == "__main__":
    unittest.main()
