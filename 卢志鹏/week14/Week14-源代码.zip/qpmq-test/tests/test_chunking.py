# -*- coding: utf-8 -*-
"""docqa.chunking 测试: HTML表格 / 标题树构建 / 分块器 / headings 序列化."""
import unittest

from docqa.chunking import (Chunker, build_heading_tree, headings_to_json,
                            html_table_to_text)
from tests.helpers import make_settings, sample_content_list


class TestHtmlTableToText(unittest.TestCase):
    def test_basic_table(self):
        html = "<table><tr><td>A</td><td>B</td></tr><tr><td>C</td><td>D</td></tr></table>"
        out = html_table_to_text(html)
        lines = [ln.strip() for ln in out.strip().splitlines() if ln.strip()]
        self.assertEqual(len(lines), 2)
        self.assertIn("A", lines[0]); self.assertIn("B", lines[0])
        self.assertIn("C", lines[1]); self.assertIn("D", lines[1])
        self.assertNotIn("<", out)


class TestBuildHeadingTree(unittest.TestCase):
    def setUp(self):
        self.nodes, self.root_ids, self.images = build_heading_tree(
            sample_content_list(), "doc1", "manual.pdf", min_level=5)

    def test_chart_registered_as_image_with_caption(self):
        """chart 类型(如 Fig.X 统计图)与 image 同样登记, 走多模态识别."""
        cl = [{"type": "chart", "img_path": "images/c1.jpg",
               "chart_caption": ["Fig. 1. Annual flow duration curves"], "page_idx": 1},
              {"type": "text", "text": "正文", "page_idx": 1}]
        nodes, _, images = build_heading_tree(cl, "d1", "a.pdf")
        self.assertEqual(len(images), 1)
        im = next(iter(images.values()))
        self.assertEqual(im["caption"], "Fig. 1. Annual flow duration curves")
        self.assertEqual(im["rel_path"], "data/d1/images/c1.jpg")
        self.assertIn(im["img_key"], nodes["h0"].image_keys)

    def test_list_items_become_body(self):
        """list 类型(参考文献等)按行拼进正文."""
        cl = [{"type": "list", "list_items": ["Bosch, J.M., 1979.", "Hewlett, J.D., 1982."],
               "page_idx": 2}]
        nodes, _, _ = build_heading_tree(cl, "d1", "a.pdf")
        body = "\n".join(nodes["h0"].body_parts)
        self.assertIn("Bosch, J.M., 1979.", body)
        self.assertIn("Hewlett, J.D., 1982.", body)

    def test_page_furniture_types_skipped(self):
        """header/footer/page_number/page_footnote 是页眉页脚噪声, 不进正文."""
        cl = [{"type": "header", "text": "www.elsevier.com", "page_idx": 0},
              {"type": "footer", "text": "J. Hydrol.", "page_idx": 0},
              {"type": "page_number", "text": "254", "page_idx": 0},
              {"type": "page_footnote", "text": "Corresponding author.", "page_idx": 0},
              {"type": "text", "text": "真实正文", "page_idx": 0}]
        nodes, _, _ = build_heading_tree(cl, "d1", "a.pdf")
        self.assertEqual("\n".join(nodes["h0"].body_parts), "真实正文")

    def _find(self, title):
        hits = [n for n in self.nodes.values() if n.title == title]
        self.assertEqual(len(hits), 1, f"节点 {title} 应唯一")
        return hits[0]

    def test_root_h0_holds_preamble(self):
        root = self.nodes["h0"]
        self.assertEqual(root.level, 0)
        self.assertIn("前言内容第一段", root.own_text())

    def test_hierarchy_parents_and_children(self):
        ch1 = self._find("第一章 概述")
        s11 = self._find("1.1 背景")
        s111 = self._find("1.1.1 深入分析")
        self.assertEqual(ch1.parent_id, "h0")
        self.assertEqual(s11.parent_id, ch1.id)
        self.assertEqual(s111.parent_id, s11.id)
        self.assertIn(s11.id, ch1.child_ids)
        self.assertIn(s111.id, s11.child_ids)
        self.assertEqual(self.root_ids, [ch1.id])

    def test_own_text_attribution(self):
        s11 = self._find("1.1 背景")
        s111 = self._find("1.1.1 深入分析")
        self.assertIn("背景内容甲", s11.own_text())
        self.assertIn("背景内容乙", s11.own_text())
        self.assertNotIn("背景内容", s11.own_text().replace("背景内容甲", "").replace("背景内容乙", ""))
        # 子节点内容不进父节点正文
        self.assertNotIn("深层小节正文", s11.own_text())
        self.assertIn("深层小节正文", s111.own_text())
        # 六级标题按正文
        self.assertIn("六级标题当正文处理", s111.own_text())
        # 表格文本进正文
        self.assertIn("项目", s111.own_text())
        self.assertIn("数值", s111.own_text())

    def test_image_registered_on_node(self):
        s11 = self._find("1.1 背景")
        self.assertEqual(len(s11.image_keys), 1)
        entry = self.images[s11.image_keys[0]]
        self.assertEqual(entry["img_path"], "images/fig1.jpg")
        self.assertEqual(entry["caption"], "图1 背景示意")
        self.assertEqual(entry["page_idx"], 1)

    def test_path_ids_and_text(self):
        s111 = self._find("1.1.1 深入分析")
        self.assertEqual(s111.path_ids(self.nodes), ["h0", self._find("第一章 概述").id, self._find("1.1 背景").id, s111.id])
        self.assertEqual(s111.path_text(self.nodes)[1:], ["第一章 概述", "1.1 背景", "1.1.1 深入分析"])

    def test_no_heading_document_falls_back_to_root(self):
        cl = [{"type": "text", "text": "全文无标题。", "page_idx": 0}]
        nodes, root_ids, images = build_heading_tree(cl, "doc1", "x.pdf", 5)
        self.assertEqual(root_ids, [])
        self.assertIn("全文无标题。", nodes["h0"].own_text())


class TestChunker(unittest.TestCase):
    def setUp(self):
        self.s = make_settings()
        self.doc_id = "doc1"
        self.nodes, self.root_ids, self.images = build_heading_tree(
            sample_content_list(), self.doc_id, "manual.pdf", min_level=5)
        # 模拟已完成的多模态识别结果
        for k, e in self.images.items():
            e["analysis"] = "这是一张背景示意图。"
            e["status"] = "ok"
            e["rel_path"] = f"data/{self.doc_id}/{e['img_path']}"
        self.chunker = Chunker(self.s)

    def test_chunk_object_shape(self):
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", self.nodes, self.root_ids, self.images)
        for key in ("doc_id", "version", "chunks", "chunk_size_bytes", "chunk_overlap_bytes"):
            self.assertIn(key, obj)
        self.assertEqual(obj["chunk_size_bytes"], 512)

    def test_heading_and_text_chunk_types(self):
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", self.nodes, self.root_ids, self.images)
        types = {c["type"] for c in obj["chunks"]}
        self.assertIn("heading", types)
        self.assertIn("text", types)

    def test_text_chunks_within_byte_limit(self):
        cl = sample_content_list()
        cl.append({"type": "text", "text": "超长正文。" * 400, "page_idx": 3})  # 挂在最后一个节点
        nodes, root_ids, images = build_heading_tree(cl, self.doc_id, "manual.pdf", 5)
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", nodes, root_ids, images)
        text_chunks = [c for c in obj["chunks"] if c["type"] == "text"]
        self.assertGreater(len(text_chunks), 2)
        for c in text_chunks:
            self.assertLessEqual(len(c["text"].encode("utf-8")), 512, msg=c["text"][:30])

    def test_chunk_keeps_heading_path_ids(self):
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", self.nodes, self.root_ids, self.images)
        s111_id = [n.id for n in self.nodes.values() if n.title == "1.1.1 深入分析"][0]
        deep = [c for c in obj["chunks"] if c["heading_id"] == s111_id]
        self.assertTrue(deep)
        for c in deep:
            self.assertEqual(c["heading_path_ids"][-1], s111_id)
            self.assertEqual(c["heading_path_ids"][0], "h0")
            self.assertIn("1.1.1 深入分析", c["heading_path_text"])
            self.assertEqual(c["doc_id"], self.doc_id)

    def test_headings_json_resolves_every_path_id(self):
        """chunks.heading_path_ids 的每个 id(含虚拟根 h0)都必须能在 headings.json 回溯."""
        obj = headings_to_json(self.doc_id, "manual.pdf", self.nodes)
        ids = {n["id"] for n in obj["nodes"]}
        self.assertIn("h0", ids, "虚拟根 h0 未写入 nodes, 路径回溯会断")
        chunks = self.chunker.chunk(self.doc_id, "manual.pdf",
                                    self.nodes, self.root_ids, self.images)["chunks"]
        for c in chunks:
            for pid in c["heading_path_ids"]:
                self.assertIn(pid, ids, f"路径 id {pid} 无法在 headings.json 回溯")

    def test_images_attached_with_analysis(self):
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", self.nodes, self.root_ids, self.images)
        with_img = [c for c in obj["chunks"] if c["images"]]
        self.assertTrue(with_img)
        img = with_img[0]["images"][0]
        for key in ("img_path", "rel_path", "caption", "analysis", "page_idx", "status"):
            self.assertIn(key, img)
        self.assertEqual(img["analysis"], "这是一张背景示意图。")
        self.assertTrue(img["rel_path"].startswith(f"data/{self.doc_id}/"))

    def test_page_metadata(self):
        obj = self.chunker.chunk(self.doc_id, "manual.pdf", self.nodes, self.root_ids, self.images)
        for c in obj["chunks"]:
            self.assertIsInstance(c["page_start"], int)
            self.assertLessEqual(c["page_start"], c["page_end"])


if __name__ == "__main__":
    unittest.main()
