# -*- coding: utf-8 -*-
"""docqa.config Settings 校验测试."""
import unittest

from tests.helpers import make_settings


class TestSettings(unittest.TestCase):
    def test_validate_rejects_bad_overlap(self):
        s = make_settings(chunk_overlap_bytes=600)
        with self.assertRaises(ValueError):
            s.validate()

    def test_validate_rejects_wrong_redis_db(self):
        s = make_settings(redis_db=5)
        with self.assertRaises(ValueError):
            s.validate()

    def test_validate_ok(self):
        make_settings().validate()


if __name__ == "__main__":
    unittest.main()
