# -*- coding: utf-8 -*-
"""Kafka 手动操作演示脚本(触网, 不属于 unittest 自动套件).

注意: 文件名刻意不以 test 开头 — unittest discover 只收集 test*.py,
触网脚本混进自动套件会让 broker 不可用时整个套件连带失败.

用法(项目根):
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/kafka_demo.py status
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/kafka_demo.py send [--count 3]
    PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe tests/kafka_demo.py recv [--from-beginning] [--wait 8] [--group G]

操作说明(全部输出到控制台):
    status  连接诊断: TCP → AdminClient 元数据(列出 topic) → 目标 topic 分区与水位(end_offsets)
    send    向事件 topic 发送 N 条演示事件(与生产同 schema, key=doc_id 保证同文档有序)
    recv    订阅 topic 并实时打印事件(等价 python -m docqa consume, --wait 秒后自动退出)
"""
from __future__ import annotations

import argparse
import json
import socket
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # 项目根, 供 import docqa

from docqa.config import Settings                              # noqa: E402
from docqa.console import cprint                               # noqa: E402
from docqa.events import ConsoleEventPrinter                   # noqa: E402

SHORT_TIMEOUT_MS = 8000   # broker 半死时快速失败, 不让脚本干等 30s


def _tcp_probe(bootstrap: str) -> bool:
    host, _, port = bootstrap.partition(":")
    try:
        sock = socket.socket()
        sock.settimeout(3)
        sock.connect((host, int(port or 9092)))
        sock.close()
        cprint("TCP", f"{bootstrap} 可连接", "green")
        return True
    except Exception as e:
        cprint("TCP", f"{bootstrap} 连接失败: {e}", "red")
        return False


def op_status(s: Settings) -> int:
    """诊断: TCP / 元数据 / topic 分区与水位."""
    ok = _tcp_probe(s.kafka_bootstrap)
    try:
        from kafka import KafkaAdminClient
        admin = KafkaAdminClient(bootstrap_servers=s.kafka_bootstrap, client_id="kafka-demo",
                                 request_timeout_ms=SHORT_TIMEOUT_MS)
        topics = sorted(admin.list_topics())
        admin.close()
        cprint("元数据", f"AdminClient OK, topics({len(topics)}): {topics[:10]}", "green")
        ok = True
    except Exception as e:
        cprint("元数据", f"AdminClient 失败: {str(e)[:100]}", "red")
        cprint("提示", "TCP 通但元数据超时 = broker 进程半死/假活, 需到服务器上重启 Kafka", "yellow")
        return 2

    from kafka import KafkaConsumer, TopicPartition
    consumer = KafkaConsumer(bootstrap_servers=s.kafka_bootstrap,
                             request_timeout_ms=SHORT_TIMEOUT_MS)
    try:
        tps = [TopicPartition(s.kafka_topic, p)
               for p in consumer.partitions_for_topic(s.kafka_topic) or ()]
        if not tps:
            cprint("topic", f"{s.kafka_topic} 不存在(partitions_for_topic 为空)", "yellow")
            return 2
        offsets = consumer.end_offsets(tps)
        for tp in sorted(offsets):
            cprint("水位", f"{tp.topic}[{tp.partition}] 下一条偏移 = {offsets[tp]}"
                         f"(即已有 {offsets[tp]} 条事件)", "cyan")
    finally:
        consumer.close()
    return 0 if ok else 2


def op_send(s: Settings, count: int) -> int:
    """发送 N 条演示事件(与 docqa 生产事件同 schema)."""
    from docqa.events import KafkaEventBus
    try:
        bus = KafkaEventBus(s.kafka_bootstrap, s.kafka_topic, client_id="kafka-demo")
    except Exception as e:
        cprint("错误", f"生产者初始化失败: {e}", "red")
        return 2
    doc_id = f"demo-{uuid.uuid4().hex[:8]}"
    try:
        for i in range(1, count + 1):
            ev = bus.emit(doc_id=doc_id, file_name="kafka_demo.pdf", stage="parse",
                          state="PARSING",
                          progress={"extracted_pages": i, "total_pages": count},
                          detail=f"演示事件 {i}/{count}")
            print(ConsoleEventPrinter.format_line(ev), flush=True)
        ev = bus.emit(doc_id=doc_id, file_name="kafka_demo.pdf", stage="parse",
                      state="DONE", detail="演示完毕")
        print(ConsoleEventPrinter.format_line(ev), flush=True)
        cprint("发送", f"完成: {count + 1} 条事件, doc_id={doc_id}(此 id 可在 recv 中观察顺序)", "green")
        return 0
    except Exception as e:
        cprint("错误", f"发送失败(broker 不可达?): {str(e)[:120]}", "red")
        return 2
    finally:
        bus.flush_and_close()


def op_recv(s: Settings, from_beginning: bool, wait: float, group: str) -> int:
    """订阅并打印 wait 秒(随机组/命名组, 从头回放用随机组避免提交偏移)."""
    from kafka import KafkaConsumer
    gid = group or (None if from_beginning else "kafka-demo")
    consumer = None
    try:
        consumer = KafkaConsumer(
            s.kafka_topic, bootstrap_servers=s.kafka_bootstrap,
            group_id=gid or f"demo-{uuid.uuid4().hex[:6]}",
            auto_offset_reset="earliest" if from_beginning else "latest",
            enable_auto_commit=True, consumer_timeout_ms=1000,
            request_timeout_ms=SHORT_TIMEOUT_MS,      # 必须 > session_timeout
            session_timeout_ms=6000)
        cprint("消费", f"订阅 {s.kafka_topic} @ {s.kafka_bootstrap} "
                      f"(group={gid or '随机(只看新事件)'}, 监听 {wait}s)", "cyan")
        got = 0
        t0, assigned = time.time(), False
        while time.time() - t0 < wait:
            polled = consumer.poll(timeout_ms=500)
            if not assigned:
                if consumer.assignment():
                    assigned = True
                    cprint("消费", f"分区分配完成: {consumer.assignment()}", "green")
                elif time.time() - t0 > 8:
                    cprint("提示", "8s 未获得分区分配(broker 半死特征), 继续等到超时…", "yellow")
                    assigned = True   # 只提示一次
            for _tp, records in polled.items():
                for rec in records:
                    try:
                        print(ConsoleEventPrinter.format_line(json.loads(rec.value.decode("utf-8"))),
                              flush=True)
                        got += 1
                    except Exception:
                        print(f"[无法解析] {rec.value[:80]!r}", flush=True)
        cprint("消费", f"结束: 共打印 {got} 条事件", "green" if got else "yellow")
        return 0
    except Exception as e:
        cprint("错误", f"消费者失败: {str(e)[:120]}", "red")
        return 2
    finally:
        if consumer is not None:
            try:
                consumer.close()
            except Exception:
                pass


def main() -> int:
    p = argparse.ArgumentParser(prog="kafka_demo.py", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("op", choices=["status", "send", "recv"], help="status=诊断 / send=发事件 / recv=收事件")
    p.add_argument("--bootstrap", default="", help="覆盖 .env 的 KAFKA_BOOTSTRAP")
    p.add_argument("--count", type=int, default=3, help="send: 发送条数(默认3)")
    p.add_argument("--from-beginning", action="store_true", help="recv: 从头回放(随机组)")
    p.add_argument("--wait", type=float, default=8, help="recv: 监听秒数(默认8)")
    p.add_argument("--group", default="", help="recv: 指定消费组(默认 kafka-demo)")
    args = p.parse_args()

    s = Settings.load()
    if args.bootstrap:
        import dataclasses
        s = dataclasses.replace(s, kafka_bootstrap=args.bootstrap)
    print(f"目标: {s.kafka_bootstrap} / topic {s.kafka_topic}\n")
    if args.op == "status":
        return op_status(s)
    if args.op == "send":
        return op_send(s, max(1, args.count))
    return op_recv(s, args.from_beginning, args.wait, args.group)


if __name__ == "__main__":
    raise SystemExit(main())
