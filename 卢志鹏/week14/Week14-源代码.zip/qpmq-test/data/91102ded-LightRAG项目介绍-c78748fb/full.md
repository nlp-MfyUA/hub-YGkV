![](images/59de258611d15047f52c83d3a5cb40f48332f9ea828e15301f8f29b24a86979d.jpg)  
Figure 1: Overall architecture of the proposed LightRAG framework.

![](images/796e387d1887ed195f4fd3e9d9fec07536a0689056c13c0a830d0d6eb4af49d6.jpg)

## � 新闻

[2026.07]�[新功能]: 添加 Word 文档 智能章节标题 识别功能。

[2026.05]�[新功能]：将 RagAnything 合并至 LightRAG�。支持通过 MinerU / Docling 服务进行多模态内容解析与提取。

[2026.05]�[新功能]：引入四种可选的文本分块策略： Fix （固定）、 Recursive （递归）、 Vector （向量）和 Paragraph （段落语义）。

[2026.05]�[新功能]：支持按角色配置 LLM，提供四个独立角色：EXTRACT、QUERY、KEYWORDS 和 VLM，每个角色拥有独立的 LLM 设置。

[2026.03]�[新功能]: 集成了 OpenSearch 作为统一存储后端，为 LightRAG 的全部四种存储类型提供全面支持。

[2026.03]�[新功能]: 推出交互式安装向导，支持通过 Docker 在本地部署 Embedding、Reranking 及存储后端服务。

[2025.11]�[新功能]: 集成了 RAGAS 评估和 Langfuse 追踪。更新了 API 以在查询结果中返回召回上下文，支持上下文精度指标。

[2025.10]�[可扩展性增强]: 消除了处理瓶颈，以高效支持大规模数据集。

[2025.09]�[新功能]: 显著提升了 Qwen3-30B-A3B 等开源 LLM 的知识图谱提取准确性。

[2025.08]�[新功能]: 现已支持 Reranker，显著提升混合查询性能（已设为默认查询模式）。

[2025.08]�[新功能]: 添加了文档删除功能，并支持自动重新生成知识图谱，以确保最佳查询性能。

[2025.06]�[新发布]: 我们的团队发布了 RAG-Anything —— 一个用于无缝处理文本、图像、表格和方程式的全功能多模态 RAG 系统。

[2025.06]�[新功能]: LightRAG 现已集成 RAG-Anything，支持全面的多模态数据处理，实现对 PDF、图像、Office 文档、表格和公式等多种格式的无缝文档解析和 RAG 能力。详见多模态文档处理部分。

[2025.03]�[新功能]: LightRAG 现已支持引用功能，实现了准确的源归因和增强的文档可追溯性。

[2025.02]�[新功能]: 现在您可以使用 MongoDB 作为一体化存储解决方案，实现统一的数据管理。

[2025.02]�[新发布]: 我们的团队发布了 VideoRAG —— 一个用于理解超长上下文视频的 RAG 系统。

[2025.01]�[新发布]: 我们的团队发布了 MiniRAG，使用小型模型简化 RAG。

[2025.01]�现在您可以使用 PostgreSQL 作为一体化存储解决方案进行数据管理。

[2024.11]�[新资源]: LightRAG 的综合指南现已在 LearnOpenCV 上发布 —— 探索深入的教程和最佳实践。非常感谢博客作者的杰出贡献！

[2024.11]�[新功能]: 推出 LightRAG WebUI —— 一个允许您通过直观的 Web 界面插入、查询和可视化 LightRAG知识的仪表板。

[2024.11]�[新功能]: 现在您可以使用 Neo4J 进行存储 —— 开启图数据库支持。

[2024.10]�[新功能]: 我们添加了 LightRAG 介绍视频 的链接 —— 演示 LightRAG 的各项功能。感谢作者的杰出贡献！

[2024.10]�[新频道]: 我们创建了一个 Discord 频道！� 欢迎加入我们的社区进行分享、讨论和协作！ ��

## 算法流程图

![](images/40051daece040bda34e72f03a62e0880537bcfa1c043b080711b0bfd27b05fb5.jpg)

1 LightRAG - Source  
![](images/0a84ec869d13404c0e757cb1a83a54b386771584d4525afa3df426c8c786b7b9.jpg)  
2 LightRAG - Source

## 安装

使用 uv 进行包管理: 本项目使用 uv 进行快速可靠的 Python 包管理。首先安装 uv: curl -LsSfhtt<sub>p</sub>s: astral.sh/uv/install.sh | sh (Unix/macOS) 或 <sub>p</sub>owershell -c "irmhttps: astral.sh/uv/install.ps1 | iex" (Windows)

注意：如果您愿意，也可以使用 pip，但为了获得更好的性能和更可靠的依赖管理，建议使用 uv。

� 离线部署: 对于离线或隔离环境，请参阅离线部署指南，了解预安装所有依赖项和缓存文件的说明。[!WARNING] 在共享网络上启动服务前，请先做好访问保护。 lightrag-server 默认监听所有网卡（ HOST=0.0.0.0 ），且默认不开启认证。在云服务器上，这意味着所有接口都对公网开放，任何人都能调用并消耗你的 LLM 额度。首次启动前，请二选一：在 .env 中绑定到私有地址（ HOST=127.0.0.1 ，或 VPN / 隧道地址）；或者配置认证： LIGHTRAG\_API\_KEY ，或 AUTH\_ACCOUNTS 加 TOKEN\_SECRET （可用 openssl rand -hex 32 生成）。为兼容客户端，Ollama 兼容的 /api/ 路由默认不需要认证；设置WHITELIST\_PATHS=/health 可让它们也要求认证。以下所有安装方式均适用。

## 从 PyPI 安装

PyPI 包已内置构建好的 WebUI，无需构建前端。

# 使用 uv 将 LightRAG 服务器安装为工具 （推荐）  
uv tool <sup>i</sup>nstall "l<sup>i</sup>ghtrag-hku[ap<sup>i</sup>]"  
# 或在虚拟环境中使用 pip  
# pyt<sup>h</sup>on -m venv .venv  
# source .venv/bin/activate # Windows: .venv\Scripts\activate  
# pip install "lightrag-hku[api]"  
# 获取配置模板并编辑 （参见下文"最少需要修改的 .env 配置"）  
curl -O https: raw.githubusercontent.com/HKUDS/LightRAG/main/env.example  
cp env.example .env

## 从源码安装

## 前置要求

<table><tr><td rowspan=1 colspan=1>工具</td><td rowspan=1 colspan=1>用途</td><td rowspan=1 colspan=1>安装方式</td></tr><tr><td rowspan=1 colspan=1>git</td><td rowspan=1 colspan=1>克隆仓库</td><td rowspan=1 colspan=1>系统包管理器</td></tr><tr><td rowspan=1 colspan=1>uv</td><td rowspan=1 colspan=1>创建虚拟环境、安装Python 依赖；系统没有合适的 Python(3.11+)时会自动下载</td><td rowspan=1 colspan=1>见上方 uv 说明</td></tr><tr><td rowspan=1 colspan=1>bun</td><td rowspan=1 colspan=1>构建 WebUI</td><td rowspan=1 colspan=1>curl -fsSL https://bun.sh/install \| bash (Windows:powershell -c &quot;irm bun.sh/install.ps1 \| iex&quot;)。Linux 安装脚本依赖 unzip，精简版 Debian / Ubuntu 镜像需先执行 sudo apt-getinstall -y unzip</td></tr><tr><td rowspan=1 colspan=1>make</td><td rowspan=1 colspan=1>可选：make dev 快捷命令和 make env-*设置向导</td><td rowspan=1 colspan=1>系统包管理器</td></tr></table>

## 第 1 步：克隆仓库

```html
g<sup>i</sup>t clone https: g<sup>i</sup>thub.com/HKUDS/L<sup>i</sup>ghtRAG.g<sup>i</sup>t
cd L<sup>i</sup>ghtRAG
```

第 2 步：安装 Python 依赖。 以下两种方式二选一：

# 方式 A ： 只运行服务器 （API + WebUI） <sub>，</sub> 安装量最小  
uv sync - extra ap<sup>i</sup>

```markdown
# 方式 B： 参与开发 安装测试工具链以及全部存储后端和 LLM 提供商集成
uv sync -extra test -extra o<sup>ff</sup>l<sup>i</sup>ne
```

uv s<sub>y</sub>nc 会在 .venv/ 中创建虚拟环境，用 source .venv/bin/activate 激活

（Windows： .venv\Scripts\activate ）。使用 pip 而非 uv 时： python -m venv .venv ，激活后执行 pipinstall -e ".[api]" （或 pip install -e ".[test,offline]" ）。

## 第 3 步：构建 WebUI

```shell
cd l<sup>i</sup>ghtrag_webu<sup>i</sup>
bun install -frozen-lockfile
bun run build
cd .
```

make dev 一条命令即可完成第 2 步方式 B 和第 3 步。如果已经运行过它，直接进入第 4 步。

第 4 步：创建 .env 。 可以运行交互式向导 make env-base （参见使用设置向导创建 .env 文件），也可以复制模板后手动编辑（参见最少需要修改的 .env 配置）：

```batch
cp env.example .env
```

## 第 5 步：启动服务器

```html
l<sup>i</sup>ghtrag-server
```

浏览器打开 http: localhost:9621/webui 进入 WebUI；交互式 REST API 文档位于htt<sub>p</sub>: localhost:9621/docs 。如果修改过 HOST / PORT ，请替换成对应的地址和端口。

## 使用 Docker Compose 启动

g<sup>i</sup>t clone https: g<sup>i</sup>thub.com/HKUDS/L<sup>i</sup>ghtRAG.g<sup>i</sup>t  
cd L<sup>i</sup>ghtRAG  
cp env.example .env # 先编辑它： 参见下文"最少需要修改的 .env 配置"  
docker compose up

在此获取LightRAG docker镜像历史版本: LightRAG Docker Images

由 GitHub Actions 发布到 GHCR 的官方镜像已使用 GitHub OIDC 和 Sigstore Cosign 进行签名。校验方式请参阅docs/DockerDeployment.md。

在 Apple Silicon（macOS 26）上，无需 Docker Desktop 即可在 Apple 原生的 container 运行时上运行相同的Postgres/Neo4j/Milvus 存储栈 —— 参见 docs/AppleContainerSetup.md。

## 最少需要修改的 .env 配置

env.example 开箱即用：默认使用本地文件存储、不启用重排序、使用内置文档解析器，无需安装数据库或其他服务，只需要关注模型配置。使用默认的 OpenAI 模型时：

<table><tr><td rowspan=1 colspan=1>变量</td><td rowspan=1 colspan=1>操作</td></tr><tr><td rowspan=1 colspan=1>LLM_BINDING_API_KEY</td><td rowspan=1 colspan=1>必改。填入你的 OpenAI API key</td></tr><tr><td rowspan=1 colspan=1>EMBEDDING_BINDING_API_KEY</td><td rowspan=1 colspan=1>必改。填入你的 OpenAI API key(可以与上面相同）</td></tr><tr><td rowspan=1 colspan=1>OPENAI_LLM_REASONING_EFFORT</td><td rowspan=1 colspan=1>推荐。取消注释并保持low。默认模型gpt-6-luna 是推理模型，API默认推理强度为medium，会让实体抽取(每个文本块调用一次LLM)明显变慢、变贵</td></tr></table>

使用其他服务商时，还需设置 LLM\_BINDING\_HOST 和 LLM\_MODEL （任何 OpenAI 兼容接口都保持LLM\_BINDING=openai ），以及 EMBEDDING\_BINDING\_HOST 、 EMBEDDING\_MODEL 和 EMBEDDING\_DIM 。EMBEDDING\_DIM 必须与嵌入模型的实际输出维度一致。模型选择请参见关键配置说明。

请在首次上传文档前确定嵌入模型。 之后再更换需要重新索引所有文档（参见 Embedding 模型）。

下一步： 服务跑起来之后，可以按 探索 LightRAG 逐步打开其余能力，每一步都附实测结果：PostgreSQL 存储、账号认证、角色 LLM、Rerank、图片分析、Word 智能标题、MinerU 和并发调优。

## 使用设置向导创建 .env 文件

除了手动编辑 env.example 之外，您还可以使用交互式向导生成配置好的 .env ，并在需要时生成 docker-compose.final.yml ：

make env-base # 必跑第一步： 配置 LLM Embedding Reranker  
make env-storage # 可选： 配置存储后端和数据库服务  
make env-server # 可选： 配置服务端口 鉴权和 SSL  
make env-base-rewrite # 可选： 强制重建向导托管的 compose 服务块  
make env-storage-rewrite # 可选： 强制重建向导托管的 compose 服务块  
make env-security-check # 可选： 审计当前 .env 中的安全风险

设置向导工具的详细说明请参阅 docs/InteractiveSetup.md。

## 可选：docx smart\_heading 的 spaCy 模型

Native docx 解析器的可选引擎参数 smart\_heading 使用 spaCy 做分句/NER 启发式判断。spaCy 运行时已包含在api extra 中——只有两个钉定版本的语言模型（ zh\_core\_web\_sm / en\_core\_web\_sm 3.8.0，GitHub releasewheel，未发布到 PyPI）需要额外一步安装：

```html
l<sup>i</sup>ghtrag-download-cache - spacy-<sup>i</sup>nstall
```

在 uv sync 创建的环境中（其中没有 pip），该命令会改用 uv pip install 安装。这些模型不在 uv.lock中，普通的 uv s<sub>y</sub>nc 会把它们删掉；安装后请改用 uv s<sub>y</sub>nc -inexact 以保留它们。

可以按文件/规则启用 smart\_heading（如 LIGHTRAG\_PARSER=docx:native(smart\_heading=true) ），也可以在.env 中全局启用：

```gitattributes
# 路由到 native 引擎的 .docx 文件默认启用 smart_heading<sub>；</sub>
# 单个文件/规则可用显式 native(smart_heading=false) 关闭
DOCX_SMART_HEADING=true
```

全局开关开启（或 LIGHTRAG\_PARSER 规则携带 native(smart\_heading=true) ）时，服务器会在启动阶段校验模型并在缺失时立即报错（附安装指引）。从不启用 smart\_heading 的部署无需安装模型。Docker 主镜像已内置模型（lite 镜像不含）；离线环境请参阅离线部署指南。

## 可选：SVG 栅格化所需的 libcairo（native md/textpack）

Native markdown/textpack 解析器会通过 cairosv<sub>g</sub> 把内嵌的 SVG 图片栅格化为 PNG。 cairosv<sub>g</sub> 是对 cairo 的 cffi绑定： pip install cairosvg （随 api extra 一起安装）总能成功，但只有宿主机同时装了原生的 libcairo 共享库，栅格化才真正能跑—— pip / uv 装不了系统库。缺失时栅格化会在运行时失败，对应的 SVG 会被跳过（不影响文档其余内容）；服务器会在启动时探测这一能力，缺失时以醒目的黄色警告提示，避免这个缺口一直藏到某篇文档处理时才被发现。

按平台安装对应的系统包：

```shell
# Debian / Ubuntu （官方 Docker 镜像已内置）
sudo apt-get <sup>i</sup>nstall -y l<sup>i</sup>bca<sup>i</sup>ro2
# RHEL / Fedora
sudo dn<sup>f</sup> <sup>i</sup>nstall -y ca<sup>i</sup>ro
# macOS （Homebrew）
brew install cairo
# Windows ： 安装内含 libcairo-2.dll 的 GTK3 运行时
```

从不处理带内嵌 SVG 的 markdown/textpack 文档的部署，可以忽略这条启动警告。

## 关于LightRAG

## 基于图的轻量级RAG框架

LightRAG 是一个轻量级的知识图谱 RAG 框架，被视为 Microsoft GraphRAG 的高效替代方案。它采用双层架构来同时管理知识图谱（KG）和向量嵌入，完美填补了传统基于向量的 RAG 与基于图谱的 RAG 之间的技术鸿沟。LightRAG专为高扩展性而设计，有效地解决了大规模图谱索引和查询时计算开销大、响应缓慢以及增量更新成本高等问题；LightRAG在支持大规模数据集的同时，即使搭载 30B开源大语言模型（LLM），也能保持极高的RAG质量。

## 特点与优势

1. 深度上下文理解：通过图结构索引，LightRAG 能够捕捉实体间复杂的语义依赖关系，克服了传统分块检索方法上下文割裂的缺陷。在需要全局理解或逻辑推理的垂直领域（如法律、金融），其生成质量与上下文感知能力尤为突出。

2. 卓越的全面性与多样性：LightRAG的双层检索机制使其能够同时整合详细事实与抽象概念，让其在查询结果全面性（Comprehensiveness）和多样性（Diversity）取得卓越的成绩，有效应对复杂的跨文档查询。

3. 极高的检索效率与低成本：LightRAG不需要依赖低效的社区报告和复杂查询时的多跳推理，大幅度减少了索引和查询阶段对LLM的调用，显著减少了响应延迟与LLM计算成本。

4. 支持增量更新与局部删除：LightRAG 解决了基于图的知识库难以增量更新和局部删除的问题，保证系统在动态数据环境下的时效性。删除文档时，系统可以利用构建阶段的 LLM 缓存快速重建受影响的实体与关系，大幅提升知识库的更新效率。

5. 支持多种文档解析引擎：LightRAG 的文件处理管线支持 MinerU、Docling 和 Native 等文档解析引擎，也支持第三方扩展解析引擎。LightRAG 专属的 Native 引擎可高效解析 Word 和 Markdown 文档中的图片、表格和公式，尤其适合处理多模态内容丰富的文档。Native 引擎还支持自动识别和纠正 Word 文档的章节标题，即使文档大纲不规范，也能改善内容提取效果，为后续按章节进行文本分块打下基础。

6. 支持多种文本分块策略：LightRAG 支持 4 种文本分块策略，分别是 固定长度分块(F) 、 递归字符分块(R) 、 向量语义分块(V) 和 段落语义分块(P) 。其中， 段落语义分块(P) 是 LightRAG 专属的分块策略，可以让分块边界尽可能对齐文档原生的语义边界（标题、段落和表格），从而减少标题与内容错配、长表格切分后丢失标题行等问题。

7. 支持多种存储后端：LightRAG 默认的 KV、向量和图存储均采用基于本地文件持久化的内存数据库，仅适合小数据量的测试与效果评估，不适用于生产环境。LightRAG 还支持多种主流后端存储（推荐 PostgreSQL），可用于大规模数据集的生产部署。

## 多模态能力的升级

传统 RAG 系统缺乏有效处理文档中图片、公式和表格等多模态内容的能力。从 v1.5 版本开始，LightRAG 将多模态处理能力无缝集成到文件处理管线和查询流程中。LightRAG 通过知识图谱将这些多模态内容与正文有机联系起来，在回答用户查询时能够结合多模态信息，给出更准确、更可靠的答案。这一能力可大幅提升操作说明书、学术论文等多模态内容丰富文档的 RAG 质量。

## LightRAG API 服务器

LightRAG 服务器不仅提供给了一个供出选择体验LightRAG功能的Web UI，还提供了一个完整的 REST API 。有关LightRAG服务器的更多信息，请参阅LightRAG服务器。

![](images/a4ff225e075d671e4cbe7e2d8a0e02a62e208a69c6cebdc3a7aa25a949e43067.jpg)

## 关键配置说明

## LLM 模型的选择

LightRAG 的工作过程中需要使用到 4 种角色的 LLM/VLM。应该为不同角色的 LLM 配置不同能力和速度的模型，以获得速度和能力之间的平衡。LightRAG 对大型语言模型（LLM）的能力要求会高于传统 RAG，因为它需要 LLM 执行文档中的实体关系抽取任务。在查询阶段，LLM 模型需要处理 LightRAG 召回的实体、关系和文本块等大量信息，需要模型具备在含有噪声的长上下文中作出高质量回答的能力。

## 按角色推荐的模型：

抽取 LLM（ EXTRACT ）：实体关系抽取会对每个文本块调用，选择主流的高速模型即可，并强烈推荐使用非思考模型（关闭 reasoning/thinking 模式），以免抽取变慢、变贵。国外可选 GPT-6 Luna、Claude Haiku、Gemini-mini；国内可选 DeepSeek-V4-lite、Kimi。本地部署最低可考虑 Qwen3-30B-A3B-Instruct。 如果使用 OpenAI 默认的 gpt-6-luna （推理模型），请设置 OPENAI\_LLM\_REASONING\_EFFORT=low ，让抽取保持快速、低成本（参见最少需要修改的 .env 配置）。

查询 LLM（ <sub>Q</sub>UERY ）：负责在长且嘈杂的召回内容上生成最终答案，应选择比抽取模型更强的模型，尽量提高回答质量；此处使用带思考能力的模型没有问题。

关键词 LLM（ KEYWORD ）：轻量、对延迟敏感的环节，一定要选择非思考模型以降低查询延迟；选用与抽取模型相当的高速模型即可。

VLM（ VLM ）：主流的多模态模型均可，需支持图片输入。本地部署可考虑 Qwen3.6-35B-A3B。

在可接受的时间和价格范围内，优先选择评分（各类公开榜单/基准）越高的模型越好。详细的模型配置请参见RoleSpecificLLMConfiguration-zh.md

## 查询模式的选择

LightRAG 支持 4 种查询模式：

local：聚焦于局部上下文与具体实体的精准匹配。在知识图谱中检索对应的候选实体及其直接关联属性，适用于针对特定对象、具体概念或细节事实的问答，能够提供高度相关且细致的局部上下文支持。

global：侧重于宏观主题、跨文档推理与实体间的深层关系。检索覆盖广泛主题与概念的关系链，适用于需要跨多个上下文进行总结、趋势分析或理解复杂语义依赖关系的查询。

hybrid：融合 local 和 global 两种模式的检索结果。通过同时召回具体实体与全局关系上下文，进行综合推理与生成。

naive：基于文本块的传统 RAG 检索，不使用知识图谱，直接依赖向量相似性在原始文本块中进行检索。

mix：全功能模式，融合 local、global 和 naive 三种模式的检索结果，提供最为丰富和全面的检索结果。

LightRAG 的默认查询模式为 mix。使用 mix 模式通常可以获得最为理想的查询结果。mix 模式比 naive 耗时略长；其他查询模式在耗时上基本相当。

## Embedding 模型

在选择 Embedding 模型的时候需要注意其对多语言的支持能力。LightRAG 的检索质量对 Embedding 模型的依赖有限，因此建议尽量选择低维度和速度快的模型。 env.exam<sub>p</sub>le 的默认值 OpenAI text-embeddin<sub>g</sub>-3-lar<sub>g</sub>e （3072维）更注重多语言质量； text-embedding-3-small （1536 维，需设置 EMBEDDING\_DIM=1536 ）更便宜、更快。选择主流最新的 Embedding 模型即可；本地部署首选 BAAI/bge-m3 。建议尽量本地部署 Embedding 模型，以获得最好的性能。

重要提示：在文档索引前必须确定使用的 Embedding 模型，且在文档查询阶段必须沿用与索引阶段相同的模型。嵌入模型一旦选定通常就不能修改。如果修改的话，需要对所有文本块、实体和关系进行重新嵌入。LightRAG 目前没有提供重新嵌入的工具。有些存储（例如 PostgreSQL）在首次建立数据表的时候需要确定向量维度，因此更换Embedding 模型后需要删除向量相关库表，以便让 LightRAG 重建新的库表。

## 开启 Rerank 选项

查询阶段开启 Rerank 选项可以显著提高查询的质量。开启 Rerank 通常会引入 1～2 秒的延时。为了降低延时，建议尽量在本地部署 Rerank 模型。主流最新的 Reranker 皆可，本地部署推荐 BAAI/bge-reranker-v2-m3 。Rerank 的相关配置方式请参考 .env.example 文件。Rerank 模型与 Embedding 模型不同，可以在查询阶段随时更换。

## 文档处理流水线的配置

LightRAG 的默认流水线配置并不能让系统发挥最好的性能。文件内容解析的好坏会极大地影响文档的索引和查询效果。因此建议配置流水线开启 MinerU 文件解析引擎，并开启流水线的图片分析功能。建议添加的配置为：

LIGHTRAG\_PARSER=\*:native-iteP,\*:mineru-iteP,\*:legacy-R   
VLM\_PROCESS\_ENABLE=true   
VLM\_LLM\_MODEL=<your\_vlm\_model\_name>

由于云端的 MinerU 服务有使用量、文件大小和页数等限制，建议使用本地部署的 MinerU。文件处理流水线的具体配置方法请参考 FileProcessingPipeline-zh.md

## 文件处理并发优化

对于大规模的文档处理，需要提高文档处理的并发能力。几个涉及文件并发处理性能的关键环境变量包括：

MAX\_ASYNC\_LLM：设置 LLM 角色的基础并发数（ MAX\_ASYNC 仍作为兼容旧名保留）。文件处理时，它还限制单个文档内各文本块的实体/关系抽取 task 数；每个实体合并或关系合并阶段最多可运行其两倍数量的 task。

EXTRACT\_MAX\_ASYNC\_LLM：可选地覆盖 Extract 角色的实际 LLM 请求并发数，适用于抽取和合并时的摘要请求。未设置时继承 MAX\_ASYNC\_LLM ；它不会改变前述流水线 task 上限。

MAX\_PARALLEL\_INSERT：控制可并行处理的文件数量，而非单个文档内的 chunk 或图合并 task 上限。建议约为MAX<sub>\_</sub>ASYNC<sub>\_</sub>LLM 的 1/3。

MAX\_PARALLEL\_PARSE\_MINERU：控制 MinerU 文件解析的并发处理文件数。

MAX\_PARALLEL\_PARSE\_DOCLING：控制 Docling 文件解析的并发处理文件数。

EMBEDDING\_FUNC\_MAX\_ASYNC：控制嵌入模型的最大并发数。

EMBEDDING\_BATCH\_NUM：控制每个嵌入模型请求包含的待嵌入文本的数量（每批做多少个嵌入）；提高这个数量可以大幅度减少调用嵌入模型的次数，提高嵌入存储的落盘速度。

# 设置示例   
MAX\_ASYNC\_LLM=8   
MAX\_PARALLEL\_INSERT=3   
EMBEDDING\_FUNC\_MAX\_ASYNC=16   
EMBEDDING\_BATCH\_NUM=32

## 后台存储的选择

LightRAG 需要使用到 4 种后台存储类型，分别是：

KV\_STORAGE：用于保存 LLM 响应缓存、文本分块结果、实体关系提取结果等信息。

VECTOR\_STORAGE：用于保存文本块、实体和关系的向量信息。

GRAPH\_STORAGE：用于保存知识图谱。

DOC\_STATUS\_STORAGE：用于保存文件列表。

4 种默认存储全部都是内存数据库（ JsonKVStora<sub>g</sub>e 、 NanoVectorDBStora<sub>g</sub>e 、 NetworkXStora<sub>g</sub>e 、

JsonDocStatusStorage ）：全部数据常驻服务进程的内存中， WORKING\_DIR 下的本地文件仅用于持久化，因此容量受可用内存限制。默认存储仅适合小数据量的测试、效果评估与开发调试，不能用于生产环境部署。

生产环境推荐使用 PostgreSQL —— 它可以独自承担全部 4 种类型的后台存储；MongoDB 与 OpenSearch 是另外两个单一后端方案。也可以单独为向量存储或图存储选择专业化的数据库，例如使用 Milvus 或 Qdrant 作为向量存储，使用 Neo4j 或 Memgraph 作为图存储。

各存储类型的完整可选实现列表，请参考 支持的存储类型。

## 文档处理阶段其他重要配置

在文档插入阶段还有以下环境变量建议根据实际需要进行调整：

SUMMARY\_LANGUAGE：控制 LLM 输出实体关系名称和摘要时使用的语言，例如： Chinese , English 。

ENTITY\_EXTRACTION\_USE\_JSON：控制 LLM 输出实体关系的时候是否使用 JSON 格式。使用 JSON 格式通常可以获得更加稳定的效果，但是输出需要消耗更多的 Token，速度也会略微慢一些。

ENABLE\_CONTENT\_HEADINGS：控制查询阶段是否把文本块所属章节标题信息送给LLM（默认允许，为LLM提供更多的上下文信息）

FORCE\_LLM\_SUMMARY\_ON\_MERGE / MAX\_SOURCE\_IDS\_PER\_RELATION：控制每个 实体/关系 能够最多与多少个文本块保持关联

SOURCE\_IDS\_LIMIT\_METHOD：控制 实体/关系 关联文本块超过限制后是否继续更新实体关系的描述（默认不再更新，因为此时实体关系的描述已经足够丰富，继续更新的意义不大；放弃更新可以极大地提高知识库的构建速度）

DEFAULT\_MAX\_FILE\_PATHS：控制 实体/关系 关联的原始文件的最大数量，超过这个数量之后新的文件名不再写入到向量存储。

## 解决实体关系抽取阶段的 LLM 超时

实体关系抽取阶段的 LLM 超时通常源于以下三种原因之一。先判断原因，再采用对应的解决方案（参数可以组合使用）：

模型太慢。 速度低于约 50 tokens/秒的模型，可能无法在请求超时前完成包含大量实体关系的文本块的抽取。可以通过 \*\_LLM\_TIMEOUT 增大超时时间——既可以是全局的 LLM\_TIMEOUT ，也可以是抽取阶段专用的角色参数EXTRACT\_LLM\_TIMEOUT 。注意实际的执行超时是所配置值的两倍，因此 EXTRACT\_LLM\_TIMEOUT=300 对应最长600 秒。

文本块产生的实体关系太多。 例如参考文献文本块会让模型输出极其大量的记录，从而无法在限定时间内完成。可以通过 OPENAI\_LLM\_MAX\_TOKENS 或 OPENAI\_LLM\_MAX\_COMPLETION\_TOKENS 限制输出长度（具体参数名取决于LLM 供应商，详见 env.example ）。一个实用的估算规则是 max\_output\_tokens < LLM\_TIMEOUT × 每秒token数 （例如 9000 < 240s × 50 t<sub>p</sub>s ）。

模型存在缺陷，陷入输出死循环。 某些模型（尤其是本地部署的 Qwen 模型）在遇到特殊文本时偶尔会陷入无尽的输出死循环。如果是偶发情况，通常只需将该文档重新处理一次即可解决。

专门针对参考文献（P 分块策略）。 使用段落语义（ P ）分块策略（例如 LIGHTRAG\_PARSER=. -iteP ）时，设置 CHUNK\_P\_DROP\_REFERENCES=true 可在分块前自动删除匹配的参考文献块，从而避免参考文献产生大量低价值的实体关系（这是导致超时的常见原因）。也可以通过文件名提示 paper.[-P(drop\_rf=true)].pdf 对单个文件启用；相关的检测参数（ CHUNK\_P\_REFERENCES\_TAIL\_N 、 CHUNK\_P\_REFERENCES\_HEADINGS ）详见env.example 。

## 文档查询阶段其他重要配置

在文档查询阶段还有以下环境变量建议根据实际需要进行调整： - MAX\_ENTITY\_TOKENS /

MAX\_RELATION\_TOKENS / MAX\_TOTAL\_TOKENS：控制召回内容送给LLM上下文的Token长度。召回内容包含 实体 、 关系 和 文本块 三部分，实体和关系的长度可以单独控制长度，文本块的长度由总长度减去实体和关系的长度来控制。 - ENABLE\_CONTENT\_HEADINGS：控制是否把文本块所在的章节标题送给LLM；默认开启，可以为LLM提供更加丰富的上下文信息，提高回答质量。 - ENABLE\_LLM\_CACHE：是否允许缓存查询结果。默认开启，相同的查询问题、查询模式、LLM模型参数将返回相同的结果。 - USER\_PROMPT\_PREFIX / USER\_PROMPT\_PREFIX\_FILE：拼接在每个请求的 user\_prompt 前面的全局指令（对应回答提示词中的"Additional Instructions"部分），为运维方提供一个统一定制LLM输出的入口。拼接是逐字节的、不会自动插入分隔符，请自行在内容结尾加上 \n\n 。如果请求的 user\_prompt 为空，该前缀将单独成为送给 LLM 的指令；只有 API 字段 disable\_user\_prompt\_prefix 能禁用它，且请求无法读取或替换它。较长或多段落的内容请使用 USER\_PROMPT\_PREFIX\_FILE

（ PROMPT\_DIR/user\_prompt 目录下的 .md / .txt 文件名），因为 .env 中的值必须写在一行内。

## WebUI 入口与默认入口

服务器基于同一次前端构建挂载两个 WebUI 入口。 /webui 是后台管理界面：文档管理、知识图谱浏览，以及带完整查询参数面板的查询调试。 /workspace 是面向日常查询用户的纯问答入口：只有聊天界面（无文档管理、无知识图谱、无查询参数侧栏、无 API 文档入口），针对移动端优化，未登录的访客会先看到欢迎页。

LIGHTRAG\_DEFAULT\_UI：根路径 / 重定向到哪个入口—— webui （默认）或 workspace 。它只控制这一个行为：该重定向。无论取值如何，两个入口都保持挂载、各自的 URL 始终可访问；取其它值会导致启动失败。当部署的主要使用者是查询用户而非管理员时，可将其设为 works<sub>p</sub>ace 。

UI\_TEMPLATES\_DIR：指向一个可选的多语言定制包，用你自己的内容替换欢迎页、登录页文案、查询空白页、品牌 Logo 和版权行，无需重新构建 WebUI。参见 UserDefinedUI-zh.md。

ENABLE\_AI\_CONTENT\_NOTICE：在两个查询界面（ /works<sub>p</sub>ace 与 /webui 的检索面板）中为每条由 LLM 生成的回答标注"由AI生成"；不是模型写的文本——无检索结果时的固定回复、管理面板的调试输出——不会被标注。默认关闭；它只是界面元素，不会进入 API 响应，也不会写入聊天历史。

把最终用户引导到 /workspace 之前有两点需要了解。其一，那里的查询参数只继承、不可编辑：每次查询使用同一浏览器中 /webui 保存的设置（未保存时使用前端默认值），这是按浏览器的本地状态，不是服务端全局策略。其二，隐藏后台界面是使用体验上的划分，不是安全边界——服务端仍会对每个接口执行鉴权。查询入口的完整行为参见 LightRAG-API-Server-zh.md。

## 使用LightRAG SDK

⚠️ 如果您希望将LightRAG集成到您的项目中，建议您使用LightRAG Server提供的REST API。LightRAG SDK通常用于嵌入式应用，或供希望进行研究与评估的学者使用。

## 安装LightRAG SDK

## 从源代码安装

cd L<sup>i</sup>ghtRAG  
# 注意: uv sync 会自动在 .venv/ 目录创建虚拟环境  
uv sync  
source .venv/bin/activate # 激活虚拟环境 (Linux/macOS)  
# Windows 系统: .venv\Scripts\activate  
# 或: pip install -e .

## 从PyPI安装

```html
uv p<sup>i</sup>p <sup>i</sup>nstall l<sup>i</sup>ghtrag-hku
# 或: pip install lightrag-hku
```

## LightRAG SDK示例代码

LightRAG核心功能的示例代码请参见 examples 目录。您还可参照视频视频完成环境配置。若已持有OpenAI API密钥，可以通过以下命令运行演示代码：

### you should run the demo code with project folder   
cd L<sup>i</sup>ghtRAG   
### provide your API-KEY for OpenAI   
export OPENAI\_API\_KEY="sk-. your\_opea<sup>i</sup>\_key. "   
### download the demo document of "A Christmas Carol" by Charles Dickens   
curl https: raw.githubusercontent.com/gusye1234/nano-graphrag/main/tests/mock\_data.txt > ./book.txt   
### run the demo code   
python examples/l<sup>i</sup>ghtrag\_opena<sup>i</sup>\_demo.py

如需流式响应示例的实现代码，请参阅 examples/lightrag\_openai\_compatible\_demo.py 。运行前，请确保根据需求修改示例代码中的LLM及嵌入模型配置。

注意1：在运行 demo 程序的时候需要注意，不同的测试程序可能使用的是不同的 embedding 模型。一个模型写入的向量对另一个模型不可用，所以更换 embedding 模型后必须重建向量。对 demo 数据而言，最简单的做法是直接删除 demo 目录（ ./dickens ）后重跑——语料很小且可丢弃；想保留 LLM 缓存可以保留

kv\_store\_llm\_response\_cache.json 文件。但生产部署请不要删除工作目录：它保存着知识图谱和文本块，删掉会把重新嵌入变成全量重新摄取。正确做法是运行 lightrag-rebuild-vdb ，参见 Switching embedding models。

注意2：官方支持的示例代码仅为 lightrag\_openai\_demo.py 和 lightrag\_openai\_compatible\_demo.py 两个文件。其他示例文件均为社区贡献内容，尚未经过完整测试与优化。

## 使用SDK的注意事项

SDK的使用说明详见 docs/ProgramingWithCore.md（英文）。有部份LightRAG功能没有提供 REST API，仅能够通过SDK使用。这部份功能往往是不稳定，不能保证在将来的版本上可以兼容。

## 重现论文结果

LightRAG 在农业、计算机科学、法律和混合等领域均显著优于 NaiveRAG、RQ-RAG、HyDE 和 GraphRAG。完整评估方法论、提示词和复现步骤详见 docs/Reproduce.md（英文）。

## 总体性能表

<table><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">农业</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">计算机科学</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">法律</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">混合</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">NaiveRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">NaiveRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">NaiveRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">NaiveRAG</td><td colspan="1" rowspan="1">LightRAG</td></tr><tr><td colspan="1" rowspan="1">全面性</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td><td colspan="1" rowspan="1">38.4%</td><td colspan="1" rowspan="1">61.6%</td><td colspan="1" rowspan="1">16.4%</td><td colspan="1" rowspan="1">83.6%</td><td colspan="1" rowspan="1">38.8%</td><td colspan="1" rowspan="1">61.2%</td></tr><tr><td colspan="1" rowspan="1">多样性</td><td colspan="1" rowspan="1">23.6%</td><td colspan="1" rowspan="1">76.4%</td><td colspan="1" rowspan="1">38.0%</td><td colspan="1" rowspan="1">62.0%</td><td colspan="1" rowspan="1">13.6%</td><td colspan="1" rowspan="1">86.4%</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td></tr><tr><td colspan="1" rowspan="1">赋能性</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td><td colspan="1" rowspan="1">38.8%</td><td colspan="1" rowspan="1">61.2%</td><td colspan="1" rowspan="1">16.4%</td><td colspan="1" rowspan="1">83.6%</td><td colspan="1" rowspan="1">42.8%</td><td colspan="1" rowspan="1">57.2%</td></tr><tr><td colspan="1" rowspan="1">总体</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td><td colspan="1" rowspan="1">38.8%</td><td colspan="1" rowspan="1">61.2%</td><td colspan="1" rowspan="1">15.2%</td><td colspan="1" rowspan="1">84.8%</td><td colspan="1" rowspan="1">40.0%</td><td colspan="1" rowspan="1">60.0%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">RQ-RAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">RQ-RAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">RQ-RAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">RQ-RAG</td><td colspan="1" rowspan="1">LightRAG</td></tr><tr><td colspan="1" rowspan="1">全面性</td><td colspan="1" rowspan="1">31.6%</td><td colspan="1" rowspan="1">68.4%</td><td colspan="1" rowspan="1">38.8%</td><td colspan="1" rowspan="1">61.2%</td><td colspan="1" rowspan="1">15.2%</td><td colspan="1" rowspan="1">84.8%</td><td colspan="1" rowspan="1">39.2%</td><td colspan="1" rowspan="1">60.8%</td></tr><tr><td colspan="1" rowspan="1">多样性</td><td colspan="1" rowspan="1">29.2%</td><td colspan="1" rowspan="1">70.8%</td><td colspan="1" rowspan="1">39.2%</td><td colspan="1" rowspan="1">60.8%</td><td colspan="1" rowspan="1">11.6%</td><td colspan="1" rowspan="1">88.4%</td><td colspan="1" rowspan="1">30.8%</td><td colspan="1" rowspan="1">69.2%</td></tr><tr><td colspan="1" rowspan="1">赋能性</td><td colspan="1" rowspan="1">31.6%</td><td colspan="1" rowspan="1">68.4%</td><td colspan="1" rowspan="1">36.4%</td><td colspan="1" rowspan="1">63.6%</td><td colspan="1" rowspan="1">15.2%</td><td colspan="1" rowspan="1">84.8%</td><td colspan="1" rowspan="1">42.4%</td><td colspan="1" rowspan="1">57.6%</td></tr><tr><td colspan="1" rowspan="1">总体</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td><td colspan="1" rowspan="1">38.0%</td><td colspan="1" rowspan="1">62.0%</td><td colspan="1" rowspan="1">14.4%</td><td colspan="1" rowspan="1">85.6%</td><td colspan="1" rowspan="1">40.0%</td><td colspan="1" rowspan="1">60.0%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">HyDE</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">HyDE</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">HyDE</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">HyDE</td><td colspan="1" rowspan="1">LightRAG</td></tr><tr><td colspan="1" rowspan="1">全面性</td><td colspan="1" rowspan="1">26.0%</td><td colspan="1" rowspan="1">74.0%</td><td colspan="1" rowspan="1">41.6%</td><td colspan="1" rowspan="1">58.4%</td><td colspan="1" rowspan="1">26.8%</td><td colspan="1" rowspan="1">73.2%</td><td colspan="1" rowspan="1">40.4%</td><td colspan="1" rowspan="1">59.6%</td></tr><tr><td colspan="1" rowspan="1">多样性</td><td colspan="1" rowspan="1">24.0%</td><td colspan="1" rowspan="1">76.0%</td><td colspan="1" rowspan="1">38.8%</td><td colspan="1" rowspan="1">61.2%</td><td colspan="1" rowspan="1">20.0%</td><td colspan="1" rowspan="1">80.0%</td><td colspan="1" rowspan="1">32.4%</td><td colspan="1" rowspan="1">67.6%</td></tr><tr><td colspan="1" rowspan="1">赋能性</td><td colspan="1" rowspan="1">25.2%</td><td colspan="1" rowspan="1">74.8%</td><td colspan="1" rowspan="1">40.8%</td><td colspan="1" rowspan="1">59.2%</td><td colspan="1" rowspan="1">26.0%</td><td colspan="1" rowspan="1">74.0%</td><td colspan="1" rowspan="1">46.0%</td><td colspan="1" rowspan="1">54.0%</td></tr><tr><td colspan="1" rowspan="1">总体</td><td colspan="1" rowspan="1">24.8%</td><td colspan="1" rowspan="1">75.2%</td><td colspan="1" rowspan="1">41.6%</td><td colspan="1" rowspan="1">58.4%</td><td colspan="1" rowspan="1">26.4%</td><td colspan="1" rowspan="1">73.6%</td><td colspan="1" rowspan="1">42.4%</td><td colspan="1" rowspan="1">57.6%</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">GraphRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">GraphRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">GraphRAG</td><td colspan="1" rowspan="1">LightRAG</td><td colspan="1" rowspan="1">GraphRAG</td><td colspan="1" rowspan="1">LightRAG</td></tr><tr><td colspan="1" rowspan="1">全面性</td><td colspan="1" rowspan="1">45.6%</td><td colspan="1" rowspan="1">54.4%</td><td colspan="1" rowspan="1">48.4%</td><td colspan="1" rowspan="1">51.6%</td><td colspan="1" rowspan="1">48.4%</td><td colspan="1" rowspan="1">51.6%</td><td colspan="1" rowspan="1">50.4%</td><td colspan="1" rowspan="1">49.6%</td></tr><tr><td colspan="1" rowspan="1">多样性</td><td colspan="1" rowspan="1">22.8%</td><td colspan="1" rowspan="1">77.2%</td><td colspan="1" rowspan="1">40.8%</td><td colspan="1" rowspan="1">59.2%</td><td colspan="1" rowspan="1">26.4%</td><td colspan="1" rowspan="1">73.6%</td><td colspan="1" rowspan="1">36.0%</td><td colspan="1" rowspan="1">64.0%</td></tr><tr><td colspan="1" rowspan="1">赋能性</td><td colspan="1" rowspan="1">41.2%</td><td colspan="1" rowspan="1">58.8%</td><td colspan="1" rowspan="1">45.2%</td><td colspan="1" rowspan="1">54.8%</td><td colspan="1" rowspan="1">43.6%</td><td colspan="1" rowspan="1">56.4%</td><td colspan="1" rowspan="1">50.8%</td><td colspan="1" rowspan="1">49.2%</td></tr><tr><td colspan="1" rowspan="1">总体</td><td colspan="1" rowspan="1">45.2%</td><td colspan="1" rowspan="1">54.8%</td><td colspan="1" rowspan="1">48.0%</td><td colspan="1" rowspan="1">52.0%</td><td colspan="1" rowspan="1">47.2%</td><td colspan="1" rowspan="1">52.8%</td><td colspan="1" rowspan="1">50.4%</td><td colspan="1" rowspan="1">49.6%</td></tr></table>

## � 文档与工具清单

## 参考文档（ docs/ ）

下表优先给出中文版链接；同目录下的同名 \*.md 为对应的英文原版。

## 部署与安装

<table><tr><td rowspan=1 colspan=1>文档</td><td rowspan=1 colspan=1>内容</td></tr><tr><td rowspan=1 colspan=1>ExploreLightRAG-zh.md</td><td rowspan=1 colspan=1>从默认配置到生产可用：PostgreSQL、认证、角色LLM、Rerank、VLM、智能标题、MinerU与并发调优，逐步操作并附实测结果</td></tr><tr><td rowspan=1 colspan=1>InteractiveSetup.md</td><td rowspan=1 colspan=1>make env-* 安装向导：生成.env 以及由向导管理的 docker-compose.final.yml</td></tr><tr><td rowspan=1 colspan=1>DockerDeployment.md</td><td rowspan=1 colspan=1>Docker / Docker Compose 部署、镜像版本差异，以及用 Cosign 验证官方 GHCR 镜像</td></tr><tr><td rowspan=1 colspan=1>AppleContainerSetup.md</td><td rowspan=1 colspan=1>在 Apple 原生 container 运行时上运行 Postgres / Neo4j / Milvus 存储栈(AppleSilicon，无需 Docker Desktop)</td></tr><tr><td rowspan=1 colspan=1>OfflineDeployment.md</td><td rowspan=1 colspan=1>离线/内网环境部署：预装依赖、tiktoken 缓存与 spaCy 模型</td></tr><tr><td rowspan=1 colspan=1>MultiSiteDeployment.md</td><td rowspan=1 colspan=1>单机反向代理后运行多个相互隔离的实例，共用一份 WebUI 构建产物(LIGHTRAG_API_PREFIX)</td></tr><tr><td rowspan=1 colspan=1>FrontendBuildGuide.md</td><td rowspan=1 colspan=1>WebUI的构建与分发方式（Bun/Node），以及哪些安装场景需要自行构建</td></tr></table>

## 服务器与 API

<table><tr><td>文档</td><td>内容</td></tr><tr><td>LightRAG-API-Server-zh.md</td><td>服务器完整指南：启动、配置、认证、REST接口与WebUI使用</td></tr></table>

## 文档处理

<table><tr><td rowspan=1 colspan=1>文档</td><td rowspan=1 colspan=1>内容</td></tr><tr><td rowspan=1 colspan=1>FileProcessingPipeline-zh.md</td><td rowspan=1 colspan=1>流水线规格说明：LIGHTRAG_PARSER 路由规则、各引擎参数、多模态分析、文档状态生命周期</td></tr><tr><td rowspan=1 colspan=1>ParserServiceDeployment-zh.md</td><td rowspan=1 colspan=1>自行搭建 MinerU 与 docling-serve 外部解析服务(Docker、GPU、模型权重)</td></tr><tr><td rowspan=1 colspan=1>ParagraphSemanticChunking-zh.md</td><td rowspan=1 colspan=1>Paragraph semantic（P)分块策略：对齐标题/段落/表格边界、参考文献丢弃</td></tr><tr><td rowspan=1 colspan=1>LightRAGSidecarFormat-zh.md</td><td rowspan=1 colspan=1>sidecar（*.parsed/）交换格式规范，所有支持多模态的解析引擎都必须遵循</td></tr><tr><td rowspan=1 colspan=1>ThirdPartyParser-zh.md</td><td rowspan=1 colspan=1>开发并注册自定义 parser 引擎</td></tr><tr><td rowspan=1 colspan=1>ParserDebugCLl-zh.md</td><td rowspan=1 colspan=1>python -m lightrag.parser.cli      脱离服务器离线解析单个文件并查看结果</td></tr></table>

## 模型与存储

<table><tr><td rowspan=1 colspan=1>文档</td><td rowspan=1 colspan=1>内容</td></tr><tr><td rowspan=1 colspan=1>RoleSpecificLLMConfiguration-zh.md</td><td rowspan=1 colspan=1>按角色（EXTRACT / QUERY / KEYWORD / VLM）配置 LLM 与 VLM</td></tr><tr><td rowspan=1 colspan=1>LLMProviderOptions.md</td><td rowspan=1 colspan=1>provider 生成参数完整参考（OPENAI_LLM_*、OLLAMA_LLM_*、GEMINI_LLM_*、BEDROCK_LLM_*、*_EMBEDDING_*，英文)</td></tr><tr><td rowspan=1 colspan=1>AsymmetricEmbedding.md</td><td rowspan=1 colspan=1>查询/文档非对称 embedding（EMBEDDING_ASYMMETRIC）与各模型的前缀</td></tr><tr><td rowspan=1 colspan=1>MilvusConfigurationGuide.md</td><td rowspan=1 colspan=1>通过vector_db_storage_cls_kwargs 调整 Milvus 索引|参数</td></tr></table>

## SDK 与开发

<table><tr><td rowspan=1 colspan=1>文档</td><td rowspan=1 colspan=1>内容</td></tr><tr><td rowspan=1 colspan=1>ProgramingWithCore.md</td><td rowspan=1 colspan=1>以 Python SDK 方式使用 LightRAG，包含未通过 REST 暴露的功能</td></tr><tr><td rowspan=1 colspan=1>Reproduce.md</td><td rowspan=1 colspan=1>复现论文中的评测结果</td></tr><tr><td rowspan=1 colspan=1>UV_LOCK_GUIDE.md</td><td rowspan=1 colspan=1>何时以及如何更新uv.lock</td></tr></table>

## 运维工具（ li<sub>g</sub>htra<sub>g</sub>/tools/ ）

涉及存储的工具与服务器一样读取 .env 和环境变量，请在项目根目录下、使用同一套配置运行。其中若干工具会原地改写存储——是否必须先停掉服务器（以及其它写入方）请查看对应指南， rebuild\_vdb 必须先停。

rebu<sup>i</sup>ld\_vdb.py lightrag-rebuild-vdb — README\_REBUILD\_VDB.md

丢弃并从权威数据源（图节点/边、 text\_chunks KV 存储）重建全部向量存储。用于向量写入失败后的恢复，以及更换 embedding 模型或维度之后的重建；另提供只读的一致性检查模式。

clean\_llm\_query\_cache.py lightrag-clean-llmqc — README\_CLEAN\_LLM\_QUERY\_CACHE.md

删除查询模式的 LLM 缓存条目（ mix:\* 、 hybrid:\* 、 local:\* 、 global:\* 、 naive:\* ），同时保留成本高昂的抽取缓存。

```shell
m<sup>i</sup>grate_llm_cache.py python -m l<sup>i</sup>ghtrag.tools.m<sup>i</sup>grate_llm_cache
README_MIGRATE_LLM_CACHE.md
```

在不同 KV 存储后端之间迁移 default 模式缓存（抽取、摘要、多模态分析），并保持 workspace 隔离。

kg\_<sup>i</sup>ntegr<sup>i</sup>ty\_repa<sup>i</sup>r.py python -m l<sup>i</sup>ghtrag.tools.kg\_<sup>i</sup>ntegr<sup>i</sup>ty\_repa<sup>i</sup>r [- apply] README\_KG\_INTEGRITY\_REPAIR.md

全图审计，找出未被 full\_entities / full\_relations 恢复锚点引用的图数据，报告无法归属的孤儿对象，并可选地补齐锚点，使删除/重试流程重新能够发现它们。

source\_conflict\_repair.py — python -m lightrag.tools.source\_conflict\_repair list / . repair README\_SOURCE\_CONFLICT\_REPAIR.md

列出争用同一个规范 source key 的文档，并把运维人员未选中的候选降级为重复项。工具本身从不自行裁定胜者，也从不删除内容。

download\_cache.py li<sub>g</sub>htra<sub>g</sub>-download-cache [- s<sub>p</sub>ac<sub>y</sub>-install] — OfflineDeployment.md

预先下载离线部署及 docx smart\_heading 引擎参数所需的 tiktoken 编码与钉版 spaCy 模型。

hash\_password.py — lightrag-hash-password [- username USER] — LightRAG-API-Server-zh.md

生成可直接粘贴进 AUTH\_ACCOUNTS 的 bcrypt 口令值。

check\_<sup>i</sup>n<sup>i</sup>t<sup>i</sup>al<sup>i</sup>zat<sup>i</sup>on.py python -m l<sup>i</sup>ghtrag.tools.check\_<sup>i</sup>n<sup>i</sup>t<sup>i</sup>al<sup>i</sup>zat<sup>i</sup>on - demo ProgramingWithCore.md

SDK 诊断工具：校验 LightRAG 实例是否已完整初始化，用于排查最常见的「忘记 awaitrag.initialize\_storages() 」问题。

![](images/5b9398984c7d52daaf0bd47c6fbf60006b5c921c42184ee27c4d799aea6379d4.jpg)

## 相关项目

生态与扩展

![](images/f818d2e7794bcc414e19221986c5947360c509f40aee615d2e77c785157f0734.jpg)

我们欢迎各种形式的贡献——Bug 修复、新功能、文档改进等。

提交 Pull Request 前，请阅读 贡献指南。

我们感谢所有贡献者做出的宝贵贡献。

![](images/ec3f4e9372ae46e0b904735da6fff1aa56283dba1b62d75869b045ec67f4f51b.jpg)

� 引用

@art<sup>i</sup>cle{guo2024l<sup>i</sup>ghtrag,

title={LightRAG: Simple and Fast Retrieval-Augmented Generation},

author={Zirui Guo and Lianghao Xia and Yanhua Yu and Tu Ao and Chao Huang},

year={2024},

eprint={2410.05779},

archivePrefix={arXiv},

primaryClass={cs.IR}

![](images/491f341ff9456c377fcdd39b64f111910326fe079c17c9f05bf84a362488b6c1.jpg)

![](images/f2b572236e40de5632c6cc34d074f74c1c7021b7238e7941328ee179daea4fd9.jpg)