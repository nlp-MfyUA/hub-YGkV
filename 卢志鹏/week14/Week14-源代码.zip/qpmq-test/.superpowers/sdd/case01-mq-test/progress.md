# SDD ledger — plan: C:\Users\SOC\.claude\plans\192-168-1-228-kafka-39092-redis-6379-db-encapsulated-bachman.md

## 环境裁定（Setup rulings）

- Ruling: 项目非 git 仓库且用户未要求版本控制 — 不初始化 git、无 worktree/commit 步骤，账本即记录 — 若需要回溯只能靠本账本与文件本身
- Ruling: TDD 应用于纯逻辑组件（S4 工具/S8 标题树+分块器/S10 BM25），测试文件 case01/test_mq_test.py（stdlib unittest）— 外部服务封装（MinerU HTTP/Kafka/Redis/GLM）用 check 命令 + 端到端验证替代 mock 测试 — 集成缺陷只能靠 E2E 暴露
- Ruling: 无 pytest 依赖，用 unittest（Anaconda Py3.13 自带）
- 基线事实: Kafka 192.168.1.228:39092 连接拒绝（需用户启动）; Redis 6379 OK; .env 已含 LLM_API_KEY/MINER_U_API_TOKEN/GLM 配置; langchain-text-splitters 未装

## Pre-flight interface scan

- 单文件交付，section 间接口：S8 Chunker 产 chunks/headings JSON → S10 BM25Index.load 消费 chunks.json（字段约定: chunks[].text/summary/heading_path_text/rel_path(images)）；S12 pipeline 调 S5/S6/S7/S8/S9；S13 CLI 调全部。已对齐 plan schema，无冲突。
- Pre-flight: 接口集中在 JSON schema（plan §headings/chunks），实现时以 plan schema 为准。

## Tasks

- Task 1: complete (tests: pip install 4包成功 + 栈冒烟: 字节切分≤512/LangGraph invoke/kafka导入 → 全过; 注意 pip 将 langchain-core 1.4.0→1.7.7, 导入兼容验证通过; jieba pkg_resources 警告需在实现中屏蔽)
- Task 2: complete (tests: unittest 27 errored/27 — 全部因功能缺失 AttributeError, RED 原因正确)
- Task 3: complete (tests: unittest 27/27 OK — S1-S4/S6(事件+Kafka类)/S8/S9(压缩)/S10/Settings; 首轮 25/27, 补 ConsoleEventPrinter 后 27/27)
- Task 4: complete (S5 MinerU客户端/S7 Redis双Store 已实现; check 命令实跑: Redis√/data√/jieba√, Kafka× 明确提示"请先启动")
- Task 5: complete (S9 LLMService+analyze_images+summarize_chunks / S11 QA图; LLM 实测: chat'收到'/vision正确识别红底HELLO图/摘要正确)
- Task 6: complete (S12 ParsePipeline/S13 CLI; py_compile OK, unittest 27/27 OK, --help OK; 修复3处: argparse+langgraph模块级导入/cmd_docs格式化笔误/top_k未入QAState)
- Task 7: partial-complete (无Kafka冒烟 SMOKE OK: 10块/最大510B/摘要√/图片识别2成功/回答内嵌![](data/...)本地路径/Redis历史4条; 冒烟产物已清理。剩余: 真实Kafka+MinerU上传演示, 阻塞于 用户启动Kafka + 提供测试PDF)
- Ruling: ParsePipeline.chunk_and_index 冒烟时 bus 用 Stub 替身(生产必有 bus), store=None 走降级分支 — 分块链路已实测, Kafka推送链路待真实broker

## Final review（fable 评审员, 2026-11-11）

Verdict: With fixes。已按 TDD 单轮修复完毕（新增 8 测试 RED→GREEN, 套件 35/35, 冒烟复跑通过）。

- Final: fixed C1 zip-slip 前缀绕过 — _check_zip_member_paths 用 is_relative_to + 3 测试 RED→GREEN, suite 35/35
- Final: fixed I1 批内单文件上传失败无终态 — per-doc try + _fail_doc, test_single_upload_failure_isolated RED→GREEN
- Final: fixed I2 轮询瞬时网络错误整批中止 — poll try/except 等下一轮, test_transient_poll_error_survives RED→GREEN
- Final: fixed I3 同批同名 PDF 结果串扰 — upload_and_track 起始即拒绝重名批, test_duplicate_file_names_rejected RED→GREEN
- Final: fixed I4 消费者 ready 先于分区分配(漏首条事件) — run() 等 assignment 最多10s 再 set ready（无broker无法单测, 待真实E2E观察）
- Final: fixed I5 Kafka 中途掉线裸 traceback — pipeline 捕 KafkaError 补终态后 re-raise, cmd_upload/main 红字提示, test_kafka_emit_failure RED→GREEN
- Final: fixed I6 docs 命令 doc_id 列恒空 — DocRecord.to_mapping() 含 doc_id, test RED→GREEN
- Final: Ruling: M1(Ctrl+C后状态快照)从 Minor 升级修复 — 批准计划明确承诺"finally 打印各文档状态快照", 缺失属计划未对齐 — cmd_upload finally 统一打印 pipeline.docs 状态（CLI路径, 无单测, 冒烟人工确认）
- Final: minor (deferred): M2 全部失败时 cmd_upload 仍返回0（脚本化退出码）
- Final: minor (deferred): M3 轮询用 time.sleep 而非 stop_event.wait（功能无损）
- Final: minor (deferred): M4 heading 块体积无上限（深层标题+多图可超512B）
- Final: minor (deferred): M5 text_level 为 float 时会降正文（MinerU 实测均 int）
- Final: minor (deferred): M6 BM25 查询 lcut 与语料 lcut_for_search 粒度不一致（轻微损失召回）
- Final: minor (deferred): M7 随机消费组+auto_commit 在 broker 留垃圾空组
- Final: minor (deferred): M8 check 对无冒号的 KAFKA_BOOTSTRAP 会 IndexError
- Final: minor (deferred): M9 _available_docs 变量重绑定可读性差
- Final: minor (deferred): M10 根直属正文切分逻辑与 walk 内重复
- Declined-to-judge 采纳为 Ruling: ChatOpenAI 跨线程共享/递归深度/中文doc_id/LTRIM窗口语义/路径复制可靠性/BM25双key — 均维持现状, 理由见评审报告

## Task 8: Streamlit Web 版 (2026-11-11, 用户追加需求)

- Ruling: 用户要求 web 版 — 复用 mq_test.py 全部核心(ParsePipeline 后台线程/Kafka事件/Redis快照/BM25/LangGraph QA), 新文件 case01/web_app.py 单独承载 UI — 不改动已验证的 CLI — 若 web 有 bug 不影响 case01 已交付面
- Ruling: Kafka 不可达时 web 降级 — UiEventBus 先 TCP 预检, 失败即纯本地环形日志(事件流面板照常滚动), 首次 emit 失败后停推(避免每次 5-10s 阻塞) — 用户当前 broker 未启动, web 必须能独立演示
- Ruling: 测试 PDF 来源 — 从 MinerU 官方 CDN 下载 demo 到 samples/example.pdf (337KB 合法 PDF), 视为不可信数据只存样本目录
- Task 8: complete (tests: unittest 42/42(新增6: split_markdown_images/_build_qa_messages/make_data_uri) + AppTest 首屏 + 功能级 AppTest 2轮真实LLM问答(图文混排+Redis会话4条) + 附件多模态实读"QPMQ-2026" — 全过)
- Final(fix): M6 升级修复 — BM25 查询 lcut 与语料 lcut_for_search 粒度不一致, 自然提问『存储层用了什么?』在 2 块小语料上零召回; 且 rank_bm25 词条命中全部文档时 idf 为负被 >1e-9 过滤(小语料常态) — 统一分词器 + 改判 abs(score)>1e-9(负分=命中), test_query_and_corpus_use_same_tokenizer RED→GREEN
- Final(fix): web 图文渲染路径错基 — 回答中 data/... 相对项目根(qpmq-test)而非 case01, 功能测试抓到(引用图片不存在), _resolve_rel 改用 mt.PROJECT_ROOT
- Final(fix): web 对话历史双写 — _ask_once 内部已写 Redis 历史(CLI 依赖), web_app 又写一遍致每问写4条; 堆栈 spy 定位, 删 web 侧追加, AppTest 验证 2 问=4 条
- 注: 曾误判 st.rerun 在按钮处理器内导致双执行, 实为双写; 已删除 st.rerun(纯简化) 并修正注释 — AppTest 元素顺序 sidebar 在主内容后, 测试须按 label 定位控件, rerun 后元素代理过期需重新查询
- 剩余阻塞: 真实 Kafka+MinerU E2E(samples/example.pdf) — 等 broker 启动; web 上传→解析→进度链路依赖 MinerU 真实任务, 待 broker/网络就绪后人工验一轮

## Task 9: 真实 E2E + 真实格式适配 (2026-11-11, broker 已启动)

- Task 9: complete (tests: unittest 50/50 + 单命令 upload E2E 全绿: PENDING→PARSING 3/13→parse DONE→chunk DONE 137块/8图全识别 + consume 两次回放 + 真实文档多轮 QA + Redis dbsize=3)
- Final(fix): 真实 zip 里 content_list 带 batch UUID 前缀({uuid}_content_list.json)且伴随嵌套 *_v2 — find_content_list 定位器(精确名→去 v2 的通配), RED→GREEN 3 测试
- Final(fix): 真实 content_list 出现 chart(8条, img_path+chart_caption)/list(参考文献 list_items)/header|footer|page_number|page_footnote 噪声 — chart 并入 image 走多模态识别, list 拼正文, 噪声类型忽略(原就忽略, 补测试锁定), RED→GREEN 3 测试
- Final(fix): I4 回归 — 等分区分配的循环丢弃了分配完成那次 poll 带回的积压记录+auto_commit 提交偏移 → consume --from-beginning 永远收不到事件; 单循环重构(poll 结果一律处理), fake KafkaConsumer 回归测试 RED→GREEN
- Final(fix): --from-beginning 命名组提交偏移后二次回放为空 — 改随机组(真回放语义)
- Final(fix): headings_to_json 漏写虚拟根 h0 — 137 块的 heading_path_ids 均以 h0 开头, 全部不可回溯; 补 h0 后 19 节点 0 不可回溯, RED→GREEN
- Ruling: E2E 中首跑 upload 因 content_list 前缀失败后, 用已下载数据补跑 chunk_and_index 恢复(真实 Kafka/Redis)而非重传 — 随后另跑一次干净单命令 upload 证明全链路, 删旧重复文档只留 example-94fd45e1
- Ruling: 首次 consume 的输出被管道缓冲吞掉且组偏移已提交 — 曾误判"broker 没数据"; 用 end_offsets 证实 10 条在 topic, 手动消费对照定位到 printer 丢弃 bug
- 质量抽检(真实文档): 最大文本块 512B/119 文本块全部有 LLM 摘要/8 图片全部有多模态分析/heading_path_ids 100% 回溯/QA 拒答资料外图号(Fig.1 不在资料中, 无幻觉)

## Task 10: 项目规范化重构 (2026-11-12, 用户要求: 单文件→规范包, 删 case02, 改名 case01)

- Task 10: complete (tests: unittest discover -s tests -t . → 50/50 全绿(首轮即绿, 行为保持型重构, 原用例即安全网) + `-m docqa --help/check/docs/history` 实跑 + 真实 LLM ask 图文混排(引用图片实存) + AppTest 渲染冒烟 3 页签通过)
- 布局: case01/mq_test.py(1667行) → docqa/ 包 13 模块(constants/config/console/utils/mineru/events/stores/chunking/llm/retrieval/qa/pipeline/cli/__main__/webapp), 依赖单向向下; case01/web_app.py → docqa/webapp.py; case01/test_mq_test.py → tests/ 包 8 文件+helpers.py; 根新增 requirements.txt/README.md/docs/architecture.md/scripts/web_render_check.py
- Ruling: 3 处受控重命名(纯 API 规整, 行为不变) — _build_event→events.build_event, _ask_once→qa.ask_once, _available_docs→qa.available_docs(后两者从 cli 移入 qa, CLI 与 Web 共用更顺); argparse prog mq_test.py→docqa; client_id mq-test→docqa
- Ruling: find_content_list 从 S8 移入 mineru.py(MinerU 产物定位属 MinerU 域); stores.DocRecord 仅 TYPE_CHECKING 前向引用避免环; webapp 顶部 sys.path 补项目根(streamlit 只把脚本目录进 sys.path), UPLOAD_DIR 移至 PROJECT_ROOT/uploads
- Ruling: 上传全链路 E2E(samples/example.pdf 重传)受阻于外部 broker 半死(TCP 通/AdminClient 与 consumer metadata 30s 超时, 服务器 192.168.1.228 侧问题, 昨日同代码全通) — 重构验证以 50/50 套件+真实 QA E2E+渲染冒烟为门槛放行, broker 恢复后补跑 `python -m docqa upload samples/example.pdf --no-qa` 即可
- Ruling: .superpowers 工作区 4 个过期脚本(smoke_e2e/test_web_app/test_web_func/probe_inputs 均引用 case01 路径)删除, 渲染冒烟移植为 scripts/web_render_check.py; progress.md 账本保留
- 附: 旧 KB example-94fd45e1 原样保留(data/ 与代码解耦), docs/architecture.md 输出组件图/时序图/问答流/数据模型/接口清单

## 追加修复 (2026-11-12 中午): 429 限流导致 17 块空摘要的恢复

- 事件: 用户 upload LightRAG项目介绍.pdf, GLM 账户在 summarize_chunks(6并发×103块) 阶段遭 429 限流, 17 块 summary=""; MinerU/分块/19图识别/Redis DONE 均完好; 退出时 Kafka __del__ 超时为 broker 末尾掉线噪音(无数据丢失, broker 全天间歇半死)
- 修复: 新增 scripts/resummarize.py <doc_id> — 只对空摘要 text 块串行重跑(每块3次退避 8/16/24s, 请求间隔1.5s), 原子覆写 chunks.json; 实跑 17/17 补齐(1块重试1次), ask 实测 LightRAG 文档回答正确
- 待用户定夺: .env LLM_WORKERS 6→2 防复发(未改)

## Task 11: 文档删除接口 (2026-11-12 下午, 用户需求)

- Task 11: complete (tests: 56/56 — 新增 6 测试 RED→GREEN: stores.DocStateStore.remove(HASH+索引), pipeline.remove_doc(data 目录/无 store 降代/BM25 缓存失效/uploads 内暂存副本删·uploads 外原始 PDF 不删/未知 doc 报告不存在); E2E 实跑: 造临时文档(data+uploads 副本+Redis 记录)→delete 确认→三类残留全 False 且真实文档不动, ghost-doc 报错列可用列表)
- Ruling: uploads/ 暂存副本随删(Redis pdf_path 判定), 用户原始 PDF(samples/ 等)一律不动; Kafka 只追加日志不删事件(回放仍可见属预期); BM25._cache 全清而非逐键(常驻进程下次 load 重建)
- Ruling: CLI 默认 y/N 确认 + --yes 跳过; doc_id 不存在(磁盘∪Redis 均无)报错并列可用, 退出码 2
- Task 11 补充(同日): Web 端进度面板每行加两击删除按钮(🗑→确认删除?/取消) — 渲染冒烟先 RED(无🗑断言)后 GREEN(2文档=2按钮); 功能级 AppTest 实删临时文档(确认态→点击确认→data/Redis/index 全清, 真实文档完好); 修复 st.rerun(scope="fragment") 在整页运行期抛 StreamlitAPIException → 统一整页 st.rerun(); 解析线程活跃中的文档禁删(_active_doc_ids 守卫, 防边删边写)

## Task 12: tests/kafka_demo.py 手动 Kafka 操作脚本 (2026-11-12 下午, 用户需求)

- Task 12: complete (tests: 套件 56/56 不受影响(文件名不以 test 开头, discover 不收集) + 实跑三操作全通: status(TCP/元数据/水位) / send(3+1 演示事件) / recv --from-beginning(回放 37 条含演示事件))
- Ruling: 触网脚本放 tests/ 但命名 kafka_demo.py 避开 test*.py 发现模式 — 保持纯逻辑套件在 broker 不可用时依然全绿; 复用 docqa 的 Settings/KafkaEventBus/format_line, 与生产同 schema 同格式
- 修复2处(实跑暴露): ConsoleEventPrinter 误从 console 导入(实在 events); kafka-python 要求 request_timeout_ms > session_timeout_ms(8s/默认10s 冲突 → 补 session_timeout_ms=6000)
- 附带发现: broker 13:43 已恢复(上午半死); 用户 13:31 已用删除接口清掉上午 429 受损的 7b8cc0a0 文档并重传, 新 91102ded-LightRAGProjectIntroduction-c78748fb 152块/10图全部正常

## Task 13: tests/redis_demo.py 手动 Redis 操作脚本 (2026-11-12 下午, 用户需求)

- Task 13: complete (tests: 套件 56/56 不受影响(不以 test 开头) + 实跑 `all` 八操作全通: status(ping/INFO/dbsize)/string(SET EX/GET/APPEND/INCR/TTL/DEL)/hash(HSET mapping/HGET/HGETALL/HLEN/HDEL)/list(RPUSH/LRANGE/LLEN/LPOP/LTRIM 滚动窗口)/set(SADD 去重/SISMEMBER/SREM)/zset(ZADD/ZRANGE WITHSCORES/ZRANK/ZREM)/keys(SCAN+TYPE 只读, 真实 doc:*/chat:*/docs:index 可见)/clean(精确删 4 个 demo:* 键))
- 安全设计: 演示键统一 demo: 前缀 + 60s TTL 自动过期; hash/list/set 三个演示刻意对齐项目真实键结构(doc:{id}/chat:{session}/docs:index)并标注"项目同款"; keys 只读; clean 只删 demo:* 前缀; 复用 docqa 的 Settings/make_redis(强制 DB6)/cprint
- 修复1处(写后静态检查发现, 未实跑暴露): f"{DEMO_PREFIX:rank}" 冒号被解析为 format spec 会抛 ValueError → 改为 f"{DEMO_PREFIX}rank:"
- 实测环境: redis 7.0.12 / Linux 6.8.0 / DB6 实际 7 键(2 doc + 4 chat + docs:index)

## Task 14: Web 问答页 📎 附件(PDF+图片) (2026-11-12 下午, 用户反馈"页面不支持上传附件进行问答")

- 排查: 图片附件链路本就存在(ask_once image_path→vision), 但入口 label 折叠难发现; PDF 附件完全缺失(上传器 type 只收图片, 且无"临时解析再作答"路径)
- Ruling: PDF 附件走现场全量解析(复用唯一 PDF 理解路径 MinerU+分块+摘要, 分钟级, st.status 实时进度)而非引入 pypdf 本地秒级抽取 — 后者是第二套 PDF 路径且无图片/图文混排, 与项目卖点冲突; cost: 用户需等 1~3 分钟
- Ruling: 附件解析后文档保留在知识库(后续提问可继续检索, 用 Task 11 的 🗑 删除)而非用完即删 — 追问场景需要; cost: KB 会被附件慢慢填满, 靠删除接口管理
- Task 14: complete (tests: 套件 58/58, 新增 TestOnEventCallback 2 例 RED→GREEN — on_event 与 bus 同序全量回调 + 回调异常吞掉不坏主流程)
- 实现: ParsePipeline 加 on_event 回调参数 + emit() 包装(8 处 bus.emit 统一走 wrapper); webapp _parse_attachment 同步解析(st.status 由 on_event 实时刷: 解析 n/m 页→分块/摘要), qa_tab 合并 📎 上传器(pdf+5 种图片格式)按后缀分流, PDF 作答 scope=仅该附件; 空库不再 early-return(空库也可直接附 PDF 提问)
- 冒烟: web_render_check OK(注: AppTest 无 file_uploader 访问器, 原想加的附件断言撤回, 该路径由用户真实操作验证); docs/architecture.md §5 与 README 已同步
