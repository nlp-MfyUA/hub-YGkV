# -*- coding: utf-8 -*-
"""MinerU 精准解析 API v4 客户端: 批量申请上传URL → PUT 文件 → 轮询 → 下载解压."""
from __future__ import annotations

import zipfile
from pathlib import Path

import requests

from .utils import retry


class MinerUError(Exception):
    pass


class MinerUApiError(MinerUError):
    def __init__(self, code: int, msg: str):
        super().__init__(f"MinerU code={code}: {msg}")
        self.code, self.msg = code, msg


class MinerUStateError(MinerUError):
    pass


def _check_zip_member_paths(dest_dir: Path, names: list[str]) -> None:
    """zip-slip 防护: 每个条目解压后必须仍位于 dest_dir 内.

    用 is_relative_to 而非字符串前缀比较 —— `doc1` 与 `doc1evil` 这类
    前缀碰撞在 startswith 下会放行, 造成解压到目录外.
    """
    root = dest_dir.resolve()
    for name in names:
        if not (dest_dir / name).resolve().is_relative_to(root):
            raise MinerUError(f"zip 条目路径非法(zip-slip 防护): {name}")


class MinerUClient:
    """MinerU 精准解析 API v4: 批量申请上传URL → PUT 文件 → 自动建任务 → 轮询 → 下载zip."""
    BASE = "https://mineru.net/api/v4"
    MAX_FILE_BYTES = 200 * 1024 * 1024
    TERMINAL_STATES = ("done", "failed")

    def __init__(self, token: str, model_version: str = "pipeline",
                 language: str = "ch", timeout: float = 30.0):
        self.model_version, self.language, self.timeout = model_version, language, timeout
        self.http = requests.Session()
        self.http.headers.update({"Authorization": f"Bearer {token}"})

    def _check(self, resp: requests.Response) -> dict:
        resp.raise_for_status()
        data = resp.json()
        if data.get("code") != 0:
            raise MinerUApiError(data.get("code", -1), str(data.get("msg", "unknown")))
        return data.get("data") or {}

    @staticmethod
    def check_local_pdf(path: Path) -> None:
        if not path.exists():
            raise MinerUError(f"文件不存在: {path}")
        if path.suffix.lower() != ".pdf":
            raise MinerUError(f"仅支持 PDF 文件: {path}")
        if path.stat().st_size > MinerUClient.MAX_FILE_BYTES:
            raise MinerUError(f"超过 MinerU 200MB 限制: {path}")

    def create_batch(self, files: list[tuple[str, str]]) -> tuple[str, list[str]]:
        """files: [(file_name, data_id=doc_id)]; 返回 (batch_id, upload_urls 与 files 等长同序)."""
        data = self._check(self.http.post(
            f"{self.BASE}/file-urls/batch",
            json={"files": [{"name": n, "data_id": d} for n, d in files],
                  "model_version": self.model_version, "language": self.language},
            timeout=self.timeout))
        batch_id = data.get("batch_id")
        urls = data.get("file_urls") or []
        if not batch_id or len(urls) != len(files):
            raise MinerUError(f"create_batch 响应异常: {data}")
        return batch_id, urls

    def upload_file(self, put_url: str, pdf_path: Path) -> None:
        """PUT 到 OSS 预签名地址; 绝不能带 Content-Type(预签名会 403)."""
        with open(pdf_path, "rb") as f:
            resp = requests.put(put_url, data=f, timeout=600)
        if resp.status_code not in (200, 201):
            raise MinerUError(f"OSS 上传失败 HTTP {resp.status_code}: {resp.text[:200]}")

    def poll_batch(self, batch_id: str) -> list[dict]:
        """返回 extract_result[]: 每项含 file_name/state/err_msg/extract_progress/full_zip_url."""
        data = self._check(self.http.get(
            f"{self.BASE}/extract-results/batch/{batch_id}", timeout=self.timeout))
        return data.get("extract_result") or []

    @retry(times=3, delay=2.0)
    def _download_zip(self, zip_url: str, zip_path: Path) -> None:
        with requests.get(zip_url, stream=True, timeout=300) as r:  # 不带 token, CDN 直连
            r.raise_for_status()
            with open(zip_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=1 << 20):
                    if chunk:
                        f.write(chunk)

    def download_and_extract(self, zip_url: str, dest_dir: Path) -> Path:
        """下载结果 zip 并解压到 dest_dir(含 full.md/content_list.json/images/)."""
        dest_dir.mkdir(parents=True, exist_ok=True)
        zip_path = dest_dir.with_suffix(".mineru.zip")
        try:
            self._download_zip(zip_url, zip_path)
            with zipfile.ZipFile(zip_path) as zf:
                _check_zip_member_paths(dest_dir, zf.namelist())
                zf.extractall(dest_dir)
        finally:
            zip_path.unlink(missing_ok=True)
        return dest_dir


def find_content_list(base: Path) -> Path:
    """定位 content_list.json: 精确名 → MinerU v4 zip 的 `{uuid}_content_list.json`(排除嵌套的 *_v2)."""
    exact = base / "content_list.json"
    if exact.exists():
        return exact
    cands = sorted(p for p in base.glob("*_content_list.json")
                   if not p.name.endswith("_v2.json"))
    if cands:
        return cands[0]
    raise MinerUError(
        f"data 目录 {base} 未找到 content_list(.json), 现有: "
        f"{sorted(p.name for p in base.glob('*.json'))}")
