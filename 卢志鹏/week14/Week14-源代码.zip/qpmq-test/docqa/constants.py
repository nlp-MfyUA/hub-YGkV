# -*- coding: utf-8 -*-
"""全局常量: 文档状态机 / 事件阶段 / 事件协议版本.

事件状态机: PENDING → PARSING → DONE | FAILED (parse/chunk 两个阶段各自走一遍).
"""
ST_PENDING = "PENDING"      # 待解析
ST_PARSING = "PARSING"      # 解析中
ST_DONE = "DONE"            # 解析完毕
ST_FAILED = "FAILED"        # 失败

STAGE_PARSE = "parse"       # 阶段: MinerU 解析
STAGE_CHUNK = "chunk"       # 阶段: 分块/图片识别/摘要

EVENT_VERSION = 1
