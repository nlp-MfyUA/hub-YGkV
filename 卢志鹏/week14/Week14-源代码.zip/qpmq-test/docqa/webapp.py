# -*- coding: utf-8 -*-
"""docqa — Streamlit Web 版.

批量上传 PDF → 后台线程跑 MinerU 解析+分块(Kafka 事件 + Redis 快照双写),
前端 fragment 每 2 秒自动刷新展示各文档进度; 多模态问答: 回答图文混排
(引用解析出的本地图片), 问答支持 📎 附件 — 图片走 vision 模型,
PDF 现场解析(st.status 实时进度)后仅就该附件检索作答.

运行(项目根目录): D:/anaconda3/python.exe -m streamlit run docqa/webapp.py
"""
from __future__ import annotations

import sys
import threading
import uuid
from collections import deque
from pathlib import Path

# Streamlit 只把脚本所在目录(docqa/)放进 sys.path, 手动补项目根以便 import docqa
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import socket

import streamlit as st

from docqa.config import PROJECT_ROOT, Settings
from docqa.constants import (STAGE_CHUNK, STAGE_PARSE, ST_DONE, ST_FAILED,
                             ST_PARSING, ST_PENDING)
from docqa.events import ConsoleEventPrinter, KafkaEventBus, build_event
from docqa.mineru import MinerUClient
from docqa.pipeline import ParsePipeline, remove_doc
from docqa.qa import ask_once, available_docs, split_markdown_images
from docqa.stores import ChatHistoryStore, DocStateStore, make_redis
from docqa.utils import now_iso

UPLOAD_DIR = PROJECT_ROOT / "uploads"        # Web 上传的 PDF/附件暂存

st.set_page_config(page_title="docqa 知识库", page_icon="📄", layout="wide")

# 状态/阶段的中文展示
STATE_CN = {ST_PENDING: "待解析", ST_PARSING: "解析中",
            ST_DONE: "完毕", ST_FAILED: "失败"}
STATE_ICON = {ST_PENDING: "⏳", ST_PARSING: "🔄", ST_DONE: "✅", ST_FAILED: "❌"}
STAGE_CN = {STAGE_PARSE: "解析", STAGE_CHUNK: "分块"}


# ============================================================
# 事件总线: Kafka 优先, 本地环形日志兜底(前端"事件流"面板数据源)
# ============================================================
class UiEventBus:
    """emit 永远写入本地环形日志; Kafka 可达时同时推送, 失败一次后自动停推并记录原因."""

    def __init__(self, settings: Settings):
        self.s = settings
        self.log: deque[dict] = deque(maxlen=500)
        self.lock = threading.Lock()
        self.kafka: KafkaEventBus | None = None
        self.kafka_err = ""
        try:
            host, _, port = settings.kafka_bootstrap.partition(":")
            sock = socket.socket()
            sock.settimeout(3)
            sock.connect((host, int(port or 9092)))   # TCP 预检, broker 没起就别建 producer
            sock.close()
        except Exception as e:
            self.kafka_err = f"Kafka 不可达({e}) — 已降级为仅本地事件日志"
            return
        try:
            bus = KafkaEventBus(settings.kafka_bootstrap, settings.kafka_topic,
                                client_id="docqa-web")
            bus.ensure_topic()
            self.kafka = bus
        except Exception as e:
            self.kafka_err = f"Kafka 初始化失败({str(e)[:120]}) — 已降级为仅本地事件日志"

    def emit(self, *, doc_id: str, file_name: str, stage: str, state: str,
             progress: dict | None = None, detail: str = "") -> dict:
        ev = build_event(doc_id=doc_id, file_name=file_name, stage=stage,
                         state=state, progress=progress, detail=detail)
        with self.lock:
            self.log.append(ev)
        if self.kafka is not None:
            try:
                self.kafka.emit(doc_id=doc_id, file_name=file_name, stage=stage,
                                state=state, progress=progress, detail=detail)
            except Exception as e:
                self.kafka = None   # 后续不再重试, 避免每次 emit 阻塞
                self.kafka_err = f"Kafka 推送失败({str(e)[:100]}) — 已降级为仅本地事件日志"
        return ev

    def flush_and_close(self) -> None:
        if self.kafka is not None:
            self.kafka.flush_and_close()
            self.kafka = None


# ============================================================
# 基础设施(跨 rerun / 跨会话单例)
# ============================================================
@st.cache_resource(show_spinner="连接基础设施…")
def infra() -> dict:
    s = Settings.load()
    s.validate()
    bus = UiEventBus(s)
    rc = None
    try:
        rc = make_redis(s)
        rc.ping()
    except Exception:
        rc = None
    return {
        "s": s,
        "bus": bus,
        "rc": rc,
        "store": DocStateStore(rc) if rc else None,
        "hist": ChatHistoryStore(rc, s.history_window) if rc else None,
    }


# ============================================================
# 后台解析线程(批量上传 → MinerU 轮询 → 下载 → 分块建索引)
# ============================================================
def run_parse_job(settings: Settings, bus: UiEventBus,
                  store: DocStateStore | None, pdf_paths: list[Path], job: dict) -> None:
    try:
        mineru = MinerUClient(settings.mineru_token, settings.mineru_model_version,
                              settings.mineru_language)
        pipe = ParsePipeline(settings, mineru, bus, store)
        job["pipeline"] = pipe
        docs = pipe.upload_and_track(pdf_paths)
        for d in docs:                       # 解析完毕的继续分块+摘要+建索引
            pipe.chunk_and_index(d)
        job["done_at"] = now_iso()
    except Exception as e:
        job["error"] = str(e)


def start_job(inf: dict, pdf_paths: list[Path], names: list[str]) -> dict:
    job = {"names": names, "pipeline": None, "error": "", "done_at": ""}
    t = threading.Thread(target=run_parse_job,
                         args=(inf["s"], inf["bus"], inf["store"], pdf_paths, job),
                         daemon=True, name=f"parse-{uuid.uuid4().hex[:6]}")
    job["thread"] = t
    st.session_state.setdefault("jobs", []).append(job)
    t.start()
    return job


# ============================================================
# 上传与解析 Tab
# ============================================================
def _active_doc_ids() -> set[str]:
    """仍在解析线程中的 doc_id(删除按钮对其禁用, 避免线程边删边写)."""
    ids: set[str] = set()
    for job in st.session_state.get("jobs", []):
        pipe, t = job.get("pipeline"), job.get("thread")
        if pipe and t is not None and t.is_alive():
            ids.update(d.doc_id for d in pipe.docs)
    return ids


def _delete_button(doc_id: str, inf: dict, disabled: bool = False) -> None:
    """两击确认删除: 🗑 → 确认删除?/取消; 确认后 remove_doc 并整页刷新."""
    ck = f"confirm-del:{doc_id}"
    if st.session_state.get(ck):
        col_ok, col_no = st.columns(2)
        if col_ok.button("确认删除?", key=f"delok:{doc_id}", type="primary",
                         disabled=disabled, use_container_width=True):
            remove_doc(doc_id, inf["s"], inf["store"])
            st.session_state.pop(ck, None)
            st.toast(f"已删除 {doc_id} 及其分块/图片/记录", icon="🗑")
            st.rerun()                       # 整页刷新, 进度/检索范围同步消失
        if col_no.button("取消", key=f"delno:{doc_id}", use_container_width=True):
            st.session_state.pop(ck, None)
            st.rerun()
    else:
        if st.button("🗑", key=f"del:{doc_id}", disabled=disabled,
                     help="解析进行中, 等任务结束再删除" if disabled
                     else "删除该文档及其分块/图片/Redis 记录(原始 PDF 与 Kafka 事件保留)"):
            st.session_state[ck] = True
            st.rerun()                       # 整页重跑以渲染确认态(scope=fragment 在整页运行期不合法)


@st.fragment(run_every=2)
def progress_panel(inf: dict) -> None:
    rows: dict[str, dict] = {}
    if inf["store"] is not None:
        try:
            for d in inf["store"].list_docs():
                rows[d["doc_id"]] = d
        except Exception:
            pass
    for job in st.session_state.get("jobs", []):     # 后台线程内存态兜底(Redis 断线也能看)
        pipe = job.get("pipeline")
        if pipe:
            for d in pipe.docs:
                rows[d.doc_id] = d.to_mapping()

    if not rows:
        st.info("尚无文档。请在上方上传 PDF 开始解析。")
        return
    active = _active_doc_ids()
    for d in sorted(rows.values(), key=lambda x: x.get("created_at", ""), reverse=True):
        state, stage = d.get("state", ""), d.get("stage", "")
        icon = STATE_ICON.get(state, "❓")
        c1, c2, c3 = st.columns([3, 2, 1])
        c1.markdown(f"**{icon} {d.get('file_name', '?')}**　"
                    f"`{d.get('doc_id', '?')[:26]}`")
        c2.markdown(f"{STAGE_CN.get(stage, stage)}阶段 · "
                    f"**{STATE_CN.get(state, state)}**"
                    + (f" · {d.get('chunks_count', 0)} 块"
                       if d.get("chunks_count") else ""))
        with c3:
            _delete_button(d.get("doc_id", ""), inf,
                           disabled=d.get("doc_id", "") in active)
        if state == ST_PARSING and d.get("total_pages"):
            ep, tp = int(d.get("extracted_pages", 0)), int(d["total_pages"])
            st.progress(min(ep / tp, 1.0), text=f"MinerU 解析进度 {ep}/{tp} 页")
        if state == ST_FAILED and d.get("err_msg"):
            st.error(f"{d['file_name']}: {d['err_msg'][:300]}")
        st.divider()


def upload_tab(inf: dict) -> None:
    st.caption("PDF 上传后由后台线程提交 MinerU 解析, 状态经 Kafka 推送并快照到 Redis, "
               "下方面板每 2 秒自动刷新。")
    files = st.file_uploader("上传 PDF(支持批量)", type=["pdf"], accept_multiple_files=True,
                             label_visibility="collapsed")
    if st.button("🚀 开始解析", type="primary", disabled=not files) and files:
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        paths, names = [], []
        for f in files:
            p = UPLOAD_DIR / f"{uuid.uuid4().hex[:8]}-{f.name}"
            p.write_bytes(f.getvalue())          # UploadedFile 字节直接落盘
            paths.append(p)
            names.append(f.name)
        start_job(inf, paths, names)
        st.toast(f"已提交 {len(paths)} 个文件, 解析任务已在后台启动", icon="🚀")

    for job in st.session_state.get("jobs", []):
        if job.get("error"):
            st.error(f"解析任务失败({', '.join(job['names'])}): {job['error'][:300]}")

    st.subheader("文档进度")
    progress_panel(inf)


# ============================================================
# 智能问答 Tab
# ============================================================
def _resolve_rel(rel: str) -> Path:
    """回答里的 `data/.../images/x.jpg` 相对项目根解析(与 Settings.data_dir 同基)."""
    p = Path(rel)
    return p if p.is_absolute() else PROJECT_ROOT / p


def render_answer(text: str) -> None:
    """回答图文混排渲染: 文本片段 markdown, ![](path) 片段直接显示本地图片."""
    for kind, content in split_markdown_images(text):
        if kind == "text":
            if content.strip():
                st.markdown(content)
        else:
            img = _resolve_rel(content)
            if img.exists():
                st.image(str(img), caption=content, width=520)
            else:
                st.warning(f"图片不存在: {content}")


def _parse_attachment(inf: dict, pdf_path: Path):
    """QA 页附件 PDF 现场同步解析(st.status 实时进度), 返回 DocRecord 或 None(失败已提示).

    复用与「上传与解析」完全相同的流水线(Kafka 事件 + Redis 快照双写),
    文档留在知识库中 — 后续提问仍可检索到, 不需要时用进度面板的 🗑 删除.
    """
    s = inf["s"]
    with st.status(f"📎 现场解析附件 {pdf_path.name}(MinerU 解析+分块, 约 1~3 分钟)…",
                   expanded=True) as stt:

        def on_progress(ev: dict) -> None:
            prog = ev.get("progress") or {}
            if ev.get("stage") == STAGE_CHUNK:
                stt.update(label=f"📎 {pdf_path.name}: 图片识别/分块/摘要 …")
            elif ev.get("state") == ST_PARSING and prog:
                stt.update(label=f"📎 {pdf_path.name}: MinerU 解析 "
                                 f"{prog.get('extracted_pages', 0)}/{prog.get('total_pages', 0)} 页")

        try:
            mineru = MinerUClient(s.mineru_token, s.mineru_model_version, s.mineru_language)
            pipe = ParsePipeline(s, mineru, inf["bus"], inf["store"], on_event=on_progress)
            docs = pipe.upload_and_track([pdf_path])
            for d in docs:
                pipe.chunk_and_index(d)
            failed = [d for d in pipe.docs if d.state == ST_FAILED]
            if not docs or failed:
                msg = failed[0].err_msg if failed else "解析未返回结果"
                stt.update(label=f"📎 附件解析失败: {msg[:120]}", state="error")
                st.error(f"附件 {pdf_path.name} 解析失败: {msg[:300]} — 本轮未作答, "
                         f"可去掉附件重试或检查文件。")
                return None
            stt.update(label=f"📎 附件就绪({docs[0].chunks_count} 块), 检索作答中…",
                       state="complete")
            return docs[0]
        except Exception as e:
            stt.update(label=f"📎 附件解析异常: {str(e)[:120]}", state="error")
            st.error(f"附件解析异常: {str(e)[:300]}")
            return None


def qa_tab(inf: dict) -> None:
    s, hist = inf["s"], inf["hist"]
    avail = available_docs(s)
    if not avail:
        st.info("知识库为空 — 可直接在下方附上 PDF 提问(现场解析后作答), "
                "或先到「上传与解析」页解析文档。")
        doc_ids, top_k = [], s.top_k
    else:
        left, right = st.columns([3, 1])
        with left:
            doc_ids = st.multiselect("检索范围(留空=全部文档)", avail, default=avail)
        with right:
            top_k = st.slider("召回块数 top-k", 1, 10, s.top_k)

    st.session_state.setdefault("chat", [])
    qcol, acol = st.columns([4, 1])
    with qcol:
        question = st.text_input(label="提问",
                                 placeholder="例: 这份文档讲了什么? 有配图吗?",
                                 label_visibility="collapsed")
    with acol:
        attach = st.file_uploader(
            "📎 附件(可选)",
            type=["pdf", "png", "jpg", "jpeg", "webp", "bmp"],
            help="图片: 随问题走 vision 模型; PDF: 现场解析(约 1~3 分钟)后"
                 "仅就该附件检索作答, 并入知识库(不需要可在「上传与解析」删除)")
    submitted = st.button("提问", type="primary", use_container_width=True)

    if submitted and question.strip():
        q = question.strip()
        image_path: Path | None = None
        scope: list[str] | None = doc_ids or None
        is_pdf_attach = attach is not None and Path(attach.name).suffix.lower() == ".pdf"
        ok_to_ask = True
        if attach is not None:
            UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
            suffix = Path(attach.name).suffix or ".png"
            saved = UPLOAD_DIR / f"ask-{uuid.uuid4().hex[:8]}{suffix}"
            saved.write_bytes(attach.getvalue())
            if is_pdf_attach:
                rec = _parse_attachment(inf, saved)
                if rec is None:
                    ok_to_ask = False      # 失败提示已展示, 本轮不作答
                else:
                    scope = [rec.doc_id]   # 仅就该附件检索
            else:
                image_path = saved
        if ok_to_ask:
            with st.spinner("思考中…(多模态问题走 vision 模型)"):
                answer = ask_once(s, q, st.session_state.session_id,
                                  scope, top_k, hist, image_path=image_path)
            # Redis 对话历史由 ask_once 内部负责写入, 这里只维护页面内会话转录
            st.session_state.chat.append({"role": "user", "content": q,
                                          "image": str(image_path) if image_path else ""})
            st.session_state.chat.append({"role": "assistant", "content": answer})
            if is_pdf_attach:
                st.toast(f"附件 {attach.name} 已解析入库, 后续提问也可检索;"
                         f"不需要时在「上传与解析」点 🗑 删除", icon="📎")
            # 不调 st.rerun(): 对话转录在下文同一轮渲染即可, 少一次整页重跑。

    st.subheader("对话")
    if not st.session_state.chat:
        st.info("还没有提问。回答会引用解析出的文档图片(图文混排), 也可上传图片附件提问。")
    for msg in st.session_state.chat:
        with st.chat_message(msg["role"]):
            if msg["role"] == "user":
                st.markdown(msg["content"])
                if msg.get("image"):
                    st.image(msg["image"], width=280)
            else:
                render_answer(msg["content"])


# ============================================================
# 事件流 Tab(等价于 CLI 的 consume 控制台演示)
# ============================================================
@st.fragment(run_every=2)
def event_tab(inf: dict) -> None:
    bus: UiEventBus = inf["bus"]
    if bus.kafka_err:
        st.warning(bus.kafka_err)
    else:
        st.success(f"Kafka 已连接: {inf['s'].kafka_bootstrap} / topic `{inf['s'].kafka_topic}`")
    st.caption("解析状态事件流(本地日志, 与 Kafka 推送同源)")
    with bus.lock:
        evs = list(bus.log)
    if not evs:
        st.info("暂无事件。上传 PDF 后这里会实时滚动解析进度。")
        return
    for ev in reversed(evs[-80:]):
        st.code(ConsoleEventPrinter.format_line(ev), language=None)


# ============================================================
# 页面骨架
# ============================================================
def main() -> None:
    inf = infra()
    s = inf["s"]

    with st.sidebar:
        st.title("📄 docqa 知识库")
        st.caption("MinerU 解析 · Kafka 事件 · Redis 快照 · BM25+GLM 问答")
        st.session_state.setdefault("session_id", "web")
        st.text_input("会话 ID(Redis 对话记录键)", key="session_id")
        st.divider()
        st.markdown("**服务状态**")
        (st.markdown("🟢 Kafka: " + s.kafka_bootstrap) if inf["bus"].kafka
         else st.markdown(f"🔴 Kafka: 不可用\n\n{inf['bus'].kafka_err}"))
        (st.markdown(f"🟢 Redis: {s.redis_host}:{s.redis_port} DB{s.redis_db}")
         if inf["rc"] is not None
         else st.markdown("🔴 Redis: 不可用(快照/历史降级为本地)"))
        st.markdown(f"🤖 LLM: `{s.llm_model}` / 视觉 `{s.llm_multi_model}`")
        st.divider()
        if st.button("🧹 清空当前会话对话"):
            st.session_state.chat = []
            if inf["hist"] is not None:
                try:
                    inf["hist"].clear(st.session_state.session_id)
                except Exception:
                    pass
            st.rerun()

    tab_up, tab_qa, tab_ev = st.tabs(["📄 上传与解析", "💬 智能问答", "🔔 事件流"])
    with tab_up:
        upload_tab(inf)
    with tab_qa:
        qa_tab(inf)
    with tab_ev:
        event_tab(inf)


main()
