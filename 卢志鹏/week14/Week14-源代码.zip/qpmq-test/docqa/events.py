# -*- coding: utf-8 -*-
"""Kafka 事件总线: 事件组装(纯函数) + 生产者 + 控制台消费者(演示后端).

事件 schema: {event_id, version:1, ts, doc_id, file_name, stage: parse|chunk,
              state, progress:{extracted_pages,total_pages}|null, detail}
"""
from __future__ import annotations

import json
import threading
import uuid

from .console import LOG
from .constants import EVENT_VERSION
from .utils import now_iso


def build_event(*, doc_id: str, file_name: str, stage: str, state: str,
                progress: dict | None = None, detail: str = "") -> dict:
    """组装 Kafka 事件(纯函数, 便于测试)."""
    return {
        "event_id": uuid.uuid4().hex,
        "version": EVENT_VERSION,
        "ts": now_iso(),
        "doc_id": doc_id,
        "file_name": file_name,
        "stage": stage,
        "state": state,
        "progress": progress,
        "detail": detail,
    }


class KafkaEventBus:
    """事件生产者: 每次 doc 状态变化发一条 JSON 事件(按 doc_id 做 key, 同文档分区内有序)."""

    def __init__(self, bootstrap: str, topic: str, client_id: str = "docqa"):
        from kafka import KafkaProducer
        self.bootstrap, self.topic = bootstrap, topic
        self._producer = KafkaProducer(
            bootstrap_servers=bootstrap, client_id=client_id,
            acks="all", retries=3, linger_ms=0,
            max_block_ms=5000, request_timeout_ms=15000)

    def ensure_topic(self, partitions: int = 1, replication_factor: int = 1) -> None:
        """best-effort 建 topic; 失败仅警告(依赖 broker auto.create.topics 时也能跑)."""
        try:
            from kafka import KafkaAdminClient
            from kafka.admin import NewTopic
            from kafka.errors import TopicAlreadyExistsError
            admin = KafkaAdminClient(bootstrap_servers=self.bootstrap, client_id="docqa-admin")
            try:
                admin.create_topics([NewTopic(self.topic, partitions, replication_factor)],
                                    timeout_ms=10000)
                LOG.info("已创建 Kafka topic: %s", self.topic)
            except TopicAlreadyExistsError:
                pass
            finally:
                try:
                    admin.close()
                except Exception:
                    pass
        except Exception as e:
            LOG.warning("ensure_topic 失败(继续, 依赖 broker auto.create): %s", e)

    def emit(self, *, doc_id: str, file_name: str, stage: str, state: str,
             progress: dict | None = None, detail: str = "") -> dict:
        ev = build_event(doc_id=doc_id, file_name=file_name, stage=stage,
                         state=state, progress=progress, detail=detail)
        payload = json.dumps(ev, ensure_ascii=False).encode("utf-8")
        self._producer.send(self.topic, key=doc_id.encode("utf-8"), value=payload).get(timeout=10)
        return ev

    def flush_and_close(self) -> None:
        try:
            self._producer.flush(timeout=5)
            self._producer.close(timeout=5)
        except Exception:
            pass


class ConsoleEventPrinter(threading.Thread):
    """演示后端: 订阅 Kafka 事件 topic, 实时打印解析进度到控制台."""

    def __init__(self, bootstrap: str, topic: str, stop_event: threading.Event,
                 ready_event: threading.Event, *, group_id: str | None = None,
                 auto_offset_reset: str = "latest"):
        super().__init__(daemon=True)
        self.bootstrap, self.topic = bootstrap, topic
        self.stop_event, self.ready_event = stop_event, ready_event
        self.group_id = group_id            # None → 每次随机组, 只看启动之后的事件
        self.auto_offset_reset = auto_offset_reset

    def run(self) -> None:
        consumer = None
        try:
            from kafka import KafkaConsumer
            consumer = KafkaConsumer(
                self.topic, bootstrap_servers=self.bootstrap,
                group_id=self.group_id or f"printer-{uuid.uuid4().hex[:6]}",
                auto_offset_reset=self.auto_offset_reset,
                enable_auto_commit=True, consumer_timeout_ms=1500)
            # 单循环消费: 每次 poll 的记录一律处理(分配完成的那次 poll 往往
            # 恰好带回积压事件, 丢弃=丢单); 分区分配完成后才宣告就绪,
            # 保证 latest 模式下 producer 发出的第一条(PENDING)不被漏掉.
            waited, assigned = 0, False
            while not self.stop_event.is_set():
                polled = consumer.poll(timeout_ms=500)
                if not assigned:
                    if consumer.assignment():
                        assigned = True
                        self.ready_event.set()
                    else:
                        waited += 500
                        if waited >= 10000:   # 分配迟迟不下来, 放弃等待但继续消费
                            assigned = True
                            self.ready_event.set()
                for _tp, records in polled.items():
                    for rec in records:
                        try:
                            ev = json.loads(rec.value.decode("utf-8"))
                        except Exception:
                            continue
                        print(self.format_line(ev), flush=True)
        except Exception as e:
            if not self.stop_event.is_set():
                LOG.error("Kafka 消费者异常退出: %s", e)
        finally:
            if consumer is not None:
                try:
                    consumer.close()
                except Exception:
                    pass
            self.ready_event.set()

    @staticmethod
    def format_line(ev: dict) -> str:
        ts = str(ev.get("ts", ""))[11:19] or "--:--:--"
        prog = ev.get("progress") or {}
        extra = ""
        if prog.get("total_pages"):
            extra = f" {prog.get('extracted_pages', 0)}/{prog['total_pages']}"
        if ev.get("detail"):
            extra += f" | {ev['detail']}"
        return (f"[{ts}] [{ev.get('stage', '?')}] {ev.get('file_name', '?')} "
                f"{ev.get('state', '?')}{extra}")
