# -*- coding: utf-8 -*-
"""解析流水线编排: 上传→轮询→下载→(图片识别→分块→摘要→建索引).

Kafka 事件 + Redis 快照双写: Kafka 不可达视为致命(broker 是演示链路核心),
Redis 不可达降级为仅 Kafka(快照丢失但流程继续).
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from kafka.errors import KafkaError

from .chunking import Chunker, build_heading_tree, headings_to_json
from .config import PROJECT_ROOT, Settings
from .console import LOG, cprint
from .constants import (STAGE_CHUNK, STAGE_PARSE, ST_DONE, ST_FAILED,
                        ST_PARSING, ST_PENDING)
from .events import KafkaEventBus
from .llm import analyze_images, get_llm_service, summarize_chunks
from .mineru import MinerUClient, MinerUError, find_content_list
from .retrieval import BM25Index
from .stores import DocStateStore
from .utils import atomic_write_json, new_doc_id, now_iso


@dataclass
class DocRecord:
    doc_id: str
    file_name: str
    pdf_path: str
    batch_id: str = ""
    state: str = ST_PENDING
    stage: str = STAGE_PARSE
    extracted_pages: int = 0
    total_pages: int = 0
    err_msg: str = ""
    chunks_count: int = 0
    created_at: str = field(default_factory=now_iso)

    def to_mapping(self) -> dict:
        return {
            "doc_id": self.doc_id,
            "file_name": self.file_name, "pdf_path": self.pdf_path,
            "batch_id": self.batch_id, "stage": self.stage, "state": self.state,
            "extracted_pages": self.extracted_pages, "total_pages": self.total_pages,
            "err_msg": self.err_msg, "chunks_count": self.chunks_count,
            "created_at": self.created_at, "updated_at": now_iso(),
        }


class ParsePipeline:
    """上传→轮询→下载→分块建索引; Kafka 事件 + Redis 快照双写(Redis 不可用则只走 Kafka)."""

    def __init__(self, settings: Settings, mineru: MinerUClient, bus: KafkaEventBus,
                 store: DocStateStore | None,
                 on_event: Callable[[dict], None] | None = None):
        self.s, self.mineru, self.bus, self.store = settings, mineru, bus, store
        self.on_event = on_event     # 每次事件发出后同步回调(Web 附件解析刷 st.status 用)
        self.docs: list[DocRecord] = []
        self._redis_warned = False

    def emit(self, **kw) -> dict:
        """bus.emit + 进度回调; 回调异常吞掉(展示层故障不能影响解析主流程)."""
        ev = self.bus.emit(**kw)
        if self.on_event is not None:
            try:
                self.on_event(ev)
            except Exception:
                LOG.warning("on_event 回调失败(忽略)", exc_info=True)
        return ev

    def _redis(self, fn: Callable) -> None:
        if self.store is None:
            return
        try:
            fn()
        except Exception as e:
            if not self._redis_warned:
                LOG.warning("Redis 不可用, 状态快照降级(仅 Kafka): %s", e)
                self._redis_warned = True

    def _snapshot(self, doc: DocRecord, **extra) -> None:
        fields = dict(stage=doc.stage, state=doc.state, err_msg=doc.err_msg,
                      extracted_pages=doc.extracted_pages, total_pages=doc.total_pages,
                      chunks_count=doc.chunks_count, **extra)
        self._redis(lambda: self.store.update(doc.doc_id, **fields))

    def _fail_doc(self, doc: DocRecord, msg: str) -> None:
        """单文档失败终态: 状态+快照+FAILED 事件(事件发送失败不掩盖原始错误)."""
        doc.state, doc.err_msg = ST_FAILED, msg
        cprint("失败", f"{doc.file_name}: {msg}", "red")
        self._snapshot(doc)
        try:
            self.emit(doc_id=doc.doc_id, file_name=doc.file_name,
                          stage=doc.stage, state=ST_FAILED, detail=msg[:200])
        except Exception:
            pass

    def upload_and_track(self, pdf_paths: list[Path]) -> list[DocRecord]:
        docs: list[DocRecord] = []
        for p in pdf_paths:
            MinerUClient.check_local_pdf(p)
            docs.append(DocRecord(doc_id=new_doc_id(p), file_name=p.name,
                                  pdf_path=str(p.resolve())))
        self.docs = docs
        names = [d.file_name for d in docs]
        dupes = sorted({n for n in names if names.count(n) > 1})
        if dupes:
            raise MinerUError(f"同批文件名重复 {dupes}: MinerU 结果按文件名匹配会串扰, "
                              f"请重命名后分批上传")
        try:
            return self._upload_and_track_inner(docs)
        except KafkaError as e:
            for d in docs:  # broker 中途掉线: 所有未到终态的文档补 FAILED 终态
                if d.state not in (ST_DONE, ST_FAILED):
                    self._fail_doc(d, f"Kafka 不可达: {e}")
            raise

    def _upload_and_track_inner(self, docs: list[DocRecord]) -> list[DocRecord]:
        batch_id, urls = self.mineru.create_batch([(d.file_name, d.doc_id) for d in docs])
        for d in docs:
            d.batch_id = batch_id
        # 1) 待解析
        for d in docs:
            self.emit(doc_id=d.doc_id, file_name=d.file_name, stage=STAGE_PARSE,
                          state=ST_PENDING, detail=f"doc_id={d.doc_id}")
            self._redis(lambda d=d: self.store.init_doc(d))
        # 2) 上传文件(MinerU 上传完成后自动创建解析任务); 单个失败只影响该文档
        for d, url in zip(docs, urls):
            try:
                self.mineru.upload_file(url, Path(d.pdf_path))
                LOG.info("已上传 %s (doc_id=%s)", d.file_name, d.doc_id)
            except Exception as e:
                self._fail_doc(d, f"上传失败: {e}")
        alive = [d for d in docs if d.state != ST_FAILED]
        for d in alive:
            d.state = ST_PARSING
            self.emit(doc_id=d.doc_id, file_name=d.file_name, stage=STAGE_PARSE,
                          state=ST_PARSING, detail="已提交解析")
            self._snapshot(d, batch_id=d.batch_id)
        # 3) 轮询(状态 diff, 页码变化才发事件; 瞬时网络错误等下一轮)
        pending = {d.doc_id: d for d in alive}
        done_docs: list[DocRecord] = []
        deadline = time.time() + self.s.parse_timeout_sec
        while pending and time.time() < deadline:
            try:
                results = self.mineru.poll_batch(batch_id)
            except Exception as e:
                LOG.warning("轮询请求失败(等待下一轮): %s", e)
                results = None
            if results is not None:
                by_key = {}
                for r in results:
                    by_key[r.get("data_id") or r.get("file_name")] = r
                for doc in list(pending.values()):
                    r = by_key.get(doc.doc_id) or by_key.get(doc.file_name)
                    if not r:
                        continue
                    st = r.get("state", "")
                    if st == "running":
                        prog = r.get("extract_progress") or {}
                        ep = int(prog.get("extracted_pages", 0) or 0)
                        tp = int(prog.get("total_pages", 0) or 0)
                        if tp and (ep, tp) != (doc.extracted_pages, doc.total_pages):
                            doc.extracted_pages, doc.total_pages = ep, tp
                            self.emit(doc_id=doc.doc_id, file_name=doc.file_name,
                                          stage=STAGE_PARSE, state=ST_PARSING,
                                          progress={"extracted_pages": ep, "total_pages": tp})
                            self._snapshot(doc)
                    elif st == "done":
                        zip_url = r.get("full_zip_url", "")
                        try:
                            self.mineru.download_and_extract(zip_url,
                                                             self.s.data_dir / doc.doc_id)
                            doc.state, doc.stage = ST_DONE, STAGE_PARSE
                            self.emit(doc_id=doc.doc_id, file_name=doc.file_name,
                                          stage=STAGE_PARSE, state=ST_DONE,
                                          detail="解析完毕, 结果已下载")
                            self._snapshot(doc)
                            done_docs.append(doc)
                        except Exception as e:
                            self._fail_doc(doc, f"下载失败: {e}")
                        pending.pop(doc.doc_id)
                    elif st == "failed":
                        self._fail_doc(doc, r.get("err_msg", "") or "unknown")
                        pending.pop(doc.doc_id)
            if pending:
                time.sleep(self.s.poll_interval_sec)
        for doc in pending.values():  # 超时
            self._fail_doc(doc, "轮询超时")
        return done_docs

    def chunk_and_index(self, doc: DocRecord) -> int:
        base = self.s.data_dir / doc.doc_id
        doc.stage = STAGE_CHUNK
        try:
            self.emit(doc_id=doc.doc_id, file_name=doc.file_name, stage=STAGE_CHUNK,
                          state=ST_PARSING, detail="图片识别/分块/摘要")
            doc.state = ST_PARSING
            self._snapshot(doc)
            content_list = json.loads(
                find_content_list(base).read_text(encoding="utf-8"))
            nodes, root_ids, images = build_heading_tree(
                content_list, doc.doc_id, doc.file_name, self.s.heading_min_level)
            llm = get_llm_service(self.s)
            ok, fail = analyze_images(list(images.values()), llm, base, self.s.llm_workers)
            chunks_obj = Chunker(self.s).chunk(doc.doc_id, doc.file_name,
                                               nodes, root_ids, images)
            summarize_chunks(chunks_obj["chunks"], llm, self.s.llm_workers)
            atomic_write_json(base / "chunks.json", chunks_obj)
            atomic_write_json(base / "headings.json",
                              headings_to_json(doc.doc_id, doc.file_name, nodes))
            BM25Index._cache.clear()  # 新文档入池, 失效旧索引缓存
            doc.state, doc.chunks_count = ST_DONE, len(chunks_obj["chunks"])
            self.emit(doc_id=doc.doc_id, file_name=doc.file_name, stage=STAGE_CHUNK,
                          state=ST_DONE,
                          detail=f"{doc.chunks_count} chunks, 图片识别 {ok}成功/{fail}失败")
            self._snapshot(doc)
            return doc.chunks_count
        except Exception as e:
            doc.state, doc.err_msg = ST_FAILED, str(e)
            LOG.exception("分块失败 %s", doc.doc_id)
            self._snapshot(doc)
            try:
                self.emit(doc_id=doc.doc_id, file_name=doc.file_name, stage=STAGE_CHUNK,
                              state=ST_FAILED, detail=str(e)[:200])
            except Exception:
                pass
            return 0


def remove_doc(doc_id: str, settings: Settings, store: DocStateStore | None,
               project_root: Path | None = None) -> dict:
    """删除单个文档的全部痕迹: data/{doc_id}/ 目录 + Redis 快照 + uploads 暂存副本.

    - 用户原始 PDF(uploads/ 之外, 如 samples/)一律不动, 只删 Web 上传的暂存副本
    - BM25 进程内缓存失效(常驻进程如 Web 需要重建索引)
    - Kafka topic 是只追加日志, 历史事件保留(事件流回放仍可见, 属正常)
    返回报告: {doc_id, existed, data_dir, redis, staged_pdf}
    """
    root = Path(project_root) if project_root else PROJECT_ROOT
    base = settings.data_dir / doc_id
    rec = None
    if store is not None:
        try:
            rec = store.get(doc_id)
        except Exception as e:
            LOG.warning("读取 Redis 快照失败(忽略): %s", e)
    pdf_path = (rec or {}).get("pdf_path", "")

    report = {"doc_id": doc_id, "existed": base.exists() or rec is not None,
              "data_dir": False, "redis": False, "staged_pdf": ""}
    if base.exists():
        shutil.rmtree(base, ignore_errors=True)
        report["data_dir"] = True
    if pdf_path:
        p = Path(pdf_path)
        try:
            if p.exists() and p.resolve().is_relative_to((root / "uploads").resolve()):
                p.unlink()
                report["staged_pdf"] = str(p)
        except OSError as e:
            LOG.warning("删除暂存 PDF 失败(忽略): %s", e)
    if store is not None:
        try:
            store.remove(doc_id)
            report["redis"] = True
        except Exception as e:
            LOG.warning("删除 Redis 记录失败: %s", e)
    BM25Index._cache.clear()
    return report
