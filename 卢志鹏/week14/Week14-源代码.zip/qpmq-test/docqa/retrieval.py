# -*- coding: utf-8 -*-
"""BM25 检索索引: jieba(lcut_for_search) + rank_bm25, 进程内懒构建按 doc 集合缓存."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, ClassVar


class BM25Index:
    """进程内懒构建的 BM25 检索索引(按 doc_id 集合缓存, 不持久化)."""

    _cache: ClassVar[dict[frozenset, "BM25Index"]] = {}

    def __init__(self, entries: list[dict]):
        import jieba
        from rank_bm25 import BM25Okapi
        self._jieba = jieba
        tokenized = [(e, self._tokenize(jieba, e.get("search_text", ""))) for e in entries]
        tokenized = [(e, t) for e, t in tokenized if t]
        self.entries = [e for e, _ in tokenized]
        self._corpus = [t for _, t in tokenized]
        self._bm25 = BM25Okapi(self._corpus) if self._corpus else None

    @staticmethod
    def _tokenize(jieba: Any, text: str) -> list[str]:
        return [t for t in jieba.lcut_for_search(text) if any(c.isalnum() for c in t)]

    @classmethod
    def load(cls, data_dir: Path, doc_ids: list[str] | None = None) -> "BM25Index":
        key = frozenset(doc_ids) if doc_ids else frozenset(["*"])
        cached = cls._cache.get(key)
        if cached is not None:
            return cached
        dirs = ([data_dir / d for d in doc_ids] if doc_ids
                else sorted(p for p in data_dir.glob("*") if p.is_dir()))
        entries: list[dict] = []
        for d in dirs:
            cf = d / "chunks.json"
            if not cf.exists():
                continue
            obj = json.loads(cf.read_text("utf-8"))
            for c in obj.get("chunks", []):
                entries.append({
                    "search_text": " / ".join(c.get("heading_path_text", []))
                    + "\n" + c.get("summary", "") + "\n" + c.get("text", ""),
                    "chunk": c,
                })
        if not entries:
            raise RuntimeError("尚无已完成的文档分块, 请先执行 upload")
        idx = cls(entries)
        cls._cache[key] = idx
        return idx

    def search(self, query: str, top_k: int = 5) -> list[tuple[float, dict]]:
        if not self._bm25:
            return []
        tokens = self._tokenize(self._jieba, query)   # 与语料同分词器, 保证粒度一致
        if not tokens:
            return []
        scores = self._bm25.get_scores(tokens)
        order = sorted(range(len(scores)), key=lambda i: -scores[i])[:top_k]
        # 非零分=有词条命中: rank_bm25 在词条命中全部文档时 idf 为负(小语料常见),
        # 负分不代表不相关, 零分才是未命中.
        return [(float(scores[i]), self.entries[i]["chunk"])
                for i in order if abs(scores[i]) > 1e-9]
