# -*- coding: utf-8 -*-
"""标题树与分块: MinerU content_list → 标题树 → 512字节(UTF-8)+Overlap 文本块.

输出契约(与 retrieval.QA 消费方对齐):
    chunks.json    文本块数组(heading/text 两类, 含 heading_path_ids/summary/images)
    headings.json  标题树扁平序列化(含虚拟根 h0, 按 id 可回溯完整父标题块)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .config import Settings
from .constants import EVENT_VERSION
from .utils import hard_split_bytes, now_iso, utf8len


def html_table_to_text(html: str) -> str:
    """HTML 表格 → 纯文本: 行内单元格用 ' | ' 分隔."""
    if not html:
        return ""
    s = re.sub(r"(?i)</(td|th)>", " | ", html)
    s = re.sub(r"(?i)</tr>", "\n", s)
    s = re.sub(r"(?i)<br\s*/?>", "\n", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"[ \t]+", " ", s)
    lines = [ln.strip().rstrip("|").strip() for ln in s.splitlines()]
    return "\n".join(ln for ln in lines if ln)


@dataclass
class HeadingNode:
    """标题树节点. level 0 为虚拟根(整篇文档)."""
    id: str
    level: int
    title: str
    parent_id: str | None
    page_idx: int = 0
    child_ids: list[str] = field(default_factory=list)
    body_parts: list[str] = field(default_factory=list)   # 直属正文/表格文本(不含子标题)
    body_pages: list[int] = field(default_factory=list)   # 直属内容所在页(0-based)
    image_keys: list[str] = field(default_factory=list)

    def own_text(self) -> str:
        return "\n\n".join(p for p in self.body_parts if p and p.strip()).strip()

    def pages(self) -> tuple[int, int]:
        pages = self.body_pages or [self.page_idx]
        return min(pages), max(pages)

    def path_ids(self, nodes: dict[str, "HeadingNode"]) -> list[str]:
        chain, cur = [], self
        while cur is not None:
            chain.append(cur.id)
            cur = nodes.get(cur.parent_id) if cur.parent_id else None
        return list(reversed(chain))

    def path_text(self, nodes: dict[str, "HeadingNode"]) -> list[str]:
        chain, cur = [], self
        while cur is not None:
            chain.append(cur.title)
            cur = nodes.get(cur.parent_id) if cur.parent_id else None
        return list(reversed(chain))


def build_heading_tree(content_list: list[dict], doc_id: str, file_name: str,
                       min_level: int = 5) -> tuple[dict[str, HeadingNode], list[str], dict[str, dict]]:
    """MinerU content_list → (标题节点表, 根节点直属子标题id列表, 图片条目表).

    - text 且 1<=text_level<=min_level: 建标题节点(栈维护层级)
    - text 无 text_level 或 text_level>min_level: 归入栈顶正文
    - table: caption + 表格文本归正文; equation: 归正文
    - image/chart: 登记图片条目(img_key), 挂到栈顶节点
    - header/footer/page_number/page_footnote 等页眉页脚噪声: 忽略
    - 无标题文档: 全部内容挂虚拟根 h0
    """
    root = HeadingNode(id="h0", level=0, title=file_name, parent_id=None)
    nodes: dict[str, HeadingNode] = {"h0": root}
    images: dict[str, dict] = {}
    stack: list[HeadingNode] = [root]
    seq = 0

    def add_body(node: HeadingNode, text: str, page_idx: int) -> None:
        if text and text.strip():
            node.body_parts.append(text.strip())
            node.body_pages.append(page_idx)

    for item in content_list:
        itype = item.get("type", "")
        page_idx = int(item.get("page_idx", 0) or 0)
        if itype == "text":
            level = item.get("text_level")
            text = str(item.get("text", "") or "")
            if isinstance(level, int) and 1 <= level <= min_level and text.strip():
                while stack[-1].level >= level:
                    stack.pop()
                seq += 1
                node = HeadingNode(
                    id=f"h{seq:06d}", level=level, title=text.strip(),
                    parent_id=stack[-1].id, page_idx=page_idx)
                nodes[node.id] = node
                stack[-1].child_ids.append(node.id)
                stack.append(node)
            else:
                add_body(stack[-1], text, page_idx)
        elif itype == "table":
            caption = " ".join(item.get("table_caption") or [])
            table_text = html_table_to_text(str(item.get("table_body", "") or ""))
            add_body(stack[-1], f"{caption}\n{table_text}" if caption else table_text, page_idx)
        elif itype == "equation":
            add_body(stack[-1], str(item.get("text", "") or ""), page_idx)
        elif itype == "list":                       # 参考文献等列表: 逐条拼正文
            lines = "\n".join(str(x) for x in (item.get("list_items") or []))
            add_body(stack[-1], lines or str(item.get("text", "") or ""), page_idx)
        elif itype in ("image", "chart"):           # chart(统计图)同样走多模态识别
            seq_img = len(images) + 1
            key = f"img{seq_img:06d}"
            img_path = str(item.get("img_path", "") or "")
            cap_src = item.get("img_caption") or item.get("chart_caption") \
                or item.get("chart_footnote") or []
            caption = " ".join(str(c) for c in cap_src)
            images[key] = {
                "img_key": key,
                "img_path": img_path,                       # 相对 data/{doc_id}/
                "rel_path": f"data/{doc_id}/{img_path}".replace("\\", "/") if img_path else "",
                "caption": caption,
                "page_idx": page_idx,
                "analysis": "",                             # 多模态识别结果(专门字段)
                "status": "pending",
            }
            stack[-1].image_keys.append(key)
        # 其它类型忽略
    return nodes, list(root.child_ids), images


class Chunker:
    """标题树 → 文本块: 叶子标题块内按 chunk_size_bytes(UTF-8字节)切分 + overlap."""

    def __init__(self, settings: Settings):
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        self.s = settings
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.chunk_size_bytes,
            chunk_overlap=settings.chunk_overlap_bytes,
            length_function=utf8len,          # size 与 overlap 都按 UTF-8 字节度量
            separators=["\n\n", "\n", "。", "；", "，", " ", ""],
            keep_separator=True,
            strip_whitespace=True,
        )

    def chunk(self, doc_id: str, file_name: str, nodes: dict[str, HeadingNode],
              root_ids: list[str], images: dict[str, dict]) -> dict:
        chunks: list[dict] = []
        counter = {"n": 0}

        def node_images(node: HeadingNode) -> list[dict]:
            return [dict(images[k]) for k in node.image_keys if k in images]

        def emit(node: HeadingNode, ctype: str, text: str) -> None:
            if not text or not text.strip():
                return
            counter["n"] += 1
            page_start, page_end = node.pages()
            chunks.append({
                "chunk_id": f"{doc_id}-c{counter['n']:06d}",
                "doc_id": doc_id,
                "type": ctype,
                "text": text,
                "heading_id": node.id,
                "heading_path_ids": node.path_ids(nodes),
                "heading_path_text": node.path_text(nodes),
                "page_start": page_start,
                "page_end": page_end,
                "summary": "",                 # LLM 摘要, 后续填充
                "images": node_images(node),
            })

        def split_own(node: HeadingNode) -> None:
            own = node.own_text()
            if not own:
                return
            for part in self.splitter.split_text(own):
                if utf8len(part) > self.s.chunk_size_bytes:      # 兜底: 无分隔符超长片段
                    for piece in hard_split_bytes(part, self.s.chunk_size_bytes,
                                                 self.s.chunk_overlap_bytes):
                        emit(node, "text", piece)
                else:
                    emit(node, "text", part)

        def walk(node_id: str) -> None:
            node = nodes[node_id]
            if node.level >= 1:
                head = " > ".join(node.path_text(nodes))
                for k in node.image_keys:
                    e = images.get(k, {})
                    if e.get("caption") or e.get("analysis"):
                        head += f"\n[图] {e.get('caption', '')} {e.get('analysis', '')}".rstrip()
                emit(node, "heading", head)
            split_own(node)
            for cid in node.child_ids:
                walk(cid)

        # 虚拟根直属正文(文档前言)最先, 再按文档顺序 DFS
        root = nodes["h0"]
        split_own(root)
        for rid in root_ids:
            walk(rid)

        return {
            "doc_id": doc_id,
            "file_name": file_name,
            "version": EVENT_VERSION,
            "created_at": now_iso(),
            "chunk_size_bytes": self.s.chunk_size_bytes,
            "chunk_overlap_bytes": self.s.chunk_overlap_bytes,
            "chunks": chunks,
        }


def headings_to_json(doc_id: str, file_name: str, nodes: dict[str, HeadingNode]) -> dict:
    """标题树序列化: 扁平数组, 通过 id/parent_id/child_ids 可找回任意完整父标题块."""
    return {
        "doc_id": doc_id,
        "file_name": file_name,
        "version": EVENT_VERSION,
        "created_at": now_iso(),
        "nodes": [
            {
                "id": n.id,
                "level": n.level,
                "title": n.title,
                "parent_id": n.parent_id,
                "child_ids": n.child_ids,
                "page_idx": n.page_idx,
                "path_ids": n.path_ids(nodes),
                "path_text": n.path_text(nodes),
                "own_text": n.own_text(),
                "image_keys": n.image_keys,
            }
            for n in nodes.values()   # 含虚拟根 h0(level=0): chunks 的
            # heading_path_ids 均以 h0 开头, 不写入则路径回溯断裂
        ],
    }
