# -*- coding: utf-8 -*-
"""配置: 项目根定位 + Settings(.env 可覆盖, 代码内默认值兜底) + 校验."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# docqa/config.py → docqa/ → 项目根(qpmq-test/)
PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _env_str(name: str, default: str = "") -> str:
    v = os.getenv(name)
    return v if v not in (None, "") else default


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, "").strip() or default)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    """全部配置项; .env 可覆盖, 代码内默认值兜底."""
    mineru_token: str = ""
    llm_api_key: str = ""
    llm_base_url: str = "https://open.bigmodel.cn/api/coding/paas/v4"
    llm_model: str = "glm-5.3"
    llm_multi_model: str = "glm-5.3-flash"
    kafka_bootstrap: str = "192.168.1.228:39092"
    kafka_topic: str = "qpmq.doc.events"
    redis_host: str = "192.168.1.228"
    redis_port: int = 6379
    redis_db: int = 6
    data_dir: Path = field(default_factory=lambda: PROJECT_ROOT / "data")
    chunk_size_bytes: int = 512
    chunk_overlap_bytes: int = 64
    heading_min_level: int = 5
    mineru_model_version: str = "pipeline"
    mineru_language: str = "ch"
    poll_interval_sec: int = 5
    parse_timeout_sec: int = 900
    llm_workers: int = 6
    image_max_side: int = 1600
    image_jpeg_quality: int = 85
    top_k: int = 5
    history_window: int = 12

    @classmethod
    def load(cls, env_file: Path | None = None) -> "Settings":
        load_dotenv(env_file or (PROJECT_ROOT / ".env"), override=False)
        data_dir = Path(_env_str("DATA_DIR", "data"))
        if not data_dir.is_absolute():
            data_dir = PROJECT_ROOT / data_dir
        return cls(
            mineru_token=_env_str("MINER_U_API_TOKEN"),
            llm_api_key=_env_str("LLM_API_KEY") or _env_str("MINER_U_API_TOKEN"),
            llm_base_url=_env_str("LLM_BASE_URL"),
            llm_model=_env_str("LLM_MODEL"),
            llm_multi_model=_env_str("LLM_MULTI_MODEL"),
            kafka_bootstrap=_env_str("KAFKA_BOOTSTRAP"),
            kafka_topic=_env_str("KAFKA_TOPIC"),
            redis_host=_env_str("REDIS_HOST"),
            redis_port=_env_int("REDIS_PORT", 6379),
            redis_db=_env_int("REDIS_DB", 6),
            data_dir=data_dir,
            chunk_size_bytes=_env_int("CHUNK_SIZE_BYTES", 512),
            chunk_overlap_bytes=_env_int("CHUNK_OVERLAP_BYTES", 64),
            heading_min_level=_env_int("HEADING_MIN_LEVEL", 5),
            mineru_model_version=_env_str("MINERU_MODEL_VERSION", "pipeline"),
            mineru_language=_env_str("MINERU_LANGUAGE", "ch"),
            poll_interval_sec=_env_int("POLL_INTERVAL_SEC", 5),
            parse_timeout_sec=_env_int("PARSE_TIMEOUT_SEC", 900),
            llm_workers=_env_int("LLM_WORKERS", 6),
            image_max_side=_env_int("IMAGE_MAX_SIDE", 1600),
            image_jpeg_quality=_env_int("IMAGE_JPEG_QUALITY", 85),
            top_k=_env_int("TOP_K", 5),
            history_window=_env_int("HISTORY_WINDOW", 12),
        )

    def validate(self) -> None:
        if not self.mineru_token:
            raise ValueError(".env 缺少 MINER_U_API_TOKEN")
        if not self.llm_api_key:
            raise ValueError(".env 缺少 LLM_API_KEY(或 MINER_U_API_TOKEN 兜底)")
        if not self.llm_base_url or not self.llm_model:
            raise ValueError(".env 缺少 LLM_BASE_URL / LLM_MODEL")
        if self.redis_db != 6:
            raise ValueError(f"REDIS_DB 必须为 6, 当前 {self.redis_db}")
        if not 0 <= self.chunk_overlap_bytes < self.chunk_size_bytes:
            raise ValueError(
                f"CHUNK_OVERLAP_BYTES({self.chunk_overlap_bytes}) 必须 < CHUNK_SIZE_BYTES({self.chunk_size_bytes})")
        if not 1 <= self.heading_min_level <= 5:
            raise ValueError("HEADING_MIN_LEVEL 必须在 1~5")
