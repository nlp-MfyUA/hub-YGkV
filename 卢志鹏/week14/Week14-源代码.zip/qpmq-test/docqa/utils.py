# -*- coding: utf-8 -*-
"""通用工具: 时间/doc_id/原子写 JSON/重试装饰器/字节硬切."""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Any, Callable

from .console import LOG


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def utf8len(s: str) -> int:
    return len(s.encode("utf-8"))


def new_doc_id(pdf_path: str | Path) -> str:
    stem = Path(pdf_path).stem
    safe = re.sub(r"[^\w]+", "-", stem, flags=re.UNICODE).strip("-") or "doc"
    return f"{safe}-{uuid.uuid4().hex[:8]}"


def atomic_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def retry(times: int = 3, delay: float = 2.0, exceptions: tuple = (Exception,)) -> Callable:
    """简单重试装饰器, 用于 zip 下载等瞬态失败."""
    def deco(fn: Callable) -> Callable:
        @wraps(fn)
        def wrapper(*args, **kwargs):
            last: Exception | None = None
            for attempt in range(1, times + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:  # noqa: PERF203
                    last = e
                    if attempt < times:
                        LOG.warning("重试 %s 第%s次失败: %s", fn.__name__, attempt, e)
                        time.sleep(delay * attempt)
            raise last  # type: ignore[misc]
        return wrapper
    return deco


def hard_split_bytes(text: str, size: int, overlap: int = 0) -> list[str]:
    """兜底硬切: 按 UTF-8 字节限制切分, 逐字符累加保证不切断多字节字符.

    相邻块之间携带 ≤overlap 字节的尾部作为下一块开头; overlap=0 时无损重组.
    """
    if overlap < 0 or overlap >= size:
        raise ValueError("overlap 必须满足 0 <= overlap < size")
    if utf8len(text) <= size:
        return [text] if text else []
    parts: list[str] = []
    cur: list[str] = []
    cur_bytes = 0
    for ch in text:
        b = len(ch.encode("utf-8"))
        if cur and cur_bytes + b > size:
            parts.append("".join(cur))
            tail: list[str] = []
            tail_bytes = 0
            for c in reversed(cur):
                cb = len(c.encode("utf-8"))
                if tail_bytes + cb > overlap:
                    break
                tail.insert(0, c)
                tail_bytes += cb
            cur, cur_bytes = tail, tail_bytes
        cur.append(ch)
        cur_bytes += b
    if cur:
        parts.append("".join(cur))
    return parts
