# -*- coding: utf-8 -*-
"""控制台与日志: stdout/stderr UTF-8 化, 进程级 logger, 彩色打印."""
from __future__ import annotations

import logging
import sys


def setup_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def get_logger(name: str = "docqa") -> logging.Logger:
    lg = logging.getLogger(name)
    if not lg.handlers:
        h = logging.StreamHandler(sys.stderr)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S"))
        lg.addHandler(h)
        lg.setLevel(logging.INFO)
    return lg


LOG = get_logger()


def cprint(tag: str, msg: str, color: str = "") -> None:
    codes = {"green": "32", "yellow": "33", "red": "31", "cyan": "36", "": "0"}
    print(f"\033[{codes.get(color, '0')}m[{tag}]\033[0m {msg}", flush=True)
