# -*- coding: utf-8 -*-
"""Redis 存储(必须 DB 6): 文档状态快照(HASH+SET 索引) + 对话记录(LIST 滚动窗口).

Key 布局:
    doc:{doc_id}   HASH  文档状态快照(DocRecord.to_mapping)
    docs:index     SET   文档清单
    chat:{session} LIST  元素 {"role","content","ts"} JSON, LTRIM 保留最近 window 条
"""
from __future__ import annotations

import json
from typing import TYPE_CHECKING

from .config import Settings
from .utils import now_iso

if TYPE_CHECKING:  # 仅类型标注用, 避免循环导入
    from .pipeline import DocRecord


def make_redis(settings: Settings):
    import redis as redis_mod
    return redis_mod.Redis(
        host=settings.redis_host, port=settings.redis_port, db=settings.redis_db,
        decode_responses=True, socket_connect_timeout=4, socket_timeout=4)


class DocStateStore:
    """文档状态快照(Redis HASH): doc:{doc_id} + docs:index(SET)."""

    INDEX_KEY = "docs:index"

    def __init__(self, client):
        self.c = client

    @staticmethod
    def key(doc_id: str) -> str:
        return f"doc:{doc_id}"

    def init_doc(self, doc: "DocRecord") -> None:
        pipe = self.c.pipeline()
        pipe.hset(self.key(doc.doc_id), mapping=doc.to_mapping())
        pipe.sadd(self.INDEX_KEY, doc.doc_id)
        pipe.execute()

    def update(self, doc_id: str, **fields) -> dict | None:
        fields.setdefault("updated_at", now_iso())
        self.c.hset(self.key(doc_id), mapping={k: str(v) for k, v in fields.items()})
        return self.get(doc_id)

    def get(self, doc_id: str) -> dict | None:
        h = self.c.hgetall(self.key(doc_id))
        return h or None

    def list_docs(self) -> list[dict]:
        ids = sorted(self.c.smembers(self.INDEX_KEY))
        return [d for d in (self.get(i) for i in ids) if d]

    def remove(self, doc_id: str) -> None:
        """删除文档快照: HASH + 索引成员."""
        pipe = self.c.pipeline()
        pipe.delete(self.key(doc_id))
        pipe.srem(self.INDEX_KEY, doc_id)
        pipe.execute()


class ChatHistoryStore:
    """对话记录(Redis LIST): chat:{session_id}, 元素为 JSON, 滚动窗口保留最近 window 条."""

    def __init__(self, client, window: int = 12):
        self.c, self.window = client, window

    @staticmethod
    def key(session_id: str) -> str:
        return f"chat:{session_id}"

    def append(self, session_id: str, role: str, content: str) -> None:
        entry = json.dumps({"role": role, "content": content, "ts": now_iso()},
                           ensure_ascii=False)
        pipe = self.c.pipeline()
        pipe.rpush(self.key(session_id), entry)
        pipe.ltrim(self.key(session_id), -self.window, -1)
        pipe.execute()

    def recent(self, session_id: str, n: int | None = None) -> list[dict]:
        n = n or self.window
        items = self.c.lrange(self.key(session_id), -n, -1)
        return [json.loads(x) for x in items]

    def all(self, session_id: str) -> list[dict]:
        return [json.loads(x) for x in self.c.lrange(self.key(session_id), 0, -1)]

    def clear(self, session_id: str) -> None:
        self.c.delete(self.key(session_id))
