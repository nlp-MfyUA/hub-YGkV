# -*- coding: utf-8 -*-
"""LLM 服务: ChatOpenAI(GLM OpenAI 兼容端点) + 图片压缩/dataURI + 并发图片识别/块摘要."""
from __future__ import annotations

import base64
import io
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from .config import Settings
from .console import LOG


def compress_image(path: Path, max_side: int = 1600, quality: int = 85) -> tuple[bytes, str]:
    """图片压缩为 JPEG 字节(多模态输入用), 长边不超过 max_side."""
    from PIL import Image
    with Image.open(path) as im:
        if im.mode != "RGB":
            im = im.convert("RGB")
        im.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=quality)
        return buf.getvalue(), "image/jpeg"


def make_data_uri(path: Path, max_side: int = 1600, quality: int = 85) -> str:
    """本地图片 → 压缩 JPEG 的 base64 data URI(多模态输入/附件共用)."""
    data, mime = compress_image(path, max_side, quality)
    return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")


class LLMService:
    """ChatOpenAI 走 bigmodel(OpenAI 兼容)端点; 实例线程安全, 进程内复用."""

    def __init__(self, settings: Settings):
        from langchain_openai import ChatOpenAI
        self.s = settings
        common = dict(api_key=settings.llm_api_key, base_url=settings.llm_base_url)
        self.text_llm = ChatOpenAI(model=settings.llm_model, temperature=0.2,
                                   timeout=60, max_retries=2, **common)
        self.vision_llm = ChatOpenAI(model=settings.llm_multi_model, temperature=0.0,
                                     timeout=90, max_retries=1, **common)

    @staticmethod
    def _content_str(content: Any) -> str:
        if isinstance(content, list):  # GLM 偶发多段 content
            return "".join(p.get("text", "") for p in content if isinstance(p, dict)).strip()
        return str(content or "").strip()

    def chat(self, messages: list) -> str:
        return self._content_str(self.text_llm.invoke(messages).content)

    def summarize(self, text: str, title_path: str = "") -> str:
        prompt = ("用一句中文(不超过40字)概括下面文档片段的主要内容, 直接输出摘要本身, 不要任何前缀.\n"
                  f"标题路径: {title_path}\n\n片段内容:\n{text[:1500]}")
        return self.chat([{"role": "user", "content": prompt}])

    def describe_image(self, image_path: Path) -> str:
        """多模态模型识别单张本地图片(压缩→base64 data URI)."""
        from langchain_core.messages import HumanMessage
        uri = make_data_uri(image_path, self.s.image_max_side, self.s.image_jpeg_quality)
        msg = HumanMessage(content=[
            {"type": "text",
             "text": "用一两句中文描述这张图片的内容与作用; 若是图表/流程图/截图, 请说出关键信息."},
            {"type": "image_url", "image_url": {"url": uri}},
        ])
        return self._content_str(self.vision_llm.invoke([msg]).content)


_LLM_SERVICE: LLMService | None = None


def get_llm_service(settings: Settings) -> LLMService:
    global _LLM_SERVICE
    if _LLM_SERVICE is None:
        _LLM_SERVICE = LLMService(settings)
    return _LLM_SERVICE


def analyze_images(entries: list[dict], llm: LLMService, base_dir: Path,
                   workers: int = 6) -> tuple[int, int]:
    """并发图片识别, 结果写回 entry['analysis']; 返回 (成功数, 失败数). 单条失败不中断."""
    entries = [e for e in entries if e.get("img_path")]
    ok = fail = 0
    if not entries:
        return 0, 0

    def work(e: dict) -> None:
        e["analysis"] = llm.describe_image(base_dir / e["img_path"])
        e["status"] = "ok"

    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        futs = {ex.submit(work, e): e for e in entries}
        for f in as_completed(futs):
            e = futs[f]
            try:
                f.result()
                ok += 1
            except Exception as err:
                e["analysis"] = f"[图片识别失败: {err}]"
                e["status"] = "failed"
                fail += 1
                LOG.warning("图片识别失败 %s: %s", e.get("img_path"), err)
    return ok, fail


def summarize_chunks(chunks: list[dict], llm: LLMService, workers: int = 6) -> None:
    """并发生成文本块摘要(heading 块跳过: 标题即摘要); 失败置空串, 检索退化为原文."""

    def work(c: dict) -> None:
        c["summary"] = llm.summarize(c["text"], " > ".join(c.get("heading_path_text", [])[1:]))

    targets = [c for c in chunks if c["type"] == "text" and c.get("text", "").strip()]
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        futs = {ex.submit(work, c): c for c in targets}
        for f in as_completed(futs):
            c = futs[f]
            try:
                f.result()
            except Exception as err:
                c["summary"] = ""
                LOG.warning("摘要失败 %s: %s", c.get("chunk_id"), err)
