# -*- coding: utf-8 -*-
"""python -m docqa 入口."""
from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
