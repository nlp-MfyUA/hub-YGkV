# -*- coding: utf-8 -*-
"""问答: LangGraph 状态图(BM25 检索 → LLM 生成) + 问答编排(历史/附件出入).

ask_once 是 CLI 与 Web 共用的单轮问答入口: 读 Redis 历史 → invoke 图 → 写回两条历史.
历史读写只在 ask_once 内做一次, 调用方不要再写(否则双写).
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, TypedDict

from langgraph.graph import END, START, StateGraph

from .config import Settings
from .console import LOG
from .llm import get_llm_service, make_data_uri
from .retrieval import BM25Index
from .stores import ChatHistoryStore


class QAState(TypedDict, total=False):
    session_id: str
    question: str
    doc_ids: list[str] | None
    top_k: int
    image_data_uri: str          # 用户上传的提问附件图片(data URI, 空串=无附件)
    history: list[dict]          # [{"role","content"}] 最近 N 条(来自 Redis)
    retrieved: list[dict]        # BM25 top-k 块
    image_candidates: list[dict] # 去重后的可用图片条目
    answer: str
    error: str | None


_QA_SYSTEM = (
    "你是文档问答助手。请严格依据【参考资料】用中文回答用户问题, 可适当组织语言但不得编造资料外的事实; "
    "若资料不足以回答, 直接说明。回答需要配图时, 只能从【可用图片】列表中选择, "
    "把路径原样放入 Markdown 图片语法, 例如 ![](data/xxx/images/a.jpg); "
    "路径必须逐字复制列表中的路径, 禁止编造或修改。"
)


def _render_context(retrieved: list[dict]) -> str:
    lines = []
    for i, c in enumerate(retrieved, 1):
        path = " > ".join(c.get("heading_path_text", [])[1:]) or c.get("doc_id", "")
        lines.append(f"【资料{i}】{path} (第{c.get('page_start', 0) + 1}页起)\n{c.get('text', '')}")
    return "\n\n".join(lines)


def _render_images(images: list[dict]) -> str:
    if not images:
        return "(无)"
    return "\n".join(
        f"【图片{i}】{im.get('rel_path', '')} — {im.get('caption', '')}: {im.get('analysis', '')}"
        for i, im in enumerate(images, 1))


def _build_qa_messages(history: list[dict], retrieved: list[dict],
                       image_candidates: list[dict], question: str,
                       image_data_uri: str = "") -> list[dict]:
    """组装问答消息列表(纯函数, 便于测试). 附件图片时用户消息为多模态 content 块."""
    user_text = (f"【参考资料】\n{_render_context(retrieved)}\n\n"
                 f"【可用图片】\n{_render_images(image_candidates)}\n\n"
                 f"【问题】{question}")
    if image_data_uri:
        user_text += "\n\n(用户另附了一张图片, 见本消息的图片部分, 请结合图片与资料一起回答)"
        content: Any = [
            {"type": "text", "text": user_text},
            {"type": "image_url", "image_url": {"url": image_data_uri}},
        ]
    else:
        content = user_text
    return ([{"role": "system", "content": _QA_SYSTEM}] + list(history)
            + [{"role": "user", "content": content}])


_MD_IMAGE_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")


def split_markdown_images(text: str) -> list[tuple[str, str]]:
    """把回答拆成交替的 ("text", 内容)/("image", 路径) 片段, 供前端分段渲染图文."""
    segs: list[tuple[str, str]] = []
    pos = 0
    for m in _MD_IMAGE_RE.finditer(text):
        if m.start() > pos:
            segs.append(("text", text[pos:m.start()]))
        segs.append(("image", m.group(1)))
        pos = m.end()
    if pos < len(text):
        segs.append(("text", text[pos:]))
    return segs if segs else [("text", text)]


_QA_GRAPH = None


def get_qa_graph(settings: Settings):
    """START → retrieve(BM25) → generate(LLM) → END; 进程级单例, 历史由调用层出入."""
    global _QA_GRAPH
    if _QA_GRAPH is not None:
        return _QA_GRAPH

    def retrieve(state: QAState) -> dict:
        try:
            idx = BM25Index.load(settings.data_dir, state.get("doc_ids"))
            top_k = int(state.get("top_k") or settings.top_k)
            hits = idx.search(state.get("question", ""), top_k)
        except Exception as e:
            return {"retrieved": [], "image_candidates": [], "error": f"检索失败: {e}"}
        retrieved = []
        for score, chunk in hits:
            c = dict(chunk)
            c["_score"] = round(score, 3)
            retrieved.append(c)
        images: dict[str, dict] = {}
        for c in retrieved:
            for im in c.get("images", []):
                if im.get("rel_path"):
                    images[im["rel_path"]] = im
        return {"retrieved": retrieved, "image_candidates": list(images.values())}

    def generate(state: QAState) -> dict:
        if not state.get("retrieved"):
            return {"answer": f"未检索到相关内容({state.get('error') or '知识库为空或问题不匹配'}), "
                              f"请先 upload 文档或换个问法。"}
        try:
            llm = get_llm_service(settings)
            history = [{"role": h["role"], "content": h["content"]}
                       for h in state.get("history", []) if h.get("role") in ("user", "assistant")]
            image_uri = state.get("image_data_uri") or ""
            messages = _build_qa_messages(history, state["retrieved"],
                                          state.get("image_candidates", []),
                                          state["question"], image_uri)
            target = llm.vision_llm if image_uri else llm.text_llm
            return {"answer": llm._content_str(target.invoke(messages).content), "error": None}
        except Exception as e:
            return {"answer": "", "error": f"生成失败: {e}"}

    g = StateGraph(QAState)
    g.add_node("retrieve", retrieve)
    g.add_node("generate", generate)
    g.add_edge(START, "retrieve")
    g.add_edge("retrieve", "generate")
    g.add_edge("generate", END)
    _QA_GRAPH = g.compile()
    return _QA_GRAPH


def ask_once(settings: Settings, question: str, session_id: str,
             doc_ids: list[str] | None, top_k: int,
             history_store: ChatHistoryStore | None,
             image_path: Path | None = None) -> str:
    """单轮问答: 读历史 → 图 → 写回两条历史(只在此处写, 调用方勿重复)."""
    history = []
    if history_store is not None:
        try:
            history = history_store.recent(session_id)
        except Exception as e:
            LOG.warning("读取对话历史失败(忽略): %s", e)
    image_uri = ""
    if image_path is not None:
        image_uri = make_data_uri(Path(image_path), settings.image_max_side,
                                  settings.image_jpeg_quality)
    graph = get_qa_graph(settings)
    result = graph.invoke({
        "session_id": session_id, "question": question,
        "doc_ids": doc_ids, "top_k": top_k, "image_data_uri": image_uri,
        "history": history,
    }, config={"recursion_limit": 10})
    answer = result.get("answer", "")
    if result.get("error"):
        answer = f"{answer}\n[错误] {result['error']}".strip()
    if history_store is not None:
        try:
            history_store.append(session_id, "user", question)
            history_store.append(session_id, "assistant", answer)
        except Exception as e:
            LOG.warning("写入对话历史失败(忽略): %s", e)
    return answer


def available_docs(settings: Settings) -> list[str]:
    """知识库中已建好 chunks.json 的 doc_id 列表(磁盘即真相, 不依赖 Redis)."""
    if not settings.data_dir.exists():
        return []
    return sorted(p.name for p in settings.data_dir.glob("*/chunks.json")
                  for p in [p.parent])
