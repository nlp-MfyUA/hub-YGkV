# -*- coding: utf-8 -*-
"""CLI 入口: check / upload / ask / chat / docs / history / consume.

用法:
    python -m docqa check                    # 预检 Kafka/Redis/.env/依赖
    python -m docqa upload a.pdf [--no-qa]   # 全流程演示
    python -m docqa ask "问题" [--session S] [--doc D] [--top-k N]
    python -m docqa chat [--session S]       # 交互式问答 REPL
    python -m docqa docs | history [--clear] | consume [--from-beginning]
    python -m docqa delete <doc_id>... [--yes]   # 删除文档及其分块/图片/Redis 记录
"""
from __future__ import annotations

import argparse
import socket
import threading
from pathlib import Path

from kafka.errors import KafkaError

from .config import Settings
from .console import cprint, setup_stdio
from .events import ConsoleEventPrinter, KafkaEventBus
from .mineru import MinerUClient, MinerUError
from .pipeline import DocRecord, ParsePipeline, remove_doc
from .qa import ask_once, available_docs
from .stores import ChatHistoryStore, DocStateStore, make_redis


def _connect_redis_or_none(settings: Settings):
    try:
        client = make_redis(settings)
        client.ping()
        return client
    except Exception as e:
        from .console import LOG
        LOG.warning("Redis 不可用(降级): %s", e)
        return None


def cmd_check(args: argparse.Namespace) -> int:
    s = Settings.load()
    ok_all = True
    print("=" * 46, "预检", "=" * 46)

    def item(name: str, ok: bool, msg: str = "") -> None:
        nonlocal ok_all
        ok_all = ok_all and ok
        print(f"  [{'√' if ok else '×'}] {name}{(' — ' + msg) if msg else ''}")

    try:
        s.validate()
        item(".env 配置完整性", True, f"model={s.llm_model}, multi={s.llm_multi_model}")
    except ValueError as e:
        item(".env 配置完整性", False, str(e))
        return 1
    host = s.kafka_bootstrap.split(":")[0]
    port = int(s.kafka_bootstrap.split(":")[1] or 9092)
    sock = socket.socket()
    sock.settimeout(4)
    try:
        sock.connect((host, port))
        item(f"Kafka TCP {s.kafka_bootstrap}", True)
    except Exception as e:
        item(f"Kafka TCP {s.kafka_bootstrap}", False, f"{e} — 请先在服务器启动 Kafka")
    finally:
        sock.close()
    try:
        from kafka import KafkaAdminClient
        admin = KafkaAdminClient(bootstrap_servers=s.kafka_bootstrap, client_id="check")
        item("Kafka AdminClient(元数据)", True, f"topics={sorted(admin.list_topics())[:5]}")
        admin.close()
    except Exception as e:
        item("Kafka AdminClient(元数据)", False, str(e)[:120])
    try:
        client = make_redis(s)
        client.ping()
        item(f"Redis {s.redis_host}:{s.redis_port} DB{s.redis_db}", True,
             f"dbsize={client.dbsize()}")
    except Exception as e:
        item(f"Redis {s.redis_host}:{s.redis_port} DB{s.redis_db}", False, str(e)[:120])
    try:
        s.data_dir.mkdir(parents=True, exist_ok=True)
        probe = s.data_dir / ".write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        item(f"data 目录可写 {s.data_dir}", True)
    except Exception as e:
        item(f"data 目录可写 {s.data_dir}", False, str(e)[:120])
    import jieba
    jieba.initialize()
    item("jieba 分词初始化", True)
    print("=" * 96)
    return 0 if ok_all else 2


def cmd_upload(args: argparse.Namespace) -> int:
    settings = Settings.load()
    settings.validate()
    bus = printer = pipeline = None
    stop_ev, ready_ev = threading.Event(), threading.Event()
    done_docs: list[DocRecord] = []
    try:
        store = None
        client = _connect_redis_or_none(settings)
        if client is not None:
            store = DocStateStore(client)
        try:
            bus = KafkaEventBus(settings.kafka_bootstrap, settings.kafka_topic)
        except Exception as e:
            cprint("错误", f"Kafka 不可达({e}): 请先启动 broker {settings.kafka_bootstrap}", "red")
            return 2
        bus.ensure_topic()
        printer = ConsoleEventPrinter(settings.kafka_bootstrap, settings.kafka_topic,
                                      stop_ev, ready_ev)
        printer.start()
        if not ready_ev.wait(timeout=15):
            from .console import LOG
            LOG.warning("Kafka 消费者 15s 内未就位, 可能错过早期事件")
        pipeline = ParsePipeline(settings, MinerUClient(
            settings.mineru_token, settings.mineru_model_version, settings.mineru_language),
            bus, store)
        cprint("上传", f"共 {len(args.pdfs)} 个PDF, doc 目录: {settings.data_dir}", "cyan")
        done_docs = pipeline.upload_and_track([Path(p) for p in args.pdfs])
        for d in done_docs:
            pipeline.chunk_and_index(d)
        cprint("完成", f"成功 {len(done_docs)}/{len(args.pdfs)} 个文档", "green")
    except KeyboardInterrupt:
        print("\n[中断] 正在清理退出...")
    except KafkaError as e:
        cprint("错误", f"Kafka 中途不可达: {e}", "red")
    finally:
        stop_ev.set()
        if printer is not None:
            printer.join(timeout=6)
        if bus is not None:
            bus.flush_and_close()
        if pipeline is not None and pipeline.docs:
            cprint("状态", "本批文档: " + ", ".join(
                f"{d.file_name}={d.state}" + (f"({d.chunks_count}块)" if d.chunks_count else "")
                for d in pipeline.docs), "yellow")
    if done_docs and not args.no_qa:
        doc_ids = [d.doc_id for d in done_docs]
        print()
        cprint("问答", f"新文档已就绪: {doc_ids}, 输入问题开始问答(/exit 退出)", "cyan")
        _run_repl(settings, session_id="default", doc_ids=doc_ids)
    return 0


def _run_repl(settings: Settings, session_id: str, doc_ids: list[str] | None) -> None:
    client = _connect_redis_or_none(settings)
    history_store = ChatHistoryStore(client, settings.history_window) if client else None
    cprint("会话", f"session={session_id} docs={doc_ids or '全部'} "
                  f"(/doc 切换 /history 查看 /new 清空 /exit 退出)", "cyan")
    while True:
        try:
            q = input("\n问题> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not q:
            continue
        low = q.lower()
        if low in ("/exit", "/quit"):
            return
        if low == "/history":
            if history_store:
                for m in history_store.all(session_id):
                    print(f"  [{m['ts']}] {m['role']}: {m['content'][:80]}")
            else:
                print("  (Redis 不可用)")
            continue
        if low == "/new":
            if history_store:
                history_store.clear(session_id)
            print("  已清空对话记录")
            continue
        if low.startswith("/doc"):
            parts = q.split()
            doc_ids = parts[1:] if len(parts) > 1 else None
            if doc_ids:
                avail = available_docs(settings)
                bad = [d for d in doc_ids if d not in avail]
                if bad:
                    print(f"  不存在的 doc_id: {bad}, 可用: {avail}")
                    doc_ids = None
            print(f"  检索范围: {doc_ids or '全部文档'}")
            continue
        print(ask_once(settings, q, session_id, doc_ids, settings.top_k, history_store))


def cmd_ask(args: argparse.Namespace) -> int:
    settings = Settings.load()
    settings.validate()
    doc_ids = None
    if args.doc:
        doc_ids = [d.strip() for d in args.doc.split(",") if d.strip()]
        avail = available_docs(settings)
        bad = [d for d in doc_ids if d not in avail]
        if bad:
            cprint("错误", f"不存在的 doc_id: {bad}, 可用: {avail}", "red")
            return 2
    client = _connect_redis_or_none(settings)
    history_store = ChatHistoryStore(client, settings.history_window) if client else None
    answer = ask_once(settings, args.question, args.session, doc_ids,
                      args.top_k or settings.top_k, history_store)
    print(answer)
    return 0


def cmd_chat(args: argparse.Namespace) -> int:
    settings = Settings.load()
    settings.validate()
    _run_repl(settings, session_id=args.session, doc_ids=None)
    return 0


def cmd_docs(args: argparse.Namespace) -> int:
    settings = Settings.load()
    client = _connect_redis_or_none(settings)
    if client is None:
        cprint("错误", "Redis 不可用, 无法查询文档状态", "red")
        return 2
    docs = DocStateStore(client).list_docs()
    if not docs:
        print("(尚无文档记录, 先执行 upload)")
        return 0
    print(f"{'doc_id':<28} {'stage':<6} {'state':<8} {'pages':<9} {'chunks':<7} file")
    for d in docs:
        pages = f"{d.get('extracted_pages', '0')}/{d.get('total_pages', '0')}"
        print(f"{str(d.get('doc_id', '')):<28} {d.get('stage', ''):<6} "
              f"{d.get('state', ''):<8} {pages:<9} "
              f"{str(d.get('chunks_count', '0')):<7} {d.get('file_name', '')}")
        if d.get("err_msg"):
            print(f"{'':<28} └ err: {d['err_msg'][:100]}")
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    settings = Settings.load()
    client = _connect_redis_or_none(settings)
    if client is None:
        cprint("错误", "Redis 不可用, 无法查询对话记录", "red")
        return 2
    store = ChatHistoryStore(client, settings.history_window)
    if args.clear:
        store.clear(args.session)
        print(f"已清空 session={args.session} 的对话记录")
        return 0
    msgs = store.all(args.session)
    if not msgs:
        print(f"(session={args.session} 无对话记录)")
        return 0
    print(f"—— session={args.session} 共 {len(msgs)} 条 ——")
    for m in msgs:
        print(f"  [{m['ts']}] {m['role']}: {m['content'][:100]}")
    return 0


def cmd_delete(args: argparse.Namespace) -> int:
    settings = Settings.load()
    client = _connect_redis_or_none(settings)
    store = DocStateStore(client) if client else None
    redis_ids = []
    if store is not None:
        try:
            redis_ids = [d["doc_id"] for d in store.list_docs()]
        except Exception:
            pass
    avail = sorted(set(available_docs(settings)) | set(redis_ids))
    unknown = [d for d in args.doc_ids if d not in avail]
    if unknown:
        cprint("错误", f"不存在的 doc_id: {unknown}, 可用: {avail}", "red")
        return 2
    if not args.yes:
        ans = input(f"将删除 {len(args.doc_ids)} 个文档及其分块/图片/Redis 记录"
                    f"(Kafka 历史事件保留): {args.doc_ids}  确认? [y/N] ")
        if ans.strip().lower() not in ("y", "yes"):
            print("已取消")
            return 0
    for d in args.doc_ids:
        rep = remove_doc(d, settings, store)
        parts = [f"数据目录 {'√' if rep['data_dir'] else '-'}",
                 f"Redis {'√' if rep['redis'] else '-'}"]
        if rep["staged_pdf"]:
            parts.append(f"暂存PDF 已删")
        cprint("删除", f"{d}: " + " | ".join(parts), "green")
    return 0


def cmd_consume(args: argparse.Namespace) -> int:
    settings = Settings.load()
    stop_ev, ready_ev = threading.Event(), threading.Event()
    printer = ConsoleEventPrinter(
        settings.kafka_bootstrap, settings.kafka_topic, stop_ev, ready_ev,
        # 从头回放用随机组(命名组会提交偏移, 第二次回放就什么都没有了)
        group_id=args.group or (None if args.from_beginning else "qpmq-console"),
        auto_offset_reset="earliest" if args.from_beginning else "latest")
    cprint("消费", f"订阅 {settings.kafka_topic} @ {settings.kafka_bootstrap} "
                  f"(Ctrl+C 退出{' 从头回放' if args.from_beginning else ''})", "cyan")
    try:
        printer.run()
    except KeyboardInterrupt:
        pass
    finally:
        stop_ev.set()
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="docqa", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("check", help="预检 Kafka/Redis/.env/依赖")\
        .set_defaults(func=cmd_check)

    pu = sub.add_parser("upload", help="上传PDF→解析→分块→(问答)")
    pu.add_argument("pdfs", nargs="+", help="PDF 文件路径")
    pu.add_argument("--no-qa", action="store_true", help="完成后不进入问答 REPL")
    pu.set_defaults(func=cmd_upload)

    pa = sub.add_parser("ask", help="单次问答")
    pa.add_argument("question")
    pa.add_argument("--session", default="default", help="会话ID(默认 default)")
    pa.add_argument("--doc", default="", help="限定 doc_id(逗号分隔, 默认全部)")
    pa.add_argument("--top-k", type=int, default=0)
    pa.set_defaults(func=cmd_ask)

    pc = sub.add_parser("chat", help="交互式问答 REPL")
    pc.add_argument("--session", default="default")
    pc.set_defaults(func=cmd_chat)

    sub.add_parser("docs", help="列出文档状态(Redis)")\
        .set_defaults(func=cmd_docs)

    ph = sub.add_parser("history", help="查看/清空对话记录(Redis)")
    ph.add_argument("--session", default="default")
    ph.add_argument("--clear", action="store_true")
    ph.set_defaults(func=cmd_history)

    pco = sub.add_parser("consume", help="独立 Kafka 消费者, 打印事件")
    pco.add_argument("--from-beginning", action="store_true")
    pco.add_argument("--group", default="", help="消费组(默认 qpmq-console)")
    pco.set_defaults(func=cmd_consume)

    pd = sub.add_parser("delete", help="删除文档及其分块/图片/Redis 记录")
    pd.add_argument("doc_ids", nargs="+", help="要删除的 doc_id(可多个)")
    pd.add_argument("--yes", action="store_true", help="跳过确认")
    pd.set_defaults(func=cmd_delete)
    return p


def main(argv: list[str] | None = None) -> int:
    setup_stdio()
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except MinerUError as e:
        cprint("MinerU错误", str(e), "red")
        return 1
    except KafkaError as e:
        cprint("Kafka错误", f"{e} — 请检查 broker {Settings.load().kafka_bootstrap}", "red")
        return 2
    except KeyboardInterrupt:
        print("\n[中断] 退出")
        return 130
