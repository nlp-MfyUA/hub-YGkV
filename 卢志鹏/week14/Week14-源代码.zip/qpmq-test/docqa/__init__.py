# -*- coding: utf-8 -*-
"""docqa — PDF解析 + 分块 + 问答 端到端演示(LangChain/LangGraph + MinerU + Kafka + Redis).

链路: 上传PDF → MinerU API 解析(状态经 Kafka 推送, Redis 存快照)
      → 标题树递归分块(512字节+Overlap, LLM摘要, 图片多模态识别)
      → BM25 检索 + LangGraph 问答(图文混排, 对话记录存 Redis DB6)

模块分层(依赖单向向下):
    constants/config/console/utils   基础层
    mineru/events/stores             外部服务封装层
    chunking/llm/retrieval           核心能力层
    qa/pipeline                      编排层
    cli/webapp                       交互层

用法:
    python -m docqa check | upload a.pdf | ask "问题" | chat | docs | history | consume
    streamlit run docqa/webapp.py    # Web 版
"""
import warnings

warnings.filterwarnings("ignore", message="pkg_resources is deprecated")

from .config import PROJECT_ROOT, Settings
from .constants import (EVENT_VERSION, STAGE_CHUNK, STAGE_PARSE, ST_DONE,
                        ST_FAILED, ST_PARSING, ST_PENDING)
from .console import LOG, cprint, get_logger, setup_stdio
from .utils import (atomic_write_json, hard_split_bytes, new_doc_id, now_iso,
                    retry, utf8len)
from .mineru import (MinerUApiError, MinerUClient, MinerUError, MinerUStateError,
                     find_content_list)
from .events import ConsoleEventPrinter, KafkaEventBus, build_event
from .stores import ChatHistoryStore, DocStateStore, make_redis
from .chunking import (Chunker, HeadingNode, build_heading_tree, headings_to_json,
                       html_table_to_text)
from .llm import (LLMService, analyze_images, compress_image, get_llm_service,
                  make_data_uri, summarize_chunks)
from .retrieval import BM25Index
from .qa import QAState, ask_once, available_docs, get_qa_graph, split_markdown_images
from .pipeline import DocRecord, ParsePipeline

__all__ = [
    "PROJECT_ROOT", "Settings",
    "EVENT_VERSION", "STAGE_CHUNK", "STAGE_PARSE", "ST_DONE", "ST_FAILED",
    "ST_PARSING", "ST_PENDING",
    "LOG", "cprint", "get_logger", "setup_stdio",
    "atomic_write_json", "hard_split_bytes", "new_doc_id", "now_iso", "retry", "utf8len",
    "MinerUApiError", "MinerUClient", "MinerUError", "MinerUStateError", "find_content_list",
    "ConsoleEventPrinter", "KafkaEventBus", "build_event",
    "ChatHistoryStore", "DocStateStore", "make_redis",
    "Chunker", "HeadingNode", "build_heading_tree", "headings_to_json", "html_table_to_text",
    "LLMService", "analyze_images", "compress_image", "get_llm_service",
    "make_data_uri", "summarize_chunks",
    "BM25Index",
    "QAState", "ask_once", "available_docs", "get_qa_graph", "split_markdown_images",
    "DocRecord", "ParsePipeline",
]
