# docqa 架构说明

> 项目: PDF 解析 + 分块 + 问答端到端演示（LangChain/LangGraph + MinerU + Kafka + Redis + GLM）
> 对应代码: `docqa/`（CLI 与 Streamlit Web 共用同一套核心）

## 1. 组件架构图

```mermaid
graph TB
    subgraph 交互层
        CLI["cli.py<br/>check/upload/ask/chat/docs/history/consume"]
        WEB["webapp.py<br/>Streamlit 三页签"]
    end

    subgraph 编排层
        QA["qa.py<br/>LangGraph 问答图 + ask_once"]
        PIPE["pipeline.py<br/>ParsePipeline 解析流水线"]
    end

    subgraph 核心能力层
        CHUNK["chunking.py<br/>标题树 + 512B 分块器"]
        LLM["llm.py<br/>GLM 文本/视觉 + 并发摘要/识图"]
        RETR["retrieval.py<br/>BM25 索引(jieba)"]
    end

    subgraph 外部服务封装层
        MINERU["mineru.py<br/>MinerU v4 客户端"]
        EVENTS["events.py<br/>Kafka 生产者/控制台消费者"]
        STORES["stores.py<br/>Redis 快照/对话记录"]
    end

    subgraph 基础层
        CONFIG["config.py Settings"]
        UTILS["utils.py"]
        CONST["constants.py"]
        CONSOLE["console.py"]
    end

    CLI --> PIPE & QA
    WEB --> PIPE & QA
    PIPE --> MINERU & EVENTS & STORES & CHUNK & LLM & RETR
    QA --> RETR & LLM & STORES
    CHUNK & LLM & RETR --> CONFIG
    MINERU & EVENTS & STORES --> CONFIG --> UTILS --> CONSOLE

    subgraph 外部系统
        K[("Kafka<br/>qpmq.doc.events")]
        R[("Redis DB6<br/>doc:* / chat:*")]
        M[("MinerU API")]
        G[("GLM LLM")]
        FS[("data/{doc_id}/<br/>chunks/headings/images")]
    end

    EVENTS <--> K
    STORES <--> R
    MINERU <--> M
    LLM <--> G
    CHUNK & RETR <--> FS
```

依赖单向向下：`constants/config/console/utils`（基础）← `mineru/events/stores`（外部封装）← `chunking/llm/retrieval`（核心能力）← `qa/pipeline`（编排）← `cli/webapp`（交互）。

## 2. 上传解析时序图（Request 1 主链路）

```mermaid
sequenceDiagram
    autonumber
    participant U as 用户(CLI/Web)
    participant P as ParsePipeline
    participant M as MinerU API
    participant K as Kafka(事件)
    participant R as Redis(DB6)
    participant C as ConsoleEventPrinter<br/>(演示消费者)
    participant L as LLM(GLM)
    participant F as data/{doc_id}/

    U->>P: upload [pdf...]
    P->>M: POST /file-urls/batch (Bearer token)
    M-->>P: batch_id + OSS 预签名 PUT urls
    P->>K: PENDING 事件(key=doc_id)
    P->>R: HSET doc:{id} + SADD docs:index
    P->>M: PUT pdf 字节(不带 Content-Type)
    P->>K: PARSING 事件
    C-->>U: [parse] a.pdf PENDING → PARSING

    loop 每 5s 轮询(页码 diff 才发事件)
        P->>M: GET /extract-results/batch/{id}
        M-->>P: running(extract_progress n/m)
        P->>K: PARSING n/m 事件
        P->>R: HSET 进度字段
        C-->>U: [parse] a.pdf PARSING 3/13
    end
    M-->>P: done(full_zip_url)
    P->>F: 下载 zip → 解压(zip-slip 防护)
    P->>K: parse DONE 事件
    P->>R: HSET state=DONE

    Note over P,F: —— 阶段二: chunk ——
    P->>K: chunk PARSING 事件
    P->>F: 定位 content_list.json → build_heading_tree
    P->>L: 并发 describe_image(全部 image/chart)
    P->>F: Chunker 512B 切分 → summarize_chunks 并发摘要
    P->>F: 原子写 chunks.json + headings.json
    P->>K: chunk DONE 事件(含块数/识图统计)
    P->>R: HSET state=DONE chunks_count
    C-->>U: [chunk] a.pdf DONE | 137 chunks
```

失败语义：单文档失败不影响同批其它文档（FAILED 终态事件+快照）；Kafka 中途掉线是致命错误（全部补 FAILED 后退出）；Redis 不可达仅降级（丢快照，流程继续）。

## 3. 问答数据流（Request 3）

```mermaid
flowchart LR
    Q["用户提问<br/>(可附图片)"] --> AO["ask_once(qa.py)"]
    RDB[("chat:{session}<br/>Redis LIST")] -- recent(N) --> AO
    AO --> G["LangGraph<br/>START→retrieve→generate→END"]
    G -- BM25 top-k --> B["retrieval.BM25Index<br/>search_text=标题路径/摘要/正文"]
    KB[("chunks.json<br/>data/*/")] --> B
    G -- 多模态消息 --> LLM["GLM 文本或视觉模型"]
    B -- 命中块+图片候选 --> G
    G -- answer(可含 ![](data/..)) --> AO
    AO -- append user/assistant --> RDB
    AO --> A["回答<br/>Web: split_markdown_images<br/>图文分段渲染"]
```

- 检索：BM25（jieba `lcut_for_search` 查询与语料同分词器；`abs(score)>1e-9` 判命中，规避小语料负 idf）
- 生成：system 约束“仅依据资料、图片路径逐字复制”，回答可内嵌 `![](data/{doc_id}/images/x.jpg)` 本地路径
- 历史：只在 `ask_once` 内读写 Redis（调用方再写会双写）
- 附件：本地图片 → 压缩 JPEG base64 data URI → 走视觉模型多模态 content 块

## 4. 存储与数据模型

```mermaid
erDiagram
    REDIS_DB6 {
        string doc_colon_docid "HASH: file_name/state/stage/pages/err/chunks_count/created_at/updated_at"
        set docs_index "SET: 全部 doc_id"
        list chat_colon_session "LIST: JSON {role,content,ts} ×N (LTRIM 滚动窗口)"
    }
    DATA_DIR {
        string content_list_json "MinerU 原始结构化输出(含 text_level/page_idx/img_path)"
        string full_md "全文 Markdown"
        string images_slash "文档图片(chart 与 image 同列)"
        string chunks_json "分块产物(检索语料)"
        string headings_json "标题树扁平序列化(路径回溯)"
    }
    CHUNKS_JSON {
        string chunk_id "doc_id-c000123"
        string type "heading | text"
        string text "块正文(≤512B UTF-8)"
        string heading_id "所属标题节点"
        list heading_path_ids "h0→…→本节点(含全部父标题 id)"
        list heading_path_text "标题路径文本"
        int page_start "0-based"
        string summary "LLM 一句摘要(失败为空)"
        list images "img_path/rel_path/caption/analysis(多模态识别)/status"
    }
    HEADINGS_JSON {
        string id "h0(虚拟根)/h000001…"
        int level "0~5"
        string parent_id "构成树"
        string own_text "直属正文(不含子标题)"
        list child_ids
        list path_ids "自根路径"
    }
    KAFKA_TOPIC {
        string event "JSON: event_id/version=1/ts/doc_id/file_name/stage(parse|chunk)/state/progress{n,m}|null/detail"
    }
    DATA_DIR ||..|| CHUNKS_JSON : "检索语料来源"
    DATA_DIR ||..|| HEADINGS_JSON : "父标题块按 id 回溯"
    REDIS_DB6 ||..|| KAFKA_TOPIC : "同一状态双写: Kafka 推送流 + Redis 快照面"
```

目录级数据布局：

```
data/
└── example-94fd45e1/          # doc_id = 文件名词干-8位hex
    ├── *_content_list.json    # MinerU 结构化输出(带 batch uuid 前缀)
    ├── full.md / *_origin.pdf / *_model.json
    ├── images/*.jpg           # 文档图片(rel_path = data/{doc_id}/images/x.jpg)
    ├── chunks.json            # 分块+摘要+图片分析(检索语料)
    └── headings.json          # 标题树(含 h0, 路径回溯)
uploads/                       # Web 上传暂存(uuid 前缀防同名)
samples/                       # 测试 PDF
```

## 5. Web 前端如何拿到进度（与 CLI 的关系）

`webapp.py` 复用同一套核心（ParsePipeline 后台线程 + KafkaEventBus + Redis）：

- **进度面板**：`@st.fragment(run_every=2)` 每 2 秒服务端重算——读 Redis `docs:index`/`doc:*` 快照，后台线程内存态兜底；这是服务器端 fragment 周期重跑经现有 WebSocket 推送，**不是**浏览器 HTTP 轮询。每行文档带 **🗑 两击删除**（`remove_doc`，解析进行中的文档禁删）。
- **事件流页签**：展示 `UiEventBus` 本地环形日志（与 Kafka 推送同源），Kafka 不可达时自动降级仅本地。
- **问答**：与 CLI 共用 `ask_once`，页面内转录存 session_state。📎 附件：**图片**随问题走 vision 模型；**PDF** 由 `_parse_attachment` 现场同步跑同一套 ParsePipeline（`ParsePipeline(on_event=…)` 回调实时刷新 `st.status`：解析 n/m 页 → 分块/摘要），完成后**仅就该附件**检索作答并入库（可用 🗑 删除）。

## 6. 功能接口清单

### CLI（`python -m docqa …`）

| 命令 | 功能 | 关键参数 |
|---|---|---|
| `check` | 预检 Kafka TCP/Admin、Redis ping(DB6)、.env、data 可写、jieba | — |
| `upload PDF…` | 全流程: Kafka 消费者就位→上传→轮询→下载→分块→(REPL) | `--no-qa` 跳过 REPL |
| `ask 问题` | 单轮问答(图文混排输出) | `--session` `--doc`(限定范围) `--top-k` |
| `chat` | 交互式 REPL(`/doc /history /new /exit`) | `--session` |
| `docs` | 文档状态表(读 Redis) | — |
| `history` | 查看/清空对话记录 | `--session` `--clear` |
| `consume` | 独立 Kafka 消费者打印事件 | `--from-beginning`(随机组真回放) `--group` |
| `delete` | 删除文档及其分块/图片/Redis 记录(`pipeline.remove_doc`: data 目录+HASH/索引+uploads 暂存副本+BM25 缓存失效; 用户原始 PDF 与 Kafka 历史事件保留) | `--yes` 跳过确认, 支持批量 doc_id |

### 核心 API（模块 → 公开接口）

| 模块 | 接口 |
|---|---|
| `config` | `Settings.load()/validate()`, `PROJECT_ROOT` |
| `mineru` | `MinerUClient.create_batch/upload_file/poll_batch/download_and_extract`, `find_content_list` |
| `events` | `build_event`, `KafkaEventBus.emit/ensure_topic/flush_and_close`, `ConsoleEventPrinter.run/format_line` |
| `stores` | `make_redis`, `DocStateStore.init_doc/update/get/list_docs`, `ChatHistoryStore.append/recent/all/clear` |
| `chunking` | `build_heading_tree`, `Chunker.chunk`, `headings_to_json`, `html_table_to_text` |
| `llm` | `get_llm_service`, `LLMService.chat/summarize/describe_image`, `analyze_images`, `summarize_chunks`, `make_data_uri` |
| `retrieval` | `BM25Index.load(data_dir, doc_ids)/search(query, top_k)` |
| `qa` | `get_qa_graph`, `ask_once`, `available_docs`, `split_markdown_images` |
| `pipeline` | `ParsePipeline.upload_and_track/chunk_and_index`, `DocRecord.to_mapping` |

### 事件协议（Kafka topic `qpmq.doc.events`，key=doc_id）

```json
{"event_id": "…", "version": 1, "ts": "2026-11-12T10:00:00",
 "doc_id": "example-94fd45e1", "file_name": "example.pdf",
 "stage": "parse", "state": "PARSING",
 "progress": {"extracted_pages": 3, "total_pages": 13}, "detail": ""}
```

状态机：每阶段 `PENDING → PARSING → DONE | FAILED`；`progress` 仅 parse 阶段 running 时非空。
