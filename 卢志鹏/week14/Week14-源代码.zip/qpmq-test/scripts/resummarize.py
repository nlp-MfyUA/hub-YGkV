# -*- coding: utf-8 -*-
"""补摘要: 对指定 doc_id 中 summary 为空的 text 块低频重跑 LLM 摘要(串行+间隔, 避开限流).

场景: upload 时 GLM 账户 429 限流导致部分块摘要失败(summary=""), 分块/图片产物完好.
用法(项目根): PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe scripts/resummarize.py <doc_id>
"""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from docqa.config import Settings          # noqa: E402
from docqa.llm import get_llm_service      # noqa: E402
from docqa.utils import atomic_write_json  # noqa: E402


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    doc_id = sys.argv[1]
    s = Settings.load()
    s.validate()
    base = s.data_dir / doc_id
    cf = base / "chunks.json"
    if not cf.exists():
        print(f"不存在 {cf}")
        return 2

    obj = __import__("json").loads(cf.read_text("utf-8"))
    targets = [c for c in obj["chunks"]
               if c.get("type") == "text" and c.get("text", "").strip()
               and not c.get("summary")]
    print(f"{doc_id}: 共 {len(obj['chunks'])} 块, 待补摘要 {len(targets)} 块")
    if not targets:
        print("无需补摘要")
        return 0

    llm = get_llm_service(s)
    ok = fail = 0
    for i, c in enumerate(targets, 1):
        title_path = " > ".join(c.get("heading_path_text", [])[1:])
        for attempt in (1, 2, 3):          # 每块最多3次, 限流退避
            try:
                c["summary"] = llm.summarize(c["text"], title_path)
                ok += 1
                print(f"  [{i}/{len(targets)}] {c['chunk_id']} ok")
                break
            except Exception as e:
                wait = 8 * attempt         # 429 退避: 8s/16s/24s
                print(f"  [{i}/{len(targets)}] {c['chunk_id']} 第{attempt}次失败({str(e)[:60]}), 等{wait}s重试")
                if attempt == 3:
                    fail += 1
                else:
                    time.sleep(wait)
        time.sleep(1.5)                    # 串行请求间隔, 控制频率

    atomic_write_json(cf, obj)             # 全部处理完原子覆写(失败块保持空串, 可再跑本脚本)
    print(f"完成: 补齐 {ok} 块, 仍失败 {fail} 块(可稍后重跑本脚本)")
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
