# -*- coding: utf-8 -*-
"""Streamlit Web 渲染冒烟(AppTest): 首屏渲染无异常 + 关键控件存在. 不触网/不耗 LLM.

运行(项目根): PYTHONIOENCODING=utf-8 D:/anaconda3/python.exe scripts/web_render_check.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from streamlit.testing.v1 import AppTest  # noqa: E402

at = AppTest.from_file(str(ROOT / "docqa" / "webapp.py"), default_timeout=120)
at.run()

assert not at.exception, f"首屏异常: {[e.value for e in at.exception]}"
print("run OK, no exception")
print("tabs:", len(at.tabs))
print("markdown 块数:", len(at.markdown))
print("info 数:", len(at.info), "| warning 数:", len(at.warning))
assert len(at.tabs) == 3, "应有 3 个 tab"
assert len(at.button) >= 1, "应有按钮(开始解析/清空会话)"
# 每个已列文档一行 → 至少一个删除按钮(🗑)
del_btns = [b for b in at.button if (b.label or "").strip() in ("🗑", "确认删除?")]
assert del_btns, "文档进度面板应有每行删除按钮(🗑)"
print("删除按钮数:", len(del_btns))
# 知识库空 → QA tab 显示提示(附件入口仍可用); 有文档 → 出现检索范围多选框
if at.multiselect:
    assert at.multiselect[0].options, "多选框应有可选文档"
else:
    msgs = [(w.value or "") for w in at.warning] + [(i.value or "") for i in at.info]
    assert any("知识库为空" in m for m in msgs), "空库时 QA 应提示(但仍可附件提问)"
print("AppTest SMOKE OK")
