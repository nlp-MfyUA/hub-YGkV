# docqa — PDF 解析 + 分块 + 问答（LangChain/LangGraph 中间件演示）

上传 PDF → MinerU API 解析（状态经 Kafka 推送, Redis 存快照）
→ 标题树递归分块（512 字节 UTF-8 + 64B Overlap, LLM 摘要, 图片多模态识别）
→ BM25 检索 + LangGraph 问答（图文混排回答, 对话记录存 Redis DB 6）。

## 项目结构

```
qpmq-test/
├── docqa/                  # 主包
│   ├── constants.py        # 状态机常量 (PENDING/PARSING/DONE/FAILED, parse/chunk)
│   ├── config.py           # Settings(.env 覆盖) + PROJECT_ROOT
│   ├── console.py          # stdout UTF-8 / logger / 彩色打印
│   ├── utils.py            # doc_id / 原子写 JSON / 重试 / 字节硬切
│   ├── mineru.py           # MinerU v4 客户端 + content_list 定位 + zip-slip 防护
│   ├── events.py           # Kafka 事件总线(生产者) + 控制台消费者
│   ├── stores.py           # Redis 文档快照(HASH/SET) + 对话记录(LIST 滚动窗口)
│   ├── chunking.py         # 标题树构建 + 递归分块器 + headings/chunks JSON
│   ├── llm.py              # GLM(OpenAI 兼容) 文本/视觉服务 + 并发摘要/图片识别
│   ├── retrieval.py        # BM25 索引(jieba lcut_for_search, 进程内缓存)
│   ├── qa.py               # LangGraph 问答图 + ask_once 单轮编排
│   ├── pipeline.py         # 解析流水线(上传→轮询→下载→分块建索引, 双写)
│   ├── cli.py              # CLI 子命令
│   ├── webapp.py           # Streamlit Web 版
│   └── __main__.py         # python -m docqa 入口
├── tests/                  # 单元测试(50 个, 不触网), 按模块拆分
├── scripts/                # 辅助检查脚本(如 Web 渲染冒烟)
├── data/{doc_id}/          # 解析产物: content_list/full.md/images/chunks.json/headings.json
├── uploads/                # Web 上传的 PDF/附件暂存
├── samples/                # 测试 PDF(来源不可信, 仅作数据)
├── docs/architecture.md    # 架构与数据流转图
└── .env                    # 密钥与环境配置(不入库)
```

## 快速开始

```bash
pip install -r requirements.txt

# 1. 预检(Kafka/Redis/.env/依赖)
python -m docqa check

# 2. 全流程: 上传→解析(控制台实时打印 Kafka 进度)→分块→进入问答 REPL
python -m docqa upload samples/example.pdf

# 3. 单次问答 / 交互式问答
python -m docqa ask "这份文档讲了什么?"
python -m docqa chat --session demo

# 4. 文档状态表 / 对话记录 / 独立事件消费者 / 删除文档
python -m docqa docs
python -m docqa history --session demo
python -m docqa consume --from-beginning
python -m docqa delete <doc_id>... [--yes]   # 删 data 目录+Redis 记录+uploads 暂存副本(原始 PDF 不动, Kafka 历史事件保留)

# 5. Web 版(批量上传/进度面板/多模态问答/📎 附件问答: 图片走 vision, PDF 现场解析/事件流)
python -m streamlit run docqa/webapp.py
```

> Windows + Anaconda: `python` 需用绝对路径如 `D:/anaconda3/python.exe`, 中文输出加 `PYTHONIOENCODING=utf-8`。

## 测试

```bash
python -m unittest discover -s tests -t . -v     # 50/50, 纯逻辑不触网
python scripts/web_render_check.py               # Streamlit 渲染冒烟
```

## .env 配置

| 变量 | 说明 | 默认 |
|---|---|---|
| `MINER_U_API_TOKEN` | MinerU API token(必填) | — |
| `LLM_API_KEY` | GLM key(缺省回退 MINER_U_API_TOKEN) | — |
| `LLM_BASE_URL` / `LLM_MODEL` / `LLM_MULTI_MODEL` | OpenAI 兼容端点/文本模型/视觉模型 | bigmodel / glm-5.3 / glm-5.3-flash |
| `KAFKA_BOOTSTRAP` / `KAFKA_TOPIC` | Kafka 地址 / 事件 topic | 192.168.1.228:39092 / qpmq.doc.events |
| `REDIS_HOST` / `REDIS_PORT` / `REDIS_DB` | Redis(**必须 DB 6**) | 192.168.1.228 / 6379 / 6 |
| `DATA_DIR` | 解析产物根目录 | ./data |
| `CHUNK_SIZE_BYTES` / `CHUNK_OVERLAP_BYTES` | 分块字节阈值 / 重叠 | 512 / 64 |
| `HEADING_MIN_LEVEL` | 建树的最小标题级(1~5, 更深层当正文) | 5 |
| `TOP_K` / `HISTORY_WINDOW` | 召回块数 / 历史窗口 | 5 / 12 |
| `LLM_WORKERS` / `IMAGE_MAX_SIDE` / `IMAGE_JPEG_QUALITY` | 并发数 / 图片压缩 | 6 / 1600 / 85 |
| `POLL_INTERVAL_SEC` / `PARSE_TIMEOUT_SEC` | 轮询间隔 / 超时 | 5 / 900 |

架构与数据流转详见 [docs/architecture.md](docs/architecture.md)。
