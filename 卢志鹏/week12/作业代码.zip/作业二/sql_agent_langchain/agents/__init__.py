"""四个 LLM Agent 的模块级定义（LangChain 版）。

与原版（openai-agents）的移植对照：

    openai-agents                                        LangChain 1.x
    ---------------------------------------------------------------------
    Agent(name, model, model_settings,           create_agent(
              instructions, output_type=Schema)      model=ChatOpenAI(model, temperature),
                                                    system_prompt=instructions,
                                                    response_format=ToolStrategy(Schema))
    Runner.run(agent, prompt) -> final_output    agent.invoke({"messages": [HumanMessage(prompt)]})
                                                  -> result["structured_response"]
    set_default_openai_api("chat_completions")   ChatOpenAI 本身走 chat completions 协议，
                                                 api_key/base_url 显式传入

Agent 边界、提示词、结构化契约与原版保持一致；工具调用式的结构化输出（ToolStrategy）
对任意支持 tool calling 的模型通用，与智谱等 OpenAI 兼容端点兼容。
"""

from __future__ import annotations

from .result_summarizer import result_summary_agent
from .sql_generator import sql_generator_agent
from .sql_rewriter import sql_rewriter_agent
from .table_selector import table_selector_agent

__all__ = [
    "result_summary_agent",
    "sql_generator_agent",
    "sql_rewriter_agent",
    "table_selector_agent",
]
