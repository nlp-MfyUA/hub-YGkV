"""运行配置（LangChain 版）。

与原版 00-sql-agent 的差异：默认模型改为智谱 GLM（OpenAI 兼容端点），
API key 优先读环境变量 ZHIPU_API_KEY / OPENAI_API_KEY，便于换 key 不改代码。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# key 优先读环境变量；缺省用代码内默认 key（仅作业环境）
DEFAULT_API_KEY = os.environ.get("ZHIPU_API_KEY") or os.environ.get("OPENAI_API_KEY") \
    or "Xa7d1eXe439741239e86eaa73811e2122d2122d0382Q"


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    db_path: Path = PROJECT_ROOT / "chinook.db"
    primary_model: str = "glm-5.3"          # 选表/生成/改写
    summary_model: str = "glm-5.3"          # 结果汇总（可用更便宜的 glm-4-flash）
    base_url: str = "https://open.bigmodel.cn/api/paas/v4"
    api_key: str = DEFAULT_API_KEY
    max_repair_attempts: int = 3
    max_result_rows: int = 200
    max_summary_rows: int = 50
    max_cell_chars: int = 2000
    query_timeout_seconds: float = 5.0

    @classmethod
    def from_env(cls) -> "Settings":
        db_path = Path(os.getenv("SQL_AGENT_DB", str(cls.db_path)))
        if not db_path.is_absolute():
            db_path = PROJECT_ROOT / db_path

        return cls(
            db_path=db_path,
            primary_model=os.getenv("SQL_AGENT_MODEL", cls.primary_model),
            summary_model=os.getenv("SQL_AGENT_SUMMARY_MODEL", cls.summary_model),
            base_url=os.getenv("OPENAI_BASE_URL", cls.base_url),
            max_repair_attempts=_env_int(
                "SQL_AGENT_MAX_REPAIR_ATTEMPTS", cls.max_repair_attempts
            ),
            max_result_rows=_env_int("SQL_AGENT_MAX_ROWS", cls.max_result_rows),
            max_summary_rows=_env_int(
                "SQL_AGENT_MAX_SUMMARY_ROWS", cls.max_summary_rows
            ),
            max_cell_chars=_env_int("SQL_AGENT_MAX_CELL_CHARS", cls.max_cell_chars),
            query_timeout_seconds=_env_float(
                "SQL_AGENT_QUERY_TIMEOUT", cls.query_timeout_seconds
            ),
        )


settings = Settings.from_env()
