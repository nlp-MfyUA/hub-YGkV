# 第十二周作业二：SQL Agent 的 LangChain 重写

> 原实现：`第十一周/作业/00-sql-agent/`（**openai-agents SDK** 实现，含设计文档 `docs/agent-design.md`）
> 本目录：将其 LLM 层完整移植为 **LangChain 1.x**，架构、数据契约、提示词、失败处理策略与原版一致。
> 验证环境：langchain 1.2.7 / langchain-openai 1.1.7 / langgraph 1.0.7 / 智谱 GLM（glm-5.3）

## 一、原实现（openai-agents）分析

`00-sql-agent` 用 **openai-agents SDK**（`from agents import Agent, Runner`）实现了一条七阶段 Text-to-SQL 工作流，其核心设计：

1. **四个 LLM Agent**（模块级定义 + Pydantic `output_type` 结构化输出）：
   `TableSelectAgent`（选表）→ `SQLGeneratorAgent`（生成）→ `SQLRewriteAgent`（修复）→ `ResultSummaryAgent`（汇总，可用更便宜模型）；
2. **三个确定性组件**（不交给 LLM）：
   `SchemaCatalog`（schema/统计/外键解析与缓存）、`SQLValidator`（安全门禁 + `EXPLAIN` 只编译不执行）、`SQLExecutor`（只读连接 + 超时 + 行数截断）；
3. **显式代码编排**（不用 handoff）：Python 状态机控制重试预算（修复 ≤3 次、选表反馈重试 1 次）、`cannot_fix` 提前退出、空结果不进汇总、汇总失败降级为 Markdown 表格；
4. **安全与防注入**：SQLite 只读连接（`mode=ro`）、单语句/SELECT 白名单/危险关键字屏蔽（字面量掩码防误判）、用户问题包在 `<question>` 标签中作为数据传入；
5. **可观测**：阶段级 key=value 日志到 stderr，最终 JSON 到 stdout。

## 二、LangChain 移植对照

| openai-agents（原版） | LangChain 1.x（本版） |
|---|---|
| `Agent(name, model, model_settings=ModelSettings(temperature), instructions, output_type=Schema)` | `create_agent(model=ChatOpenAI(model, temperature, api_key, base_url), system_prompt=instructions, response_format=ToolStrategy(Schema))`（教程 `05_结构化输出.py` 的 API） |
| `await Runner.run(agent, prompt)` → `response.final_output` | `agent.invoke({"messages": [HumanMessage(prompt)]})` → `result["structured_response"]` |
| `set_default_openai_api("chat_completions")`（兼容端点不支持 Responses API） | `ChatOpenAI` 本身即 chat completions 协议，`api_key`/`base_url` 显式传入智谱端点 |
| `trace("SQLAgentWorkflow")` | 对应物为 LangSmith 追踪（`LANGSMITH_TRACING=true` 自动生效），无需代码硬编码 |
| Workflow 为 async（Runner.run 是协程） | `agent.invoke` 为同步调用，Workflow 相应同步化，逻辑不变 |

**确定性组件原样复用**（与 LLM 框架无关）：`models.py`（Pydantic 契约）、`db/catalog.py`、`db/validator.py`、`db/executor.py`、`logging_config.py`。这也验证了原设计的分层：替换 Agent 框架时，只有 `agents/` 与 `workflow.py` 的调用层需要改。

## 三、目录结构（与原版文件一一对应）

```
作业二/
├── chinook.db                      # 数据库（与 ref/ fixture 相同）
├── requirements.txt
├── sql_agent_langchain/            # 原 src/sql_agent/
│   ├── config.py                   # 运行配置（默认模型改为智谱 glm-5.3）
│   ├── models.py                   # Pydantic 数据契约（原样复用）
│   ├── logging_config.py           # 日志配置（原样复用）
│   ├── db/
│   │   ├── catalog.py              # SchemaCatalog（原样复用）
│   │   ├── validator.py            # SQLValidator：安全门禁 + EXPLAIN（原样复用）
│   │   └── executor.py             # SQLExecutor：只读执行（原样复用）
│   ├── agents/                     # ← 移植重点：4 个 Agent 换 create_agent + ToolStrategy
│   │   ├── table_selector.py
│   │   ├── sql_generator.py
│   │   ├── sql_rewriter.py
│   │   └── result_summarizer.py
│   ├── workflow.py                 # ← 移植重点：Runner.run → agent.invoke，async → 同步
│   ├── __main__.py                 # CLI 入口
│   └── __init__.py
└── tests/
    └── test_components.py          # 18 个测试（无 LLM，mock Agent）
```

## 四、运行方式

```bash
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

# 端到端（真实 LLM）
python -m sql_agent_langchain "总共有多少张专辑？"
python -m sql_agent_langchain "美国客户的订单总金额是多少？"

# 测试（mock LLM，无需 API key）
pytest tests/ -q

# 配置：环境变量可覆盖
#   ZHIPU_API_KEY / OPENAI_API_KEY   API key
#   SQL_AGENT_MODEL                  主模型（默认 glm-5.3）
#   SQL_AGENT_SUMMARY_MODEL          汇总模型（默认 glm-5.3，可换 glm-4-flash 省钱）
#   SQL_AGENT_DB                     数据库路径（默认本目录 chinook.db）
#   SQL_AGENT_LOG_LEVEL              日志级别
```

## 五、验证记录（2026-10-29，智谱 glm-5.3）

- `pytest tests/ -q`：**18 passed** —— 覆盖安全门禁（INSERT/多语句/PRAGMA 拦截、字面量掩码）、EXPLAIN 校验、执行只读与截断、外键连通性、编排的 5 条路径（正常 / 修复一次 / cannot_fix 提前退出 / 空结果跳过汇总 / 汇总降级表格）；
- CLI「总共有多少张专辑？」：选表 albums → `SELECT COUNT(*)` → 答案 347 ✅；
- CLI「美国客户的订单总金额？」：自动选表 customers+invoices → 显式 JOIN → `SUM(Total) WHERE Country='USA'` = **523.06** ✅（与 chinook 已知数据一致），JSON/日志分流行为与原版一致。
