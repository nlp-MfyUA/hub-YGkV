"""后端：调用智谱 GLM-5.3-Flash 多模态模型，对楼道照片做消防安全隐患分级。

纯 openai client 的类模式（与第十一周 SQL Agent 作业保持一致）。
"""

import base64
import io
import json
import os
import re

from openai import OpenAI
from PIL import Image, ImageOps

# 前端允许上传的图片格式；装了 pillow-heif 才额外支持 iPhone 的 HEIC 照片
ALLOWED_IMAGE_TYPES = ["jpg", "jpeg", "png", "webp", "bmp"]
try:
    from pillow_heif import register_heif_opener

    register_heif_opener()
    ALLOWED_IMAGE_TYPES += ["heic", "heif"]
except ImportError:
    pass

# key 优先读环境变量 ZHIPU_API_KEY，便于换 key 不改代码
API_KEY = os.environ.get("ZHIPU_API_KEY", "Xa7d1eXe439741239e86eaa73811e2122d2122d0382Q")
BASE_URL = "https://open.bigmodel.cn/api/paas/v4"  # 智谱 OpenAI 兼容端点
MODEL = os.environ.get("ZHIPU_VISION_MODEL", "glm-5.3-flash")

# 五个风险等级（作业要求的分级标准）
RISK_LEVELS = ["高风险", "中风险", "低风险", "无风险", "非楼道"]

PROMPT = """你是一个专业消防专家，擅长识别各种风险。请识别照片中场景的消防安全隐患以及隐患的危险程度。根据楼道中是否存在大量堆积物，堆积物是否可燃以及是否有起火风险将隐患分为无隐患、低风险、中等风险、高风险。

- 高风险：楼道中出现电动车、电瓶、飞线充电等可能起火的元素。
- 中风险：楼道中存在大量堆积物严重影响通行或堆放大量纸箱、木质家具等能造成火势蔓延的堵塞物。
- 低风险：存在楼道堆物现象但不严重。
- 无风险：楼道干净，无堆放物品。
- 非楼道：一些与楼道无关的图片。

请严格只输出一个 JSON 对象，不要输出任何解释或多余文字，格式如下：
{"risk_level": "高风险/中风险/低风险/无风险/非楼道 中的一个",
 "items": ["画面中与隐患相关的物品，如 电动车、电瓶、飞线、纸箱、木质家具 等；没有则为空数组"],
 "reason": "50字以内的判定理由"}"""


class CorridorRiskAnalyzer:
    """楼道消防安全隐患识别器。"""

    def __init__(self, api_key: str = API_KEY, base_url: str = BASE_URL, model: str = MODEL):
        self.client = OpenAI(api_key=api_key, base_url=base_url, timeout=60)
        self.model = model

    @staticmethod
    def encode_image(image: Image.Image, max_side: int = 1280) -> str:
        """压缩手机照片并编码为 base64 data URL，避免原图过大导致请求超时。"""
        image = ImageOps.exif_transpose(image)  # 按拍摄方向摆正
        if image.mode != "RGB":
            image = image.convert("RGB")
        if max(image.size) > max_side:
            image.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        image.save(buf, format="JPEG", quality=90)
        b64 = base64.b64encode(buf.getvalue()).decode()
        return f"data:image/jpeg;base64,{b64}"

    def analyze(self, image: Image.Image) -> dict:
        """识别一张楼道照片，返回 {"risk_level": 等级, "items": [物品...], "reason": 理由}。"""
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": self.encode_image(image)}},
                        {"type": "text", "text": PROMPT},
                    ],
                }
            ],
            max_tokens=2048,  # glm-5.3-flash 会先输出思考内容，预算太小会导致正文为空
        )
        text = resp.choices[0].message.content or ""
        return self.parse_reply(text)

    @staticmethod
    def parse_reply(text: str) -> dict:
        """容错解析模型回复：优先取 JSON；失败则退化到正则匹配等级。"""
        # 剥掉可能的 ```json ... ``` 围栏
        text = text.strip()
        fence = re.search(r"```(?:json)?\s*(.+?)\s*```", text, re.S)
        if fence:
            text = fence.group(1)

        # 尝试解析第一个 {...} JSON 对象
        brace = re.search(r"\{.*\}", text, re.S)
        if brace:
            try:
                data = json.loads(brace.group(0))
                level = str(data.get("risk_level", "")).strip()
                if level in RISK_LEVELS:
                    items = data.get("items") or []
                    if not isinstance(items, list):
                        items = [str(items)]
                    return {
                        "risk_level": level,
                        "items": [str(i) for i in items],
                        "reason": str(data.get("reason", "")).strip(),
                    }
            except (json.JSONDecodeError, AttributeError):
                pass

        # 兜底：直接在原文里找等级词
        for level in RISK_LEVELS:
            if level in text:
                return {"risk_level": level, "items": [], "reason": text.strip()[:100]}

        raise ValueError(f"无法从模型回复中解析风险等级，原始回复：{text[:200]}")
