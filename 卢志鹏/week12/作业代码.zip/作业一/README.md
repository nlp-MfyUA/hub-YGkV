# 作业一：楼道消防安全隐患识别（前后端多模态应用）

参考《案例-多模态内容理解.ipynb》，用多模态大模型实时识别楼道照片中的消防安全隐患。

- **前端**：Streamlit，支持网页调用摄像头拍照 + 上传图片两种方式
  - 上传支持一次选多张照片批量识别（jpg / jpeg / png / webp / bmp，装了 pillow-heif 时还支持 iPhone 的 heic / heif）
- **后端**：纯 `openai` client 调智谱 OpenAI 兼容端点，模型 `glm-5.3-flash`

## 风险分级标准

| 等级 | 判定标准 |
| --- | --- |
| 🔴 高风险 | 楼道中出现电动车、电瓶、飞线充电等可能起火的元素 |
| 🟠 中风险 | 存在大量堆积物严重影响通行，或堆放大量纸箱、木质家具等能造成火势蔓延的堵塞物 |
| 🟡 低风险 | 存在楼道堆物现象但不严重 |
| 🟢 无风险 | 楼道干净，无堆放物品 |
| ⚪ 非楼道 | 与楼道无关的图片 |

## 运行方法

```bash
conda activate ai-learn
cd 第十二周作业/作业一
streamlit run app.py
```

浏览器自动打开 `http://localhost:8501`，在"📷 拍照识别"页点击拍照，或在"🖼️ 上传图片"页选择图片，再点"🔍 开始识别"。

## 手机访问（拍照需要 HTTPS）

`st.camera_input` 调用浏览器摄像头 API，浏览器只在 **HTTPS 或 localhost** 下允许打开摄像头。因此：

- **本机测试**：直接用电脑浏览器打开 `http://localhost:8501`，摄像头/拍照功能正常
- **手机访问**：
  1. 手机与电脑连同一 Wi-Fi，电脑上运行 `streamlit run app.py --server.address 0.0.0.0`
  2. 手机浏览器打开 `http://<电脑IP>:8501`，此时"上传图片"可用，但拍照会被浏览器安全策略拦截
  3. 想在手机上拍照，需要 HTTPS，最简单的办法是临时隧道，例如：
     ```bash
     cloudflared tunnel --url http://localhost:8501
     # 或 ngrok http 8501
     ```
     用手机打开隧道给出的 `https://xxx` 地址即可调用手机摄像头拍照

## 配置说明

- API key 优先读环境变量 `ZHIPU_API_KEY`，未设置时用代码内默认 key
- 模型可用环境变量 `ZHIPU_VISION_MODEL` 覆盖，默认 `glm-5.3-flash`

## 文件结构

```
作业一/
├── app.py       # 前端：Streamlit 页面（拍照/上传/结果展示/历史记录）
├── backend.py   # 后端：CorridorRiskAnalyzer，调 GLM-5.3-Flash 做风险分级
├── requirements.txt
└── README.md
```
