"""前端：Streamlit 楼道消防安全隐患识别应用。

运行：streamlit run app.py
"""

import time
from datetime import datetime

import streamlit as st
from PIL import Image

from backend import ALLOWED_IMAGE_TYPES, MODEL, CorridorRiskAnalyzer

st.set_page_config(page_title="楼道消防隐患识别", page_icon="🚒", layout="wide")


@st.cache_resource
def get_analyzer() -> CorridorRiskAnalyzer:
    """整个应用只创建一次客户端连接。"""
    return CorridorRiskAnalyzer()


# 等级 -> （圆点表情, st 提示组件名）
BADGE = {
    "高风险": ("🔴", "error"),
    "中风险": ("🟠", "warning"),
    "低风险": ("🟡", "warning"),
    "无风险": ("🟢", "success"),
    "非楼道": ("⚪", "info"),
}


def render_result(level: str, items: list, reason: str, elapsed: float):
    """展示单张照片的识别结果。"""
    dot, method = BADGE.get(level, ("⚪", "info"))
    getattr(st, method)(f"识别结果：{dot} **{level}**　（耗时 {elapsed:.1f} 秒）")
    if items:
        st.markdown("**相关物品：**" + "、".join(items))
    if reason:
        st.markdown(f"**判定理由：**{reason}")


# ---------- 侧边栏：分级标准 ----------
st.sidebar.title("🚒 楼道消防隐患识别")
st.sidebar.caption(f"模型：{MODEL}（智谱多模态大模型）")
st.sidebar.divider()
st.sidebar.subheader("风险分级标准")
st.sidebar.markdown(
    """
- 🔴 **高风险**：楼道中出现电动车、电瓶、飞线充电等可能起火的元素
- 🟠 **中风险**：存在大量堆积物严重影响通行，或堆放大量纸箱、木质家具等能造成火势蔓延的堵塞物
- 🟡 **低风险**：存在楼道堆物现象但不严重
- 🟢 **无风险**：楼道干净，无堆放物品
- ⚪ **非楼道**：与楼道无关的图片
"""
)

# ---------- 主区域：获取图片（拍照 / 上传） ----------
st.title("🚒 楼道消防安全隐患识别")
st.caption("拍照或上传楼道照片，AI 实时判断是否存在消防安全隐患及危险程度（支持一次上传多张批量识别）")

pending = []  # [(PIL.Image, 来源说明)]

tab_snap, tab_upload = st.tabs(["📷 拍照识别", "🖼️ 上传图片"])

with tab_snap:
    shot = st.camera_input("打开摄像头拍照")
    if shot is not None:
        pending.append((Image.open(shot), "拍照"))

with tab_upload:
    uploads = st.file_uploader(
        "选择一张或多张照片", type=ALLOWED_IMAGE_TYPES, accept_multiple_files=True
    )
    for upload in uploads or []:
        pending.append((Image.open(upload), "上传"))

# ---------- 逐张识别与结果展示 ----------
if pending:
    if st.button(f"🔍 开始识别（共 {len(pending)} 张）", type="primary"):
        history = st.session_state.setdefault("history", [])
        for idx, (image, source) in enumerate(pending, start=1):
            if len(pending) > 1:
                st.subheader(f"第 {idx} 张")
            col_img, col_res = st.columns([2, 3])
            with col_img:
                st.image(image)
            with col_res:
                start = time.time()
                with st.spinner("AI 正在分析图片…"):
                    try:
                        result = get_analyzer().analyze(image)
                    except Exception as exc:  # 单张失败不影响其余照片
                        st.error(f"识别失败：{exc}")
                        continue
                render_result(
                    result["risk_level"], result["items"], result["reason"], time.time() - start
                )
                history.insert(
                    0,
                    {
                        "时间": datetime.now().strftime("%H:%M:%S"),
                        "来源": source,
                        "风险等级": result["risk_level"],
                        "相关物品": "、".join(result["items"]),
                        "理由": result["reason"],
                    },
                )

# ---------- 历史记录 ----------
history = st.session_state.get("history", [])
if history:
    st.divider()
    st.subheader("📋 本次会话识别历史")
    st.dataframe(history, hide_index=True)
