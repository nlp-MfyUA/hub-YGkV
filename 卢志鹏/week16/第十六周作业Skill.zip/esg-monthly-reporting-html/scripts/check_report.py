#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ESG 报告自检脚本（月报、投标信息汇总、每日推送共用）。

检查一份 Markdown 报告的必备章节、占位符、引用与来源清单、表格、提示框、
标题层级、代码围栏与 Mermaid 图，以及中文排版和文件格式问题。

用法：
    python scripts/check_report.py <报告.md> --kind monthly|tender-summary|daily
        [--window 起始..结束] [--json] [--fix]

--fix 先做四类安全的自动修复并写回文件（补空格、去行尾空白、结尾补换行、去 BOM），
然后照常检查。

退出码：0 没有错误；1 有错误；2 用法或文件错误。
只用标准库，兼容 Python 3.9。
"""

import argparse
import json
import re
import sys
from calendar import monthrange
from datetime import date
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import unquote

# 每类报告必备章节的关键词组：某组任一关键词出现在某个二级标题里，该组就算有
REQUIRED_SECTIONS = {
    "monthly": [
        ["一页速览"], ["政策"], ["评级"], ["标准"], ["行业"],
        ["公司"], ["对标"], ["建议"], ["来源"],
    ],
    "tender-summary": [
        ["速览"], ["数据说明"], ["主题"], ["金额分布"], ["趋势"],
        ["采购人"], ["中标机构"], ["明细"], ["来源"],
    ],
    "daily": [["概览"], ["招标"], ["来源"]],
}

ALERT_TYPES = ("NOTE", "TIP", "IMPORTANT", "WARNING", "CAUTION")
MERMAID_TYPES = ("pie", "xychart-beta", "timeline")

CJK = r"[\u4e00-\u9fff]"
BOM = "\ufeff"  # UTF-8 BOM 字符
HEADING_RE = re.compile(r"^ {0,3}(#{1,6})(?:[ \t]+(.*?))?[ \t]*$")
FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
TABLE_ROW_RE = re.compile(r"^ {0,3}\|")
SEP_CELL_RE = re.compile(r":?-+:?")
INT_RE = re.compile(r"\d+")
PLACEHOLDER_RE = re.compile(
    r"(?<![A-Za-z])(?:TBD|TODO|XXX)(?![A-Za-z])|待补充|待填写|待完善"
)
CITATION_RE = re.compile(r"\[(\d+)\]")
ALERT_RE = re.compile(r"^ {0,3}>\s*\[!([^\]]*)\]")
# 两种日期写法：YYYY-MM-DD；YYYY年M月D日 或 YYYY年M月（没有日）
DATE_RE = re.compile(
    r"(?<!\d)(?:(?P<y>\d{4})-(?P<m>\d{1,2})-(?P<d>\d{1,2})(?!\d)"
    r"|(?P<yy>\d{4})年(?P<mm>\d{1,2})月(?:(?P<dd>\d{1,2})日)?)"
)
# 不带年份的「月-日」（如 10-21、10-26）；后面跟量词的是数字区间，不是日期
MONTH_DAY_RE = re.compile(
    r"(?<![\d.\-/:])(0?[1-9]|1[0-2])-(0?[1-9]|[12]\d|3[01])(?![\d.\-/:])"
)
UNIT_AFTER_RE = re.compile(r"\s*(?:个|年|万|%|倍|小时|分钟|天|人|家|条|次|项|元)")
LINK_RE = re.compile(r"\]\(\s*(?:<([^>]*)>|([^\s)]+))(?:\s+\"[^\"]*\")?\s*\)")
LINK_DEF_RE = re.compile(r"^ {0,3}\[([^\]]+)\]:\s*<?([^\s>]+)>?")
SCHEME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.\-]*:")
# 中文排版
SPACE_RE = re.compile(CJK + r"[A-Za-z0-9]|[A-Za-z0-9]" + CJK)
PUNCT_RE = re.compile(CJK + r"[,.;:!?]\s*" + CJK)
ITALIC_RE = re.compile(
    r"(?<!\*)\*(?![\s*])[^*\n]*" + CJK + r"[^*\n]*(?<!\s)\*(?!\*)"
)
# 排版检查时要遮掉的内容：行内代码、链接地址、裸 URL
INLINE_CODE_RE = re.compile(r"`+[^`]*`+")
LINK_DEST_RE = re.compile(r"\]\(\s*(?:<[^>]*>|[^\s)]+)(?:\s+\"[^\"]*\")?\s*\)")
AUTOLINK_RE = re.compile(r"<[^\s>]+>")
URL_RE = re.compile(r"https?://\S+|www\.\S+")
TRAILING_RE = re.compile(r"[ \t]+$")
# 「图旁有表」判断用：水平分割线、统计脚本输出的说明行
HR_RE = re.compile(r"^(?:(?:\*[ \t]*){3,}|(?:-[ \t]*){3,}|(?:_[ \t]*){3,})$")
NOTE_LINE_RE = re.compile(r"^披露金额的项目数\s*[\d,，]+\s*/\s*样本数\s*[\d,，]+$")
# 自动补空格时不改动的内容：HTML 标签、裸露的 http(s) 网址
HTML_TAG_RE = re.compile(r"</?[A-Za-z][^<>]*>")
BARE_URL_RE = re.compile(r"https?://\S+")


# ---------------------------------------------------------------- 基础工具

def _blank(match):
    """把匹配到的内容换成等长空格，保持行列位置不变。"""
    return " " * len(match.group(0))


def _mask_urls(text):
    """去掉链接地址和裸 URL，保留链接文字。"""
    text = LINK_DEST_RE.sub(_blank, text)
    text = AUTOLINK_RE.sub(_blank, text)
    return URL_RE.sub(_blank, text)


def _split_cells(line):
    """按未转义的竖线切分表格单元格；单元格里的 \\| 不算分隔符。"""
    s = line.strip()
    cells = re.split(r"(?<!\\)\|", s)
    if s.startswith("|"):
        cells = cells[1:]
    if cells and s.endswith("|") and not s.endswith("\\|"):
        cells = cells[:-1]
    return [c.strip() for c in cells]


def _is_separator(cells):
    """判断一行单元格是否是表格分隔行（如 | --- | :---: |）。"""
    return bool(cells) and all(SEP_CELL_RE.fullmatch(c) for c in cells)


def _runs(indexes):
    """把有序下标列表切成若干段连续下标。"""
    runs, current = [], []
    for i in indexes:
        if current and i != current[-1] + 1:
            runs.append(current)
            current = []
        current.append(i)
    if current:
        runs.append(current)
    return runs


def _scan(lines: List[str]):
    """扫描一遍，标出代码围栏、Mermaid 块和 HTML 注释。

    返回 (visible, comments, blocks, unbalanced)：
    - visible：每行的可见文本。围栏行（含起止标记）是空串；注释部分换成等长空格。
    - comments：[(行下标, 注释内容)]。
    - blocks：[(起始行下标, 结束行下标, 语言, 是否闭合)]。
    - unbalanced：没有闭合的围栏的起始行下标。
    """
    visible, comments, blocks, unbalanced = [], [], [], []
    in_comment = False
    fence = None  # (起始行下标, 围栏字符, 围栏长度, 语言)
    for i, raw in enumerate(lines):
        if fence is not None:
            m = FENCE_RE.match(raw)
            if (m and m.group(1)[0] == fence[1] and len(m.group(1)) >= fence[2]
                    and not m.group(2).strip()):
                blocks.append((fence[0], i, fence[3], True))
                fence = None
            visible.append("")
            continue
        line = raw
        if in_comment:
            end = line.find("-->")
            if end == -1:
                comments.append((i, line))
                visible.append("")
                continue
            comments.append((i, line[:end]))
            line = " " * (end + 3) + line[end + 3:]
            in_comment = False
        start = line.find("<!--")
        if start != -1:
            end = line.find("-->", start + 4)
            if end == -1:
                comments.append((i, line[start + 4:]))
                line = line[:start]
                in_comment = True
            else:
                comments.append((i, line[start + 4:end]))
                line = line[:start] + " " * (end + 3 - start) + line[end + 3:]
        visible.append(line)
        m = FENCE_RE.match(line)
        # 反引号围栏的信息串里不能再有反引号，否则不是围栏
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            fence = (i, m.group(1)[0], len(m.group(1)), m.group(2).strip())
    if fence is not None:
        blocks.append((fence[0], len(lines) - 1, fence[3], False))
        unbalanced.append(fence[0])
    return visible, comments, blocks, unbalanced


def _table_nearby(lines: List[str], visible: List[str], fenced: set, not_data_lines: set,
                  start: int, end: int) -> bool:
    """判断 Mermaid 图旁边有没有数据表。

    从图的上方、下方各找 8 行：跳过空行、"披露金额的项目数 N / 样本数 M"说明行和
    代码围栏行；遇到标题行或水平分割线就停，不越过它们拿别的小节的表充数；
    其余行里出现表格行就算有，中间隔一段普通文字也算。来源清单表不算数据表。
    """
    def scan(indexes):
        for j in indexes:
            if j < 0 or j >= len(lines):
                return False
            if j in fenced or not visible[j].strip():
                continue  # 代码围栏行、空行、注释行
            if NOTE_LINE_RE.match(lines[j].strip()):
                continue  # 图表下方的说明行
            if HEADING_RE.match(visible[j]) or HR_RE.match(lines[j].strip()):
                return False
            if TABLE_ROW_RE.match(lines[j]) and j not in not_data_lines:
                return True
        return False

    up = scan(range(start - 1, start - 9, -1))
    down = scan(range(end + 1, end + 9))
    return up or down


def _to_date(value) -> date:
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value).strip())


def _parse_window(window) -> Tuple[date, date]:
    try:
        start, end = window
        return _to_date(start), _to_date(end)
    except (TypeError, ValueError):
        raise ValueError(
            "window 应为（起始, 结束）两个 YYYY-MM-DD 日期，如 ('2026-10-01', '2026-10-31')"
        ) from None


def _date_span(match):
    """把日期匹配换算成 (最早日期, 最晚日期)；没有日时是整个月。不是合法日期返回 None。"""
    try:
        if match.group("y"):
            day = date(int(match.group("y")), int(match.group("m")), int(match.group("d")))
            return day, day
        year, month = int(match.group("yy")), int(match.group("mm"))
        if match.group("dd"):
            day = date(year, month, int(match.group("dd")))
            return day, day
        return date(year, month, 1), date(year, month, monthrange(year, month)[1])
    except ValueError:
        return None


def _local_target(dest: str) -> Optional[str]:
    """链接地址指向本地文件时返回去掉锚点和查询串的路径，否则返回 None。"""
    dest = dest.strip()
    if not dest or dest.startswith("#") or dest.startswith("//"):
        return None
    if SCHEME_RE.match(dest):
        return None
    dest = dest.split("#", 1)[0].split("?", 1)[0]
    return dest or None


def _exists(path: Path) -> bool:
    try:
        return path.exists()
    except OSError:
        return False


def _fenced_lines(blocks) -> set:
    """返回所有围栏行（含起止标记）的行下标集合。"""
    fenced = set()
    for start, end, _lang, _closed in blocks:
        fenced.update(range(start, end + 1))
    return fenced


# ---------------------------------------------------------------- 检查主体

def check_text(text: str, kind: str,
               window: Optional[Tuple[str, str]] = None,
               base_dir: Optional[Path] = None) -> dict:
    """检查一段报告文本。

    返回 {"errors": [issue], "warnings": [issue], "stats": {...}}；
    issue 是 {"code", "line", "message"}，line 为 None 表示全文性问题。
    给了 base_dir 时才检查本地链接。
    """
    if kind not in REQUIRED_SECTIONS:
        raise ValueError("未知的报告类型：%r" % (kind,))
    text = text.replace("\r\n", "\n")
    errors, warnings = [], []

    def add(code, line, message):
        target = errors if code.startswith("E_") else warnings
        target.append({"code": code, "line": line, "message": message})

    # ---- 文件格式
    if text.startswith(BOM):
        add("W_FORMAT_BOM", 1, "文件以 UTF-8 BOM 开头；请另存为不带 BOM 的 UTF-8")
        text = text[1:]
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    if not text.endswith("\n"):
        add("W_FORMAT_EOF", max(len(lines), 1), "文件不以换行结尾；请在末尾补一个换行")

    visible, comments, blocks, unbalanced = _scan(lines)
    fenced = _fenced_lines(blocks)
    for i, line in enumerate(lines):
        if i not in fenced and TRAILING_RE.search(line):
            add("W_FORMAT_TRAILING", i + 1, "行尾有多余空白；请删除")
    for start in unbalanced:
        add("E_FENCE_UNBALANCED", start + 1, "代码围栏没有闭合；请补上结尾的围栏标记")

    # ---- 标题
    headings = []  # (层级, 标题文字, 行号)
    for i, v in enumerate(visible):
        m = HEADING_RE.match(v)
        if m:
            title = re.sub(r"[ \t]+#+$", "", m.group(2) or "").strip()
            headings.append((len(m.group(1)), title, i + 1))
    h1_count = sum(1 for level, _, _ in headings if level == 1)
    if h1_count != 1:
        add("E_H1_COUNT", None, "一级标题应恰好一个，实际 %d 个；请只保留一个 # 标题" % h1_count)
    prev_level = None
    for level, _title, ln in headings:
        if prev_level is not None and level > prev_level + 1:
            add("E_HEADING_JUMP", ln, "标题从 %d 级跳到 %d 级；请逐级使用标题" % (prev_level, level))
        prev_level = level
    h2_titles = [title for level, title, _ in headings if level == 2]
    for group in REQUIRED_SECTIONS[kind]:
        if not any(kw in title for title in h2_titles for kw in group):
            add("E_REQUIRED_SECTIONS", None,
                "缺少必备章节：没有含「%s」的二级标题；请补上该章节，或在标题里带上关键词"
                % "/".join(group))

    # 来源章节：从标题文字含「来源」的标题起，到下一个同级或更高级标题之前（或到文末）。
    # 只有来源章节里第一格是整数的表格行才算来源清单；正文里带序号的表不算。
    source_ranges = []  # [(起始行下标, 结束行下标)]，闭区间
    opened = None  # (起始行下标, 标题层级)
    for level, title, ln in headings:
        if opened is not None and level <= opened[1]:
            source_ranges.append((opened[0], ln - 2))
            opened = None
        if "来源" in title:
            opened = (ln - 1, level)
    if opened is not None:
        source_ranges.append((opened[0], len(lines) - 1))

    def in_sources_section(i):
        return any(a <= i <= b for a, b in source_ranges)

    # ---- 占位符与待写标记
    for i, content in comments:
        if "待写" in content:
            add("E_PENDING_MARKER", i + 1, "HTML 注释里有「待写」标记，说明这部分还没写；写完后删除标记")
    noun = [_mask_urls(v) for v in visible]           # 去掉链接地址
    typo = [INLINE_CODE_RE.sub(_blank, t) for t in noun]  # 再去掉行内代码
    for i, t in enumerate(noun):
        m = PLACEHOLDER_RE.search(t)
        if m:
            add("E_PLACEHOLDER", i + 1, "可见占位符「%s」；请换成实际内容" % m.group(0))

    # ---- 表格
    row_cells = {i: _split_cells(v) for i, v in enumerate(visible) if TABLE_ROW_RE.match(v)}
    table_count = 0
    sources_table_lines = set()  # 来源清单表（表头到最后一行）占用的行下标
    for run in _runs(sorted(row_cells)):
        # 紧挨着分隔行的那一行是表头；表头开启一张新表
        headers = [k for k in run if k + 1 in row_cells and _is_separator(row_cells[k + 1])]
        if not headers:
            if len(run) >= 2:  # 孤零零一行竖线不算表格
                table_count += 1
                add("E_TABLE_NO_SEPARATOR", run[1] + 1,
                    "表格第二行不是分隔行（如 | --- | --- |）；请补上分隔行")
            continue
        if headers[0] - run[0] >= 2:  # 第一个表头之前还有两行以上
            table_count += 1
            add("E_TABLE_NO_SEPARATOR", run[1] + 1,
                "表格第二行不是分隔行（如 | --- | --- |）；请补上分隔行")
        bounds = headers + [run[-1] + 1]
        for h, nxt in zip(headers, bounds[1:]):
            table_count += 1
            width = len(row_cells[h])
            for k in range(h + 1, nxt):
                if len(row_cells[k]) != width:
                    add("E_TABLE_COLUMNS", k + 1,
                        "表格列数（%d）与表头（%d）不一致；请补齐或删去单元格，"
                        "单元格里的竖线写成 \\|" % (len(row_cells[k]), width))
            # 来源章节里带编号行的表是来源清单，不算图旁的数据表
            if in_sources_section(h) and any(
                    row_cells[k] and INT_RE.fullmatch(row_cells[k][0]) for k in range(h + 1, nxt)):
                sources_table_lines.update(range(h, nxt))

    # ---- 引用与来源清单
    source_rows = {}  # 行下标 -> 编号（来源章节内第一格是整数的表格行）
    for i, cells in row_cells.items():
        first = cells[0] if cells else ""
        if INT_RE.fullmatch(first) and in_sources_section(i):
            source_rows[i] = int(first)
    sources = {}  # 编号 -> 行号
    for i, n in source_rows.items():
        sources.setdefault(n, i + 1)
    used = {}  # 编号 -> 首次引用的行号
    for i, t in enumerate(typo):
        if i in source_rows:
            continue
        for m in CITATION_RE.finditer(t):
            used.setdefault(int(m.group(1)), i + 1)
    for n, ln in sorted(used.items()):
        if n not in sources:
            add("E_CITATION_MISSING", ln,
                "正文引用了 [%d]，但来源清单里没有第 %d 行；请补充来源或改正编号" % (n, n))
    for n, ln in sorted(sources.items()):
        if n not in used:
            add("W_SOURCE_UNUSED", ln, "来源清单第 %d 行从未被引用；请删除，或在正文引用 [%d]" % (n, n))
    not_data_lines = sources_table_lines | set(source_rows)  # 来源清单不算图旁的数据表

    # ---- 提示框
    for i, v in enumerate(visible):
        m = ALERT_RE.match(v)
        if not m:
            continue
        alert_type = m.group(1).strip()
        j = i - 1
        while j >= 0 and not lines[j].strip():
            j -= 1
        nested = j >= 0 and lines[j].lstrip().startswith(">")
        if alert_type not in ALERT_TYPES:
            add("E_ALERT_SYNTAX", i + 1,
                "提示框类型「%s」不合法；只能是 NOTE、TIP、IMPORTANT、WARNING、CAUTION，且全部大写"
                % alert_type)
        elif nested:
            add("E_ALERT_SYNTAX", i + 1,
                "提示框必须是引用块的第一行；请把它放到引用块开头，或与前面的引用分开")

    # ---- Mermaid
    mermaid_count = 0
    for start, end, lang, closed in blocks:
        if lang.lower() != "mermaid":
            continue
        mermaid_count += 1
        content = lines[start + 1:end if closed else end + 1]
        first = next((l.strip() for l in content if l.strip()), "")
        if not first.startswith(MERMAID_TYPES):
            add("E_MERMAID_UNSUPPORTED", start + 1,
                "Mermaid 块第一行应以 pie、xychart-beta 或 timeline 开头；其他图型请改成表格")
        if not _table_nearby(lines, visible, fenced, not_data_lines, start, end):
            add("W_MERMAID_NO_TABLE", start + 1,
                "Mermaid 图前后 8 行内没有数据表（中间不能隔着标题或分割线）；请在图旁放一张数据表")

    # ---- 窗口外日期
    if window is not None:
        w_start, w_end = _parse_window(window)
        for i, t in enumerate(noun):
            for m in DATE_RE.finditer(t):
                span = _date_span(m)
                if span and (span[1] < w_start or span[0] > w_end):
                    add("W_DATE_OUT_OF_WINDOW", i + 1,
                        "日期「%s」在窗口外；请确认它是否属于本报告的统计期" % m.group(0))

    # ---- 不带年份的「月-日」日期（如 10-21）：每个出现问题的行给一条警告。
    # typo 已去掉围栏、注释、链接地址、行内代码；这里再去掉 HTML 标签。
    for i, t in enumerate(typo):
        clean = HTML_TAG_RE.sub(_blank, t)
        found = []
        for m in MONTH_DAY_RE.finditer(clean):
            if m.start() > 0 and clean[m.start() - 1] == "第":
                continue  # 紧挨着「第」的是序号（第10-21条），不是日期
            if UNIT_AFTER_RE.match(clean, m.end()):
                continue  # 后面跟量词的是数字区间（3-5 个、20-30 万、5-10%）
            found.append(m.group(0))
        if found:
            add("W_DATE_NO_YEAR", i + 1,
                "日期没有年份：%s；请写成 2026-10-21 或 2026 年 10 月 21 日"
                % "、".join("「%s」" % f for f in found))

    # ---- 本地链接
    if base_dir is not None:
        base = Path(base_dir)
        for i, v in enumerate(visible):
            targets = [m.group(1) or m.group(2) for m in LINK_RE.finditer(v)]
            targets += [m.group(2) for m in LINK_DEF_RE.finditer(v)]
            for raw in targets:
                rel = _local_target(raw)
                if rel is not None and not _exists(base / unquote(rel)):
                    add("W_LOCAL_LINK_MISSING", i + 1,
                        "本地链接指向的文件不存在：%s；请检查路径或先创建文件" % raw)

    # ---- 中文排版
    for i, t in enumerate(typo):
        m = SPACE_RE.search(t)
        if m:
            add("W_TYPOGRAPHY_SPACE", i + 1, "中文与英文或数字之间缺空格，如「%s」；请加空格" % m.group(0))
        m = PUNCT_RE.search(t)
        if m:
            add("W_TYPOGRAPHY_PUNCT", i + 1, "中文之间夹了半角标点，如「%s」；请改成全角" % m.group(0))
        m = ITALIC_RE.search(t)
        if m:
            add("W_TYPOGRAPHY_ITALIC", i + 1, "中文不要用斜体，如「%s」；需要强调时请用加粗" % m.group(0))

    def order(issue):
        # 全文性问题（line 为 None）排在最前，其余按行号；同一行内保持发现顺序
        return (issue["line"] is None, issue["line"] or 0)

    errors.sort(key=order)
    warnings.sort(key=order)
    return {
        "errors": errors,
        "warnings": warnings,
        "stats": {
            "lines": len(lines),
            "h2": len(h2_titles),
            "citations_used": len(used),
            "sources_listed": len(sources),
            "tables": table_count,
            "mermaid": mermaid_count,
        },
    }


def check_file(path: Path, kind: str, window=None) -> dict:
    """检查一个报告文件；本地链接按文件所在目录解析。"""
    path = Path(path)
    text = path.read_bytes().decode("utf-8")  # 保留 BOM 字符，交给 check_text 判断
    return check_text(text, kind, window, base_dir=path.parent)


# ---------------------------------------------------------------- 自动修复

def fix_spacing(text: str) -> str:
    """在中文与 ASCII 字母、数字直接相邻的地方补一个空格，返回新文本。

    已经隔着一个空格的保持不变。下面这些位置不改（按原文长度占位，处理完再还原）：
    围栏代码块内部、行内代码、链接地址和裸露的 http(s) 网址、HTML 标签和注释、
    `> [!类型]` 提示框标记行、表格分隔行。
    """
    lines = text.split("\n")
    visible, _comments, blocks, _unbalanced = _scan(lines)
    fenced = _fenced_lines(blocks)
    out = []
    for i, raw in enumerate(lines):
        v = visible[i]
        if i in fenced or not raw.strip() or ALERT_RE.match(v):
            out.append(raw)
            continue
        if TABLE_ROW_RE.match(v) and _is_separator(_split_cells(v)):
            out.append(raw)
            continue
        # work 与 raw 等长：注释内容 _scan 已换成空格（延伸到行尾的注释用 ljust 补齐），
        # 再把行内代码、链接地址、HTML 标签、自动链接、裸网址换成空格
        work = list(v.ljust(len(raw)))
        for pattern in (INLINE_CODE_RE, LINK_DEST_RE, HTML_TAG_RE, AUTOLINK_RE, BARE_URL_RE):
            for m in pattern.finditer("".join(work)):
                work[m.start():m.end()] = [" "] * (m.end() - m.start())
        # 在 work 上找到要补空格的位置（两个相邻字符之间），从右往左插回 raw
        points = [m.start() + 1 for m in SPACE_RE.finditer("".join(work))]
        for p in reversed(points):
            raw = raw[:p] + " " + raw[p:]
        out.append(raw)
    return "\n".join(out)


def apply_fixes(text: str) -> Tuple[str, int, int]:
    """做四类安全的自动修复，返回 (修复后的文本, 补空格处数, 去行尾空白行数)。

    补空格；去掉行尾空白（围栏内不动）；确保以恰好一个换行结尾；去掉开头的 UTF-8 BOM。
    换行风格（CRLF 或 LF）保持不变。
    """
    if text.startswith(BOM):
        text = text[1:]
    fixed = fix_spacing(text)
    n_space = len(fixed) - len(text)
    lines = fixed.split("\n")
    fenced = _fenced_lines(_scan(lines)[2])
    n_trailing = 0
    for i, line in enumerate(lines):
        if i in fenced:
            continue
        stripped = re.sub(r"[ \t]+(?=\r?$)", "", line)
        if stripped != line:
            n_trailing += 1
            lines[i] = stripped
    newline = "\r\n" if "\r\n" in fixed else "\n"
    fixed = "\n".join(lines).rstrip("\r\n") + newline
    return fixed, n_space, n_trailing


def _fix_file(path: Path) -> Tuple[int, int]:
    """对文件做自动修复并以 UTF-8（无 BOM）写回；返回 (补空格处数, 去行尾空白行数)。"""
    path = Path(path)
    text = path.read_bytes().decode("utf-8")
    fixed, n_space, n_trailing = apply_fixes(text)
    if fixed != text:
        path.write_bytes(fixed.encode("utf-8"))
    return n_space, n_trailing


# ---------------------------------------------------------------- 命令行

class _UsageError(Exception):
    """用法错误。"""


class _ArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise _UsageError(message)


def _window_from_cli(value):
    if not value:
        return None
    parts = value.split("..")
    if len(parts) != 2:
        raise _UsageError("--window 的格式应为 起始..结束，如 2026-10-01..2026-10-31")
    try:
        return _to_date(parts[0]), _to_date(parts[1])
    except ValueError:
        raise _UsageError("--window 里的日期应为 YYYY-MM-DD") from None


def _force_utf8():
    """把标准输出和标准错误设成 UTF-8；只在 main() 里调用。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


def _print_report(result: dict):
    """按严重度分组打印问题清单，每条带行号和修改提示，最后打印统计。"""
    for title, key in (("错误", "errors"), ("警告", "warnings")):
        items = result[key]
        print("%s：%d 项" % (title, len(items)))
        for issue in items:
            where = "全文" if issue["line"] is None else "第 %d 行" % issue["line"]
            print("  [%s] %s：%s" % (issue["code"], where, issue["message"]))
    s = result["stats"]
    print("统计：行数 %d，二级标题 %d，引用 %d 个，来源 %d 条，表格 %d 个，Mermaid 图 %d 个"
          % (s["lines"], s["h2"], s["citations_used"], s["sources_listed"], s["tables"], s["mermaid"]))
    print("结果：%s" % ("有错误，请先修正" if result["errors"] else "没有错误"))


def main(argv: Optional[List[str]] = None) -> int:
    _force_utf8()
    parser = _ArgumentParser(
        prog="check_report.py",
        description="ESG 报告格式与引用自检（月报、投标信息汇总、每日推送共用）。",
    )
    parser.add_argument("report", help="报告的 Markdown 文件路径")
    parser.add_argument("--kind", required=True, choices=tuple(REQUIRED_SECTIONS),
                        help="报告类型")
    parser.add_argument("--window", metavar="起始..结束",
                        help="统计窗口，如 2026-10-01..2026-10-31；给出时检查窗口外的日期")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出结果")
    parser.add_argument("--fix", action="store_true",
                        help="先做安全的自动修复并写回文件，再照常检查")
    try:
        args = parser.parse_args(argv)
        window = _window_from_cli(args.window)
        path = Path(args.report)
        fixes = _fix_file(path) if args.fix else None
        result = check_file(path, args.kind, window)
    except _UsageError as exc:
        print("用法错误：%s" % exc, file=sys.stderr)
        parser.print_usage(sys.stderr)
        return 2
    except (OSError, UnicodeError, ValueError) as exc:
        print("无法检查文件：%s" % exc, file=sys.stderr)
        return 2
    if fixes is not None:
        summary = "已自动修复：补空格 %d 处，去行尾空白 %d 行" % fixes
        if args.json:
            print(summary, file=sys.stderr)  # 让 stdout 保持纯 JSON
        else:
            print(summary)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        _print_report(result)
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
