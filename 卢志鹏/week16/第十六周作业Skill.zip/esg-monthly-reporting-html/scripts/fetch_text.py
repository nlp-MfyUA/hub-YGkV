"""抓取网页并输出标题和正文纯文本（两个 ESG Skill 共用）。

用法::

    python scripts/fetch_text.py <url> [--max-chars 3000] [--around 关键词1,关键词2] [--timeout 20]

- 只接受 http:// 和 https:// 地址；file:、ftp: 等其他协议一律拒绝。
- 输出第一行是 ``# 标题``，之后是正文纯文本。
- ``--around`` 给了时，只输出各关键词出现位置附近的内容；某个关键词在页面上没有出现时，
  往 stderr 打一行警告，返回码不变。
- 退出码：0 成功；2 请求失败（原因打到 stderr）；3 没取到正文，或目标不是网页（PDF 等文件）。
"""

import argparse
import gzip
import http.client
import re
import sys
import urllib.error
import urllib.request
import zlib
from html import unescape
from typing import List, Optional, Tuple

# 桌面浏览器的 User-Agent，避免被站点当成爬虫拒绝
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

# 这些标签里的内容不是正文，连同标签整段去掉（前后标签名必须一致）。
# 其中 header、footer、nav、aside 只在页面级才删，见 _protect_page_parts。
_JUNK_RE = re.compile(
    r"<(script|style|nav|header|footer|aside|noscript|svg|head|title)\b[^>]*>.*?</\1\s*>",
    re.I | re.S,
)
_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
_TITLE_RE = re.compile(r"<title\b[^>]*>(.*?)</title\s*>", re.I | re.S)
# 文章容器（article、main、section）和"页面部件"标签（只在页面级才删的那四个）
_NEST_RE = re.compile(r"(</?)(article|main|section|header|footer|nav|aside)\b[^>]*>", re.I)
_PAGE_PARTS = frozenset(("header", "footer", "nav", "aside"))
# 块级标签（开、闭都算）和 <br> 所在处换行；行内标签（b、a、span 等）直接去掉
_BLOCK_RE = re.compile(
    r"</?(?:p|div|br|li|ul|ol|tr|td|th|table|h[1-6]|section|article|blockquote|pre|hr"
    r"|dl|dt|dd|figure|figcaption|main|form|address|caption|thead|tbody|tfoot|html|body"
    r"|x-header|x-footer|x-nav|x-aside)\b[^>]*>",
    re.I,
)
_TAG_RE = re.compile(r"<[^>]*>")
_CHARSET_RE = r"charset\s*=\s*[\"']?\s*([A-Za-z0-9_\-]+)"
_META_CHARSET_RE = re.compile(("<meta\\b[^>]*?" + _CHARSET_RE).encode("ascii"), re.I)
_HEADER_CHARSET_RE = re.compile(_CHARSET_RE, re.I)
# 判断是不是网页用：常见标签；控制字符（不含制表、换行、回车）和解码失败的替换符
_MARKUP_RE = re.compile(r"<(?:html|body|div|p)\b", re.I)
_JUNK_CHAR_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\ufffd]")
_JUNK_RATIO = 0.05
# 各段片段之间的分隔符
_SEPARATOR = "\n…\n"


class FetchError(Exception):
    """请求失败：HTTP 错误、超时、连接失败、解压失败、协议不允许等。信息里带状态码或异常类型。"""


class NotWebpageError(FetchError):
    """目标不是网页（PDF 或其他文件），没有正文可取。"""


def decode_body(body: bytes, content_type: str = "") -> str:
    """把响应体解码成文本。

    依次尝试：HTTP 头里的 charset、HTML 里 <meta> 声明的 charset、UTF-8、GBK；
    某一种解码失败就试下一种。去掉开头的 BOM。
    """
    candidates: List[str] = []
    header = _HEADER_CHARSET_RE.search(content_type or "")
    if header:
        candidates.append(header.group(1))
    meta = _META_CHARSET_RE.search(body)
    if meta:
        candidates.append(meta.group(1).decode("ascii", "ignore"))
    candidates += ["utf-8", "gbk"]
    for encoding in candidates:
        try:
            text = body.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue
        return text.lstrip("\ufeff")
    # 全部失败时用 UTF-8 容错解码，坏字节变成替换符，不让抓取直接中断
    return body.decode("utf-8", "replace").lstrip("\ufeff")


def _protect_page_parts(source: str) -> str:
    """把包在 article、main、section 里的 header、footer、nav、aside 改名成 x- 开头。

    这些是文章自己的页眉页脚（比如发布时间），不是页面装饰，不能按 _JUNK_RE 删掉。
    改了名就不会被 _JUNK_RE 匹配到；改名后的标签之后当普通标签去掉，内容保留。
    """
    depth = 0

    def rename(match):
        nonlocal depth
        tag = match.group(2).lower()
        if tag not in _PAGE_PARTS:
            # 开标签让深度加一，闭标签让深度减一。group(1) 对开标签是 "<"、闭标签是 "</"，
            # 两者都是真值，所以必须看里面有没有斜杠，不能直接拿它判真假
            is_closing = "/" in match.group(1)
            depth = max(0, depth + (-1 if is_closing else 1))
        elif depth > 0:
            return match.group(0).replace(match.group(2), "x-" + match.group(2), 1)
        return match.group(0)

    return _NEST_RE.sub(rename, source)


def extract_text(html: str) -> Tuple[str, str]:
    """从 HTML 抽取标题和正文纯文本，返回 ``(title, text)``；没有标题时 title 为空串。

    去掉 script、style、nav、header、footer、aside、noscript、svg 的内容；
    块级标签和 <br> 处换行；合并连续空白；每段之间空一行。
    """
    match = _TITLE_RE.search(html)
    title = re.sub(r"\s+", " ", match.group(1)).strip() if match else ""
    text = _COMMENT_RE.sub("", html)
    text = _protect_page_parts(text)
    text = _JUNK_RE.sub("", text)
    text = _BLOCK_RE.sub("\n", text)
    text = _TAG_RE.sub("", text)
    text = unescape(text)
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[^\S\n]+", " ", text)  # 行内空白（含 &nbsp;）合成一个空格
    text = re.sub(r" ?\n ?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return title, text.strip()


def pick_around(text: str, keywords: List[str], max_chars: int) -> str:
    """截取要输出的正文，总长不超过 ``max_chars``。

    没给关键词：返回开头 ``max_chars`` 个字符。
    给了关键词：取每个关键词**所有**出现位置附近的片段，按出现顺序拼接；重叠或相邻的片段
    合并成一段。每段向前后延伸的长度先以 ``max_chars // (2 * len(keywords))`` 为上限，
    再缩小到各段加起来不超过 ``max_chars``。关键词都没出现时返回空串。
    """
    if not keywords:
        return text[:max_chars]
    hits = []  # 每个出现位置的 (起点, 终点)
    for keyword in keywords:
        if not keyword:
            continue
        pos = text.find(keyword)
        while pos >= 0:
            hits.append((pos, pos + len(keyword)))
            pos = text.find(keyword, pos + len(keyword))
    if not hits:
        return ""
    hits.sort()

    def spans(window: int) -> List[List[int]]:
        """各出现位置向前后延伸 window 个字符后得到的区间，重叠或相邻的已合并。"""
        merged: List[List[int]] = []
        for start, end in hits:
            start, end = max(0, start - window), min(len(text), end + window)
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        return merged

    def total(window: int) -> int:
        merged = spans(window)
        return sum(end - start for start, end in merged) + len(_SEPARATOR) * (len(merged) - 1)

    # 二分查找总长不超过 max_chars 的最大延伸长度
    low, high = 0, max_chars // (2 * len(keywords))
    while low < high:
        mid = (low + high + 1) // 2
        if total(mid) <= max_chars:
            low = mid
        else:
            high = mid - 1
    return _SEPARATOR.join(text[start:end] for start, end in spans(low))[:max_chars]


def _is_webpage(content_type: str, raw: bytes, text: str) -> bool:
    """判断响应是不是网页。

    不算网页：Content-Type 是 application/pdf；正文以 %PDF 开头；
    或者解码后的文本里找不到 <html、<body、<div、<p 任何一个标签，且控制字符占比很高。
    """
    mime = content_type.split(";", 1)[0].strip().lower()
    if mime == "application/pdf" or raw.lstrip().startswith(b"%PDF"):
        return False
    if text and not _MARKUP_RE.search(text):
        return len(_JUNK_CHAR_RE.findall(text)) / len(text) < _JUNK_RATIO
    return True


def _decompress(raw: bytes, content_encoding: str) -> bytes:
    """按 Content-Encoding 解压响应体；不认识或没压缩的原样返回。"""
    try:
        if "gzip" in content_encoding:
            return gzip.decompress(raw)
        if "deflate" in content_encoding:
            try:
                return zlib.decompress(raw)
            except zlib.error:
                # 有的服务器发的是不带 zlib 头的原始 deflate 流
                return zlib.decompress(raw, -zlib.MAX_WBITS)
    except (OSError, EOFError, zlib.error) as exc:
        raise FetchError(
            f"解压失败（{type(exc).__name__}）：Content-Encoding={content_encoding}"
        ) from exc
    return raw


def fetch(url: str, timeout: int = 20) -> Tuple[str, str]:
    """抓取网页，返回 ``(title, text)``。

    只接受 http:// 和 https:// 地址，其他协议抛 FetchError。HTTP 错误、超时、连接失败
    抛 FetchError；目标不是网页（PDF 等文件）抛 NotWebpageError，它是 FetchError 的子类。
    """
    # 必须先查协议再去请求：否则 file:// 会把本地文件内容读出来
    if not url.lower().startswith(("http://", "https://")):
        raise FetchError(f"只支持 http 和 https 地址，不接受：{url}")
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Accept-Encoding": "gzip, deflate",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            content_type = response.headers.get("Content-Type", "")
            content_encoding = (response.headers.get("Content-Encoding") or "").strip().lower()
    except urllib.error.HTTPError as exc:
        raise FetchError(f"HTTP {exc.code} {exc.reason}：{url}") from exc
    except urllib.error.URLError as exc:
        raise FetchError(f"连接失败（{type(exc.reason).__name__}）：{exc.reason}") from exc
    except (OSError, ValueError, http.client.HTTPException) as exc:
        # 读响应时的超时/断开、无效 URL、对方返回了不成形的 HTTP 响应
        raise FetchError(f"请求失败（{type(exc).__name__}）：{exc}") from exc
    raw = _decompress(raw, content_encoding)
    text = decode_body(raw, content_type)
    if not _is_webpage(content_type, raw, text):
        raise NotWebpageError("目标不是网页（可能是 PDF 或其他文件），请改用读网页工具")
    return extract_text(text)


def main(argv: Optional[List[str]] = None) -> int:
    """命令行入口。返回 0 成功、2 请求失败、3 没取到正文（含目标不是网页）。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="抓取网页，输出标题和正文纯文本")
    parser.add_argument("url", help="网页地址")
    parser.add_argument("--max-chars", type=int, default=3000, help="最多输出的字符数，默认 3000")
    parser.add_argument("--around", default="", help="只输出这些关键词出现位置附近的内容，逗号分隔")
    parser.add_argument("--timeout", type=int, default=20, help="超时秒数，默认 20")
    args = parser.parse_args(argv)

    try:
        title, text = fetch(args.url, timeout=args.timeout)
    except NotWebpageError as exc:
        print(f"没取到正文：{exc}", file=sys.stderr)
        return 3
    except FetchError as exc:
        print(f"抓取失败：{exc}", file=sys.stderr)
        return 2
    if not text:
        print("没取到正文：页面没有可见文字", file=sys.stderr)
        return 3

    # 中文逗号也当作分隔符，去掉空关键词和重复关键词
    keywords = list(dict.fromkeys(kw.strip() for kw in args.around.replace("，", ",").split(",") if kw.strip()))
    # 关键词在标题和正文里一起找：标题也是页面内容
    searchable = f"{title}\n{text}" if title else text
    for keyword in keywords:
        if keyword not in searchable:
            print(f"关键词「{keyword}」在页面中没有出现", file=sys.stderr)
    body = pick_around(searchable, keywords, args.max_chars)
    if not body:
        print("没取到正文：给出的关键词都没有出现", file=sys.stderr)
        return 3
    print(f"# {title or '(无标题)'}")
    print(body)
    return 0


if __name__ == "__main__":
    sys.exit(main())
