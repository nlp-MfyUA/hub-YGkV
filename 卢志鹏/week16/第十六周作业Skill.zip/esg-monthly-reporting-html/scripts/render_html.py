#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ESG 报告渲染脚本：把 Markdown 报告转成单个自包含的 HTML 文件。

图表（柱状图、环形图、时间线）用纯 HTML/CSS 画，不引用任何外部资源。
解析按"块"逐行进行（状态机），再处理行内格式；任何输入都不抛异常，
也不产出残缺的 HTML。

用法：
    python scripts/render_html.py <报告.md> [-o <输出.html>]

不给 -o 时，输出到 Markdown 同目录下的同名 .html。渲染前先做校验：
有错误就逐条打印并返回 1，不写文件；只有警告则照常渲染并打印警告。

退出码：0 成功；1 校验有错误；2 用法或文件错误。
只用标准库，兼容 Python 3.9。
"""

from __future__ import annotations

import argparse
import html as _html
import re
import statistics
import sys
from datetime import date
from pathlib import Path

BOM = "\ufeff"  # UTF-8 BOM 字符
DEFAULT_TITLE = "报告"
# 提示框的五种类型（输出时统一用小写）
ALERT_TYPES = ("note", "tip", "important", "warning", "caution")
# 图表调色板：12 色，依次取用
PALETTE = (
    "#0f766e", "#2563eb", "#d97706", "#7c3aed", "#dc2626", "#0891b2",
    "#65a30d", "#db2777", "#9333ea", "#ea580c", "#4f46e5", "#64748b",
)

# ---------------------------------------------------------------- 正则

FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
HEADING_RE = re.compile(r"^ {0,3}(#{1,6})(?:[ \t]+(.*?))?[ \t]*$")
# 锚点行：单独一行的空链接，如 <a id="x" name="x"></a>
ANCHOR_RE = re.compile(r"^<a\s+([^<>]*)>\s*</a>$", re.I)
ID_ATTR_RE = re.compile(r"(?:^|\s)id\s*=\s*[\"']?([^\s\"'>]+)", re.I)
NAME_ATTR_RE = re.compile(r"(?:^|\s)name\s*=\s*[\"']?([^\s\"'>]+)", re.I)
# 水平分割线：单独一行的 ---、***、___（至少三个，可带空格）；=== 也按分割线降级
HR_RE = re.compile(r"^ {0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,}|(?:=[ \t]*){3,})$")
TABLE_ROW_RE = re.compile(r"^ {0,3}\|")
SEP_CELL_RE = re.compile(r":?-+:?")
# 列表项：无序（- * +）或有序（1. 1)），后面至少一个空格
LIST_RE = re.compile(r"^(\s*)(?:([-*+])|(\d{1,9})[.)])[ \t]+(.*)$")
QUOTE_RE = re.compile(r"^ {0,3}>")
QUOTE_MARK_RE = re.compile(r"^ {0,3}>[ \t]?")
ALERT_RE = re.compile(r"^\[!([^\]]+)\]\s*(.*)$")
DETAILS_OPEN_RE = re.compile(r"^<details(\s[^<>]*)?>$", re.I)
DETAILS_CLOSE_RE = re.compile(r"^</details\s*>$", re.I)
SUMMARY_RE = re.compile(r"^<summary\s*>(.*?)(?:</summary\s*>)?\s*$", re.I)
SUMMARY_FULL_RE = re.compile(r"^<summary\s*>(.*)</summary\s*>$", re.I)
CLASS_ATTR_RE = re.compile(r"\sclass\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+)", re.I)
OPEN_ATTR_RE = re.compile(r"(?:^|\s)open(?:\s|=|$)", re.I)
# 快速导航：**目录**：[甲](#a) · [乙](#b)
QUICKNAV_RE = re.compile(r"^\s*\*{0,2}\s*目录\s*\*{0,2}\s*[：:]\s*(\S.*)$")

# 行内格式
SPECIAL_RE = re.compile(r"[`\[<!*★↑↓→\\]")
CODE_RE = re.compile(r"(`+)([^`\n]+?)\1(?!`)")
# 链接（图片）的文字里不能有裸方括号，但可以嵌一层方括号，如 [参考 [1]](地址)
_BRACKET_TEXT = r"(?:[^\[\]]|\[[^\[\]]*\])*"
IMG_RE = re.compile(r"!\[(" + _BRACKET_TEXT + r")\]\(\s*(<[^<>\s]*>|[^\s)]+)(?:\s+\"[^\"]*\")?\s*\)")
LINK_RE = re.compile(r"\[(" + _BRACKET_TEXT + r")\]\(\s*(<[^<>\s]*>|[^\s)]+)(?:\s+\"[^\"]*\")?\s*\)")
A_TAG_RE = re.compile(r"</?a\b[^>]*>")
LINK_DEST_RE = re.compile(r"\]\(\s*(?:<[^<>\s]*>|[^\s)]+)(?:\s+\"[^\"]*\")?\s*\)")
AUTOLINK_RE = re.compile(r"<(https?://[^<>\s]+)>", re.I)
EXTERNAL_RE = re.compile(r"^(?:https?:)?//", re.I)
BR_RE = re.compile(r"<br\s*/?>", re.I)
STRONG_EM_RE = re.compile(r"\*\*\*(?!\s)(.+?)(?<!\s)\*\*\*")
STRONG_RE = re.compile(r"\*\*(?!\s)(.+?)(?<!\s)\*\*")
EM_RE = re.compile(r"\*(?![\s*])([^*\n]+?)(?<!\s)\*(?!\*)")
STARS_RE = re.compile(r"★{1,3}(?!★)")
_AROUND = "↑↓→←↖↗↘↙↔↕"
ARROW_RE = re.compile(r"(?<![%s])([↑↓→])(?![%s])" % (_AROUND, _AROUND))
ARROW_CLASS = {"↑": "up", "↓": "down", "→": "flat"}
CITE_RE = re.compile(r"\[(\d{1,3})\](?!\()")
CITE_FIND_RE = re.compile(r"(?<![!\\])\[(\d{1,3})\](?!\()")
BACKSLASH_RE = re.compile(r"\\([\\`*_{}\[\]()#+.!|<>\-~])")
# 裸露的 http(s) 网址：到空白、尖括号或中文标点为止；末尾的英文标点另外剔除
URL_RE = re.compile(r"(?<![A-Za-z0-9])https?://[^\s<>\"'`，。；：、！？（）【】《》「」『’]+")
URL_TAIL_RE = re.compile(r"[.,;:!?]+$")
# 完整日期 YYYY-MM-DD：渲染时包起来，不在连字符处折行
DATE_RE = re.compile(r"(?<![\d-])(\d{4}-\d{1,2}-\d{1,2})(?![\d-])")

# 校验
PLACEHOLDER_RE = re.compile(r"(?<![A-Za-z])(?:TBD|TODO|XXX)(?![A-Za-z])|待补充|待填写|待完善")
INT_RE = re.compile(r"\d{1,4}")

# Mermaid
MERMAID_TITLE_RE = re.compile(r"^title\s+(.+?)\s*$")
PIE_HEAD_RE = re.compile(r"^pie\b\s*(.*)$", re.I)
BAR_VALUES_RE = re.compile(r"^bar\s*\[(.*)\]\s*$")
XAXIS_RE = re.compile(r"^x-axis\s*\[(.*)\]\s*$")
QUOTED_RE = re.compile(r"\"([^\"]*)\"")
PIE_ROW_RE = re.compile(
    r"^\s*(?:\"([^\"]*)\"\s*|(.+?)\s*):\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*$")
TIMELINE_ROW_RE = re.compile(r"^(.*?)\s:\s(.*)$")


# ---------------------------------------------------------------- 基础工具

def _norm(text: str) -> str:
    """统一换行为 \\n，去掉 UTF-8 BOM。"""
    text = text or ""
    if text.startswith(BOM):
        text = text[1:]
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _esc(text: str) -> str:
    """HTML 文本转义：< > & 。"""
    return _html.escape(text, quote=False)


def _attr(text: str) -> str:
    """HTML 属性值转义：< > & " 。"""
    return _html.escape(text, quote=True)


def _blank(match) -> str:
    """把匹配到的内容换成等长空格，保持位置不变。"""
    return " " * len(match.group(0))


def _indent(line: str) -> int:
    """行首缩进折算成空格数（制表符按 4 个算）。"""
    width = 0
    for ch in line:
        if ch == " ":
            width += 1
        elif ch == "\t":
            width += 4 - width % 4
        else:
            break
    return width


def _fmt_num(value: float) -> str:
    """数值显示：整数不带小数点，否则最多保留两位小数。"""
    if float(value).is_integer():
        return str(int(value))
    return ("%.2f" % value).rstrip("0").rstrip(".")


def _strip_links(inner: str) -> str:
    """去掉行内 HTML 里的链接标签，只留文字。链接里不能再嵌套链接，所以目录和
    快速导航的链接文字要先用它处理（比如标题里带着角标的时候）。"""
    return A_TAG_RE.sub("", inner)


def _plain(text: str) -> str:
    """去掉行内标记，得到纯文字（用于目录、标签名、alt 等）。"""
    text = IMG_RE.sub(r"\1", text)
    text = LINK_RE.sub(r"\1", text)
    text = AUTOLINK_RE.sub(r"\1", text)
    text = BR_RE.sub(" ", text)
    text = re.sub(r"[`*]", "", text)
    return BACKSLASH_RE.sub(r"\1", text)


def _split_cells(line: str) -> list[str]:
    """按未转义的竖线切分表格单元格；单元格里的 \\| 先保留，渲染时还原。"""
    s = line.strip()
    cells = re.split(r"(?<!\\)\|", s)
    if s.startswith("|"):
        cells = cells[1:]
    if cells and s.endswith("|") and not s.endswith("\\|"):
        cells = cells[:-1]
    return [c.strip() for c in cells]


def _is_separator(line: str) -> bool:
    """判断一行是不是表格分隔行（如 | --- | :---: |）。"""
    cells = _split_cells(line)
    return bool(cells) and all(SEP_CELL_RE.fullmatch(c) for c in cells)


def _cell_align(cell: str) -> str:
    """分隔行的一格决定该列对齐：以冒号结尾是右对齐（num）。"""
    return "num" if cell.strip().endswith(":") else ""


def _starts_table(lines: list[str], j: int) -> bool:
    """第 j 行是不是一张表的表头行：以竖线开头，且下一行是分隔行。"""
    return (j + 1 < len(lines) and bool(TABLE_ROW_RE.match(lines[j]))
            and bool(TABLE_ROW_RE.match(lines[j + 1])) and _is_separator(lines[j + 1]))


def _scan(lines: list[str]) -> dict:
    """扫描一遍，标出代码围栏和 HTML 注释。

    返回：
    - clean：每行的可见文本。围栏内外的行都不改动，只把围栏外的注释删掉
      （行号保持不变，整行是注释的变成空行）；
    - comments：[(行下标, 注释内容)]；
    - blocks：[(起始行下标, 结束行下标, 信息串, 是否闭合)]；
    - unbalanced：没有闭合的围栏的起始行下标；
    - fenced：所有围栏行（含起止标记和内部）的行下标集合。
    """
    clean, comments, blocks, unbalanced, fenced = [], [], [], [], set()
    in_comment = False
    fence = None  # (起始行下标, 围栏字符, 围栏长度, 信息串)
    for i, raw in enumerate(lines):
        if fence is not None:
            clean.append(raw)
            fenced.add(i)
            m = FENCE_RE.match(raw)
            if (m and m.group(1)[0] == fence[1] and len(m.group(1)) >= fence[2]
                    and not m.group(2).strip()):
                blocks.append((fence[0], i, fence[3], True))
                fence = None
            continue
        line, out = raw, []
        while True:
            if in_comment:
                end = line.find("-->")
                if end == -1:
                    comments[-1][1] += "\n" + line
                    line = ""
                    break
                comments[-1][1] += "\n" + line[:end]
                line = line[end + 3:]
                in_comment = False
            start = line.find("<!--")
            if start == -1:
                out.append(line)
                break
            out.append(line[:start])
            end = line.find("-->", start + 4)
            if end == -1:
                comments.append([i, line[start + 4:]])
                line = ""
                in_comment = True
                break
            comments.append([i, line[start + 4:end]])
            line = line[end + 3:]
        text = "".join(out)
        # 注释一直延伸到行尾时，剩下的行尾空白不算"行尾两个空格"的硬换行
        if in_comment or raw.rstrip().endswith("-->"):
            text = text.rstrip()
        clean.append(text)
        m = FENCE_RE.match(text)
        # 反引号围栏的信息串里不能再有反引号，否则不是围栏
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            fence = (i, m.group(1)[0], len(m.group(1)), m.group(2).strip())
            fenced.add(i)
    if fence is not None:
        blocks.append((fence[0], len(lines) - 1, fence[3], False))
        unbalanced.append(fence[0])
    return {"clean": clean, "comments": comments, "blocks": blocks,
            "unbalanced": unbalanced, "fenced": fenced}


def _fence_body(lines: list[str], start: int, end: int, closed: bool) -> list[str]:
    """取出围栏内部的行。"""
    return lines[start + 1:end if closed else end + 1]


# ---------------------------------------------------------------- 行内格式

def _trim_url(url: str) -> str:
    """去掉网址末尾不属于网址的标点：句号、逗号，以及落单的右括号。"""
    while True:
        url = URL_TAIL_RE.sub("", url)
        if url.endswith(")") and url.count("(") < url.count(")"):
            url = url[:-1]
            continue
        return url


def _dest(raw: str) -> str:
    """链接地址：去掉包着的尖括号。"""
    raw = raw.strip()
    if raw.startswith("<") and raw.endswith(">"):
        raw = raw[1:-1]
    return raw


def _link_html(dest: str, inner: str) -> str:
    """输出链接。http(s) 地址在新标签页打开，相对地址原样输出。"""
    attrs = 'href="%s"' % _attr(dest)
    if EXTERNAL_RE.match(dest):
        attrs += ' target="_blank" rel="noopener"'
    return "<a %s>%s</a>" % (attrs, inner)


def _cite_html(n: str, ctx: dict) -> str:
    """来源角标 [n]：来源清单里有第 n 行就带链接，否则只有上标。"""
    number = int(n)
    ctx["stats"]["cites"].add(number)
    if number in ctx["sources"]:
        return '<sup class="cite"><a href="#src-%d">%s</a></sup>' % (number, n)
    return '<sup class="cite">%s</sup>' % n


def _wrap_dates(text: str) -> str:
    """转义一段普通文字，并把完整的 YYYY-MM-DD 日期包起来，免得在连字符处折成两行。"""
    return DATE_RE.sub(lambda m: '<span class="date">%s</span>' % m.group(1), _esc(text))


def _text(s: str) -> str:
    """两个特殊符号之间的普通文字：转义，并把裸露的 http(s) 网址变成链接。"""
    if not s:
        return ""
    if "http" not in s:
        return _wrap_dates(s)
    out, pos = [], 0
    for m in URL_RE.finditer(s):
        url = _trim_url(m.group(0))
        if not url:
            continue
        end = m.start() + len(url)
        out.append(_wrap_dates(s[pos:m.start()]))
        out.append(_link_html(url, _esc(url)))
        pos = end
    out.append(_wrap_dates(s[pos:]))
    return "".join(out)


def _special(text: str, pos: int, ctx: dict) -> tuple[str, int]:
    """从 pos 处的一个特殊符号起，尝试识别一种行内格式，返回 (HTML, 新位置)。

    都认不出来时，这个符号按普通字符转义输出。
    """
    ch = text[pos]
    m = CODE_RE.match(text, pos)
    if m:
        return "<code>%s</code>" % _esc(m.group(2)), m.end()
    if ch == "!":
        m = IMG_RE.match(text, pos)
        if m:
            return ('<img src="%s" alt="%s" loading="lazy" style="max-width:100%%">'
                    % (_attr(_dest(m.group(2))), _attr(m.group(1)))), m.end()
    elif ch == "[":
        m = LINK_RE.match(text, pos)
        if m:  # 先认链接，[文字](地址) 里的方括号不是角标；文字里的角标不能再带链接
            return _link_html(_dest(m.group(2)), _strip_links(_inline(m.group(1), ctx))), m.end()
        m = CITE_RE.match(text, pos)
        if m:
            return _cite_html(m.group(1), ctx), m.end()
    elif ch == "<":
        m = AUTOLINK_RE.match(text, pos)
        if m:
            return _link_html(m.group(1), _esc(m.group(1))), m.end()
        m = BR_RE.match(text, pos)
        if m:  # 只放行 <br>，其余标签一律转义
            return "<br>", m.end()
    elif ch == "*":
        m = STRONG_EM_RE.match(text, pos)
        if m:
            return "<strong><em>%s</em></strong>" % _inline(m.group(1), ctx), m.end()
        m = STRONG_RE.match(text, pos)
        if m:
            return "<strong>%s</strong>" % _inline(m.group(1), ctx), m.end()
        m = EM_RE.match(text, pos)
        if m:
            return "<em>%s</em>" % _inline(m.group(1), ctx), m.end()
    elif ch == "★":
        m = STARS_RE.match(text, pos)
        if m:
            stars = m.group(0)
            return '<span class="stars s%d">%s</span>' % (len(stars), stars), m.end()
    elif ch in ARROW_CLASS:
        m = ARROW_RE.match(text, pos)
        if m:
            return '<span class="arr %s">%s</span>' % (ARROW_CLASS[m.group(1)], m.group(1)), m.end()
    elif ch == "\\":
        m = BACKSLASH_RE.match(text, pos)
        if m:
            return _esc(m.group(1)), m.end()
    return _esc(ch), pos + 1


def _inline(text: str, ctx: dict) -> str:
    """把一段不含换行的文字渲染成行内 HTML。"""
    out, pos = [], 0
    length = len(text)
    while pos < length:
        m = SPECIAL_RE.search(text, pos)
        if not m:
            out.append(_text(text[pos:]))
            break
        if m.start() > pos:
            out.append(_text(text[pos:m.start()]))
        piece, pos = _special(text, m.start(), ctx)
        out.append(piece)
    return "".join(out)


def _joins_with_space(prev: str, nxt: str) -> bool:
    """软换行处要不要补一个空格：两侧都是字母数字，且至少一侧是 ASCII 时补。

    中文之间直接拼接；英文单词之间、中文和英文数字之间补空格。
    """
    return bool(prev and nxt and prev[-1].isalnum() and nxt[0].isalnum()
                and (prev[-1].isascii() or nxt[0].isascii()))


def _para_inline(lines: list[str], ctx: dict) -> str:
    """把一个段落的几行合并成行内 HTML：行尾两个空格换成 <br>。"""
    out = []
    last = len(lines) - 1
    for k, raw in enumerate(lines):
        hard = raw.endswith("  ") or raw.endswith("\\")
        line = raw.strip()
        if k < last and line.endswith("\\") and not line.endswith("\\\\"):
            line = line[:-1].rstrip()  # 行尾反斜杠也是硬换行
        piece = _inline(line, ctx)
        if k < last:
            if hard:
                piece += "<br>"
            elif _joins_with_space(line, lines[k + 1].strip()):
                piece += " "
        out.append(piece)
    return "".join(out)


def _visible(line: str) -> str:
    """校验用：把链接地址、裸网址和行内代码换成等长空格，只留可见文字。"""
    line = LINK_DEST_RE.sub(_blank, line)
    line = URL_RE.sub(_blank, line)
    return CODE_RE.sub(_blank, line)


# ---------------------------------------------------------------- 块解析

def _new_id(ctx: dict, wanted: str | None) -> str:
    """给标题分配 id：锚点行给出的优先，否则按顺序自动编号（sec-1、sec-2 …）；重复的加后缀。"""
    if wanted:
        base = wanted
    else:
        ctx["seq"] += 1
        base = "sec-%d" % ctx["seq"]
    uid, k = base, 1
    while uid in ctx["ids"]:
        k += 1
        uid = "%s-%d" % (base, k)
    ctx["ids"].add(uid)
    return uid


def _anchor_id(attrs: str) -> str | None:
    """从锚点行的属性里取 id（没有 id 时取 name）。"""
    m = ID_ATTR_RE.search(attrs) or NAME_ATTR_RE.search(attrs)
    return m.group(1) if m else None


def _code_block(info: str, body: list[str], line: int, ctx: dict) -> dict:
    """围栏代码块：信息串是 mermaid 的试着解析成图表，解析不了就按普通代码输出。"""
    words = info.split()
    lang = words[0].lower() if words else ""
    block = {"kind": "code", "lang": lang, "lines": body, "line": line}
    if lang == "mermaid":
        try:
            block["chart"] = _parse_mermaid(body)
            block["kind"] = "chart"
        except Exception:  # 解析不了就是校验错误（见 validate），渲染时降级成代码块
            pass
    return block


def _starts_block(lines: list[str], j: int, in_list: bool = False) -> bool:
    """第 j 行是不是另一个块的开头：围栏、锚点、标题、分割线、details、引用、表格、列表项。"""
    raw = lines[j]
    s = raw.strip()
    if not s:
        return False
    if FENCE_RE.match(raw) or HEADING_RE.match(raw) or HR_RE.match(s):
        return True
    if ANCHOR_RE.match(s) or DETAILS_OPEN_RE.match(s) or QUOTE_RE.match(raw):
        return True
    if _starts_table(lines, j):
        return True
    return not in_list and bool(LIST_RE.match(raw))


def _collect_list(lines: list[str], i: int, n: int) -> tuple[int, list[dict]]:
    """从第 i 行（列表项）起收集属于同一个列表的行，返回 (结束行下标, 条目列表)。

    条目：{"indent": 缩进, "ordered": 是否有序, "start": 起始编号,
           "paras": [[段落行, ...], ...], "groups": [子列表组, ...]}。
    列表项行开启新条目；其余非空行是上一个条目的续行（空行之后的续行另起一段）；
    空行之后不再是列表内容时，列表在空行前结束。
    """
    entries: list[dict] = []
    base = _indent(lines[i])
    j, blank = i, False
    while j < n:
        raw = lines[j]
        s = raw.strip()
        if not s:
            blank = True
            j += 1
            continue
        m = LIST_RE.match(raw)
        if m and not HR_RE.match(s):
            entries.append({
                "indent": _indent(raw),
                "ordered": m.group(3) is not None,
                "start": int(m.group(3)) if m.group(3) else 1,
                "paras": [[m.group(4)]],
                "groups": [],
            })
            blank = False
            j += 1
            continue
        if not entries or _starts_block(lines, j, in_list=True):
            break
        if blank:
            # 空行之后的缩进行是上一个条目里的新段落；缩进不够就不属于这个列表
            if _indent(raw) < base + 2:
                break
            entries[-1]["paras"].append([s])
        else:
            entries[-1]["paras"][-1].append(s)
        blank = False
        j += 1
    return j, entries


def _list_tree(entries: list[dict]) -> list[dict]:
    """把线性的列表条目按缩进组织成嵌套的组：{"ordered", "start", "items"}。

    缩进更深的条目挂到上一个条目的子列表里；缩进相同但有序无序不同的另起一组。
    """
    roots: list[dict] = []
    stack: list[tuple] = []  # [(缩进, 是否有序, 组)]
    for e in entries:
        while stack and (e["indent"] < stack[-1][0]
                         or (e["indent"] == stack[-1][0] and e["ordered"] != stack[-1][1])):
            stack.pop()
        if stack and e["indent"] == stack[-1][0]:
            group = stack[-1][2]
        else:
            group = {"ordered": e["ordered"], "start": e["start"], "items": []}
            if stack and stack[-1][2]["items"]:
                stack[-1][2]["items"][-1]["groups"].append(group)
            elif len(stack) > 1 and stack[-2][2]["items"]:
                stack[-2][2]["items"][-1]["groups"].append(group)  # 父组还没有条目时往上挂
            else:
                roots.append(group)
            stack.append((e["indent"], e["ordered"], group))
        group["items"].append(e)
    return roots


def _parse_blocks(lines: list[str], ctx: dict, depth: int = 0) -> list[dict]:
    """按块逐行解析 Markdown，返回块列表。

    每个块是一个 dict，kind 取值：heading / para / code / chart / table / quote /
    callout / list / details / hr / quicknav。line 是块起始行的下标。
    """
    blocks: list[dict] = []
    i, n = 0, len(lines)
    pending_id = None  # 锚点行给出的 id，留给下一个标题
    if depth > 8:  # 引用层层嵌套过深时不再递归，全部当段落
        lines = [ln for ln in lines if ln.strip()]
        n = len(lines)
    while i < n:
        raw = lines[i]
        s = raw.strip()
        if not s:
            i += 1
            continue
        # 1. 围栏代码块
        m = FENCE_RE.match(raw)
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            marker = m.group(1)
            j = i + 1
            while j < n:
                mm = FENCE_RE.match(lines[j])
                if (mm and mm.group(1)[0] == marker[0] and len(mm.group(1)) >= len(marker)
                        and not mm.group(2).strip()):
                    break
                j += 1
            closed = j < n
            blocks.append(_code_block(m.group(2).strip(), lines[i + 1:j if closed else n], i, ctx))
            i = j + 1 if closed else n
            continue
        if depth > 8:
            blocks.append({"kind": "para", "lines": lines[i:], "line": i})
            break
        # 2. 锚点行：不输出，id 留给下一个标题
        m = ANCHOR_RE.match(s)
        if m:
            aid = _anchor_id(m.group(1))
            if aid:
                pending_id = aid
            i += 1
            continue
        # 3. ATX 标题
        m = HEADING_RE.match(raw)
        if m:
            text = re.sub(r"[ \t]+#+[ \t]*$", "", (m.group(2) or "").strip())
            hid = _new_id(ctx, pending_id)
            pending_id = None
            blocks.append({"kind": "heading", "level": len(m.group(1)),
                           "text": text, "id": hid, "line": i})
            i += 1
            continue
        # 4. 水平分割线
        if HR_RE.match(s):
            blocks.append({"kind": "hr", "line": i})
            i += 1
            continue
        # 5. <details> 原生块：收集到 </details> 为止（没闭合就到文末）
        m = DETAILS_OPEN_RE.match(s)
        if m:
            inner = []
            j = i + 1
            while j < n and not DETAILS_CLOSE_RE.match(lines[j].strip()):
                inner.append(lines[j])
                j += 1
            blocks.append({"kind": "details", "attrs": m.group(1) or "", "lines": inner, "line": i})
            i = j + 1
            continue
        # 6. 表格：表头行 + 分隔行 + 若干数据行（两张表之间漏了空行时，遇到下一张表的表头就停）
        if _starts_table(lines, i):
            sep_cells = _split_cells(lines[i + 1])
            aligns = [_cell_align(c) for c in sep_cells]
            rows = []
            j = i + 2
            while j < n and TABLE_ROW_RE.match(lines[j]) and not _starts_table(lines, j):
                rows.append({"cells": _split_cells(lines[j]), "src": None, "line": j})
                j += 1
            blocks.append({"kind": "table", "header": _split_cells(lines[i]), "aligns": aligns,
                           "aligned": any(":" in c for c in sep_cells),
                           "rows": rows, "line": i, "meta": False, "fold": False, "kpi": False})
            i = j
            continue
        # 7. 引用块：第一个非空行是 [!类型] 的渲染成提示框
        if QUOTE_RE.match(raw):
            body = []
            j = i
            while j < n and QUOTE_RE.match(lines[j]):
                body.append(QUOTE_MARK_RE.sub("", lines[j], count=1))
                j += 1
            indents = [_indent(b) for b in body if b.strip()]
            shift = min(indents) if indents else 0
            body = [b[shift:] if b[:shift].strip() == "" else b.lstrip() for b in body]
            first = next((k for k, b in enumerate(body) if b.strip()), None)
            am = ALERT_RE.match(body[first].strip()) if first is not None else None
            kind = am.group(1).strip().lower() if am else ""
            if am and kind in ALERT_TYPES:
                blocks.append({"kind": "callout", "type": kind, "title": am.group(2).strip(),
                               "lines": body[first + 1:], "line": i})
            else:
                blocks.append({"kind": "quote", "lines": body, "line": i})
            i = j
            continue
        # 8. 列表
        if LIST_RE.match(raw):
            j, entries = _collect_list(lines, i, n)
            blocks.append({"kind": "list", "groups": _list_tree(entries), "line": i})
            i = j
            continue
        # 9. 段落（只有一行的"目录：…"渲染成快速导航）
        j, para = i, []
        while j < n and lines[j].strip() and (j == i or not _starts_block(lines, j)):
            para.append(lines[j])
            j += 1
        qm = QUICKNAV_RE.match(para[0].strip()) if len(para) == 1 else None
        if qm and LINK_RE.search(qm.group(1)):
            blocks.append({"kind": "quicknav", "text": qm.group(1), "line": i})
        else:
            blocks.append({"kind": "para", "lines": para, "line": i})
        i = j
    return blocks


# ---------------------------------------------------------------- 图表

class ChartError(ValueError):
    """Mermaid 图表块解析不了。"""


def _unquote(s: str) -> str:
    """去掉成对的双引号或单引号。"""
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1].strip()
    return s


def _numbers(text: str) -> list[float]:
    """把 "3, 7, 5" 这样的列表转成数值列表；有一格不是数字就报错。"""
    values = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            values.append(float(part))
        except ValueError:
            raise ChartError("图表里的数值「%s」不是数字" % part) from None
    if not values:
        raise ChartError("图表的数据列表是空的")
    return values


def _parse_mermaid(body: list[str]) -> dict:
    """解析一个 Mermaid 块：只支持 xychart-beta 柱状图、pie 环形图、timeline 时间线。

    返回 {"type": "bar"|"donut"|"timeline", "title": 标题, …}：
    bar 带 labels 和 values；donut 带 items（[名称, 数值] 的列表）；
    timeline 带 events（[日期, [事件, …]] 的列表）。解析不了抛 ChartError。
    """
    rows = []
    for raw in body:
        s = raw.strip()
        if not s or s.startswith("%%"):
            continue
        s = re.sub(r"\s+%%.*$", "", s)  # 行尾注释
        if s:
            rows.append(s)
    if not rows:
        raise ChartError("Mermaid 块是空的")
    head = rows[0].split()[0].lower()
    if head == "xychart-beta":
        return _parse_bar(rows[1:])
    if head == "pie":
        return _parse_donut(rows)
    if head == "timeline":
        return _parse_timeline(rows[1:])
    raise ChartError("Mermaid 块第一行应是 pie、xychart-beta 或 timeline，实际是「%s」"
                     % rows[0].split()[0])


def _parse_bar(rows: list[str]) -> dict:
    """柱状图：title "…"、x-axis ["…", …]、y-axis "…" 0 --> 10、bar [3, 7, 5]。"""
    chart = {"type": "bar", "title": "", "labels": [], "values": []}
    for s in rows:
        m = MERMAID_TITLE_RE.match(s)
        if m:
            chart["title"] = _unquote(m.group(1))
            continue
        m = XAXIS_RE.match(s)
        if m:
            labels = QUOTED_RE.findall(m.group(1))
            chart["labels"] = labels or [c.strip() for c in m.group(1).split(",") if c.strip()]
            continue
        m = BAR_VALUES_RE.match(s)
        if m and not chart["values"]:  # 只取第一个 bar 行
            chart["values"] = _numbers(m.group(1))
    if not chart["values"]:
        raise ChartError("柱状图没有 bar 数据行（如 bar [3, 7, 5]）")
    if not chart["labels"]:
        raise ChartError("柱状图没有 x-axis 标签行（如 x-axis [\"甲\", \"乙\"]）")
    return chart


def _parse_donut(rows: list[str]) -> dict:
    """环形图：第一行 pie，后面可以跟 showData，也可以把标题写在同一行（pie title 标题）；
    之后每行 "名称" : 数值。"""
    chart = {"type": "donut", "title": "", "items": []}
    head = PIE_HEAD_RE.match(rows[0])
    inline = re.match(r"^(?:showData\s+)?(?:title\s+(.+))?$", head.group(1).strip() if head else "",
                      re.I | re.S)
    if inline and inline.group(1):
        chart["title"] = _unquote(inline.group(1))
    for s in rows[1:]:
        m = MERMAID_TITLE_RE.match(s)
        if m:
            chart["title"] = _unquote(m.group(1))
            continue
        m = PIE_ROW_RE.match(s)
        if m:
            name = m.group(1) if m.group(1) is not None else m.group(2).strip()
            chart["items"].append([name, float(m.group(3))])
            continue
        raise ChartError("环形图有一行读不懂：%s" % s)
    if not chart["items"]:
        raise ChartError("环形图没有数据行（如 \"名称\" : 12）")
    return chart


def _parse_timeline(rows: list[str]) -> dict:
    """时间线：title 标题，之后每行"日期 : 事件 : 事件"。"""
    chart = {"type": "timeline", "title": "", "events": []}
    for s in rows:
        m = MERMAID_TITLE_RE.match(s)
        if m:
            chart["title"] = _unquote(m.group(1))
            continue
        m = TIMELINE_ROW_RE.match(s)
        if m:
            events = [e.strip() for e in m.group(2).split(" : ") if e.strip()]
            if m.group(1).strip() and events:
                chart["events"].append([m.group(1).strip(), events])
                continue
        raise ChartError("时间线有一行读不懂：%s（应写成「日期 : 事件」）" % s)
    if not chart["events"]:
        raise ChartError("时间线没有事件行（如 2026-10-19 : 某事件）")
    return chart


def parse_charts(text: str) -> list[dict]:
    """从 Markdown 全文里抽出图表数据。解析不了的图表块不包含在结果里。"""
    lines = _norm(text).split("\n")
    charts: list[dict] = []
    for start, end, info, closed in _scan(lines)["blocks"]:
        words = info.split()
        if words and words[0].lower() == "mermaid":
            try:
                charts.append(_parse_mermaid(_fence_body(lines, start, end, closed)))
            except Exception:
                pass
    return charts


def _figcaption(chart: dict, ctx: dict) -> str:
    return "<figcaption>%s</figcaption>" % _inline(chart["title"], ctx) if chart["title"] else ""


def _render_chart(chart: dict, ctx: dict) -> str:
    """图表统一输出成 <figure class="chart chart-类型">，标题用 <figcaption>。"""
    kind = chart["type"]
    ctx["stats"][kind] += 1
    inner = {"bar": _bar_html, "donut": _donut_html, "timeline": _timeline_html}[kind](chart, ctx)
    return '<figure class="chart chart-%s">\n%s\n%s\n</figure>' % (kind, _figcaption(chart, ctx), inner)


def _bar_html(chart: dict, ctx: dict) -> str:
    """柱状图：一排竖条，高度是各值占最大值的百分比（写在 CSS 变量 --h 里）。"""
    labels, values = chart["labels"], chart["values"]
    peak = max(values) if values else 0
    shown = _fmt_num
    out = ['<div class="bars">']
    for k in range(max(len(labels), len(values))):
        value = values[k] if k < len(values) else 0.0
        label = labels[k] if k < len(labels) else ""
        height = value / peak * 100 if peak > 0 else 0
        height = ("%.1f" % max(height, 0.0)).rstrip("0").rstrip(".")
        out.append(
            '<div class="bar-col"><div class="bar-track">'
            '<div class="bar" data-value="%s" style="--h:%s%%"><span class="bar-value">%s</span></div>'
            '</div><div class="bar-label">%s</div></div>'
            % (shown(value), height, shown(value), _inline(label, ctx)))
    out.append("</div>")
    return "\n".join(out)


def _donut_html(chart: dict, ctx: dict) -> str:
    """环形图：圆环用 conic-gradient 按占比着色，中间显示合计，右边是图例。"""
    items = chart["items"]
    total = sum(v for _, v in items)
    stops, cursor = [], 0.0
    for k, (_name, value) in enumerate(items):
        share = value / total * 100 if total else 100.0 / len(items)
        end = 100.0 if k == len(items) - 1 else cursor + share  # 最后一段补到 100%，不留缝
        stops.append("%s %.1f%% %.1f%%" % (PALETTE[k % len(PALETTE)], cursor, end))
        cursor = end
    ring = ('<div class="ring" style="background:conic-gradient(%s)">'
            '<div class="ring-center"><b class="ring-total">%s</b>'
            '<span class="ring-caption">合计</span></div></div>' % (", ".join(stops), _fmt_num(total)))
    out = ['<div class="donut-wrap">', ring, '<ul class="legend">']
    for k, (name, value) in enumerate(items):
        pct = value / total * 100 if total else 0.0
        out.append(
            '<li><i class="swatch" style="background:%s"></i><span class="legend-name">%s</span>'
            '<span class="legend-value">%s</span><span class="legend-pct">%.1f%%</span></li>'
            % (PALETTE[k % len(PALETTE)], _inline(name, ctx), _fmt_num(value), pct))
    out.append("</ul></div>")
    return "\n".join(out)


def _timeline_html(chart: dict, ctx: dict) -> str:
    """时间线：每个日期一条，里面有日期、圆点和竖线、一个或多个事件。"""
    out = ['<ol class="timeline">']
    for when, events in chart["events"]:
        happened = "".join('<p class="tl-event">%s</p>' % _inline(e, ctx) for e in events)
        out.append(
            '<li class="tl-item"><div class="tl-date">%s</div>'
            '<div class="tl-axis"><span class="tl-line"></span><span class="tl-dot"></span></div>'
            '<div class="tl-events">%s</div></li>' % (_inline(when, ctx), happened))
    out.append("</ol>")
    return "\n".join(out)


# ---------------------------------------------------------------- 块渲染

def _list_html(groups: list[dict], ctx: dict) -> str:
    """渲染嵌套的列表组：单段落的条目直接放文字，多段落的条目每段一个 <p>。"""
    out = []
    for g in groups:
        tag = "ol" if g["ordered"] else "ul"
        start = ' start="%d"' % g["start"] if g["ordered"] and g["start"] != 1 else ""
        out.append("<%s%s>" % (tag, start))
        for item in g["items"]:
            paras = item["paras"]
            if len(paras) == 1:
                body = _para_inline(paras[0], ctx)
            else:
                body = "".join("<p>%s</p>" % _para_inline(p, ctx) for p in paras)
            children = "\n" + _list_html(item["groups"], ctx) if item["groups"] else ""
            out.append("<li>%s%s</li>" % (body, children))
        out.append("</%s>" % tag)
    return "\n".join(out)


def _column_widths(header: list[str], rows: list[dict], width: int) -> list[str]:
    """按内容长度给各列分配宽度（百分比字符串，保留一位小数，合计 100%）。

    每列的内容长度 L 取"表头和各数据行纯文本长度"的中位数与最大值的平均。
    两个都要看：只看中位数，一列里仅仅有一格特别长时（比如一行列出五个发文机关），
    这一列会被定得很窄，那一格就被竖着排成十几行；只看最大值，一列里其余的短格子会空着一大片。
    权重 w = min(max(L, 6), 30)，宽度按权重占比；四舍五入的尾差记在最后一列上。
    """
    lines = [header] + [row["cells"] for row in rows]
    weights = []
    for k in range(width):
        lengths = [len(_plain(line[k].replace("\\|", "|")).strip())
                   for line in lines if k < len(line)]
        measure = (statistics.median(lengths) + max(lengths)) / 2.0 if lengths else 0
        weights.append(min(max(measure, 6), 30))

    # 每列的最小宽度：放得下该列最长的一段"不能断开"的内容（日期、编号、角标），外加单元格内边距。
    # 按正文栏里表格的宽度约 760 像素、每个字符约 8 像素换算成百分比。
    # 只管 10 个字符以内的：更长的英文单词在单元格里可以断行（overflow-wrap:anywhere）。
    atomic = re.compile(r"[0-9A-Za-z][0-9A-Za-z.\-:/_%]*")
    whole = re.compile(r"[\dA-Za-z .\-/:]{1,10}")
    mins = []
    for k in range(width):
        longest = 1
        for line in lines:
            if k >= len(line):
                continue
            # 角标 [15][16] 量宽度时按 "15 16" 算：方括号不占宽度，渲染出来是两个上标数字
            plain = re.sub(r"\[(\d+)\]", r"\1 ", _plain(line[k].replace("\\|", "|"))).strip()
            if whole.fullmatch(plain):
                longest = max(longest, len(plain))
            for run in atomic.findall(plain):
                longest = max(longest, len(run))
        mins.append((28.0 + 8.0 * min(longest, 10)) / 760.0 * 100.0)

    total = float(sum(weights)) or 1.0
    shares = [w / total * 100.0 for w in weights]
    if sum(mins) >= 100.0:
        # 最窄要求加起来已经超了，只能按最小宽度等比压缩
        shares = [m / sum(mins) * 100.0 for m in mins]
    else:
        # 先按权重分；不到最小宽度的列固定到最小宽度，余下的宽度再按权重分给其余各列
        settled: set = set()
        for _ in range(width):
            short = [i for i in range(width) if i not in settled and shares[i] < mins[i]]
            if not short:
                break
            settled.update(short)
            for i in short:
                shares[i] = mins[i]
            rest = 100.0 - sum(shares[i] for i in settled)
            free = [i for i in range(width) if i not in settled]
            free_total = sum(weights[i] for i in free) or 1.0
            for i in free:
                shares[i] = weights[i] / free_total * rest
    widths = [round(s, 1) for s in shares]
    widths[-1] = round(100.0 - sum(widths[:-1]), 1)
    return ["%.1f" % w for w in widths]


def _table_html(block: dict, ctx: dict) -> str:
    """表格：包在可横向滚动的容器里；分隔行以冒号结尾的列加 class="num"。

    3 列及以上的表按内容长度定列宽（<colgroup> + 类 cols），2 列的保持自动布局。
    """
    ctx["stats"]["tables"] += 1
    header, aligns, rows = block["header"], block["aligns"], block["rows"]
    width = max([len(header)] + [len(r["cells"]) for r in rows])
    wide = width >= 3
    out = ['<div class="table-wrap">', '<table class="cols">' if wide else "<table>"]
    if wide:
        out.append("<colgroup>" + "".join('<col style="width:%s%%">' % w
                                           for w in _column_widths(header, rows, width))
                   + "</colgroup>")
    out.append("<thead>")
    out.append("<tr>")
    for k, cell in enumerate(header):
        cls = ' class="num"' if k < len(aligns) and aligns[k] == "num" else ""
        out.append("<th%s>%s</th>" % (cls, _inline(cell.replace("\\|", "|"), ctx)))
    out.append("</tr>")
    out.append("</thead>")
    out.append("<tbody>")
    for row in rows:
        rid = ' id="%s"' % row["src"] if row.get("src") else ""
        cells = row["cells"] + [""] * (width - len(row["cells"]))
        out.append("<tr%s>" % rid)
        for k, cell in enumerate(cells):
            cls = ' class="num"' if k < len(aligns) and aligns[k] == "num" else ""
            out.append("<td%s>%s</td>" % (cls, _inline(cell.replace("\\|", "|"), ctx)))
        out.append("</tr>")
    out.append("</tbody>")
    out.append("</table>")
    out.append("</div>")
    return "\n".join(out)


def _meta_html(block: dict, ctx: dict) -> str:
    """元信息表：每格一张卡片（标签 + 值），渲染进封面。"""
    labels = [_plain(c.replace("\\|", "|")) for c in block["header"]]
    out = ['<section class="meta">', '<dl class="meta-grid">']
    for row in block["rows"]:
        for k, cell in enumerate(row["cells"]):
            label = labels[k] if k < len(labels) else ""
            out.append('<div class="meta-item"><dt>%s</dt><dd>%s</dd></div>'
                       % (_esc(label), _inline(cell.replace("\\|", "|"), ctx) or "&#8212;"))
    out.append("</dl>")
    out.append("</section>")
    return "\n".join(out)


def _is_kpi_header(header: list[str]) -> bool:
    """表头是否恰好是"指标 | 数值"两列。"""
    names = [_plain(c.replace("\\|", "|")).strip() for c in header]
    return len(names) == 2 and names == ["指标", "数值"]


def _kpis_html(block: dict, ctx: dict) -> str:
    """"指标 / 数值"两列表：每行一张数字卡片；数值文字超过 16 个字符的卡片单独占一行。"""
    out = ['<section class="kpis">']
    for row in block["rows"]:
        cells = row["cells"] + [""] * (2 - len(row["cells"]))
        label, value = cells[0], cells[1]
        wide = len(_plain(value.replace("\\|", "|")).strip()) > 16
        out.append('<div class="kpi%s"><span class="kpi-label">%s</span><span class="kpi-value">%s</span></div>'
                   % (" kpi-wide" if wide else "", _inline(label.replace("\\|", "|"), ctx),
                      _inline(value.replace("\\|", "|"), ctx)))
    out.append("</section>")
    return "\n".join(out)


def _quicknav_html(text: str, ctx: dict) -> str:
    """快速导航：一行"目录：[甲](#a) · [乙](#b)"，每个链接一个胶囊。"""
    chips = []
    for m in LINK_RE.finditer(text):
        chips.append('<a class="chip" href="%s">%s</a>'
                     % (_attr(_dest(m.group(2))), _strip_links(_inline(m.group(1), ctx))))
    return ('<nav class="quicknav" aria-label="快速导航"><span class="quicknav-label">目录</span>'
            + "".join(chips) + "</nav>")


def _details_html(block: dict, ctx: dict, depth: int) -> str:
    """<details> 原生块：保留标签和 summary，中间的内容按 Markdown 解析。"""
    attrs = CLASS_ATTR_RE.sub("", block["attrs"])
    extra = ' open' if OPEN_ATTR_RE.search(attrs) else ""
    inner_lines, summary = block["lines"], None
    for k, line in enumerate(inner_lines):
        if not line.strip():
            continue
        m = SUMMARY_FULL_RE.match(line.strip()) or SUMMARY_RE.match(line.strip())
        if m:
            summary = m.group(1)
            inner_lines = inner_lines[k + 1:]
        break
    out = ['<details class="fold"%s>' % extra]
    if summary is not None:
        out.append("<summary>%s</summary>" % _inline(summary, ctx))
    out.append(_render_blocks(_parse_blocks(inner_lines, ctx, depth + 1), ctx, depth + 1))
    out.append("</details>")
    return "\n".join(out)


def _render_block(block: dict, ctx: dict, depth: int) -> str:
    """把一个块渲染成 HTML。"""
    kind = block["kind"]
    if kind == "heading":
        return '<h%d id="%s">%s</h%d>' % (block["level"], _attr(block["id"]),
                                          _inline(block["text"], ctx), block["level"])
    if kind == "para":
        return "<p>%s</p>" % _para_inline(block["lines"], ctx)
    if kind == "list":
        return _list_html(block["groups"], ctx)
    if kind == "hr":
        return "<hr>"
    if kind == "code":
        if block.get("lang") == "mermaid":  # 解析不了的 Mermaid 块：原样展示，不画图
            body = "\n".join(block["lines"]).rstrip("\n")
            note = '<p class="chart-fallback">下面这个图表块无法解析，按原样显示。</p>\n'
            return note + "<pre><code>%s</code></pre>" % _esc(body)
        return "<pre><code>%s</code></pre>" % _esc("\n".join(block["lines"]) + "\n" if block["lines"] else "")
    if kind == "chart":
        return _render_chart(block["chart"], ctx)
    if kind == "table":
        return _kpis_html(block, ctx) if block.get("kpi") else _table_html(block, ctx)
    if kind == "quote":
        return "<blockquote>\n%s\n</blockquote>" % _render_blocks(
            _parse_blocks(block["lines"], ctx, depth + 1), ctx, depth + 1)
    if kind == "callout":
        ctx["stats"]["callouts"] += 1
        out = ['<aside class="callout callout-%s">' % block["type"]]
        if block["title"]:
            out.append('<p class="callout-title">%s</p>' % _inline(block["title"], ctx))
        content = _render_blocks(_parse_blocks(block["lines"], ctx, depth + 1), ctx, depth + 1)
        if content:
            out.append(content)
        out.append("</aside>")
        return "\n".join(out)
    if kind == "details":
        return _details_html(block, ctx, depth)
    if kind == "quicknav":
        return _quicknav_html(block["text"], ctx)
    return ""


def _render_blocks(blocks: list[dict], ctx: dict, depth: int) -> str:
    """把块列表渲染成 HTML；顶层正文由 _body_html 负责（还要处理封面和折叠）。"""
    return "\n".join(_render_block(b, ctx, depth) for b in blocks)


# ---------------------------------------------------------------- 文档组装

NUMBER_IN_CELL_RE = re.compile(r"-?\d[\d,]*(?:\.\d+)?")


def _cell_number(cell: str):
    """取单元格里第一个数字（去掉千分位逗号）；没有数字返回 None。"""
    m = NUMBER_IN_CELL_RE.search(cell)
    return float(m.group(0).replace(",", "")) if m else None


def _table_matches_chart(table: dict, chart: dict) -> bool:
    """图后面的表是不是这个图的数据表：有一列数值（或文字）和图里的数据序列一模一样。"""
    rows = [r["cells"] for r in table["rows"]]
    if not rows:
        return True
    if chart["type"] == "bar":
        numbers, texts = list(chart["values"]), list(chart["labels"])
    elif chart["type"] == "donut":
        numbers = [v for _, v in chart["items"]]
        texts = [name for name, _ in chart["items"]]
    else:
        numbers = None
        texts = [when for when, _ in chart["events"]]
    width = max(len(r) for r in rows)
    for k in range(width):
        column = [_plain(r[k].replace("\\|", "|")).strip() for r in rows if k < len(r)]
        if len(column) != len(rows):
            continue
        if texts and column == [t.strip() for t in texts]:
            return True
        if numbers and all(_cell_number(c) is not None for c in column) \
                and [_cell_number(c) for c in column] == [float(v) for v in numbers]:
            return True
    return False


def _analyze(blocks: list[dict], ctx: dict) -> None:
    """顶层块的四项标记：来源清单行、数字卡片表、图旁要折叠的数据表、元信息表。"""
    # 1. 来源清单：标题含"来源"的章节里，表格第一格是整数的行
    in_sources, level = False, 0
    for b in blocks:
        if b["kind"] == "heading":
            if in_sources and b["level"] <= level:
                in_sources = False
            if "来源" in b["text"]:
                in_sources, level = True, b["level"]
        elif b["kind"] == "table" and in_sources:
            for row in b["rows"]:
                first = _plain(row["cells"][0].replace("\\|", "|")).strip() if row["cells"] else ""
                if INT_RE.fullmatch(first):
                    n = int(first)
                    row["src"] = _new_id(ctx, "src-%d" % n)
                    ctx["sources"].add(n)
    # 2. "指标 / 数值"两列表：渲染成数字卡片，而不是表格（要不要算元信息表，见第 4 步）。
    #    分隔行里写了对齐标记（冒号）的保持表格：作者明确要的是带对齐的列。
    for b in blocks:
        if (b["kind"] == "table" and b["rows"] and not b.get("aligned")
                and _is_kpi_header(b["header"])):
            b["kpi"] = True
    # 3. 图旁的数据表：紧挨着图表（中间只隔空行，最多隔一行说明文字）的表折叠起来。
    #    图前面的表按规范无条件折叠；图后面的表要和图的数据对得上才算，
    #    免得"表、图、下一张表、下一张图"连排时，把无关的表也收起来。数字卡片不算。

    def near_table(k: int, step: int) -> int | None:
        """从图表下标 k 沿 step 方向找紧挨着的表，返回表的下标。"""
        j = k + step
        if not 0 <= j < len(blocks):
            return None
        if blocks[j]["kind"] == "para" and len(blocks[j]["lines"]) == 1:
            j += step
        if not 0 <= j < len(blocks) or blocks[j]["kind"] != "table" or blocks[j].get("kpi"):
            return None
        if step > 0 and not _table_matches_chart(blocks[j], blocks[k]["chart"]):
            return None
        return j
    for k, b in enumerate(blocks):
        if b["kind"] == "chart":
            for step in (-1, 1):
                t = near_table(k, step)
                if t is not None:
                    blocks[t]["fold"] = True
    # 4. 元信息表：一级标题之后、第一个二级标题之前的那张表。
    #    这一段要由二级标题收尾才算（全文没有二级标题时不认定）；
    #    紧挨着图表的数据表是图的一部分，也不算。它优先于数字卡片。
    start = next((k for k, b in enumerate(blocks) if b["kind"] == "heading" and b["level"] == 1), None)
    if start is not None:
        candidate, closed_by_h2 = None, False
        for b in blocks[start + 1:]:
            if b["kind"] == "heading" and b["level"] <= 2:
                closed_by_h2 = b["level"] == 2
                break
            if candidate is None and b["kind"] == "table" and not b["fold"]:
                candidate = b
        if candidate is not None and closed_by_h2:
            candidate["meta"] = True
            candidate["kpi"] = False


def _body_html(blocks: list[dict], ctx: dict) -> tuple[str, str, str]:
    """渲染顶层正文，返回 (正文 HTML, 封面里的 h1, 封面里的元信息卡片)。"""
    out, cover_h1, cover_meta = [], "", ""
    first_h1 = True
    for b in blocks:
        if b["kind"] == "heading" and b["level"] == 1 and first_h1:
            first_h1 = False  # 第一个一级标题放进封面
            cover_h1 = '<h1 id="%s">%s</h1>' % (_attr(b["id"]), _inline(b["text"], ctx))
            continue
        if b["kind"] == "heading" and b["level"] in (2, 3):
            ctx["stats"]["sections"] += 1
            ctx["headings"].append((b["level"], b["id"], _inline(b["text"], ctx)))
        if b["kind"] == "table" and b["meta"]:
            cover_meta = _meta_html(b, ctx)
            continue
        piece = _render_block(b, ctx, 0)
        if b["kind"] == "table" and b["fold"] and not b.get("kpi"):
            piece = '<details class="chart-data"><summary>数据表</summary>\n%s\n</details>' % piece
        if piece:
            out.append(piece)
    return "\n".join(out), cover_h1, cover_meta


def _toc_html(headings: list[tuple]) -> str:
    """二级和三级标题的目录：三级标题嵌在所属二级标题下面。"""
    out = ['<nav class="toc" aria-label="目录">', '<p class="toc-title">目录</p>', "<ol>"]
    open_item, open_sub = False, False
    for level, hid, inner in headings:
        link = '<a href="#%s">%s</a>' % (_attr(hid), _strip_links(inner))
        if level == 2:
            if open_sub:
                out.append("</ol>")
                open_sub = False
            if open_item:
                out.append("</li>")
            out.append("<li>%s" % link)
            open_item = True
        else:
            if not open_item:
                out.append("<li>")
                open_item = True
            if not open_sub:
                out.append("<ol>")
                open_sub = True
            out.append("<li>%s</li>" % link)
    if open_sub:
        out.append("</ol>")
    if open_item:
        out.append("</li>")
    out.append("</ol>")
    out.append("</nav>")
    return "\n".join(out)


def _new_ctx() -> dict:
    """一次渲染的共享状态。"""
    return {
        "ids": set(),       # 已占用的标题 id
        "seq": 0,           # 自动编号计数器
        "sources": set(),   # 来源清单里存在的编号
        "headings": [],     # [(层级, id, 标题 HTML)]，只收顶层的二级和三级标题
        "stats": {"sections": 0, "tables": 0, "callouts": 0,
                  "bar": 0, "donut": 0, "timeline": 0, "cites": set()},
    }


# 渲染器内部出了岔子时的保底文档：原文转义后原样放进去，仍然是一份完整的 HTML
_MINIMAL_DOC = (
    "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n"
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>%s</title>\n"
    "</head>\n<body>\n<pre>%s</pre>\n</body>\n</html>\n")


def _render(text: str, title: str | None) -> tuple[str, dict]:
    """Markdown 全文 → HTML 全文和统计。接口函数 render_html 和命令行共用。"""
    lines = _norm(text).split("\n")
    ctx = _new_ctx()
    try:
        blocks = _parse_blocks(_scan(lines)["clean"], ctx)
        _analyze(blocks, ctx)
        body, cover_h1, cover_meta = _body_html(blocks, ctx)
        name = title or _plain(re.sub(r"<[^>]+>", "", cover_h1)) or DEFAULT_TITLE
        return _document(name, cover_h1, cover_meta, ctx["headings"], body), ctx["stats"]
    except Exception:
        # 最后一道防线：解析器自己出了岔子，也不能崩溃或产出残缺的 HTML
        return (_MINIMAL_DOC % (_esc(title or DEFAULT_TITLE), _esc("\n".join(lines))),
                _new_ctx()["stats"])


def render_html(text: str, title: str | None = None) -> str:
    """Markdown 全文 → 单个自包含的 HTML 全文。title 用作页面标题，不给时用一级标题。"""
    return _render(text, title)[0]


# ---------------------------------------------------------------- 校验

def validate(text: str) -> tuple[list[str], list[str]]:
    """渲染前的校验，返回 (错误列表, 警告列表)，都是中文消息。

    错误：注释里残留"待写"标记；可见的占位符（围栏代码块里的不算）；
    Mermaid 图表块解析不了；代码围栏不成对。
    警告：正文引用了来源清单里没有的 [n]；一级标题不是恰好一个。
    """
    lines = _norm(text).split("\n")
    scan = _scan(lines)
    clean, fenced = scan["clean"], scan["fenced"]
    found: list[tuple] = []   # (是否错误, 行号或 None, 消息)

    def error(line, message):
        found.append((True, line, message))

    def warn(line, message):
        found.append((False, line, message))

    # 残留的待写标记
    for i, content in scan["comments"]:
        if "待写" in content:
            error(i + 1, "HTML 注释里有「待写」标记，说明这部分还没写；写完后删除注释")
    # 可见的占位符
    for i, line in enumerate(clean):
        if i in fenced:
            continue
        m = PLACEHOLDER_RE.search(_visible(line))
        if m:
            error(i + 1, "可见的占位符「%s」；请换成实际内容" % m.group(0))
    # Mermaid 图表块和代码围栏
    for start, end, info, closed in scan["blocks"]:
        words = info.split()
        if words and words[0].lower() == "mermaid":
            try:
                _parse_mermaid(_fence_body(lines, start, end, closed))
            except Exception as exc:
                error(start + 1, "Mermaid 图解析不了：%s" % (exc or "未知原因"))
    for start in scan["unbalanced"]:
        error(start + 1, "代码围栏没有闭合；请补上结尾的围栏标记")

    # 一级标题的数量，以及正文角标和来源清单是否对得上
    try:
        ctx = _new_ctx()
        blocks = _parse_blocks(clean, ctx)
        _analyze(blocks, ctx)
        h1 = sum(1 for b in blocks if b["kind"] == "heading" and b["level"] == 1)
        if h1 != 1:
            warn(None, "一级标题应恰好一个，实际 %d 个；请只保留一个 # 标题" % h1)
        source_rows = {row["line"] for b in blocks if b["kind"] == "table"
                       for row in b["rows"] if row.get("src")}
        first_seen: dict[int, int] = {}  # 缺失的编号 -> 首次出现的行号
        for i, line in enumerate(clean):
            if i in fenced or i in source_rows:
                continue
            for m in CITE_FIND_RE.finditer(_visible(line)):
                n = int(m.group(1))
                if n not in ctx["sources"]:
                    first_seen.setdefault(n, i + 1)
        for n in sorted(first_seen):
            warn(first_seen[n], "正文引用了 [%d]，但来源清单里没有第 %d 行；请补充来源或改正编号" % (n, n))
    except Exception:
        # 解析器自己出了岔子：前面查出的问题照常返回，这一项降级成一条警告
        warn(None, "标题和引用这一项没能检查完（渲染器内部出错）；请留意渲染结果")

    found.sort(key=lambda item: (item[1] is None, item[1] or 0))
    errors = ["第 %d 行：%s" % (line, msg) if line else msg
              for is_error, line, msg in found if is_error]
    warnings = ["第 %d 行：%s" % (line, msg) if line else msg
                for is_error, line, msg in found if not is_error]
    return errors, warnings


# ---------------------------------------------------------------- 命令行

class _UsageError(Exception):
    """用法错误。"""


class _ArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise _UsageError(message)


def _force_utf8():
    """把标准输出和标准错误设成 UTF-8；只在 main() 里调用。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


def _summary_line(path, stats: dict) -> str:
    charts = stats["bar"] + stats["donut"] + stats["timeline"]
    return ("已生成 %s：章节 %d，表格 %d，提示框 %d，图表 %d（柱状 %d，环形 %d，时间线 %d），引用 %d"
            % (path, stats["sections"], stats["tables"], stats["callouts"], charts,
               stats["bar"], stats["donut"], stats["timeline"], len(stats["cites"])))


def main(argv: list[str] | None = None) -> int:
    """命令行入口：python scripts/render_html.py <报告.md> [-o <输出.html>]。"""
    _force_utf8()
    parser = _ArgumentParser(
        prog="render_html.py",
        description="把 Markdown 报告渲染成单个自包含的 HTML 文件。",
    )
    parser.add_argument("report", help="报告的 Markdown 文件路径")
    parser.add_argument("-o", "--output", metavar="输出.html",
                        help="输出的 HTML 路径；不给时写到 Markdown 同目录下的同名 .html")
    try:
        args = parser.parse_args(argv)
        text = Path(args.report).read_bytes().decode("utf-8-sig")
    except _UsageError as exc:
        print("用法错误：%s" % exc, file=sys.stderr)
        parser.print_usage(sys.stderr)
        return 2
    except (OSError, UnicodeError) as exc:
        print("无法读取文件：%s" % exc, file=sys.stderr)
        return 2

    errors, warnings = validate(text)
    for message in errors:
        print("错误：" + message)
    for message in warnings:
        print("警告：" + message)
    if errors:
        print("共 %d 个错误，没有生成 HTML；请先修正报告。" % len(errors))
        return 1

    page, stats = _render(text, None)
    out = Path(args.output) if args.output else Path(args.report).with_suffix(".html")
    try:
        if out.parent and not out.parent.exists():
            out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(page.encode("utf-8"))
    except (OSError, ValueError) as exc:
        print("无法写入文件：%s" % exc, file=sys.stderr)
        return 2
    print(_summary_line(out, stats))
    return 0


# ---------------------------------------------------------------- 模板：样式

# 内嵌样式：不引用任何外部资源。变量集中放在 :root 里，方便整体调整配色。
CSS = r"""
:root{
  --bg:#f5f7f6;
  --card:#ffffff;
  --text:#1f2a26;
  --muted:#5f6f69;
  --primary:#0f766e;
  --primary-soft:#eaf2f0;
  --line:#e2e8e6;
  --font:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue","Microsoft YaHei","PingFang SC","Hiragino Sans GB","Noto Sans CJK SC","Source Han Sans SC",sans-serif;
  --mono:"Cascadia Code",Consolas,"SF Mono",Menlo,monospace;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font-family:var(--font);font-size:15.5px;line-height:1.75;-webkit-font-smoothing:antialiased}
a{color:var(--primary);text-decoration:none;border-bottom:1px solid rgba(15,118,110,.28)}
a:hover{border-bottom-color:var(--primary)}

/* 封面：报告标题 + 元信息卡片 */
.cover{max-width:1280px;margin:32px auto 0;padding:0 32px}
.cover-inner{background:var(--card);border:1px solid var(--line);border-top:4px solid var(--primary);border-radius:14px;padding:40px 48px 32px}
.cover h1{margin:0 0 22px;font-size:30px;line-height:1.35;font-weight:700}
.meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:0;padding:0}
.meta-item{min-width:0;background:#f5f8f7;border:1px solid var(--line);border-radius:8px;padding:9px 14px}
.meta-item dt{margin:0 0 1px;font-size:12.5px;line-height:1.5;color:var(--muted)}
.meta-item dd{margin:0;font-size:14.5px;font-weight:600;line-height:1.5;overflow-wrap:anywhere}

/* "指标 / 数值"表：数字卡片，宽屏一行四到五个，窄屏自动换行；数值过长的一张占满一行 */
.kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;margin:18px 0}
.kpi{display:flex;flex-direction:column;gap:2px;min-width:0;padding:12px 16px;background:#f5f8f7;border:1px solid var(--line);border-radius:8px}
.kpi-label{font-size:12.5px;line-height:1.5;color:var(--muted)}
.kpi-value{font-size:22px;line-height:1.3;font-weight:700;color:var(--primary);font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
.kpi-wide{grid-column:1 / -1}
.kpi-wide .kpi-value{font-size:15px;color:var(--text)}

/* 布局：宽屏时目录固定在左侧，正文栏最宽约 860px */
.layout{max-width:1280px;margin:28px auto 0;padding:0 32px;display:grid;grid-template-columns:240px minmax(0,860px);justify-content:center;align-items:start;gap:40px}
.layout.no-toc{grid-template-columns:minmax(0,860px)}
.toc{position:sticky;top:24px;max-height:calc(100vh - 48px);overflow:auto;padding:4px 0;font-size:13.5px;line-height:1.6}
.toc-title{margin:0 0 8px 14px;font-size:12.5px;font-weight:700;letter-spacing:.12em;color:var(--muted)}
.toc ol{list-style:none;margin:0;padding:0}
.toc a{display:block;padding:5px 12px;color:var(--muted);border:0;border-left:2px solid transparent;border-radius:0 6px 6px 0}
.toc a:hover{color:var(--primary);background:var(--primary-soft)}
.toc a.active{color:var(--primary);border-left-color:var(--primary);background:var(--primary-soft);font-weight:600}
.toc ol ol{margin:2px 0 6px 12px;font-size:12.5px}
.content{min-width:0;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:36px 48px 44px}

/* 标题与文字 */
.content h1,.content h2,.content h3,.content h4,.content h5,.content h6{font-weight:700;line-height:1.4;scroll-margin-top:24px}
.content h1{margin:40px 0 16px;font-size:26px}
.content h2{margin:44px 0 18px;padding-left:14px;font-size:22px;border-left:4px solid var(--primary)}
.content h3{margin:30px 0 12px;font-size:17.5px}
.content h4{margin:22px 0 8px;font-size:15.5px}
.content h5,.content h6{margin:18px 0 8px;font-size:14px;color:var(--muted)}
.content > :first-child{margin-top:0}
.content > :last-child{margin-bottom:0}
p{margin:0 0 14px}
ul,ol{margin:0 0 16px;padding-left:1.6em}
li{margin:3px 0}
li > ul,li > ol{margin:4px 0 6px}
blockquote{margin:18px 0;padding:10px 20px;color:var(--muted);background:#fafbfa;border-left:3px solid var(--line);border-radius:0 8px 8px 0}
blockquote > :last-child{margin-bottom:0}
hr{margin:32px 0;border:0;border-top:1px solid var(--line)}
code{padding:1px 5px;font-family:var(--mono);font-size:.9em;color:#0b5c56;background:#f1f4f3;border-radius:4px}
pre{margin:18px 0;padding:16px 20px;overflow:auto;line-height:1.6;background:#f6f8f7;border:1px solid var(--line);border-radius:8px}
pre code{padding:0;font-size:13.5px;color:var(--text);background:none}
img{display:block;max-width:100%;height:auto;margin:12px auto;border-radius:6px}
.date{white-space:nowrap}

/* 来源角标、星级、箭头 */
sup.cite{margin-left:1px;font-size:11px;line-height:0;vertical-align:super}
sup.cite + sup.cite{margin-left:0}
sup.cite a{padding:0 2px;border:0;color:var(--primary)}
.stars{font-size:13px;letter-spacing:1px;white-space:nowrap;color:var(--primary)}
.stars.s2{opacity:.8}
.stars.s1{opacity:.55}
.arr{display:inline-block;min-width:18px;height:18px;margin:0 1px;line-height:18px;text-align:center;vertical-align:1px;font-size:12px;font-weight:700;border-radius:50%}
.arr.up{color:var(--primary);background:#e6f2f0}
.arr.down{color:#dc2626;background:#fdecec}
.arr.flat{color:var(--muted);background:#eef1f0}

/* 提示框：左侧色条、浅色底、标题加粗 */
.callout{position:relative;margin:20px 0;padding:14px 20px 14px 22px;background:var(--tint);border-left:4px solid var(--accent);border-radius:0 10px 10px 0}
.callout > :last-child,.callout ul:last-child,.callout ol:last-child{margin-bottom:0}
.callout-title{margin:0 0 8px;font-weight:700;color:var(--accent)}
.callout-note{--accent:#2563eb;--tint:#eff6ff}
.callout-tip{--accent:#16a34a;--tint:#f0fdf4}
.callout-important{--accent:#7c3aed;--tint:#f5f3ff}
.callout-warning{--accent:#d97706;--tint:#fffbeb}
.callout-caution{--accent:#dc2626;--tint:#fef2f2}

/* 表格：隔行浅底色，表头加粗并在滚动容器内吸顶，宽表可横向滚动 */
.table-wrap{max-height:max(320px,calc(100vh - 120px));margin:18px 0;overflow:auto;background:var(--card);border:1px solid var(--line);border-radius:10px}
table{width:100%;font-size:14px;line-height:1.65;border-spacing:0;border-collapse:separate}
.cols{table-layout:fixed}
th,td{padding:9px 14px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line);overflow-wrap:anywhere}
thead th{position:sticky;top:0;z-index:1;font-weight:700;white-space:nowrap;color:var(--text);background:#f3f6f5;border-bottom:2px solid #d5dedb}
.cols thead th{white-space:normal}
tbody tr:nth-child(even){background:#f8faf9}
tbody tr:hover{background:#f1f6f4}
th.num,td.num{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}

/* 可折叠区块：<details class="fold"> 和图旁的数据表 */
details.fold > summary,details.chart-data > summary{display:inline-block;list-style:none;cursor:pointer;user-select:none;margin:0 0 12px;padding:4px 14px 4px 11px;font-size:14px;font-weight:600;color:var(--primary);background:var(--card);border:1px solid #cfe0dc;border-radius:999px}
details.fold > summary::-webkit-details-marker,details.chart-data > summary::-webkit-details-marker{display:none}
details.fold > summary::before,details.chart-data > summary::before{content:"";display:inline-block;width:0;height:0;margin-right:8px;vertical-align:2px;border-left:5px solid currentColor;border-top:4px solid transparent;border-bottom:4px solid transparent;transition:transform .2s}
details[open] > summary::before{transform:rotate(90deg)}
details.fold > summary:hover,details.chart-data > summary:hover{color:#fff;background:var(--primary);border-color:var(--primary)}
details.fold{margin:18px 0}
details.chart-data{margin:0 0 22px}
details.chart-data .table-wrap{margin:0}

/* 图表：纯 CSS 画 */
.chart{margin:24px 0;padding:20px 24px 22px;background:#fafbfa;border:1px solid var(--line);border-radius:12px}
.chart figcaption{margin:0 0 16px;font-size:14.5px;font-weight:700}
.chart-fallback{margin:0 0 8px;font-size:13px;color:var(--muted)}
.bars{display:flex;align-items:flex-end;gap:10px}
.bar-col{flex:1 1 0;min-width:0;display:flex;flex-direction:column;align-items:center}
.bar-track{width:100%;height:200px;display:flex;align-items:flex-end;justify-content:center;border-bottom:1px solid #d5dedb}
.bar{position:relative;width:72%;max-width:76px;height:var(--h,0%);background:linear-gradient(180deg,#14b8a6 0%,var(--primary) 100%);border-radius:4px 4px 0 0;transition:height .4s ease}
.bar-value{position:absolute;left:50%;bottom:100%;margin-bottom:4px;font-size:12.5px;font-weight:600;white-space:nowrap;font-variant-numeric:tabular-nums;transform:translateX(-50%)}
.bar-label{margin-top:8px;font-size:12.5px;line-height:1.4;text-align:center;color:var(--muted)}
.donut-wrap{display:flex;flex-wrap:wrap;align-items:center;gap:32px}
.ring{position:relative;flex:0 0 auto;width:200px;height:200px;border-radius:50%}
.ring::after{content:"";position:absolute;inset:27%;border-radius:50%;background:#fafbfa}
.ring-center{position:absolute;inset:27%;z-index:1;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.25}
.ring-total{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums}
.ring-caption{font-size:12px;color:var(--muted)}
.legend{flex:1 1 280px;display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:6px 24px;margin:0;padding:0;font-size:14px;list-style:none}
.legend li{display:grid;grid-template-columns:12px minmax(0,1fr) auto 52px;align-items:center;gap:10px}
.swatch{width:12px;height:12px;border-radius:3px}
.legend-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.legend-value{font-weight:600;font-variant-numeric:tabular-nums}
.legend-pct{font-variant-numeric:tabular-nums;text-align:right;color:var(--muted)}
.timeline{margin:0;padding:0;list-style:none}
.tl-item{display:grid;grid-template-columns:110px 22px minmax(0,1fr);gap:0 14px;padding:6px 0}
.tl-date{padding-top:2px;font-size:13.5px;text-align:right;color:var(--muted);font-variant-numeric:tabular-nums}
.tl-axis{position:relative;display:flex;justify-content:center}
.tl-line{position:absolute;top:0;bottom:0;left:50%;width:2px;margin-left:-1px;background:#d5dedb}
.tl-item:first-child .tl-line{top:13px}
.tl-item:last-child .tl-line{bottom:calc(100% - 13px)}
.tl-dot{position:relative;z-index:1;width:12px;height:12px;margin-top:7px;border-radius:50%;background:var(--primary);box-shadow:0 0 0 3px #e0eeeb}
.tl-events{padding-top:1px}
.tl-event{margin:0 0 4px}
.tl-event:last-child{margin-bottom:0}

/* 快速导航 */
.quicknav{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 26px;padding:12px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
.quicknav-label{margin-right:4px;font-size:13px;font-weight:700;color:var(--muted)}
.quicknav .chip{display:inline-block;padding:3px 12px;font-size:13.5px;line-height:1.6;color:var(--primary);background:#f3f8f7;border:1px solid #cfe0dc;border-radius:999px}
.quicknav .chip:hover{color:#fff;background:var(--primary);border-color:var(--primary)}

/* 页脚 */
.foot{max-width:1280px;margin:0 auto;padding:20px 32px 48px;font-size:12.5px;text-align:center;color:var(--muted)}

/* 窄屏：目录移到正文上方 */
@media (max-width:1100px){
  .layout{grid-template-columns:minmax(0,1fr);gap:20px}
  .toc{position:static;max-height:none;overflow:visible;padding:14px 16px;background:var(--card);border:1px solid var(--line);border-radius:12px}
  .toc > ol{columns:2;column-gap:28px}
  .toc li{break-inside:avoid}
}
@media (max-width:640px){
  .cover,.layout{padding-left:16px;padding-right:16px}
  .cover-inner{padding:26px 20px 22px}
  .cover h1{font-size:23px}
  .content{padding:22px 18px 28px}
  .toc > ol{columns:2}       /* 手机上目录只列二级标题，免得占满一屏 */
  .toc ol ol{display:none}
  .donut-wrap{justify-content:center}
  .tl-item{grid-template-columns:92px 20px minmax(0,1fr);gap:0 10px}
  .bars{gap:6px}
}
@media (max-width:420px){
  .toc > ol{columns:1}
}

/* 打印：隐藏目录和快速导航，表格和提示框内部不分页 */
@page{margin:14mm 16mm}
@media print{
  html{scroll-behavior:auto}
  body{font-size:11pt;line-height:1.6;background:#fff}
  .toc,.quicknav{display:none !important}
  .cover,.layout,.foot{max-width:none;margin:0;padding:0}
  .layout{display:block}
  .cover-inner,.content{padding:0;border:0;border-radius:0}
  .cover-inner{margin-bottom:18px;padding-bottom:14px;border-bottom:2px solid var(--primary)}
  .content h2,.content h3,.content h4{break-after:avoid}
  table,.callout,.chart,.meta-item,.bar-col,.tl-item,.kpi{break-inside:avoid}
  tr,li{break-inside:avoid}
  .table-wrap{max-height:none;overflow:visible}
  a{color:inherit;border:0}
  sup.cite a{color:var(--primary)}
}
"""

# ---------------------------------------------------------------- 模板：脚本和骨架

# 内嵌脚本只做一件事：滚动时高亮目录里的当前章节（及其所属的二级章节）。
SCRIPT = r"""
(function () {
  "use strict";
  var toc = document.querySelector(".toc");
  if (!toc || !window.addEventListener) { return; }
  var links = [].slice.call(toc.querySelectorAll("a[href^='#']"));
  var targets = [];
  links.forEach(function (a) {
    var el = document.getElementById(a.getAttribute("href").slice(1));
    if (el) { targets.push([el, a]); }
  });
  var raf = window.requestAnimationFrame || function (fn) { return window.setTimeout(fn, 50); };
  var queued = false;
  function highlight() {
    queued = false;
    var line = window.innerHeight * 0.2;   // 离视口顶部两成处算阅读位置
    var current = null;
    for (var i = 0; i < targets.length; i++) {
      if (targets[i][0].getBoundingClientRect().top <= line) { current = targets[i][1]; }
    }
    var bottom = window.innerHeight + window.pageYOffset >= document.documentElement.scrollHeight - 4;
    if (targets.length && (bottom || current)) { current = bottom ? targets[targets.length - 1][1] : current; }
    links.forEach(function (a) { a.classList.remove("active"); });
    if (!current) { return; }
    current.classList.add("active");
    // 目录的结构是 nav > ol > li > a，三级标题嵌在二级条目的 li 里的 ol。
    // 从当前链接往上找到顶层列表的直接条目，它的第一个链接就是所属的二级标题。
    var root = toc.querySelector("ol");
    var branch = current.parentNode;
    if (root) {
      while (branch && branch.parentNode !== root) { branch = branch.parentNode; }
      if (branch) {
        var top = branch.querySelector("a");
        if (top && top !== current) { top.classList.add("active"); }
      }
      // 目录自己能滚动时，把当前条目滚到可见范围里
      var box = toc.getBoundingClientRect(), rect = current.getBoundingClientRect();
      if (rect.top < box.top + 8) { toc.scrollTop += rect.top - box.top - 8; }
      else if (rect.bottom > box.bottom - 8) { toc.scrollTop += rect.bottom - box.bottom + 8; }
    }
  }
  function schedule() {
    if (!queued) { queued = true; raf(highlight); }
  }
  window.addEventListener("scroll", schedule, { passive: true });
  window.addEventListener("resize", schedule);
  highlight();
})();
"""


def _document(name: str, cover_h1: str, cover_meta: str, headings: list[tuple], body: str) -> str:
    """拼出完整的 HTML 文档：封面、目录 + 正文的两栏布局、页脚、内嵌的样式和脚本。"""
    cover = ""
    if cover_h1 or cover_meta:
        cover = '<header class="cover"><div class="cover-inner">\n%s\n%s\n</div></header>' % (cover_h1, cover_meta)
    toc = _toc_html(headings) if headings else ""
    layout = "layout" if toc else "layout no-toc"
    return "\n".join([
        "<!DOCTYPE html>",
        '<html lang="zh-CN">',
        "<head>",
        '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        '<meta name="generator" content="render_html.py">',
        "<title>%s</title>" % _esc(name),
        "<style>",
        CSS.strip(),
        "</style>",
        "</head>",
        "<body>",
        cover,
        '<div class="%s">' % layout,
        toc,
        '<main class="content">',
        body,
        "</main>",
        "</div>",
        '<footer class="foot">由 Markdown 报告渲染生成，%s</footer>' % date.today().isoformat(),
        "<script>",
        SCRIPT.strip(),
        "</script>",
        "</body>",
        "</html>",
        "",
    ])


if __name__ == "__main__":
    sys.exit(main())
