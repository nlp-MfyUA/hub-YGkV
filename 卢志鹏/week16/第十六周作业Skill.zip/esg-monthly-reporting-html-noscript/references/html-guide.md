# 把报告做成 HTML

手工把 Markdown 报告写成一个网页。整个过程不用脚本，产出的网页里也没有 JavaScript，只靠 HTML 和 CSS。外观与带脚本版渲染出来的网页一致：样式表就是 [../assets/report.css](../assets/report.css)。

## 目录

1. [页面骨架](#页面骨架)
2. [六条规则](#六条规则)
3. [封面、元信息卡片、目录](#封面元信息卡片目录)
4. [标题、段落、角标](#标题段落角标)
5. [提示框](#提示框)
6. [表格](#表格)
7. [柱状图](#柱状图)
8. [环形图](#环形图)
9. [时间线](#时间线)
10. [数字卡片和折叠块](#数字卡片和折叠块)
11. [写完之后核对](#写完之后核对)

## 页面骨架

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>报告标题</title>
<style>
（把 assets/report.css 的全部内容原样抄在这里）
</style>
</head>
<body>
<header class="cover"><div class="cover-inner">
<h1 id="top">报告标题</h1>
<section class="meta">…元信息卡片…</section>
</div></header>
<div class="layout">
<nav class="toc" aria-label="目录"><p class="toc-title">目录</p><ol>…目录…</ol></nav>
<main class="content">
…正文各节…
</main>
</div>
<footer class="foot">报告生成于 YYYY-MM-DD</footer>
</body>
</html>
```

## 六条规则

1. **一个文件搞定。** 不引用任何外部资源：没有外链的样式、字体、图片。没有 `<script>`。
2. **样式表原样照抄**，不改一个字。组件的类名也照本文件写，样式才对得上。
3. **内容以 Markdown 报告为准。** 数字、日期、角标编号一个都不改，不增不减。
4. **文字里的 `<`、`>`、`&`** 写成 `&lt;`、`&gt;`、`&amp;`。
5. **标签都要闭合。** 每个开标签都有对应的闭标签。
6. **分批写入。** 先写骨架（样式表、封面、目录、各节标题），再一节一节补正文，每写完一节就保存。没写的位置用 `<!-- 待写 -->` 注释占位，全部写完后一处不留。

## 封面、元信息卡片、目录

Markdown 报告一级标题下面那张元信息表，做成一组卡片，每格一张：

```html
<header class="cover"><div class="cover-inner">
<h1 id="top">ESG 相关中标情况分析（2026-01 至 2026-06）</h1>
<section class="meta">
<dl class="meta-grid">
<div class="meta-item"><dt>统计区间</dt><dd><span class="date">2026-01-01</span> 至 <span class="date">2026-06-30</span></dd></div>
<div class="meta-item"><dt>样本项目数</dt><dd>39</dd></div>
</dl>
</section>
</div></header>
```

封面卡片里的日期也要包成 `<span class="date">…</span>`，否则会从中间折行。

Markdown 里紧跟在一级标题后面、第一个二级标题之前的提示框（比如"本次为测试运行"那一条），放在 `<main class="content">` 的最前面。

目录列出全部二级标题和三级标题。链接的 `#` 后面是各个标题的 `id`，二级标题沿用 Markdown 里 `<a id="…" name="…"></a>` 给出的名字，三级标题自己起，例如 `sec-1`、`sec-2`：

```html
<nav class="toc" aria-label="目录"><p class="toc-title">目录</p><ol>
<li><a href="#summary">一页速览</a></li>
<li><a href="#scope">一、数据说明</a>
<ol>
<li><a href="#sec-1">搜了什么</a></li>
<li><a href="#sec-2">时间和金额口径</a></li>
</ol>
</li>
</ol></nav>
```

Markdown 里"**目录**：[甲](#a) · [乙](#b)"那一行，转成正文最前面的快速导航，和左侧目录并存：

```html
<nav class="quicknav" aria-label="快速导航"><span class="quicknav-label">目录</span><a class="chip" href="#summary">一页速览</a><a class="chip" href="#sources">来源</a></nav>
```

## 标题、段落、角标

```html
<h2 id="policy">一、政策与监管动态</h2>
<h3 id="sec-5">重点解读：标题就是结论</h3>
<p>发生了什么、为什么重要。加粗用 <strong>strong</strong>，链接写成
<a href="https://example.com/a" target="_blank" rel="noopener">原文</a>。</p>
<ol>
<li>第一条。</li>
<li>第二条。</li>
</ol>
```

Markdown 里的几样东西，在网页里这样写：

| Markdown | HTML |
| --- | --- |
| 来源角标 `[21][22]` | `<sup class="cite"><a href="#src-21">21</a></sup><sup class="cite"><a href="#src-22">22</a></sup>` |
| 角标范围 `[13]–[22]` | 起止两个角标，中间用 `–` 连接 |
| 完整日期 `2026-10-21` | `<span class="date">2026-10-21</span>` |
| `↑`、`↓`、`→` | `<span class="arr up">↑</span>`、`<span class="arr down">↓</span>`、`<span class="arr flat">→</span>` |
| `★★★`、`★★`、`★` | `<span class="stars s3">★★★</span>`、`s2`、`s1` |
| 裸露的网址 | 包成链接，链接文字就是网址本身：`<a href="网址" target="_blank" rel="noopener">网址</a>` |
| 水平分割线 | 不要，标题已经分开了 |

来源清单里第 n 行，要给 `<tr>` 加 `id="src-n"`，角标才点得到：

```html
<tr id="src-21"><td>21</td><td>中国神华能源股份有限公司 2026 年第三季度报告</td><td>中国神华能源股份有限公司</td><td><span class="date">2026-10-24</span></td><td><a href="…" target="_blank" rel="noopener">原文</a></td><td>A</td></tr>
```

## 提示框

Markdown 的 `> [!类型] 标题` 对应一个 `aside`。类名是 `callout callout-类型`，类型用小写：`note`、`tip`、`important`、`warning`、`caution`。标题放 `callout-title`，其余内容按段落或列表写：

```html
<aside class="callout callout-important">
<p class="callout-title">三条核心结论</p>
<ol>
<li>第一条结论，含 <strong>关键数字</strong> <sup class="cite"><a href="#src-12">12</a></sup>。</li>
<li>第二条结论。</li>
</ol>
</aside>
```

## 表格

包在 `table-wrap` 里。数字列加 `num`，会右对齐。哪些列算数字列：Markdown 分隔行里以冒号结尾的列，以及内容全是数字的列。给这一列的每个 `th` 和 `td` 都加上：

```html
<div class="table-wrap">
<table>
<thead>
<tr><th>金额区间（万元）</th><th class="num">项目数</th></tr>
</thead>
<tbody>
<tr><td>10–50</td><td class="num">13</td></tr>
<tr><td>50–100</td><td class="num">15</td></tr>
</tbody>
</table>
</div>
```

长表格逐行照抄。写完数一遍行数，要和 Markdown 里一样多。

## 柱状图

Markdown 里的 `xychart-beta` 代码块改成柱状图。每一根柱子是一个 `bar-col`：

```html
<figure class="chart chart-bar">
<figcaption>各金额区间的项目数</figcaption>
<div class="bars">
<div class="bar-col"><div class="bar-track"><div class="bar" data-value="2" style="--h:13.3%"><span class="bar-value">2</span></div></div><div class="bar-label">10 以下</div></div>
<div class="bar-col"><div class="bar-track"><div class="bar" data-value="15" style="--h:100%"><span class="bar-value">15</span></div></div><div class="bar-label">50–100</div></div>
<div class="bar-col"><div class="bar-track"><div class="bar" data-value="0" style="--h:0%"><span class="bar-value">0</span></div></div><div class="bar-label">500–1000</div></div>
</div>
</figure>
```

- `data-value` 和 `bar-value` 写这个类的数值。
- `--h` 是柱高：该值除以全部柱子里的最大值，再乘 100%，保留一位小数。最大值那根是 `100%`。
- 值为 0 的也要输出一根，`--h:0%`。
- `bar-label` 写横轴标签，`figcaption` 写图的标题。
- 图在前，图旁那张数据表的折叠块紧跟在图后面（写法见"数字卡片和折叠块"）。

## 环形图

Markdown 里的 `pie` 代码块改成环形图：

```html
<figure class="chart chart-donut">
<figcaption>各一级主题的项目数</figcaption>
<div class="donut-wrap">
<div class="ring" style="background:conic-gradient(#0f766e 0.0% 53.8%, #2563eb 53.8% 76.9%, #d97706 76.9% 100.0%)"><div class="ring-center"><b class="ring-total">39</b><span class="ring-caption">合计</span></div></div>
<ul class="legend">
<li><i class="swatch" style="background:#0f766e"></i><span class="legend-name">碳核算与碳核查</span><span class="legend-value">21</span><span class="legend-pct">53.8%</span></li>
<li><i class="swatch" style="background:#2563eb"></i><span class="legend-name">碳足迹与认证</span><span class="legend-value">9</span><span class="legend-pct">23.1%</span></li>
<li><i class="swatch" style="background:#d97706"></i><span class="legend-name">碳资产与碳市场服务</span><span class="legend-value">5</span><span class="legend-pct">12.8%</span></li>
</ul>
</div>
</figure>
```

画法：

1. 每一项的占比等于它的数值除以合计，保留一位小数。`ring-total` 写合计。
2. `conic-gradient` 里每一项一段，从上一项的终点画到自己这一项的累计占比。第一项从 `0.0%` 开始，最后一项画到 `100.0%`。
3. 颜色按这个顺序依次取，用到第几项就取第几个：`#0f766e`、`#2563eb`、`#d97706`、`#7c3aed`、`#dc2626`、`#0891b2`、`#65a30d`、`#db2777`、`#9333ea`、`#ea580c`、`#4f46e5`、`#64748b`。
4. 图例每项一行，色块的颜色和圆环里那一段相同，后面写名称、数值、百分比。

## 时间线

Markdown 里的 `timeline` 代码块改成时间线。每个日期一个 `tl-item`，同一天有几件事就写几个 `tl-event`：

```html
<figure class="chart chart-timeline">
<figcaption>可持续披露与碳足迹标准进展</figcaption>
<ol class="timeline">
<li class="tl-item"><div class="tl-date"><span class="date">2026-10-19</span></div><div class="tl-axis"><span class="tl-line"></span><span class="tl-dot"></span></div><div class="tl-events"><p class="tl-event">五部门印发碳足迹标准行动方案</p></div></li>
<li class="tl-item"><div class="tl-date"><span class="date">2026-10-26</span></div><div class="tl-axis"><span class="tl-line"></span><span class="tl-dot"></span></div><div class="tl-events"><p class="tl-event">财政部征求意见截止</p><p class="tl-event">证监会公布可持续报告电子化规范</p></div></li>
</ol>
</figure>
```

## 数字卡片和折叠块

表头恰好是"指标"和"数值"的两列表，做成数字卡片。其他两列表（比如月报的"关键指标"表）照常做成表格。数值超过 16 个字符的那一行加 `kpi-wide`，单独占一行：

```html
<section class="kpis">
<div class="kpi"><span class="kpi-label">样本项目数</span><span class="kpi-value">39</span></div>
<div class="kpi"><span class="kpi-label">总金额（万元）</span><span class="kpi-value">2964.17</span></div>
<div class="kpi kpi-wide"><span class="kpi-label">最大单笔项目</span><span class="kpi-value">吉林省某项目的名称</span></div>
</section>
```

图旁边的数据表收进折叠块，默认收起。很长的清单（比如全部项目明细）也一样，类名换成 `fold`：

```html
<details class="chart-data"><summary>数据表</summary>
<div class="table-wrap">
<table>…</table>
</div>
</details>

<details class="fold"><summary>展开查看全部项目明细（共 39 条）</summary>
…表格…
</details>
```

## 写完之后核对

1. **没有脚本，没有外部资源。** 在网页文件里搜 `<script` 和 `http` 开头的样式、图片地址，应该一无所获（正文里的来源链接不算）。
2. **标签成对。** 分别数 `<table` 和 `</table>`、`<tr` 和 `</tr>`、`<div` 和 `</div>`、`<aside` 和 `</aside>`、`<figure` 和 `</figure>`、`<details` 和 `</details>`、`<ol` 和 `</ol>`、`<ul` 和 `</ul>`、`<p` 和 `</p>`，每对的个数应该相同。
3. **没有残留的 `<!-- 待写 -->`。**
4. **图表数对得上。** 网页里 `class="chart ` 出现的次数，等于 Markdown 里 Mermaid 代码块的个数。每张图的数值和它旁边折叠的数据表一致。
5. **角标对得上。** 正文里每个角标的链接，在来源清单里都有 `id` 相同的那一行。
6. **数字对得上。** 从 Markdown 的每张表里取第一行、中间一行、最后一行各一个数字，在网页里搜，都应该能搜到。能把所有数字都比一遍更好。
7. **能用浏览器打开就打开看一眼**，看图表、提示框、表格的样子对不对。

核对时可以用编辑器的搜索、命令行的文本工具，也可以自己临时写几行代码。本 Skill 里没有脚本文件，写网页这一步也不要去运行别的脚本。用了什么办法核对，告诉用户。
