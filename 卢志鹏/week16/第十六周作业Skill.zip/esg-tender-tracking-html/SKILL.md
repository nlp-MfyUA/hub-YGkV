---
name: esg-tender-tracking-html
description: Use when the user asks to aggregate, analyse or monitor ESG-related tenders and award notices in China and deliver the report as an HTML page (HTML 版 ESG投标信息汇总; 招标公告、中标公告、成交公告 related to ESG、可持续发展、双碳、碳核算、碳足迹), such as a multi-year summary of award results with hot tender topics and award-amount distribution, or a daily digest of newly published ESG tenders. Triggers include ESG投标信息汇总, ESG tender summary, 中标情况汇总, 热点招标, 中标金额分布, 招标日报, 招标监控, 每日推送.
argument-hint: "[汇总|每日推送] [起始..结束]"
---

# ESG 投标信息汇总（HTML 版）

把公开的 ESG、可持续发展、双碳相关招标信息，做成两种产物：

- **汇总报告**：一段时间内（默认过去 2 年）的中标情况。回答三个问题：哪些主题在招标，中标金额怎么分布，谁在招、谁在中标。
- **每日推送**：最近几天新发布的招标信息，去重后的一页日报。

搜索、判断、写作由你完成。数字计算、去重、格式校验和 HTML 渲染交给脚本。最终交付的是 HTML 报告，Markdown 报告是它的源文件。下文路径都相对本 Skill 所在目录。

## 输入参数

$ARGUMENTS

- 上面如果显示的是字面量 `$ARGUMENTS`，说明调用方没有替换。改为从用户消息里找参数，找不到就用默认值。
- 模式：参数或用户消息里出现"每日""日报""监控""推送"任意一个，走每日推送；否则走汇总。
- 汇总的时间范围写成 `起始..结束`，默认过去 2 年。
- 输出目录默认是当前工作目录下的 `ESG投标信息汇总/`。
- 动手前用一句话告诉用户：走哪种模式、时间范围、报告写到哪。

## 工具对照

| 能力 | 怎么做 |
| --- | --- |
| 联网搜索 | 用所在环境的搜索工具（Claude Code 里是 `WebSearch`）。一次只发一个查询 |
| 读公告原文 | 用所在环境的读网页工具（Claude Code 自带 `WebFetch`；装有网页读取类的 MCP 工具时也可以用它）。页面很长，或只需要关键数字时，改用 `python scripts/fetch_text.py <url> --around 中标,成交,金额 --max-chars 1500` |
| 文件 | 用读写和编辑工具 |
| 脚本 | 在 shell 里运行 `python scripts/...` |

## 台账是唯一的事实来源

- 核实过的公告都要入账，用 `python scripts/ledger.py add`。几个执行者并行采集时，各写各的台账：`<工作记录>/采集_<查询族>/本批台账.jsonl`。
- 全部采集完后合并进总台账 `<输出目录>/数据/招标台账.jsonl`：`python scripts/ledger.py add <总台账> --input <分台账>`。重复的记录会被自动跳过。
- 更正公告：用 `python scripts/ledger.py replace <台账> --input <记录.json>` 改原来那条。
- 报告里的每个数字都从台账来：统计用 `tender_stats.py`，明细用 `ledger.py export-md`。不手算，不凭记忆写数。
- 记录字段和取值见 [references/screening-rubric.md](references/screening-rubric.md) 的"记录格式"。

## 金额的四条铁律

1. `amount_wan` 只填公告里写明的中标或成交金额。公告没写就填 `null`，报告里写"未披露"。
2. 预算、最高限价只进 `budget_wan`，永远不进 `amount_wan`。
3. 金额在 PDF 或图片里读不到时填 `null`，在 `note` 里写明原因。
4. 没有可访问的公告链接的记录，不进台账。

违反字面规则就是违反规则的本意。下面是常见的自我开脱：

| 借口 | 现实 |
| --- | --- |
| "公告里只有预算，先当成交金额填上" | 预算和成交金额是两回事。填错一个，整张分布图就是假的 |
| "金额读不到，按同类项目估一个" | 估计值不是数据。填 `null`，写"未披露" |
| "拿不准算不算 ESG 相关，先收进来凑数" | 弱相关的记录会拉偏主题统计。拿不准就不收 |
| "已经核对过了，不用进台账，直接写进报告" | 报告里的数字必须能追溯到台账 |
| "搜索被限流了，样本差不多了，直接写报告" | 样本少可以如实写。但停下来的理由只能是停止条件，不能是嫌麻烦 |
| "转载页的日期差不多就是公告日期" | 时间口径是公告发布日期。转载日期会让记录落错批次 |

**出现下面任何一个念头，停下来重做**：准备填一个公告里没写的数字；准备跳过读原文；准备把预算当成交金额；准备写一个台账里没有的数字；准备同时发好几个搜索。

## 汇总模式工作流

把下面清单复制到 `<输出目录>/<区间名>/工作记录/进度.md`，随做随勾。区间名默认"近两年汇总"。

- [ ] 1. 立项：定时间范围并按自然半年切成批次（首尾两段取实际起止日）；建目录；按 [references/report-templates.md](references/report-templates.md) 写入报告骨架；填好标题和元信息表
- [ ] 2. 检索计划：读 [references/search-strategy.md](references/search-strategy.md) 和 [references/taxonomy.md](references/taxonomy.md)，为三个查询族各列一份查询清单
- [ ] 3. 采集：按检索打法把查询分成三个查询族，逐族采集，先跑 A 族。每一族走"搜索 → 判断相关性 → 读原文核对 → 记录入账"，完成后在进度里记下新增条数和搜索次数
- [ ] 4. 试跑后校准：A 族跑完算产出率（新增条数 ÷ 搜索次数）。低于 0.3 就按检索打法第 6 节调整查询，再跑 B、C 两族
- [ ] 5. 合并台账并统计：先合并，再运行 `python scripts/tender_stats.py <总台账> --window 起始..结束 --out <工作记录>/统计.md`
- [ ] 6. 成稿：按骨架逐节写，写完一节替换一个待写标记。"一页速览"最后写
- [ ] 7. 自检：先运行 `python scripts/check_report.py <报告> --kind tender-summary --window 起始..结束 --fix`，自动补全中英文之间的空格、去掉行尾空白；再按输出逐条改到错误数为 0
- [ ] 8. 渲染 HTML：`python scripts/render_html.py <报告.md>`，在 Markdown 旁边生成同名的 HTML 文件
- [ ] 9. 交付：告诉用户 HTML 报告的路径（Markdown 源文件的路径也一并给出）、样本量、三条核心结论、数据的局限

每个查询族的停止条件，满足任一条就停：

- 连续 3 个不同主题词的查询都没有带来新的中标或成交记录。同一个主题词换说法重搜，仍算那一个主题词；
- 这一族已经用了 40 次搜索。

目标样本：全表至少 50 条核实过的中标或成交记录，其中至少 30 条披露了金额。越早的公告越难搜到，某个时间段样本很少是正常现象，在"数据说明"里写明，不要凑数。

## 每日推送工作流

- [ ] 1. 读 `<输出目录>/数据/上次推送.txt`，回看范围是上次推送日期到今天。没有这个文件，回看最近 3 天。上次推送在 14 天以前，只回看最近 14 天，并在日报的局限里写明更早的几天可能漏采
- [ ] 2. 搜索新公告：主题词乘以公告类型词（招标公告、变更公告、中标候选人公示、中标公告、成交公告），查询词里带上最近的日期。逐条打开核对发布日期，不在回看范围内的一律不要
- [ ] 3. 筛出相关的，整理成记录，写进临时文件；运行 `python scripts/ledger.py filter-new <台账> --input <临时文件>`，把输出另存成一份"今日新增"文件。只有这份文件里的记录才算今天的新增
- [ ] 4. 先入账，再写日报：`python scripts/ledger.py add <台账> --input <今日新增文件>`；把今天的日期写进 `上次推送.txt`。截止提醒要从台账里取招标公告，所以必须先入账
- [ ] 5. 按 [references/report-templates.md](references/report-templates.md) 的日报骨架，写 `<输出目录>/每日推送/YYYY-MM-DD_招标推送.md`。没有新增的那一节写"本时段未发现"，不留待写标记
- [ ] 6. 推送：在对话里直接给出今天的新增数量、最值得关注的 3 条（项目、采购人、截止时间、链接）
- [ ] 7. 自检：`python scripts/check_report.py <日报> --kind daily --fix`，按输出改到错误数为 0
- [ ] 8. 渲染 HTML：`python scripts/render_html.py <日报.md>`，在日报旁边生成同名的 HTML 文件

怎么每天自动触发，见 [references/daily-monitoring.md](references/daily-monitoring.md)。

## 分批写入

- 报告文件一开始就是完整骨架，未写的位置是 `<!-- …（待写） -->` 注释，渲染时看不见。
- 每完成一节，就把对应的注释替换成正文。不要把所有内容攒到最后一次写。
- 中断后重新开始时，先读进度和台账，从没勾的那一步继续。

## HTML 报告

最终交付的是 HTML 报告。它由脚本从 Markdown 报告生成，不要手写 HTML。

- **图表的写法不变。** 统计脚本输出的 Mermaid 代码块原样贴进报告，渲染脚本会把它们画成真正的柱状图和环形图。不要改动代码块里的数字和引号，改了脚本会报错。
- **脚本自动完成的事**：左侧目录导航、五种提示框的配色、表格样式、来源角标变成可点击的上标、`★★★` 和 `↑↓` 着色、图旁的数据表折叠、"一页速览"里各项数字的展示。
- **生成之后核对**：脚本会打印"图表 N"。在 HTML 文件里搜索 `class="chart`，数出来的个数应该等于 N，也等于报告里 Mermaid 块的个数。

## 参考文件

| 什么时候读 | 文件 |
| --- | --- |
| 列查询清单、搜不到东西、被限流 | [references/search-strategy.md](references/search-strategy.md) |
| 判断一条公告属于哪个主题、采购人算哪类 | [references/taxonomy.md](references/taxonomy.md) |
| 判断收不收、金额怎么填、记录怎么写 | [references/screening-rubric.md](references/screening-rubric.md) |
| 写报告骨架和各节正文 | [references/report-templates.md](references/report-templates.md) |
| 写每一节之前 | [references/typography.md](references/typography.md) |
| 设置每天自动推送 | [references/daily-monitoring.md](references/daily-monitoring.md) |

## 交付前自检

1. 自检脚本的错误数为 0。
2. 随机抽 5 条台账记录，打开链接，确认金额和日期与记录一致。
3. 报告里的样本数与台账条数一致。
4. 没有读取、输出工作目录下的 `.env` 或任何密钥文件。
5. HTML 报告已生成，脚本打印的图表数等于报告里 Mermaid 块的个数。

## 常见错误

- **把招标公告当成果**。招标公告只有预算，没有中标金额。统计金额分布时只算中标公告和成交公告。
- **一条公告记两次**。同一项目的中标候选人公示和中标公告，只记中标公告那一条。
- **搜索结果里的日期直接用**。搜索摘要里的日期常是转载日期。以公告原文的日期为准。
- **只搜"ESG"一个词**。绝大多数双碳相关招标的标题里没有"ESG"。按主题分类表里的检索词逐类搜。
- **样本少却不说明**。报告开头必须写明样本量和检索范围。
