#!/usr/bin/env python3
"""招标台账：追加、去重、更正、查询、导出。

台账是一个 JSON Lines 文件，每行一条记录（一个 JSON 对象）。字段见设计文档 9.2：
必填 title、notice_type、purchaser、publish_date、topic_l1、relevance、url；
可选 winner、amount_wan、budget_wan、region、topic_l2、purchaser_type、source_tier、deadline、note、id。

用法：
    python scripts/ledger.py add <台账.jsonl> --input <记录.json>|-          # 追加并去重
    python scripts/ledger.py replace <台账.jsonl> --input <记录.json>|-      # 用更正后的记录替换原记录
    python scripts/ledger.py filter-new <台账.jsonl> --input <记录.json>|-  # 输出台账里没有的记录
    python scripts/ledger.py list <台账.jsonl> [--since YYYY-MM-DD] [--type 类型] [--topic 一级主题]
    python scripts/ledger.py export-md <台账.jsonl> [--window 起始..结束] [--type 类型]...
    python scripts/ledger.py export-sources <台账.jsonl> [--window 起始..结束] [--type 类型]...

--input 接受 JSON 数组，也接受每行一个 JSON 对象的 JSON Lines；- 表示标准输入。
export-md 与 export-sources 的筛选、排序、编号完全一致：明细表末列的 [n] 对应来源清单的第 n 行。
不给 --type 时只导出中标公告和成交公告，与 tender_stats.py 的统计口径一致；--type 可以重复写。
去重规则（add、filter_new、replace 找原记录时相同，命中任一算重复）：
    规则一：规范化链接、项目名称、公告类型都相同；
    规则二：项目名称、采购人、公告类型都相同。
字符串字段入账前做空白规范化：去首尾空白，内部连续空白压成一个空格。
退出码：0 成功；2 用法、输入文件或记录校验失败（有记录被拒绝、replace 有记录没找到时也是 2）。
"""

import argparse
import hashlib
import json
import math
import os
import re
import sys
import urllib.parse
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional, Tuple

# 公告类型的固定取值
NOTICE_TYPES = ("招标公告", "变更公告", "中标候选人公示", "中标公告", "成交公告", "废标流标公告")
# 导出和统计的默认口径：只算中标公告和成交公告（与 tender_stats.py 一致）
AWARD_TYPES = ("中标公告", "成交公告")

# 一级主题，必须与 Skill 的主题分类表完全一致
TOPICS_L1 = (
    "ESG 报告与披露", "ESG 管理体系与评级咨询", "可持续披露鉴证", "碳核算与碳核查", "碳足迹与认证",
    "双碳规划与方案编制", "碳资产与碳市场服务", "零碳与绿色创建咨询", "气候投融资与可持续金融",
    "生态产品与生态价值核算", "能源审计与节能降碳咨询", "其他 ESG 相关",
)
# 采购人类型，必须与 Skill 的主题分类表完全一致
PURCHASER_TYPES = (
    "政府机关", "事业单位", "央企", "地方国企", "上市公司", "民营企业", "外资企业", "金融机构", "行业协会及其他",
)

# 必填的字符串字段
_REQUIRED_STR = ("title", "notice_type", "purchaser", "publish_date", "topic_l1", "url")
# 可选的字符串字段（给了值就必须是字符串）
_OPTIONAL_STR = ("winner", "region", "topic_l2", "purchaser_type", "note")
# 入账前要做空白规范化的字符串字段
_TEXT_FIELDS = ("title", "purchaser", "winner", "region", "topic_l1", "topic_l2", "purchaser_type", "note")
# export_md（项目明细表）的表格列，以及前 8 列对应的记录字段；末列"来源角标"是自动编号
_COLUMNS = ("日期", "公告类型", "项目名称", "采购人", "中标人", "金额（万元）", "一级主题", "链接", "来源角标")
_FIELDS = ("publish_date", "notice_type", "title", "purchaser", "winner", "amount_wan", "topic_l1", "url")
# export_sources（来源清单表）的表格列
_SOURCE_COLUMNS = ("编号", "标题", "来源", "发布日期", "链接", "可信等级")

# 域名到站点名。主机名以其中一项结尾（忽略开头的 www.）就算命中；
# 不在表里的域名，用去掉开头 www. 的主机名本身。
SOURCE_NAMES = {
    "finance.sina.com.cn": "新浪财经",
    "www.fgw.sz.gov.cn": "深圳市发展和改革委员会",
    "chengezhao.com": "诚 E 招",
    "www.cebpubservice.com": "中国招标投标公共服务平台",
    "www.ccgp.gov.cn": "中国政府采购网",
}
# source_tier 到可信等级；缺失写"—"
SOURCE_TIERS = {1: "A", 2: "B", 3: "C"}

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")
_WS_RE = re.compile(r"\s+")


class UsageError(Exception):
    """命令行用法或输入文件有误。"""


def _is_int(value) -> bool:
    """整数判断。bool 是 int 的子类，但不算整数。"""
    return isinstance(value, int) and not isinstance(value, bool)


def _is_date(value) -> bool:
    """是否为 YYYY-MM-DD 格式的真实日期。"""
    if not isinstance(value, str) or not _DATE_RE.match(value):
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


def _is_datetime(value) -> bool:
    """是否为 YYYY-MM-DD HH:MM 格式的真实时间。"""
    if not isinstance(value, str) or not _DATETIME_RE.match(value):
        return False
    try:
        datetime.strptime(value, "%Y-%m-%d %H:%M")
    except ValueError:
        return False
    return True


def _is_amount(value) -> bool:
    """非负的有限数。bool、字符串、NaN、负数都不算。"""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return value >= 0 and (isinstance(value, int) or math.isfinite(value))


def _squash(text: str) -> str:
    """去掉全部空白（含全角空格），用于比较标题和采购人。"""
    return re.sub(r"\s+", "", text)


def _norm_text(value: str) -> str:
    """去掉首尾空白，内部连续空白（含换行、全角空格）压成一个空格。"""
    return _WS_RE.sub(" ", value.strip())


def normalize_record(rec: dict) -> dict:
    """返回规范化后的记录副本：_TEXT_FIELDS 里的字符串字段去首尾空白、内部连续空白压成一个空格。"""
    out = dict(rec)
    for key in _TEXT_FIELDS:
        value = out.get(key)
        if isinstance(value, str):
            out[key] = _norm_text(value)
    return out


def validate_record(rec: dict) -> List[str]:
    """校验一条记录，返回错误信息列表；空列表表示合法。

    字符串字段的取值先做空白规范化再比较。未知字段不检查。
    """
    if not isinstance(rec, dict):
        return ["记录必须是 JSON 对象"]
    errors = []
    for key in _REQUIRED_STR:
        value = rec.get(key)
        if not (isinstance(value, str) and value.strip()):
            errors.append(f"{key}：必填，必须是非空字符串")
    value = rec.get("notice_type")
    if isinstance(value, str) and value.strip() and value not in NOTICE_TYPES:
        errors.append("notice_type：必须是 " + "、".join(NOTICE_TYPES) + " 之一")
    value = rec.get("publish_date")
    if isinstance(value, str) and value.strip() and not _is_date(value):
        errors.append("publish_date：必须是 YYYY-MM-DD 格式的真实日期")
    value = rec.get("topic_l1")
    if isinstance(value, str) and value.strip() and _norm_text(value) not in TOPICS_L1:
        errors.append("topic_l1：必须是以下一级主题之一：" + "、".join(TOPICS_L1))
    value = rec.get("relevance")
    if not (_is_int(value) and 1 <= value <= 3):
        errors.append("relevance：必须是 1–3 的整数")
    for key in ("amount_wan", "budget_wan"):
        value = rec.get(key)
        if value is not None and not _is_amount(value):
            errors.append(f"{key}：必须是非负数或 null，不接受字符串")
    value = rec.get("source_tier")
    if value is not None and not (_is_int(value) and 1 <= value <= 3):
        errors.append("source_tier：必须是 1–3 的整数或 null")
    value = rec.get("url")
    if isinstance(value, str) and value.strip() and not value.strip().lower().startswith(("http://", "https://")):
        errors.append("url：必须以 http:// 或 https:// 开头")
    for key in _OPTIONAL_STR:
        value = rec.get(key)
        if value is not None and not isinstance(value, str):
            errors.append(f"{key}：必须是字符串或 null")
    value = rec.get("purchaser_type")
    if isinstance(value, str) and value.strip() and _norm_text(value) not in PURCHASER_TYPES:
        errors.append("purchaser_type：必须是以下采购人类型之一：" + "、".join(PURCHASER_TYPES))
    value = rec.get("deadline")
    if value is not None and not (isinstance(value, str) and (not value.strip() or _is_datetime(value))):
        errors.append("deadline：必须是 YYYY-MM-DD HH:MM 格式或 null")
    value = rec.get("id")
    if value is not None and not (isinstance(value, str) and value.strip()):
        errors.append("id：必须是非空字符串")
    return errors


def normalize_url(url: str) -> str:
    """规范化 URL：去掉 # 之后的部分，协议和域名转小写，去掉末尾的 /。"""
    url = url.strip()
    try:
        parts = urllib.parse.urlsplit(url)
        return urllib.parse.urlunsplit(
            (parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip("/"), parts.query, ""))
    except ValueError:
        # 极少数畸形 URL 解析失败，退回到只去掉 # 之后部分的写法
        return url.split("#", 1)[0]


def _text(value) -> str:
    """字符串去掉全部空白；非字符串当作空串。"""
    return _squash(value) if isinstance(value, str) else ""


def _url_key(rec: dict) -> Optional[str]:
    """去重键一：规范化链接、去空白的项目名称、公告类型，用 | 拼接。没有可用链接时返回 None。"""
    url = rec.get("url")
    if not (isinstance(url, str) and url.strip()):
        return None
    return "|".join((normalize_url(url), _text(rec.get("title")), _text(rec.get("notice_type"))))


def _title_key(rec: dict) -> Optional[str]:
    """去重键二：去空白的项目名称、去空白的采购人、公告类型，用 | 拼接。项目名称或采购人缺失时返回 None。"""
    title, purchaser = _text(rec.get("title")), _text(rec.get("purchaser"))
    if not title or not purchaser:
        return None
    return "|".join((title, purchaser, _text(rec.get("notice_type"))))


def _make_id(rec: dict) -> str:
    """自动生成记录 id："T" 加去重键一（规范化链接|项目名称|公告类型）的 sha1 前 8 位。

    同一份公告里不同标段的项目名称不同，不会撞 id。没有链接时退而用去重键二。
    """
    seed = _url_key(rec) or _title_key(rec) or ""
    return "T" + hashlib.sha1(seed.encode("utf-8")).hexdigest()[:8]


def load(path: Path) -> List[dict]:
    """读取台账；文件不存在时返回空列表。某行不是 JSON 对象时抛 ValueError。"""
    path = Path(path)
    if not path.is_file():
        return []
    records = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except ValueError as exc:
            raise ValueError(f"台账 {path} 第 {lineno} 行不是合法 JSON：{exc}") from None
        if not isinstance(obj, dict):
            raise ValueError(f"台账 {path} 第 {lineno} 行不是 JSON 对象")
        records.append(obj)
    return records


def _write_all(path: Path, rows: List[dict]) -> None:
    """整表重写：先写临时文件再替换，避免写一半损坏台账。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(tmp, path)


class _Seen:
    """已见记录的去重键。add 和 filter_new 共用，保证两处的去重规则完全一样。"""

    def __init__(self):
        self.urls, self.titles = set(), set()

    def add(self, rec: dict) -> None:
        """记下一条记录的键。"""
        url_key, title_key = _url_key(rec), _title_key(rec)
        if url_key:
            self.urls.add(url_key)
        if title_key:
            self.titles.add(title_key)

    def has(self, rec: dict) -> bool:
        """这条记录是否与已见的某条重复（键一或键二命中任一）。"""
        url_key, title_key = _url_key(rec), _title_key(rec)
        return bool(url_key and url_key in self.urls) or bool(title_key and title_key in self.titles)


class _Count(int):
    """带明细的计数。比较、打印、转 JSON 都和普通整数一样；.items 是它数的那几条。"""

    def __new__(cls, items=()):
        obj = super().__new__(cls, len(items))
        obj.items = list(items)
        return obj


def _validate_all(records: List[dict]) -> Tuple[List[dict], List[dict]]:
    """把输入记录分成（合法的，拒绝明细）。拒绝明细每项是 {"record": 原记录, "errors": [错误信息]}。"""
    valid, rejected = [], []
    for rec in records:
        errors = validate_record(rec)
        if errors:
            rejected.append({"record": rec, "errors": errors})
        else:
            valid.append(rec)
    return valid, rejected


def add(path: Path, records: List[dict]) -> dict:
    """校验并追加记录。返回 {"added", "skipped", "rejected"}。

    rejected 每项是 {"record": 原记录, "errors": [错误信息]}。台账文件不存在时自动创建。
    入账的是空白规范化之后的值（见 normalize_record）。

    两条记录算重复（项目名称、采购人比较前都去掉全部空白），命中任一即跳过并计数：
    - 键一：规范化链接、项目名称、公告类型都相同；
    - 键二：项目名称、采购人、公告类型都相同。
    两条规则对已有台账和同一批里靠前的记录一视同仁。所以同一份公告的不同标段（项目名称不同）、
    同一项目的候选人公示和中标公告（类型不同）各记一条。
    """
    path = Path(path)
    seen = _Seen()
    for old in load(path):
        seen.add(old)
    valid, rejected = _validate_all(records)
    fresh, skipped = [], 0
    for rec in valid:
        if seen.has(rec):
            skipped += 1
            continue
        seen.add(rec)
        stored = normalize_record(rec)
        if not stored.get("id"):
            stored["id"] = _make_id(rec)
        fresh.append(stored)
    if fresh:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8", newline="\n") as fh:
            for item in fresh:
                fh.write(json.dumps(item, ensure_ascii=False) + "\n")
    return {"added": len(fresh), "skipped": skipped, "rejected": rejected}


def replace(path: Path, records: List[dict]) -> dict:
    """用新记录替换台账里与之重复的原记录（更正公告用）。返回 {"replaced", "not_found", "rejected"}。

    输入先按现有规则校验，不合法的进 rejected。在台账里按去重规则找原记录：规范化链接、项目名称、
    公告类型都相同，或项目名称、采购人、公告类型都相同。找到就用新记录（已做空白规范化）替换它，
    保留原来的 id，其余字段以新记录为准，位置不变；一条都没找到的计入 not_found。

    三个值都是整数；其中 not_found 和 rejected 身上带 .items 明细，供命令行打印原因。
    """
    path = Path(path)
    rows = load(path)
    valid, rejected = _validate_all(records)
    replaced, missing = 0, []
    for rec in valid:
        rec = normalize_record(rec)
        url_key, title_key = _url_key(rec), _title_key(rec)
        for index, old in enumerate(rows):
            if (url_key and _url_key(old) == url_key) or (title_key and _title_key(old) == title_key):
                fresh = dict(rec)
                fresh["id"] = old.get("id") or _make_id(rec)
                rows[index] = fresh
                replaced += 1
                break
        else:
            missing.append(rec)
    if replaced:
        _write_all(path, rows)
    return {"replaced": replaced, "not_found": _Count(missing), "rejected": _Count(rejected)}


def filter_new(path: Path, records: List[dict]) -> List[dict]:
    """返回 records 里不与台账重复、且在本批里不与靠前记录重复的那些。

    去重规则与 add 完全相同：已有台账和本批里靠前的记录，都会挡住后面的重复记录。
    所以已入账公告的其他标段（项目名称不同）、其他公告类型仍会返回。本函数不校验，见 filter_new_checked。
    """
    seen = _Seen()
    for old in load(path):
        seen.add(old)
    fresh = []
    for rec in records:
        if not isinstance(rec, dict):
            continue
        if seen.has(rec):
            continue
        seen.add(rec)
        fresh.append(rec)
    return fresh


def filter_new_checked(path: Path, records: List[dict]) -> Tuple[List[dict], List[dict]]:
    """先校验再去重：返回（新记录，被拒绝的记录）。

    被拒绝的每项是 {"record": 原记录, "errors": [错误信息]}。新记录已做空白规范化，和入账时的样子一致。
    """
    valid, rejected = _validate_all(records)
    return filter_new(path, [normalize_record(rec) for rec in valid]), rejected


def list_records(path: Path, since: Optional[str] = None, notice_type: Optional[str] = None,
                 topic: Optional[str] = None) -> List[dict]:
    """按条件筛选台账记录；条件都是可选的，publish_date 不早于 since。"""
    out = []
    for rec in load(path):
        published = rec.get("publish_date") or ""
        if since and published < since:
            continue
        if notice_type and rec.get("notice_type") != notice_type:
            continue
        if topic and rec.get("topic_l1") != topic:
            continue
        out.append(rec)
    return out


def _cell(value) -> str:
    """表格单元格：None 留空；换行换成空格；竖线转义，避免被当成列分隔符。"""
    if value is None:
        return ""
    return re.sub(r"\s*\n\s*", " ", str(value)).replace("|", "\\|")


def _fmt_amount(value) -> str:
    """金额保留两位小数；None 显示为"未披露"。"""
    if value is None:
        return "未披露"
    return f"{value:.2f}" if _is_amount(value) else str(value)


def _export_types(notice_type: Optional[str], notice_types: Optional[Tuple[str, ...]]) -> Tuple[str, ...]:
    """导出用的公告类型：给了 notice_types 就用这几种；否则给了 notice_type 就用这一种；都不给取 AWARD_TYPES。"""
    if notice_types:
        return tuple(notice_types)
    if notice_type:
        return (notice_type,)
    return AWARD_TYPES


def _ordered(path: Path, window: Optional[Tuple[str, str]] = None, notice_type: Optional[str] = None,
             notice_types: Optional[Tuple[str, ...]] = None) -> List[dict]:
    """export_md 和 export_sources 共用的筛选与排序，保证两张表编号一致：按 publish_date 升序，同日按 title。"""
    types = _export_types(notice_type, notice_types)
    start, end = window if window else (None, None)
    rows = []
    for rec in load(path):
        published = rec.get("publish_date") or ""
        if rec.get("notice_type") not in types:
            continue
        if (start and published < start) or (end and published > end):
            continue
        rows.append(rec)
    rows.sort(key=lambda r: (r.get("publish_date") or "", str(r.get("title") or "")))
    return rows


def _table(columns: Tuple[str, ...], rows: List[list]) -> str:
    """拼成 Markdown 表：表头、分隔行、数据行。"""
    lines = ["| " + " | ".join(columns) + " |", "| " + " | ".join("---" for _ in columns) + " |"]
    lines.extend("| " + " | ".join(_cell(c) for c in cells) + " |" for cells in rows)
    return "\n".join(lines) + "\n"


def export_md(path: Path, window: Optional[Tuple[str, str]] = None, notice_type: Optional[str] = None,
              notice_types: Optional[Tuple[str, ...]] = None) -> str:
    """导出项目明细表，列：日期、公告类型、项目名称、采购人、中标人、金额（万元）、一级主题、链接、来源角标。

    window 是 (起始, 结束)，按 publish_date 闭区间筛选。"来源角标"列写 [n]，n 从 1 起，
    与 export_sources 导出的来源清单第 n 行一一对应。
    公告类型：给了 notice_types 取这几种；否则给了 notice_type 取这一种；都不给只取中标公告和成交公告。
    """
    rows = []
    for n, rec in enumerate(_ordered(path, window, notice_type, notice_types), 1):
        cells = [_fmt_amount(rec.get(key)) if key == "amount_wan" else rec.get(key) for key in _FIELDS]
        rows.append(cells + [f"[{n}]"])
    return _table(_COLUMNS, rows)


def _bare_host(host: str) -> str:
    """去掉主机名开头的 www.。"""
    return host[4:] if host.startswith("www.") else host


def source_name(url) -> str:
    """按 URL 的主机名查 SOURCE_NAMES 得到站点名；查不到时用去掉 www. 的主机名。"""
    try:
        host = urllib.parse.urlsplit(str(url)).hostname or ""
    except ValueError:
        host = ""
    bare = _bare_host(host.lower())
    for domain in sorted(SOURCE_NAMES, key=len, reverse=True):  # 先比长的，免得被短域名抢先命中
        target = _bare_host(domain)
        if bare == target or bare.endswith("." + target):
            return SOURCE_NAMES[domain]
    return bare


def _link(url) -> str:
    """Markdown 链接 [原文](url)。括号和空格做百分号编码，免得链接或表格被截断。"""
    url = str(url).replace("(", "%28").replace(")", "%29").replace(" ", "%20")
    return f"[原文]({url})"


def export_sources(path: Path, window: Optional[Tuple[str, str]] = None, notice_type: Optional[str] = None,
                   notice_types: Optional[Tuple[str, ...]] = None) -> str:
    """导出来源清单表，列：编号、标题、来源、发布日期、链接、可信等级。

    筛选、排序、编号与 export_md 完全一致（公告类型的取法也相同）。来源按 url 的主机名查站点名；
    可信等级由 source_tier 换算（1 对应 A，2 对应 B，3 对应 C），缺失写"—"。
    """
    rows = []
    for n, rec in enumerate(_ordered(path, window, notice_type, notice_types), 1):
        url = rec.get("url")
        rows.append([n, rec.get("title"), source_name(url), rec.get("publish_date"),
                     _link(url) if isinstance(url, str) and url.strip() else "",
                     SOURCE_TIERS.get(rec.get("source_tier"), "—")])
    return _table(_SOURCE_COLUMNS, rows)


def _read_source(source: str) -> str:
    """读取 --input 指向的内容；- 表示标准输入。"""
    if source == "-":
        return sys.stdin.read()
    path = Path(source)
    if not path.is_file():
        raise UsageError(f"找不到输入文件：{source}")
    return path.read_text(encoding="utf-8-sig")


def parse_input(text: str) -> list:
    """解析 --input 的内容：JSON 数组、单个 JSON 对象，或每行一个 JSON 对象的 JSON Lines。"""
    try:
        whole = json.loads(text)
    except ValueError:
        whole = None
    if isinstance(whole, list):
        return whole
    if isinstance(whole, dict):
        return [whole]
    records = []
    for lineno, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            records.append(json.loads(line))
        except ValueError as exc:
            raise UsageError(f"输入第 {lineno} 行不是合法 JSON：{exc}") from None
    return records


def _require_date(value: str, option: str) -> str:
    if not _is_date(value):
        raise UsageError(f"{option} 必须是 YYYY-MM-DD 格式的真实日期，收到：{value}")
    return value


def _parse_window(value: str) -> Tuple[str, str]:
    parts = value.split("..")
    if len(parts) != 2:
        raise UsageError("--window 的格式是 起始..结束，例如 2025-01-01..2025-12-31")
    start, end = (_require_date(part.strip(), "--window") for part in parts)
    if start > end:
        raise UsageError("--window 的起始日期不能晚于结束日期")
    return start, end


def _title_of(rec) -> str:
    """记录的项目名称；取不到时写"（无标题）"。"""
    title = rec.get("title") if isinstance(rec, dict) else None
    return title if isinstance(title, str) and title.strip() else "（无标题）"


def _print_rejected(item: dict, file=None) -> None:
    """打印一条被拒绝记录的原因；file 为 None 时输出到标准输出。"""
    print(f"拒绝：{_title_of(item['record'])}", file=file)
    for err in item["errors"]:
        print(f"  - {err}", file=file)


def _cmd_add(args) -> int:
    result = add(args.ledger, parse_input(_read_source(args.input)))
    for item in result["rejected"]:
        _print_rejected(item)
    print(f"新增 {result['added']}，跳过 {result['skipped']}，拒绝 {len(result['rejected'])}")
    return 2 if result["rejected"] else 0


def _cmd_replace(args) -> int:
    result = replace(args.ledger, parse_input(_read_source(args.input)))
    for rec in result["not_found"].items:
        print(f"未找到：{_title_of(rec)}")
    for item in result["rejected"].items:
        _print_rejected(item)
    print(f"替换 {result['replaced']}，未找到 {result['not_found']}，拒绝 {result['rejected']}")
    return 2 if result["not_found"] or result["rejected"] else 0


def _cmd_filter_new(args) -> int:
    fresh, rejected = filter_new_checked(args.ledger, parse_input(_read_source(args.input)))
    for item in rejected:
        _print_rejected(item, file=sys.stderr)
    print(json.dumps(fresh, ensure_ascii=False, indent=2))
    return 2 if rejected else 0


def _checked_type(value: Optional[str]) -> Optional[str]:
    """校验单个 --type 的取值；没给就是 None。"""
    if value and value not in NOTICE_TYPES:
        raise UsageError("--type 必须是 " + "、".join(NOTICE_TYPES) + " 之一")
    return value


def _checked_types(values: Optional[List[str]]) -> Optional[Tuple[str, ...]]:
    """校验可重复的 --type；一个都没给就是 None（导出时取默认两类）。"""
    if not values:
        return None
    for value in values:
        if value not in NOTICE_TYPES:
            raise UsageError("--type 必须是 " + "、".join(NOTICE_TYPES) + f" 之一，收到：{value}")
    return tuple(values)


def _cmd_list(args) -> int:
    since = _require_date(args.since, "--since") if args.since else None
    found = list_records(args.ledger, since=since, notice_type=_checked_type(args.type), topic=args.topic)
    print(json.dumps(found, ensure_ascii=False, indent=2))
    return 0


def _cmd_export_md(args) -> int:
    window = _parse_window(args.window) if args.window else None
    sys.stdout.write(export_md(args.ledger, window=window, notice_types=_checked_types(args.type)))
    return 0


def _cmd_export_sources(args) -> int:
    window = _parse_window(args.window) if args.window else None
    sys.stdout.write(export_sources(args.ledger, window=window, notice_types=_checked_types(args.type)))
    return 0


class _Parser(argparse.ArgumentParser):
    """把 argparse 的用法错误变成 UsageError，让 main 返回 2 而不是直接退出进程。"""

    def error(self, message):
        raise UsageError(message)


def main(argv: Optional[List[str]] = None) -> int:
    for stream in (sys.stdout, sys.stderr, sys.stdin):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")

    parser = _Parser(prog="ledger.py", description="招标台账：追加、去重、更正、查询、导出")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("add", help="追加并去重")
    p.add_argument("ledger", help="台账文件（JSON Lines），不存在时自动创建")
    p.add_argument("--input", required=True, help="记录文件（JSON 数组或 JSON Lines）；- 表示标准输入")
    p.set_defaults(func=_cmd_add)

    p = sub.add_parser("replace", help="用更正后的记录替换台账里与之重复的原记录")
    p.add_argument("ledger", help="台账文件（JSON Lines）")
    p.add_argument("--input", required=True, help="记录文件（JSON 数组或 JSON Lines）；- 表示标准输入")
    p.set_defaults(func=_cmd_replace)

    p = sub.add_parser("filter-new", help="输出台账里没有的记录（JSON 数组），不合法的记录报错")
    p.add_argument("ledger", help="台账文件（JSON Lines）")
    p.add_argument("--input", required=True, help="记录文件（JSON 数组或 JSON Lines）；- 表示标准输入")
    p.set_defaults(func=_cmd_filter_new)

    p = sub.add_parser("list", help="按条件列出记录（JSON 数组）")
    p.add_argument("ledger", help="台账文件（JSON Lines）")
    p.add_argument("--since", help="只列 publish_date 不早于这一天的记录，YYYY-MM-DD")
    p.add_argument("--type", help="公告类型，默认不限")
    p.add_argument("--topic", help="一级主题，默认不限")
    p.set_defaults(func=_cmd_list)

    p = sub.add_parser("export-md", help="导出项目明细表，末列是来源角标 [n]")
    p.add_argument("ledger", help="台账文件（JSON Lines）")
    p.add_argument("--window", help="publish_date 的闭区间，如 2025-01-01..2025-12-31")
    p.add_argument("--type", action="append", help="公告类型，可重复写；不写时只导出中标公告和成交公告")
    p.set_defaults(func=_cmd_export_md)

    p = sub.add_parser("export-sources", help="导出来源清单表，编号与 export-md 的来源角标一致")
    p.add_argument("ledger", help="台账文件（JSON Lines）")
    p.add_argument("--window", help="publish_date 的闭区间，如 2025-01-01..2025-12-31")
    p.add_argument("--type", action="append", help="公告类型，可重复写；不写时只导出中标公告和成交公告")
    p.set_defaults(func=_cmd_export_sources)

    try:
        args = parser.parse_args(argv)
        return args.func(args)
    except UsageError as exc:
        parser.print_usage(sys.stderr)
        print(f"错误：{exc}", file=sys.stderr)
        return 2
    except ValueError as exc:
        # 台账文件损坏、编码不对等
        print(f"错误：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
