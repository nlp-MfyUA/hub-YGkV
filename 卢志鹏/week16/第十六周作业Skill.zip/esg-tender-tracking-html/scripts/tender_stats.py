"""tender_stats.py：从招标台账算出汇总报告要用的全部数字，并排成 Markdown 表格和 Mermaid 图。

用法：
    python scripts/tender_stats.py <台账.jsonl> [--window 起始..结束] [--type 类型 ...] [--out 输出.md]
    --type 只接受 NOTICE_TYPES 里的六种公告类型，写错会报错退出（退出码 2），不会静默筛出空结果。

口径（设计文档 7.2、9.3）：
- 金额只用 amount_wan（万元）。未披露、不是数字或是负数的，一律按"未披露"处理。
- 百分比保留一位小数，金额保留两位小数；平均数、中位数用标准库 statistics。
- 百分比的分母：金额区间表用披露金额的项目数；一级主题、采购人类型、地区、中标机构类型用样本项目数。
- 样本不足时的降级：披露金额的记录不足 20 条，或不同中标机构不超过 15 家时，中标机构列出全部；
  样本不足 30 条，趋势按半年；地区不足 8 个，不做地区表。
- 趋势从第一条记录所在的期间连续列到最后一条记录所在的期间，中间没有记录的期间记 0。
- 中标机构类型：先取 winner_type 字段；没有再从 note 开头的"机构类型：某某。"里取，括号里的说明不算；
  都没有记为"未知"。

只用标准库，兼容 Python 3.9。只读台账文件，不导入 ledger.py，不读取 .env。
"""

import argparse
import json
import re
import statistics
import sys
from collections import Counter
from datetime import date
from pathlib import Path
from typing import List, Optional, Tuple

# 金额区间（万元）：左闭右开，最后一档到无穷。
AMOUNT_BINS = ((0, 10), (10, 50), (50, 100), (100, 300), (300, 500), (500, 1000), (1000, None))

# 样本不足时的降级阈值（设计文档 7.2）。
WINNERS_TOP_N = 15        # 披露金额的记录够多、且中标机构超过这么多家时，只列前 15 名
WINNERS_FULL_MIN = 20     # 披露金额的记录不足这么多条时，列出全部中标机构
TREND_QUARTER_MIN = 30    # 样本不足这么多条时，趋势按半年而不是按季度
REGION_TABLE_MIN = 8      # 地区不足这么多个时，不做地区表

DEFAULT_TYPES = ("中标公告", "成交公告")   # 命令行不传 --type 时统计的公告类型
_TYPE_ALIASES = {"中标": "中标公告", "成交": "成交公告"}
NOTICE_TYPES = ("招标公告", "变更公告", "中标候选人公示", "中标公告", "成交公告", "废标流标公告")   # 与 ledger.py 一致

_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_NOTE_TYPE_RE = re.compile(r"\s*机构类型\s*[：:]\s*([^。.（(]+)")   # note 开头的"机构类型：某某。"


def _is_date(text):
    """是不是真实的 YYYY-MM-DD 日期。"""
    if not isinstance(text, str) or not _DATE_RE.fullmatch(text):
        return False
    try:
        date.fromisoformat(text)
    except ValueError:
        return False
    return True


def _amount(rec):
    """记录披露的金额（万元）。未披露、不是数字（如 "100万"）或是负数时返回 None。"""
    value = rec.get("amount_wan")
    if isinstance(value, (int, float)) and not isinstance(value, bool) and value >= 0:
        return float(value)
    return None


def _disclosed(records):
    """返回 [(金额, 记录)]，只含披露了金额的记录。"""
    pairs = []
    for rec in records:
        value = _amount(rec)
        if value is not None:
            pairs.append((value, rec))
    return pairs


def _summarize(records):
    """返回 (项目数, 披露金额的项目数, 金额合计或 None)。没有披露金额的记录时合计为 None。"""
    values = [value for value, _ in _disclosed(records)]
    return len(records), len(values), round(sum(values), 2) if values else None


def _pct(count, whole):
    """占比（%），保留一位小数。分母为 0 时记 0.0。"""
    return round(count * 100 / whole, 1) if whole else 0.0


def _rank(counter):
    """把 Counter 排成按数量降序的列表；数量相同的保持首次出现的顺序。"""
    return sorted(counter.items(), key=lambda item: -item[1])


def _group(records, field, default=None):
    """按字段分组。字段为空时：给了 default 就归入 default，否则跳过这条记录。"""
    groups = {}
    for rec in records:
        value = rec.get(field) or default
        if value:
            groups.setdefault(str(value), []).append(rec)
    return groups


def _winner_type(rec):
    """中标机构类型：先取 winner_type 字段；没有再从 note 开头的"机构类型：某某。"里取。

    括号里的说明不算，只取括号前面的部分。都取不到时记为"未知"。
    """
    value = str(rec.get("winner_type") or "").strip()
    if value:
        return value
    match = _NOTE_TYPE_RE.match(str(rec.get("note") or ""))
    parsed = match.group(1).strip() if match else ""
    return parsed or "未知"


def _bin_label(index, low, high):
    """区间标签："10 以下"、"10–50"、"1000 以上"。"""
    if index == 0:
        return f"{high:g} 以下"
    if high is None:
        return f"{low:g} 以上"
    return f"{low:g}–{high:g}"


def _period_of(text, period):
    """把 YYYY-MM-DD 归到季度或半年，返回排序键，如 (2025, 1)。"""
    year, month = int(text[:4]), int(text[5:7])
    return (year, (month - 1) // 3 + 1) if period == "quarter" else (year, 1 if month <= 6 else 2)


def _period_label(key, period):
    """排序键转成标签：(2025, 1) 对应 "2025Q1" 或 "2025H1"。"""
    return f"{key[0]}{'Q' if period == 'quarter' else 'H'}{key[1]}"


def _period_span(first, last, period):
    """从 first 到 last 的全部期间键（含两头）。中间没有记录的期间也列出来，跨年时接着往下数。"""
    per_year = 4 if period == "quarter" else 2
    keys = []
    year, index = first
    while (year, index) <= last:
        keys.append((year, index))
        index += 1
        if index > per_year:
            year, index = year + 1, 1
    return keys


def load_records(path: Path, window: Optional[Tuple[str, str]] = None,
                 notice_types: Optional[Tuple[str, ...]] = None) -> List[dict]:
    """读取 JSONL 台账，按时间窗（两头都算）和公告类型筛选，保持文件顺序。

    window 形如 ("2025-01-01", "2025-12-31")；notice_types 为 None 时不过滤公告类型，
    出现了 NOTICE_TYPES 以外的类型时抛 ValueError，避免写错类型后静默筛出空结果。
    日期格式不对的记录在给了时间窗时直接排除，不猜它落在窗口里。
    """
    wanted = None
    if notice_types:
        unknown = [str(t) for t in notice_types if t not in NOTICE_TYPES]
        if unknown:
            raise ValueError(f"未知的公告类型：{'、'.join(unknown)}。合法取值：{'、'.join(NOTICE_TYPES)}")
        wanted = set(notice_types)
    records = []
    with open(path, encoding="utf-8-sig") as fh:
        for lineno, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except ValueError as exc:
                raise ValueError(f"{path} 第 {lineno} 行不是合法的 JSON：{exc}") from None
            if not isinstance(rec, dict):
                raise ValueError(f"{path} 第 {lineno} 行不是 JSON 对象")
            if window is not None:
                day = rec.get("publish_date")
                if not _is_date(day) or not window[0] <= day <= window[1]:
                    continue
            if wanted is not None and rec.get("notice_type") not in wanted:
                continue
            records.append(rec)
    return records


def compute(records: List[dict]) -> dict:
    """算出报告要用的全部数字。records 是台账记录的列表。

    返回的键：sample、with_amount、total_wan、mean_wan、median_wan、max_wan、max_title、
    bins、topics、trend_period、trend、purchaser_types、regions、winners_title、winners、winner_types。
    分组里的 sum_wan 在这一组没有披露金额的记录时为 None。
    """
    disclosed = _disclosed(records)
    values = [value for value, _ in disclosed]
    sample, with_amount = len(records), len(values)
    stats = {
        "sample": sample,
        "with_amount": with_amount,
        "total_wan": round(sum(values), 2) if values else None,
        "mean_wan": round(float(statistics.mean(values)), 2) if values else None,
        "median_wan": round(float(statistics.median(values)), 2) if values else None,
        "max_wan": max(values) if values else None,
        "max_title": max(disclosed, key=lambda pair: pair[0])[1].get("title") if values else None,
    }

    # 金额区间：占比的分母是披露金额的项目数，各档加起来正好是 100%。
    stats["bins"] = []
    for index, (low, high) in enumerate(AMOUNT_BINS):
        members = [value for value in values if value >= low and (high is None or value < high)]
        stats["bins"].append({
            "label": _bin_label(index, low, high),
            "count": len(members),
            "pct": _pct(len(members), with_amount),
            "sum_wan": round(sum(members), 2),
        })

    # 一级主题：占比的分母是全部样本；典型采购人取该主题下项目数最多的采购人。
    stats["topics"] = []
    for topic, members in _group(records, "topic_l1", "未分类").items():
        count, _, total = _summarize(members)
        top = _rank(Counter(rec.get("purchaser") or "未知" for rec in members))[0][0]
        stats["topics"].append({
            "topic_l1": topic, "count": count, "pct": _pct(count, sample), "sum_wan": total,
            "top_purchaser": top,
        })
    stats["topics"].sort(key=lambda t: (-t["count"], -(t["sum_wan"] or 0)))

    # 时间趋势：样本不足时按半年。从第一条到最后一条记录所在的期间连续列出，中间空的期间记 0。
    period = "half_year" if sample < TREND_QUARTER_MIN else "quarter"
    buckets = {}
    for rec in records:
        if _is_date(rec.get("publish_date")):
            buckets.setdefault(_period_of(rec["publish_date"], period), []).append(rec)
    stats["trend_period"] = period
    stats["trend"] = []
    span = _period_span(min(buckets), max(buckets), period) if buckets else []
    for key in span:
        members = buckets.get(key)
        count, n_amount, total = _summarize(members) if members else (0, 0, 0.0)
        stats["trend"].append({"period": _period_label(key, period), "count": count,
                               "with_amount": n_amount, "sum_wan": total})

    # 采购人类型和地区：没填的归入"未知"；地区不足 8 个时不出地区表。
    stats["purchaser_types"] = [
        {"type": name, "count": n} for name, n in _rank(Counter(rec.get("purchaser_type") or "未知" for rec in records))]
    regions = _rank(Counter(rec.get("region") or "未知" for rec in records))
    stats["regions"] = [{"region": name, "count": n} for name, n in regions] if len(regions) >= REGION_TABLE_MIN else []

    # 中标机构：按中标数降序。只有披露金额的记录够 20 条、且机构超过 15 家时才截断；
    # 其余情况都列全部，标题也写"全部"，保证标题和表里的内容一致。
    winners = []
    for winner, members in _group(records, "winner").items():
        count, _, total = _summarize(members)
        topics = "、".join(name for name, _ in _rank(Counter(rec.get("topic_l1") or "未分类" for rec in members)))
        winners.append({"winner": winner, "count": count, "sum_wan": total, "topics": topics})
    winners.sort(key=lambda w: (-w["count"], -(w["sum_wan"] or 0)))
    if with_amount >= WINNERS_FULL_MIN and len(winners) > WINNERS_TOP_N:
        stats["winners_title"] = f"前 {WINNERS_TOP_N} 名中标机构"
        winners = winners[:WINNERS_TOP_N]
    else:
        stats["winners_title"] = "全部中标机构"
    stats["winners"] = winners

    # 中标机构类型：占比的分母是全部样本。count 相同时"未知"排在最前，提示这里有数据缺口；其余按类型名排序。
    typed = {}
    for rec in records:
        typed.setdefault(_winner_type(rec), []).append(rec)
    stats["winner_types"] = []
    for name, members in typed.items():
        count, _, total = _summarize(members)
        stats["winner_types"].append({"type": name, "count": count, "pct": _pct(count, sample), "sum_wan": total})
    stats["winner_types"].sort(key=lambda w: (-w["count"], w["type"] != "未知", w["type"]))
    return stats


def _wan(value):
    """金额（万元）：保留两位小数；None 显示为破折号。"""
    return "—" if value is None else f"{value:.2f}"


def _table(headers, rows):
    """生成 Markdown 表。单元格里的竖线转义成 \\|，换行换成空格，避免表格错列。"""
    def cell(value):
        text = "—" if value is None else str(value)
        return text.replace("|", "\\|").replace("\n", " ").strip()

    lines = ["| " + " | ".join(cell(h) for h in headers) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    lines.extend("| " + " | ".join(cell(v) for v in row) + " |" for row in rows)
    return "\n".join(lines)


def _note(stats):
    """每张金额表下面都要有的样本说明。"""
    return f"披露金额的项目数 {stats['with_amount']} / 样本数 {stats['sample']}"


def _label(text):
    """Mermaid 图里的文字：去掉会破坏语法的双引号和换行。"""
    return str(text).replace('"', "").replace("\n", " ").strip()


def _bar_chart(title, labels, values):
    """xychart-beta 柱状图。纵轴上界取不小于最大值的 10 的倍数，刻度才都是整数。"""
    upper = max(10, (max(values) + 9) // 10 * 10)
    return "\n".join([
        "```mermaid",
        "xychart-beta",
        f'    title "{_label(title)}"',
        "    x-axis [" + ", ".join(f'"{_label(text)}"' for text in labels) + "]",
        f'    y-axis "项目数" 0 --> {upper}',
        "    bar [" + ", ".join(str(v) for v in values) + "]",
        "```",
    ])


def _pie_chart(title, labels, values):
    """pie 饼图，数值是项目数。"""
    lines = ["```mermaid", f"pie title {_label(title)}"]
    lines.extend(f'    "{_label(text)}" : {value}' for text, value in zip(labels, values))
    lines.append("```")
    return "\n".join(lines)


def render(stats: dict) -> str:
    """把 compute 的结果排成 Markdown：KPI 表、各分布表和对应的 Mermaid 图。

    没有数据的部分不输出，例如没有披露金额的项目时不画金额分布图。
    """
    note = _note(stats)
    blocks = [_table(["指标", "数值"], [
        ["样本项目数", stats["sample"]],
        ["披露金额的项目数", stats["with_amount"]],
        ["总金额（万元）", _wan(stats["total_wan"])],
        ["中位数（万元）", _wan(stats["median_wan"])],
        ["平均数（万元）", _wan(stats["mean_wan"])],
        ["最大单笔（万元）", _wan(stats["max_wan"])],
        ["最大单笔项目", stats["max_title"]],
    ]), note]

    bins = stats["bins"]
    if stats["with_amount"]:
        blocks += [
            _table(["金额区间（万元）", "项目数", "占比（%）", "金额合计（万元）"],
                   [[b["label"], b["count"], f"{b['pct']:.1f}", _wan(b["sum_wan"])] for b in bins]),
            note,
            _bar_chart("各金额区间的项目数", [b["label"] for b in bins], [b["count"] for b in bins]),
        ]

    topics = stats["topics"]
    if topics:
        blocks += [
            _table(["一级主题", "项目数", "占比（%）", "披露金额合计（万元）", "典型采购人"],
                   [[t["topic_l1"], t["count"], f"{t['pct']:.1f}", _wan(t["sum_wan"]), t["top_purchaser"]]
                    for t in topics]),
            note,
            _pie_chart("各一级主题的项目数", [t["topic_l1"] for t in topics], [t["count"] for t in topics]),
        ]

    trend = stats["trend"]
    if trend:
        unit = "季度" if stats["trend_period"] == "quarter" else "半年"
        blocks += [
            _table([unit, "项目数", "披露金额的项目数", "金额合计（万元）"],
                   [[t["period"], t["count"], t["with_amount"], _wan(t["sum_wan"])] for t in trend]),
            note,
            _bar_chart(f"各{unit}的项目数", [t["period"] for t in trend], [t["count"] for t in trend]),
        ]

    if stats["purchaser_types"]:
        blocks.append(_table(
            ["采购人类型", "项目数", "占比（%）"],
            [[p["type"], p["count"], f"{_pct(p['count'], stats['sample']):.1f}"] for p in stats["purchaser_types"]]))
    if stats["regions"]:
        blocks.append(_table(
            ["地区", "项目数", "占比（%）"],
            [[r["region"], r["count"], f"{_pct(r['count'], stats['sample']):.1f}"] for r in stats["regions"]]))

    winners = stats["winners"]
    if winners:
        # 标题写进表头第一格："前 15 名中标机构" 或 "全部中标机构"。
        blocks += [
            _table([stats["winners_title"], "中标数", "金额合计（万元）", "涉及主题"],
                   [[w["winner"], w["count"], _wan(w["sum_wan"]), w["topics"]] for w in winners]),
            note,
        ]

    winner_types = stats["winner_types"]
    if winner_types:
        blocks += [
            _table(["中标机构类型", "中标数", "条数占比（%）", "金额合计（万元）"],
                   [[w["type"], w["count"], f"{w['pct']:.1f}", _wan(w["sum_wan"])] for w in winner_types]),
            note,
        ]
    return "\n\n".join(blocks) + "\n"


class _UsageError(Exception):
    """命令行用法错误。"""


class _Parser(argparse.ArgumentParser):
    """用法错误时抛异常而不是直接退出，让 main 能返回退出码 2。"""

    def error(self, message):
        raise _UsageError(message)


def _parse_window(text):
    """把 "起始..结束" 拆成 (起始, 结束)，两头都算在窗口内。"""
    start, sep, end = text.partition("..")
    if not sep or not _is_date(start) or not _is_date(end) or start > end:
        raise _UsageError(f"--window 要写成 起始..结束（YYYY-MM-DD），例如 2024-11-26..2026-11-26；收到的是 {text}")
    return start, end


def main(argv: Optional[List[str]] = None) -> int:
    """命令行入口。返回 0 表示成功，2 表示用法或文件错误。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = _Parser(prog="tender_stats.py", description="读取招标台账（JSONL），输出汇总报告用的表格和 Mermaid 图。")
    parser.add_argument("ledger", help="台账文件（JSONL）")
    parser.add_argument("--window", help="统计区间，写成 起始..结束，如 2024-11-26..2026-11-26；不传则取全部")
    parser.add_argument("--type", action="append",
                        help="只统计这些公告类型，可重复，如 --type 中标公告 --type 成交公告；不传则取中标公告和成交公告。"
                             f"合法取值：{'、'.join(NOTICE_TYPES)}")
    parser.add_argument("--out", help="把结果写进这个 Markdown 文件；不传则打印到标准输出")
    try:
        args = parser.parse_args(sys.argv[1:] if argv is None else argv)
        types = tuple(_TYPE_ALIASES.get(t, t) for t in args.type or DEFAULT_TYPES)
        records = load_records(args.ledger, _parse_window(args.window) if args.window else None, types)
        stats = compute(records)
        text = render(stats)
        if args.out:
            out = Path(args.out)
            out.parent.mkdir(parents=True, exist_ok=True)
            with open(out, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(text)
            print(f"已写入 {out.as_posix()}：{_note(stats)}")
        else:
            print(text, end="")
    except (_UsageError, OSError, ValueError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2
    if not records:
        print("提示：没有符合条件的记录，请检查 --window 和 --type。", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
