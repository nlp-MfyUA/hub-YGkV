"""第十三周作业二：对话式数据查询（ChatBI）前端。

基于作业一的 LangGraph SQL Agent：用户在网页用自然语言提问，
后端跑 选表 -> SQL 生成 -> 校验 -> 只读执行 -> 自修复 -> 结果汇总 的图工作流，
前端以对话方式展示答案、SQL 与查询结果。

运行：streamlit run app.py   （需要同级目录 ../作业一 存在）
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

# 挂载作业一的 sql_agent_langgraph 包（兄弟目录）
_HOMEWORK1 = Path(__file__).resolve().parents[1] / "作业一"
if not _HOMEWORK1.is_dir():
    st.error(f"未找到作业一目录：{_HOMEWORK1}，请将本文件放在『第十三周作业/作业二/』下运行。")
    st.stop()
sys.path.insert(0, str(_HOMEWORK1))

from sql_agent_langgraph import SQLAgentGraph, WorkflowOutput  # noqa: E402
from sql_agent_langgraph.config import settings  # noqa: E402

st.set_page_config(page_title="ChatBI · 对话式数据查询", page_icon="💬", layout="wide")

EXAMPLES = [
    "总共有多少张专辑？",
    "美国客户的订单总金额是多少？",
    "总销售额最高的员工叫什么名字？",
    "销量前 5 的曲目有哪些？",
]


@st.cache_resource
def get_graph() -> SQLAgentGraph:
    """整个应用只构建一次图（数据库目录也只解析一次）。"""
    return SQLAgentGraph()


def render_assistant(message: dict) -> None:
    """渲染一条助手消息：答案 + 结果表 + 可展开的执行过程。"""
    output: WorkflowOutput = message["output"]
    execution = message.get("execution")
    attempts = message.get("attempts") or []

    st.markdown(output.answer)

    # 查询结果表（有行数据时）
    if execution is not None and execution.rows:
        rows = execution.rows[:50]
        st.dataframe(
            [dict(zip(execution.columns, row)) for row in rows],
            hide_index=True,
        )
        if execution.row_count > len(rows):
            st.caption(f"仅展示前 {len(rows)} 行，共 {execution.row_count} 行。")

    with st.expander("🔍 执行过程"):
        if output.tables:
            st.markdown(f"**使用的表：**{', '.join(output.tables)}")
        if output.sql:
            st.code(output.sql, language="sql")
        st.markdown(
            f"返回 {output.row_count} 行"
            f"{'（已截断）' if output.truncated else ''}　·　"
            f"SQL 自修复 {output.repair_attempts} 次"
        )
        if len(attempts) > 1:
            st.markdown("**尝试历史：**")
            for i, item in enumerate(attempts, start=1):
                err = f"　❌ {item.code}: {item.error}" if item.error else "　✅"
                st.markdown(f"{i}. `[{item.source}]` `{' '.join(item.sql.split())}`{err}")
        if output.evidence:
            st.markdown("**答案依据：**" + "；".join(output.evidence))
        for caveat in output.caveats:
            st.markdown(f"**注意：**{caveat}")
        if output.error:
            st.markdown(f"**错误：**{output.error}")


def answer_question(question: str) -> None:
    """处理一个用户问题：调用 LangGraph 工作流并渲染助手消息。"""
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("正在分析问题、生成并执行 SQL…"):
            state = get_graph().run_with_state(question)
        output = state["output"]
        message = {
            "role": "assistant",
            "output": output,
            "execution": state.get("execution"),
            "attempts": state.get("attempts"),
        }
        st.session_state.messages.append(message)
        render_assistant(message)


# ---------- 侧边栏 ----------
graph = get_graph()
st.sidebar.title("💬 ChatBI · 对话式数据查询")
st.sidebar.caption(f"后端：LangGraph SQL Agent（{settings.primary_model}）")
st.sidebar.caption(f"数据库：chinook.db（{len(graph.catalog.table_names)} 张表）")
with st.sidebar.expander("示例问题"):
    for example in EXAMPLES:
        if st.button(example, key=f"example::{example}"):
            st.session_state["pending_question"] = example
            st.rerun()
with st.sidebar.expander("LangGraph 工作流结构"):
    st.code(graph.mermaid(), language="mermaid")
st.sidebar.divider()
st.sidebar.markdown(
    "流程：选表 → SQL 生成 → 校验(EXPLAIN) → 只读执行 → "
    "失败自修复(≤3 次) → 结果汇总"
)

# ---------- 主区域：对话 ----------
st.title("💬 ChatBI · 对话式数据查询")
st.caption("用自然语言查询 chinook 音乐商店数据库：AI 自动选表、生成并执行 SQL，返回自然语言答案")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        if message["role"] == "user":
            st.markdown(message["content"])
        else:
            render_assistant(message)

question = st.chat_input("输入要查询的问题，例如：总共有多少张专辑？")
pending = st.session_state.pop("pending_question", None)
if pending:
    answer_question(pending)
elif question:
    answer_question(question)
