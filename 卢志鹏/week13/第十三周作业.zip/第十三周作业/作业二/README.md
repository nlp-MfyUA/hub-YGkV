# 第十三周作业二：对话式数据查询（ChatBI）Web 应用

基于 **作业一的 LangGraph SQL Agent** 的 Streamlit 对话界面：用户在网页输入自然语言问题，
后端跑完整的图工作流（选表 → SQL 生成 → 校验 → 只读执行 → 自修复 → 结果汇总），
前端以聊天方式返回自然语言答案、生成的 SQL 和查询结果表。

## 功能

- 💬 对话式界面：`st.chat_input` 输入问题，历史对话保存在会话中
- 📊 结果输出：自然语言答案 + 查询结果表格（`st.dataframe`）
- 🔍 执行过程：可展开查看使用的表、生成的 SQL、修复次数、尝试历史、答案依据
- 🧭 侧边栏：示例问题一键提问；LangGraph 工作流结构图（Mermaid）
- 🛡️ 安全沿用后端：只读连接、SELECT 白名单、用户问题作为数据传入防注入

## 运行方式

```bash
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r ../作业一/requirements.txt -r requirements.txt

cd 第十三周作业/作业二
streamlit run app.py
```

浏览器打开 `http://localhost:8501`，直接输入问题或点击侧边栏示例。

> 依赖关系：本目录只有前端，`app.py` 运行时会挂载兄弟目录 `../作业一/sql_agent_langgraph` 包，
> 请保持『第十三周作业/作业一』与『作业二』的相对位置不变。

## 文件结构

```
作业二/
├── app.py            # Streamlit 前端（对话 UI + 执行过程展示）
├── requirements.txt  # 前端依赖（后端依赖见 ../作业一）
└── README.md
```

## 验证记录（2026-11-05，智谱 glm-5.3）

- AppTest 烟测：页面正常渲染，chat_input / 示例按钮 / Mermaid 图均在位；
- AppTest 真实 LLM 端到端：输入「总共有多少张专辑？」→ 助手回答 **347 张专辑**，结果表、SQL、执行过程完整展示 ✅。
