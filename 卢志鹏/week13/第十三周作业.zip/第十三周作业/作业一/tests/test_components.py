"""无 LLM 的组件与 LangGraph 编排测试（Agent 调用用 monkeypatch 模拟）。

运行：cd 作业二目录 && pytest tests/ -q
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sql_agent_langgraph import graph as gf  # noqa: E402
from sql_agent_langgraph.db.catalog import SchemaCatalog  # noqa: E402
from sql_agent_langgraph.db.executor import SQLExecutionError, SQLExecutor  # noqa: E402
from sql_agent_langgraph.db.validator import SQLValidator, normalize_sql  # noqa: E402
from sql_agent_langgraph.models import (  # noqa: E402
    FinalAnswer,
    SQLDraft,
    TableSelection,
)
from sql_agent_langgraph.graph import SQLAgentGraph  # noqa: E402

DB_PATH = ROOT / "chinook.db"


@pytest.fixture(scope="module")
def catalog() -> SchemaCatalog:
    return SchemaCatalog(DB_PATH)


@pytest.fixture(scope="module")
def validator() -> SQLValidator:
    return SQLValidator(DB_PATH)


@pytest.fixture(scope="module")
def executor() -> SQLExecutor:
    return SQLExecutor(DB_PATH)


# ---------- SQLValidator：安全门禁与 EXPLAIN 校验 ----------

def test_validator_rejects_write_statements(validator):
    result = validator.validate("INSERT INTO albums (Title) VALUES ('x')")
    assert not result.ok
    assert result.code.value == "unsafe"


def test_validator_rejects_multi_statement(validator):
    result = validator.validate("SELECT 1; DROP TABLE albums")
    assert not result.ok
    assert result.code.value == "unsafe"


def test_validator_rejects_pragma(validator):
    result = validator.validate("PRAGMA table_info(albums)")
    assert not result.ok
    assert result.code.value == "unsafe"


def test_validator_unknown_column(validator):
    result = validator.validate("SELECT BadCol FROM albums")
    assert not result.ok
    assert result.code.value == "unknown_object"


def test_validator_accepts_select(validator):
    result = validator.validate("SELECT COUNT(*) AS n FROM albums")
    assert result.ok
    assert result.normalized_sql == "SELECT COUNT(*) AS n FROM albums"


def test_validator_masks_keyword_in_string(validator):
    # 字符串字面量里的 "delete" 不应误判为写操作
    result = validator.validate("SELECT 'please delete nothing' AS msg FROM albums LIMIT 1")
    assert result.ok


def test_normalize_sql_strips_fence_and_semicolon():
    assert normalize_sql("```sql\nSELECT 1;\n```") == "SELECT 1"


# ---------- SQLExecutor：只读执行与截断 ----------

def test_executor_basic_query(executor):
    result = executor.execute("SELECT COUNT(*) AS n FROM albums")
    assert result.row_count == 1
    assert result.rows[0][0] == "347"


def test_executor_truncation(executor):
    limited = SQLExecutor(DB_PATH, max_rows=2)
    result = limited.execute("SELECT Title FROM albums")
    assert result.row_count == 2
    assert result.truncated is True


def test_executor_readonly(executor):
    with pytest.raises(SQLExecutionError):
        executor.execute("INSERT INTO albums (Title) VALUES ('x')")


# ---------- SchemaCatalog：目录与外键连通性 ----------

def test_catalog_excludes_internal_tables(catalog):
    assert len(catalog.table_names) == 11
    assert "sqlite_sequence" not in catalog.table_names


def test_catalog_connectivity(catalog):
    assert catalog.is_connected(["albums", "artists"]) is True
    assert catalog.is_connected(["albums", "customers"]) is False


def test_catalog_render(catalog):
    catalog_text = catalog.render_catalog()
    assert "外键关系" in catalog_text
    assert "albums" in catalog_text
    assert "###" not in catalog_text  # 目录视图是轻量的


# ---------- Workflow：mock Agent 验证编排、重试与降级 ----------

def _make_graph() -> SQLAgentGraph:
    catalog = SchemaCatalog(DB_PATH)
    return SQLAgentGraph(
        catalog=catalog,
        validator=SQLValidator(DB_PATH),
        executor=SQLExecutor(DB_PATH),
    )


def test_graph_happy_path(monkeypatch):
    calls = []

    def fake_run_agent(agent, prompt):
        calls.append(agent)
        if agent is gf.table_selector_agent:
            return TableSelection(tables=["albums"], reason="专辑数", confidence=0.9)
        if agent is gf.sql_generator_agent:
            return SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="统计专辑总数")
        if agent is gf.result_summary_agent:
            return FinalAnswer(answer="共 347 张专辑。", evidence=["n=347"])
        raise AssertionError("不应调用改写 Agent")

    monkeypatch.setattr(gf, "_run_agent", fake_run_agent)
    output = _make_graph().run("总共有多少张专辑？")

    assert output.error is None
    assert output.tables == ["albums"]
    assert output.row_count == 1
    assert output.repair_attempts == 0
    assert output.answer == "共 347 张专辑。"
    assert gf.sql_rewriter_agent not in calls


def test_graph_repairs_invalid_sql(monkeypatch):
    def fake_run_agent(agent, prompt):
        if agent is gf.table_selector_agent:
            return TableSelection(tables=["albums"], reason="", confidence=0.9)
        if agent is gf.sql_generator_agent:
            return SQLDraft(sql="SELECT BadCol FROM albums", explanation="")
        if agent is gf.sql_rewriter_agent:
            return SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="修复列名")
        if agent is gf.result_summary_agent:
            return FinalAnswer(answer="共 347 张专辑。")
        raise AssertionError("unreachable")

    monkeypatch.setattr(gf, "_run_agent", fake_run_agent)
    output = _make_graph().run("总共有多少张专辑？")

    assert output.error is None
    assert output.repair_attempts == 1
    assert output.sql == "SELECT COUNT(*) AS n FROM albums"


def test_graph_cannot_fix_exits_early(monkeypatch):
    def fake_run_agent(agent, prompt):
        if agent is gf.table_selector_agent:
            return TableSelection(tables=["albums"], reason="", confidence=0.9)
        if agent is gf.sql_generator_agent:
            return SQLDraft(sql="SELECT BadCol FROM albums", explanation="")
        if agent is gf.sql_rewriter_agent:
            return SQLDraft(
                sql="", explanation="没有可用的列", cannot_fix=True
            )
        raise AssertionError("不应执行到这里")

    monkeypatch.setattr(gf, "_run_agent", fake_run_agent)
    output = _make_graph().run("总共有多少张专辑？")

    assert "无法回答" in output.answer
    assert output.error is not None


def test_graph_empty_result_skips_summary(monkeypatch):
    summarized = []

    def fake_run_agent(agent, prompt):
        if agent is gf.table_selector_agent:
            return TableSelection(tables=["albums"], reason="", confidence=0.9)
        if agent is gf.sql_generator_agent:
            return SQLDraft(sql="SELECT * FROM albums WHERE 1=0", explanation="")
        if agent is gf.result_summary_agent:
            summarized.append(True)
            return FinalAnswer(answer="不应被调用")
        raise AssertionError("unreachable")

    monkeypatch.setattr(gf, "_run_agent", fake_run_agent)
    output = _make_graph().run("查询不存在的专辑")

    assert output.answer == "未查询到符合条件的数据。"
    assert output.row_count == 0
    assert not summarized  # 空结果不进汇总 Agent


def test_graph_summary_fallback_to_table(monkeypatch):
    def fake_run_agent(agent, prompt):
        if agent is gf.table_selector_agent:
            return TableSelection(tables=["genres"], reason="", confidence=0.9)
        if agent is gf.sql_generator_agent:
            return SQLDraft(sql="SELECT Name FROM genres ORDER BY Name", explanation="")
        if agent is gf.result_summary_agent:
            raise RuntimeError("LLM 调用失败")
        raise AssertionError("unreachable")

    monkeypatch.setattr(gf, "_run_agent", fake_run_agent)
    output = _make_graph().run("列出所有流派")

    assert output.row_count == 25
    assert "查询返回 25 行" in output.answer  # 降级为表格输出
    assert any("降级" in caveat for caveat in output.caveats)
