# -*- coding: utf-8 -*-
"""LangGraph 版 SQL Agent 案例演示。

对几个典型问题跑完整工作流（选表 -> SQL 生成 -> 校验 -> 执行 -> 修复 -> 结果汇总），
把每一步过程和最终结果实时输出到控制台。

演示案例：
    1. 单表聚合：总共有多少张专辑？
    2. 两表 JOIN：美国客户的订单总金额是多少？
    3. 三表 JOIN：总销售额最高的员工叫什么名字？
    4. 超范围问题：今天天气怎么样？（演示澄清/拒绝路径，不会执行查询）

运行方式（在本目录下）：
    python demo.py
"""

from __future__ import annotations

import logging
import sys

# Windows 控制台中文兼容
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from sql_agent_langgraph.graph import SQLAgentGraph

# ============================================================
# 把工作流的 stage=... 阶段日志翻译成可读的中文过程输出
# ============================================================
STAGE_LABELS = {
    "catalog_loading": "【加载数据库目录】",
    "catalog_ready": "【数据库目录就绪】",
    "table_select": "【选表-LLM 决策】",
    "table_select_invalid": "【选表-发现无效选择，反馈重试】",
    "table_selected": "【确定用表】",
    "sql_generate": "【SQL 生成完成】",
    "sql_generated": "【生成 SQL】",
    "validate": "【校验 SQL】",
    "execute": "【执行 SQL】",
    "sql_rewrite_started": "【SQL 自修复-开始】",
    "sql_rewrite_finished": "【SQL 自修复-完成】",
    "sql_rewritten": "【修复后的 SQL】",
    "rewrite_cannot_fix": "【判定无法修复】",
    "repair_exhausted": "【修复次数已用尽】",
    "summarize_started": "【结果汇总-开始】",
    "summarize_finished": "【结果汇总-完成】",
    "summarize skipped": "【跳过汇总】",
    "final": "【最终答案生成】",
    "workflow started": "【工作流启动】",
    "workflow finished": "【工作流结束】",
}


def _prettify(message: str) -> str:
    """把 'stage=xxx key=value' 形式的日志替换为中文标签，其余原样输出。"""
    for key, label in STAGE_LABELS.items():
        prefix = f"stage={key}"
        if message == prefix:
            return label
        if message.startswith(prefix + " "):
            return label + " " + message[len(prefix) + 1 :]
    for key, label in STAGE_LABELS.items():
        if message.startswith(key + " "):
            return label + " " + message[len(key) + 1 :]
    return message


class StageFormatter(logging.Formatter):
    """demo 专用的过程日志格式器。"""

    def format(self, record: logging.LogRecord) -> str:
        return _prettify(record.getMessage())


def configure_demo_logging() -> None:
    """过程日志输出到 stdout（demo 场景下控制台即过程展示）。"""
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(StageFormatter("%(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[handler], force=True)
    # 第三方 HTTP 日志降噪
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)


# ============================================================
# 案例执行
# ============================================================
def run_case(workflow: SQLAgentGraph, index: int, question: str) -> None:
    print()
    print("=" * 62)
    print(f"案例 {index}：{question}")
    print("=" * 62)

    output = workflow.run(question)

    print("-" * 62)
    print("▶ 最终结果")
    print(f"  答案    ：{output.answer}")
    if output.sql:
        print(f"  执行SQL ：{' '.join(output.sql.split())}")
    print(f"  使用表  ：{', '.join(output.tables) if output.tables else '（未选表，未执行查询）'}")
    print(f"  返回行数：{output.row_count}{'（已截断）' if output.truncated else ''}")
    print(f"  修复次数：{output.repair_attempts}")
    for caveat in output.caveats:
        print(f"  注意    ：{caveat}")
    if output.evidence:
        print(f"  证据    ：{'；'.join(output.evidence)}")


def main() -> None:
    configure_demo_logging()
    print("╔" + "═" * 60 + "╗")
    print("║  LangChain SQL Agent 案例演示（chinook 音乐商店数据库）  ║")
    print("╚" + "═" * 60 + "╝")
    print()
    print("工作流：选表 -> SQL 生成 -> 校验(EXPLAIN 只编译) -> 只读执行")
    print("        -> 失败则带报错自修复(≤3次) -> 结果汇总为自然语言")

    # 复用同一个 Workflow：数据库目录（SchemaCatalog）进程内只解析一次
    workflow = SQLAgentGraph()

    cases = [
        "总共有多少张专辑？",                 # 单表聚合
        "美国客户的订单总金额是多少？",         # 两表 JOIN：invoices + customers
        "总销售额最高的员工叫什么名字？",       # 三表 JOIN：invoices + customers + employees
        "今天天气怎么样？",                    # 与数据库无关：应走澄清/拒绝路径
    ]
    for index, question in enumerate(cases, start=1):
        run_case(workflow, index, question)

    print()
    print("全部案例执行完毕。")


if __name__ == "__main__":
    main()
