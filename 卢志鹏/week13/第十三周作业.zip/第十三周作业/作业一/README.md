# 第十三周作业一：SQL Agent 的 LangGraph 重写

> 原实现：`第十二周/作业二/`（**LangChain 1.x** 版：`create_agent` + ToolStrategy 智能体，`workflow.py` 显式 Python 状态机编排）
> 本目录：将编排层完整移植为 **LangGraph 1.x StateGraph**，Agent、数据契约、提示词、防注入、降级策略与第十二周版完全一致。
> 验证环境：langgraph 1.2.9 / langchain 1.3.14 / langchain-openai 1.4.1 / 智谱 GLM（glm-5.3）

## 一、为什么只改编排层

第十二周版已经验证了分层设计：`agents/`（LLM 调用）、`db/`（SchemaCatalog / SQLValidator / SQLExecutor）、`models.py`（Pydantic 契约）与框架无关。本次替换编排框架，**只有 `workflow.py` → `graph.py` 需要重写**，其余文件原样复用（包名改为 `sql_agent_langgraph`）。

## 二、LangGraph 移植对照

| LangChain 版（workflow.py） | LangGraph 版（graph.py） |
|---|---|
| `SQLAgentWorkflow._run()` 里的顺序调用 + for 循环 | `StateGraph` 节点 + 边：`select_tables → generate_sql → validate_sql ⇄ rewrite_sql → execute_sql → summarize` |
| 修复重试：`for repair_index in range(max+1)` Python 循环 | 环形边：`rewrite_sql → validate_sql`，预算由 `state.repair_attempts` 在改写节点内控制（≤3 次改写 = 最多 4 轮校验，语义与原版一致） |
| 预算耗尽 / `cannot_fix` / 需要澄清：`return WorkflowOutput(...)` 提前退出 | 对应节点直接置 `state["output"]`，条件边路由到 `END` |
| 执行异常转校验失败后进重试 | `execute_sql` 节点捕获 `SQLExecutionError` 写回 `validation`，条件边 `execution 未设置 → rewrite_sql` |
| 空结果跳过汇总、汇总失败降级 Markdown 表格 | 原逻辑收进 `summarize` 节点（`row_count==0` 不调 LLM；`_run_agent` 异常降级） |
| `_run_agent(agent, prompt)` 调用接缝 | 保留同名模块级函数，测试继续用 monkeypatch 模拟 LLM |
| 阶段日志 `stage=...`（demo.py 依赖） | 日志消息原样保留，`demo.py` 的过程翻译无需改动 |

图结构（`graph.get_graph().draw_mermaid()` 可导出）：

```
START → select_tables ──(需澄清→END / 通过)→ generate_sql → validate_sql
  validate_sql ──(ok)→ execute_sql ──(成功)→ summarize → END
       ↑ (失败)                        (执行异常)
       └──── rewrite_sql ──(修复后重新校验；预算耗尽/cannot_fix → END)
```

## 三、目录结构

```
作业一/
├── chinook.db                      # 数据库（与第十二周版相同）
├── demo.py                         # 案例演示（LangGraph 版工作流）
├── requirements.txt
├── sql_agent_langgraph/            # 原 sql_agent_langchain
│   ├── config.py                   # 运行配置（模型 glm-5.3 / 智谱端点）
│   ├── models.py                   # Pydantic 数据契约（原样复用）
│   ├── logging_config.py           # 日志配置（原样复用）
│   ├── db/                         # catalog / validator / executor（原样复用）
│   ├── agents/                     # 4 个 create_agent 智能体（原样复用）
│   ├── graph.py                    # ← 移植重点：StateGraph 编排
│   ├── __main__.py                 # CLI 入口
│   └── __init__.py
└── tests/
    └── test_components.py          # 18 个测试（无 LLM，monkeypatch 模拟 Agent）
```

## 四、运行方式

```bash
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

# 端到端（真实 LLM）
python -m sql_agent_langgraph "总共有多少张专辑？"
python demo.py                      # 4 个案例：单表聚合 / 两表 JOIN / 三表 JOIN / 超范围问题

# 测试（mock LLM，无需 API key）
pytest tests/ -q

# 配置：环境变量可覆盖
#   ZHIPU_API_KEY / OPENAI_API_KEY   API key
#   SQL_AGENT_MODEL                  主模型（默认 glm-5.3）
#   SQL_AGENT_SUMMARY_MODEL          汇总模型（默认 glm-5.3）
#   SQL_AGENT_DB                     数据库路径（默认本目录 chinook.db）
#   SQL_AGENT_LOG_LEVEL              日志级别
```

对外接口与第十二周版兼容：`SQLAgentGraph().run(question) -> WorkflowOutput`；
新增 `run_with_state(question)` 返回完整图状态（含 `execution` 行数据），供第十三周作业二的 Web 界面展示结果表格使用。

## 五、验证记录（2026-11-05，智谱 glm-5.3）

- `pytest tests/ -q`：**18 passed** —— 13 个组件测试（安全门禁、EXPLAIN、只读执行、外键连通性）+ 5 个图编排路径测试（正常 / 修复一次 / cannot_fix 提前退出 / 空结果跳过汇总 / 汇总降级表格）；
- CLI「总共有多少张专辑？」：选表 albums → `SELECT COUNT(*)` → **347** ✅；
- CLI「美国客户的订单总金额是多少？」：自动选表 customers+invoices → 显式 JOIN → `ROUND(SUM(Total),2) WHERE Country='USA'` = **523.06** ✅（与 chinook 已知数据一致，与第十二周版结果相同）。
