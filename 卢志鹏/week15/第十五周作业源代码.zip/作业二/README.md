# 第十四周作业二：Docker 打包 openai-agents 版后端

将**作业一的 openai-agents 版代码**（`config.py` + `sentiment_openai_agents.py`，
与作业一保持同步的副本）连同精简版 FastAPI 后端打包成 Docker 镜像，部署在云服务器上。

- 镜像内只有 openai-agents 实现（langgraph 代码不进镜像，请求 langgraph 返回 400 并说明）
- **密钥安全**：`.env` 被 `.dockerignore` 排除，绝不打进镜像；运行时用 `--env-file` 注入容器
- `.env` 已检查过无带引号的值，`docker run --env-file` 可直接使用

## 文件结构

```
作业二/
├── Dockerfile                  # python:3.13-slim，层缓存友好的两段 COPY
├── .dockerignore               # 排除 .env / __pycache__ 等
├── backend_openai.py           # 镜像内后端（/chat /health，与作业一同接口）
├── config.py                   # 与作业一同步的副本
├── sentiment_openai_agents.py  # 与作业一同步的副本
├── requirements.txt            # 镜像依赖（仅 openai-agents 版所需）
└── README.md
```

## 云服务器执行步骤

### ① 本机：上传代码和 .env（在 `第十四周作业/` 目录下执行）

```bash
scp -r 作业二 <user>@<服务器IP>:~/sentiment-backend/
scp .env <user>@<服务器IP>:~/sentiment-backend/.env
```

> `.env` 只放在服务器目录里供运行时读取，`.dockerignore` 保证它不进入镜像。

### ② 云服务器：构建镜像

```bash
ssh <user>@<服务器IP>
cd ~/sentiment-backend
docker build -t sentiment-backend:1.0 .
```

#### 若报 `registry-1.docker.io ... i/o timeout`（国内服务器常见）

基础镜像被墙拉不下来，任选其一：

**方式 A：Dockerfile 已内置镜像站开关，直接用（最快，免改系统配置）**

```bash
docker build \
  --build-arg BASE_IMAGE=docker.m.daocloud.io/library/python:3.13-slim \
  -t sentiment-backend:1.0 .
# 若 daocloud 也超时，换：docker.1ms.run/library/python:3.13-slim
```

**方式 B：给 Docker 配镜像加速器（一次配好，之后所有镜像都受益）**

编辑 `/etc/docker/daemon.json`（不存在就新建）：

```json
{
  "registry-mirrors": [
    "https://docker.m.daocloud.io",
    "https://docker.1ms.run"
  ]
}
```

```bash
sudo systemctl daemon-reload
sudo systemctl restart docker
docker info | grep -A3 "Registry Mirrors"   # 确认生效
docker pull python:3.13-slim                 # 先单独拉基础镜像验证
```

拉取成功后，回到普通构建命令 `docker build -t sentiment-backend:1.0 .` 即可。
（阿里云 ECS 更稳的做法：容器镜像服务控制台 → 镜像加速器，拿专属加速地址替换上面 mirrors）

#### 海外服务器（用官方 PyPI 源）

```bash
docker build --build-arg PIP_INDEX_URL=https://pypi.org/simple -t sentiment-backend:1.0 .
```

### ③ 云服务器：运行容器（密钥此时注入）

```bash
docker run -d --name sentiment-backend -p 8000:8000 --env-file .env sentiment-backend:1.0
```

### ④ 云服务器：验证

```bash
curl http://127.0.0.1:8000/health
# {"status":"ok","model":"glm-5.3","framework":"openai-agents"}

curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"今天面试通过啦！"}'

docker logs -f sentiment-backend      # 看运行日志
```

确认密钥没有被打进镜像（应显示 "0"，即镜像文件里没有 .env）：

```bash
docker run --rm --entrypoint sh sentiment-backend:1.0 -c 'ls -a /app | grep -c "^\.env$" || echo 0'
```

### ⑤ 本机前端连云后端

云服务器安全组放行 **TCP 8000**，然后本机：

```bash
cd 第十四周作业/作业一
set BACKEND_URL=http://<服务器IP>:8000
streamlit run app.py
```

前端切到 **openai-agents** 即走云上容器；切 langgraph 会收到后端 400 提示（镜像未打包该版本）。

## 验证记录（2026-11-19，本地以 uvicorn 运行镜像同款代码）

- `GET /health` → ok，framework=openai-agents；
- `POST /chat` 正面（升职加薪→🟢 鼓励）/ 负面（被误解→🔴 排解）均正确；
- `framework=langgraph` → 400 并说明仅打包 openai-agents 版；
- `docker build` 在云服务器执行（本机未装 Docker），Dockerfile 语法与依赖已按上述本地运行结果核对。
