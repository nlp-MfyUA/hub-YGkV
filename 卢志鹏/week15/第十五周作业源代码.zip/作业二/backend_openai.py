"""第十四周作业二：Docker 镜像内的后端进程（openai-agents 版）。

与作业一的 backend.py 同一套 /chat 接口，但镜像只打包 openai-agents 实现
（langgraph 相关代码不进镜像）；请求 langgraph 框架时返回 400 并说明。

容器内启动（Dockerfile CMD 已包含）：
    uvicorn backend_openai:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import time
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

import config
from sentiment_openai_agents import run_openai_agents

app = FastAPI(title="情感陪伴服务（openai-agents · Docker 版）")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000, description="用户输入")
    framework: Literal["langgraph", "openai-agents"] = "openai-agents"


class ChatResponse(BaseModel):
    framework: str
    sentiment: str
    reason: str
    reply: str
    elapsed: float


@app.get("/health")
def health() -> dict:
    """健康检查：不返回任何敏感信息（无 key）。"""
    return {"status": "ok", "model": config.TEXT_LLM, "framework": "openai-agents"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    if req.framework != "openai-agents":
        raise HTTPException(
            status_code=400,
            detail="本镜像仅打包 openai-agents 版本；langgraph 版请在本地运行作业一的后端",
        )
    started = time.perf_counter()
    try:
        result = run_openai_agents(req.message.strip())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - 上游 LLM/网络异常统一转 502
        raise HTTPException(status_code=502, detail=f"处理失败：{exc}") from exc
    return ChatResponse(
        framework="openai-agents",
        sentiment=result["label"],
        reason=result["reason"],
        reply=result["reply"],
        elapsed=round(time.perf_counter() - started, 2),
    )
