"""前端进程：Streamlit 对话界面，可切换 langgraph / openai-agents 后端实现。

先启动后端（本目录下）：
    uvicorn backend:app --host 0.0.0.0 --port 8000
再启动前端：
    streamlit run app.py
连云服务器部署的后端（第十四周作业二）：
    set BACKEND_URL=http://<服务器IP>:8000 && streamlit run app.py
"""

from __future__ import annotations

import os

import requests
import streamlit as st

BACKEND_URL = os.environ.get("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.set_page_config(page_title="情感陪伴助手", page_icon="💛", layout="wide")

SENTIMENT_BADGE = {"正面": "🟢 正面", "负面": "🔴 负面", "中性": "🟡 中性"}


def render_assistant(message: dict) -> None:
    st.markdown(message["reply"])
    with st.expander("识别详情"):
        st.markdown(
            f"**情感倾向：**{SENTIMENT_BADGE.get(message['sentiment'], message['sentiment'])}"
            f"　·　**依据：**{message['reason'] or '—'}"
            f"　·　**框架：**`{message['framework']}`"
            f"　·　**耗时：**{message['elapsed']}s"
        )


def answer(message: str, framework: str) -> None:
    st.session_state.messages.append({"role": "user", "content": message})
    with st.chat_message("user"):
        st.markdown(message)

    with st.chat_message("assistant"):
        with st.spinner(f"[{framework}] 进程1 情感识别 → 进程2 回应…"):
            try:
                resp = requests.post(
                    f"{BACKEND_URL}/chat",
                    json={"message": message, "framework": framework},
                    timeout=120,
                )
                resp.raise_for_status()
                data = resp.json()
            except requests.HTTPError as exc:
                detail = ""
                try:
                    detail = resp.json().get("detail", "")
                except Exception:  # noqa: BLE001
                    pass
                st.error(f"后端返回错误（{exc.response.status_code}）：{detail}")
                return
            except requests.RequestException as exc:
                st.error(f"无法连接后端 {BACKEND_URL}：{exc}")
                st.info("请先在本目录启动后端：uvicorn backend:app --port 8000")
                return
        record = {
            "role": "assistant",
            "reply": data["reply"],
            "sentiment": data["sentiment"],
            "reason": data["reason"],
            "framework": data["framework"],
            "elapsed": data["elapsed"],
        }
        st.session_state.messages.append(record)
        render_assistant(record)


# ---------- 侧边栏 ----------
st.sidebar.title("💛 情感陪伴助手")
st.sidebar.caption("进程1 情感识别 → 进程2 鼓励/排解")
framework = st.sidebar.radio(
    "编排框架",
    ["langgraph", "openai-agents"],
    format_func=lambda x: f"LangGraph（{x}）" if x == "langgraph" else f"OpenAI Agents（{x}）",
    captions=["StateGraph：节点 + 条件边", "Agent + Runner 两次调用串联"],
)
st.sidebar.divider()
st.sidebar.markdown(f"**后端地址：**`{BACKEND_URL}`")
try:
    health = requests.get(f"{BACKEND_URL}/health", timeout=5).json()
    st.sidebar.success(f"后端在线：模型 `{health['model']}`")
except requests.RequestException:
    st.sidebar.error("后端不在线（请先启动 backend）")

# ---------- 主区域 ----------
st.title("💛 情感陪伴助手")
st.caption("说说最近的事：开心的事会收到鼓励，低落的事会被倾听和排解")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        if message["role"] == "user":
            st.markdown(message["content"])
        else:
            render_assistant(message)

question = st.chat_input("输入你想说的话，例如：今天面试通过啦！")
if question:
    answer(question, framework)
