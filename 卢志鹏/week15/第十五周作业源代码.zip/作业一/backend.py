"""后端进程：FastAPI 接受前端输入，按 framework 选择实现并串联进程1 → 进程2。

启动（在本目录下）：
    uvicorn backend:app --host 0.0.0.0 --port 8000
    # 或 python backend.py
"""

from __future__ import annotations

import time
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

import config
from sentiment_langgraph import run_langgraph
from sentiment_openai_agents import run_openai_agents

app = FastAPI(title="情感陪伴服务", description="进程1 情感识别 + 进程2 鼓励/排解")

RUNNERS = {"langgraph": run_langgraph, "openai-agents": run_openai_agents}


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000, description="用户输入")
    framework: Literal["langgraph", "openai-agents"] = "langgraph"


class ChatResponse(BaseModel):
    framework: str
    sentiment: str
    reason: str
    reply: str
    elapsed: float


@app.get("/health")
def health() -> dict:
    """健康检查：不返回任何敏感信息（无 key）。"""
    return {
        "status": "ok",
        "model": config.TEXT_LLM,
        "frameworks": list(RUNNERS),
    }


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    started = time.perf_counter()
    try:
        result = RUNNERS[req.framework](req.message.strip())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - 上游 LLM/网络异常统一转 502
        raise HTTPException(status_code=502, detail=f"处理失败：{exc}") from exc
    return ChatResponse(
        framework=req.framework,
        sentiment=result["label"],
        reason=result["reason"],
        reply=result["reply"],
        elapsed=round(time.perf_counter() - started, 2),
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
