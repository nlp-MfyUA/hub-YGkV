# 第十四周作业一：双框架情感陪伴应用（langgraph + openai-agents）

流程（三个进程）：

```
前端进程（app.py, Streamlit）
    │  POST /chat {message, framework}
    ▼
后端进程（backend.py, FastAPI，端口 8000）──── 按前端选择分发
    ├── langgraph：sentiment_langgraph.py
    │       StateGraph：analyze_sentiment（进程1 情感识别）
    │           ├── 正面 → encourage（进程2 鼓励）
    │           └── 负面/中性 → comfort（进程2 排解）
    └── openai-agents：sentiment_openai_agents.py
            Agent①"情感识别师"（output_type 结构化）
                ├── 正面 → Agent②"鼓励师"
                └── 负面/中性 → Agent②"倾听排解师"
```

- **进程1**：情感识别（正面/负面/中性 + 15 字依据，temperature=0）
- **进程2**：正面 → 真诚鼓励并追问细节；负面/中性 → 共情排解 + 一个具体小行动（中性按"温和排解"处理）
- 两个框架共用同一套提示词与分支规则，只对比编排方式的差异
- 大模型配置读 `../.env`（`BASE_URL` / `TEXT_LLM` / `API_KEY`），**key 不写入任何代码**

## 文件结构

```
作业一/
├── app.py                     # 前端进程：Streamlit，单选切换框架
├── backend.py                 # 后端进程：FastAPI，串联进程1→进程2
├── sentiment_langgraph.py     # LangGraph 版实现（节点 + 条件边）
├── sentiment_openai_agents.py # openai-agents 版实现（Agent + Runner）
├── config.py                  # .env / 环境变量加载（共享）
├── requirements.txt           # 用到的依赖
└── README.md
```

## 运行（ai-learn 环境）

```bash
conda activate ai-learn
cd 第十四周作业/作业一

# 1) 先启动后端
uvicorn backend:app --host 0.0.0.0 --port 8000

# 2) 再启动前端（另开终端）
streamlit run app.py
```

浏览器打开 `http://localhost:8501`，侧边栏切换 LangGraph / OpenAI Agents，输入内容对话。
连云服务器后端（作业二部署）：`set BACKEND_URL=http://<服务器IP>:8000` 后再 `streamlit run app.py`。

单测某个框架：`python sentiment_langgraph.py` / `python sentiment_openai_agents.py`（内置冒烟用例）。

## 接口

- `GET /health` → `{"status":"ok","model":"glm-5.3","frameworks":[...]}`（不含 key）
- `POST /chat` `{"message": "...", "framework": "langgraph" | "openai-agents"}`
  → `{"framework","sentiment","reason","reply","elapsed"}`

## 验证记录（2026-11-19，智谱 glm-5.3）

- 双管线直连冒烟：正面/负面各 1 条，分支与回复风格均正确；
- 后端 HTTP：2 框架 × 正负面 4 条全过（9~13 秒/条，含两次 LLM 调用）；
- 前端 AppTest 连真实后端：默认 langgraph 对话、切换 openai-agents 再对话，识别详情（情感/依据/框架/耗时）展示正确。

> 备注：openai-agents 的 `set_default_openai_client` 必须传 `AsyncOpenAI`（SDK 内部 await），
> 且兼容端点需 `set_default_openai_api("chat_completions")`。
