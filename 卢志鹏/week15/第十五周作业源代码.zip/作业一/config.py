"""共享配置：从 .env / 环境变量读取大模型配置。

约定（与 第十四周作业/.env 的键名一致）：
    BASE_URL   OpenAI 兼容端点
    TEXT_LLM   文本模型（本作业使用）
    MULTI_LLM  多模态模型（本作业未用到，预留）
    API_KEY    密钥 —— 只存在于 .env / 环境变量，绝不写入代码或镜像
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv


def _load_env() -> None:
    """本地开发时加载 第十四周作业/.env；Docker 里由 --env-file 注入环境变量，无需文件。"""
    candidates = (
        Path.cwd() / ".env",                                  # 在 作业一/ 或 作业二/ 下启动
        Path(__file__).resolve().parent.parent / ".env",      # 本模块位于 作业一/ 时取上级
        Path(__file__).resolve().parent / ".env",             # .env 与本模块同目录
    )
    for candidate in candidates:
        if candidate.is_file():
            load_dotenv(candidate, override=False)
            break


_load_env()

BASE_URL = os.environ.get("BASE_URL", "")
TEXT_LLM = os.environ.get("TEXT_LLM", "")
MULTI_LLM = os.environ.get("MULTI_LLM", "")
API_KEY = os.environ.get("API_KEY", "")


def assert_ready() -> None:
    """启动/调用前检查必要配置，避免 key 泄露到报错信息里。"""
    missing = [
        name
        for name, value in (("BASE_URL", BASE_URL), ("TEXT_LLM", TEXT_LLM), ("API_KEY", API_KEY))
        if not value
    ]
    if missing:
        raise RuntimeError(
            f"缺少大模型配置项：{', '.join(missing)}（请检查 第十四周作业/.env 或环境变量）"
        )
