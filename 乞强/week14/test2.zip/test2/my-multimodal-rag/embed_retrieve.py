"""多模态向量化与检索。

- bge-small-zh-v1.5：中文文本向量（主要的文本检索依据，对应参考实现的 text_vector）
- chinese-clip-vit-base-patch16：图文共享向量空间，用于跨模态检索
   （对应参考实现的 clip_text_vector / clip_image_vector：文本亦可检索图片）
- 向量库：本地 SQLite + 归一化余弦相似度，替代参考中的 Milvus（自包含、零外部依赖）
"""
import json
import os
import numpy as np
import torch

from config import BGE_MODEL_NAME, CLIP_MODEL_NAME
import db as dblib

_torch_device = "cuda" if torch.cuda.is_available() else "cpu"

_bge_model = None
_bge_tokenizer = None
_clip_model = None
_clip_processor = None


def _load_bge():
    global _bge_model, _bge_tokenizer
    if _bge_model is None:
        from transformers import AutoModel, AutoTokenizer
        if not os.path.isdir(BGE_MODEL_NAME):
            raise FileNotFoundError(
                f"本地模型目录不存在: {BGE_MODEL_NAME}（请先按 README 下载）")
        _bge_tokenizer = AutoTokenizer.from_pretrained(BGE_MODEL_NAME)
        _bge_model = AutoModel.from_pretrained(BGE_MODEL_NAME).to(_torch_device).eval()
    return _bge_model, _bge_tokenizer


def _load_clip():
    global _clip_model, _clip_processor
    if _clip_model is None:
        from transformers import AutoModel, AutoProcessor
        if not os.path.isdir(CLIP_MODEL_NAME):
            raise FileNotFoundError(
                f"本地模型目录不存在: {CLIP_MODEL_NAME}（请先按 README 下载）")
        _clip_model = AutoModel.from_pretrained(
            CLIP_MODEL_NAME, trust_remote_code=False).to(_torch_device).eval()
        _clip_processor = AutoProcessor.from_pretrained(CLIP_MODEL_NAME)
    return _clip_model, _clip_processor


def _mean_pool(last_hidden, attention_mask):
    mask = attention_mask.unsqueeze(-1).float()
    return (last_hidden * mask).sum(1) / mask.sum(1).clamp(min=1e-9)


@torch.no_grad()
def bge_encode(texts):
    """bge 文本向量，[CLS] 池化 + L2 归一化。"""
    q_instruction = "为这个句子生成表示以用于检索相关文章："
    model, tok = _load_bge()
    if isinstance(texts, str):
        texts = [texts]
    qs = [q_instruction + t for t in texts]
    inputs = tok(qs, padding=True, truncation=True, max_length=512,
                 return_tensors="pt").to(_torch_device)
    out = model(**inputs).last_hidden_state
    vec = _mean_pool(out, inputs["attention_mask"])
    vec = torch.nn.functional.normalize(vec, p=2, dim=1)
    return vec.float().cpu().numpy()


@torch.no_grad()
def clip_encode_text(texts):
    """Chinese-CLIP 文本向量，L2 归一化。"""
    model, proc = _load_clip()
    if isinstance(texts, str):
        texts = [texts]
    inputs = proc(text=texts, padding=True, truncation=True, max_length=77,
                  return_tensors="pt").to(_torch_device)
    # ChineseCLIPModel 可用 get_text_features
    if hasattr(model, "get_text_features"):
        vec = model.get_text_features(input_ids=inputs["input_ids"],
                                      attention_mask=inputs["attention_mask"])
    else:
        vec = model.text_model(**inputs).pooler_output
    vec = torch.nn.functional.normalize(vec, p=2, dim=1)
    return vec.float().cpu().numpy()


@torch.no_grad()
def clip_encode_image(image_path):
    """Chinese-CLIP 图片向量，L2 归一化；读取失败返回全 0 向量。"""
    from PIL import Image
    model, proc = _load_clip()
    dim = 512  # chinese-clip-vit-base-patch16 text/vision 投影维度
    if not os.path.exists(image_path):
        return np.zeros((1, dim))
    try:
        img = Image.open(image_path).convert("RGB")
        inputs = proc(images=img, return_tensors="pt").to(_torch_device)
        if hasattr(model, "get_image_features"):
            vec = model.get_image_features(pixel_values=inputs["pixel_values"])
        else:
            vec = model.vision_model(**inputs).pooler_output
        vec = torch.nn.functional.normalize(vec, p=2, dim=1)
        return vec.float().cpu().numpy()
    except Exception as e:  # noqa
        print(f"[embed] 图片编码失败 {image_path}: {e}")
        return np.zeros((1, dim))


# ---------- 文本切块（与参考实现一致） ----------
def split_text2chunks(lines, chunk_size=256):
    chunks = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line == "# References":
            continue
        if len(line) > 2 and line[0] == "[" and line[1].isdigit():
            continue
        if chunks and len(chunks[-1]) <= chunk_size:
            chunks[-1] += "\n" + line
        else:
            chunks.append(line)
    return chunks


def _extract_image_path_in_chunk(chunk, processed_root):
    """取 chunk 内第一张 markdown 图片的本地路径。"""
    for line in chunk.split("\n"):
        if line.startswith("![") and "](" in line:
            rel = line.split("](", 1)[1].split(")", 1)[0]
            if rel.startswith("images/"):
                return os.path.join(processed_root, rel)
            if os.path.isabs(rel) and os.path.exists(rel):
                return rel
    return None


def embed_chunks(chunks, file_id, file_name, file_path, processed_root):
    """对文本 chunk 编码并写库；含图 chunk 同时编码该图 CLIP 向量。"""
    if not chunks:
        return
    bge = bge_encode(chunks)
    tclip = clip_encode_text(chunks)
    rows = []
    for i, c in enumerate(chunks):
        img_path = _extract_image_path_in_chunk(c, processed_root)
        iclip = clip_encode_image(img_path) if img_path else np.zeros((1, tclip.shape[1]))
        rows.append({
            "file_id": file_id,
            "file_name": file_name,
            "chunk": c,
            "bge_vector": json.dumps(np.asarray(bge[i]).tolist()),
            "text_clip_vector": json.dumps(np.asarray(tclip[i]).tolist()),
            "image_clip_vector": json.dumps(np.asarray(iclip[0]).tolist()),
            "image_path": img_path,
            "page": 0,
        })
    dblib.add_chunks(rows)
    print(f"[embed] 写入 {len(rows)} 个片段 (file_id={file_id})")


# ---------- 检索 ----------
def _load_all_rows():
    sess = dblib.Session()
    try:
        return sess.query(dblib.TextChunk).all()
    finally:
        sess.close()


def retrieve_text(query, top_k=6):
    """bge 文本检索：返回最相关文本 chunk。"""
    q = bge_encode(query)[0]
    rows = _load_all_rows()
    if not rows:
        return []
    mat = np.array([np.array(json.loads(r.bge_vector)) for r in rows])
    scores = mat @ q
    order = np.argsort(-scores)[:top_k]
    return [{**rows[i].to_dict(), "score": float(scores[i])} for i in order]


def retrieve_images(query, top_k=4):
    """跨模态检索：CLIP 文本向量 → 图片向量。"""
    q = clip_encode_text(query)[0]
    rows = _load_all_rows()
    cands = [r for r in rows if r.image_path and os.path.exists(r.image_path)]
    if not cands:
        return []
    mat = np.array([np.array(json.loads(r.image_clip_vector)) for r in cands])
    scores = mat @ q
    order = np.argsort(-scores)[:top_k]
    return [{**cands[i].to_dict(), "score": float(scores[i])} for i in order]


def hybrid_retrieve(query, top_k_text=6, top_k_image=4):
    """文本 + 图片联合检索，按 id 去重合并。"""
    merged, seen = [], set()
    for it in retrieve_text(query, top_k_text) + retrieve_images(query, top_k_image):
        if it["id"] not in seen:
            seen.add(it["id"])
            merged.append(it)
    return merged
