"""SQLite 元信息存储：文件解析状态 + 向量片段 + 图片索引。"""
import os
import threading
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Float, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker

from config import DB_PATH

Base = declarative_base()

engine = create_engine(f"sqlite:///{DB_PATH}", echo=False)
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)


class FileRecord(Base):
    """上传的原始 PDF 文件及其解析状态（功能2 的状态流转依据）。"""
    __tablename__ = "file_records"

    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)      # 原始文件名（含后缀）
    filepath = Column(String(1000), nullable=False)     # 本地存储路径
    filestate = Column(String(20), nullable=False, default="待解析")  # 待解析/解析中/解析完成/解析失败
    page_count = Column(Integer, default=0)             # mineru 解析出的页数
    error_msg = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now)

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "filepath": self.filepath,
            "filestate": self.filestate,
            "page_count": self.page_count,
            "error_msg": self.error_msg,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M:%S") if self.created_at else None,
        }


class TextChunk(Base):
    """文本/图片片段（含文本向量与图片向量），用于多模态检索。"""
    __tablename__ = "text_chunks"

    id = Column(Integer, primary_key=True)
    file_id = Column(Integer, nullable=False)
    file_name = Column(String(255))
    chunk = Column(Text, nullable=False)                # 文本内容（含 markdown 图片语法时表示该段有图）
    bge_vector = Column(Text, nullable=False)           # bge 文本向量 (json 字符串)
    text_clip_vector = Column(Text, nullable=False)     # CLIP 文本向量
    image_clip_vector = Column(Text, nullable=False)    # CLIP 图片向量（无图时为全 0）
    image_path = Column(String(1000), nullable=True)    # 若该 chunk 内有一张图，记录图片本地路径
    page = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)

    def to_dict(self):
        return {
            "id": self.id, "file_id": self.file_id, "file_name": self.file_name,
            "chunk": self.chunk, "image_path": self.image_path, "page": self.page,
        }


_db_lock = threading.Lock()


def get_session():
    return Session()


def add_file(filename, filepath, state="待解析"):
    rec = FileRecord(filename=filename, filepath=filepath, filestate=state)
    with _db_lock:
        sess = Session()
        try:
            sess.add(rec)
            sess.commit()
            sess.refresh(rec)
            return rec.id
        finally:
            sess.close()


def update_file_state(file_id, state, page_count=None, error_msg=None):
    with _db_lock:
        sess = Session()
        try:
            rec = sess.query(FileRecord).filter(FileRecord.id == file_id).first()
            if rec:
                rec.filestate = state
                if page_count is not None:
                    rec.page_count = page_count
                if error_msg is not None:
                    rec.error_msg = error_msg
                sess.commit()
        finally:
            sess.close()


def get_file(file_id):
    sess = Session()
    try:
        rec = sess.query(FileRecord).filter(FileRecord.id == file_id).first()
        return rec
    finally:
        sess.close()


def list_files():
    sess = Session()
    try:
        return [r.to_dict() for r in sess.query(FileRecord).order_by(FileRecord.id).all()]
    finally:
        sess.close()


def delete_file(file_id):
    """删除文件记录及其向量片段，并返回本地文件路径以便清理。"""
    rec = get_file(file_id)
    with _db_lock:
        sess = Session()
        try:
            sess.query(TextChunk).filter(TextChunk.file_id == file_id).delete()
            target = sess.query(FileRecord).filter(FileRecord.id == file_id).first()
            if target:
                sess.delete(target)
            sess.commit()
            return rec.filepath if rec else None
        finally:
            sess.close()


def add_chunks(chunks):
    """批量写入切片（chunk 需为 dict 已含所有字段）。"""
    with _db_lock:
        sess = Session()
        try:
            for c in chunks:
                sess.add(TextChunk(**c))
            sess.commit()
        finally:
            sess.close()
