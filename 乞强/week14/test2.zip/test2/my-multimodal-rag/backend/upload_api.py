"""后端 API（功能1）：接收前端上传的多 PDF，存盘后经 Kafka 投递到解析 worker。

接口：
  POST /api/upload           — 一次上传多个 PDF；返回每个文件的 id 与状态（待解析）
  GET  /api/files            — 文件列表及解析状态（功能2 前端轮询依据）
  GET  /api/files/{id}/status— 单个文件解析状态
  DELETE /api/files/{id}     — 删除文件及其向量数据

走 Kafka 链路：文件落盘 → 写 FileRecord(待解析) → 发送到 pdf-parse-tasks topic
由独立的 offline worker 消费并解析（生产者/消费者解耦，对应参考实现）。
"""
import os
import sys
import uuid
import json
from pathlib import Path

import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from kafka import KafkaProducer

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))

import config
import db as dblib

app = FastAPI(title="多模态 RAG 上传后端")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Kafka 生产者（延迟初始化）
_producer = None


def get_producer():
    global _producer
    if _producer is None:
        _producer = KafkaProducer(
            bootstrap_servers=config.KAFKA_BOOTSTRAP,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        )
    return _producer


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/upload")
async def upload_pdfs(files: list[UploadFile] = File(...)):
    """接收多个 PDF，逐文件保存并投递 Kafka 解析任务。"""
    config.UPLOAD_DIR  # ensure dir
    os.makedirs(config.UPLOAD_DIR, exist_ok=True)
    results = []
    for f in files:
        if not f.filename:
            continue
        ext = os.path.splitext(f.filename)[1].lower()
        if ext != ".pdf":
            results.append({"filename": f.filename, "error": f"仅支持 PDF，收到 '{ext}'"})
            continue
        raw = await f.read()
        if not raw:
            results.append({"filename": f.filename, "error": "空文件"})
            continue
        save_name = str(uuid.uuid4()) + ".pdf"
        save_path = os.path.join(config.UPLOAD_DIR, save_name)
        with open(save_path, "wb") as out:
            out.write(raw)
        file_id = dblib.add_file(f.filename, save_path, config.STATUS_PENDING)
        try:
            get_producer().send(
                config.KAFKA_TOPIC_PARSE,
                value={
                    "file_name": f.filename,
                    "file_path": save_path,
                    "id": file_id,
                },
            )
            get_producer().flush()
        except Exception as e:  # noqa
            dblib.update_file_state(file_id, config.STATUS_FAILED, error_msg=f"Kafka 投递失败: {e}")
            results.append({"id": file_id, "filename": f.filename, "filestate": config.STATUS_FAILED, "error": str(e)})
            continue
        results.append({"id": file_id, "filename": f.filename, "filestate": config.STATUS_PENDING})
    return {"results": results}


@app.get("/api/files")
def list_files():
    return {"files": dblib.list_files()}


@app.get("/api/files/{file_id}/status")
def file_status(file_id: int):
    rec = dblib.get_file(file_id)
    if rec is None:
        raise HTTPException(404, "文件不存在")
    return rec.to_dict()


@app.delete("/api/files/{file_id}")
def delete_file(file_id: int):
    path = dblib.delete_file(file_id)
    if path and os.path.exists(path):
        os.remove(path)
    return {"ok": True}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
