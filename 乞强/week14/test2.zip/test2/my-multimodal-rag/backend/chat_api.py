"""聊天后端（功能3 — 多模态问答）。

接口：
  POST /api/chat            — 文本提问（可选附带一张用户图片，图+问一起送 LLM）
  GET  /api/images/{path}   — 提供解析产物图片的访问（图文混排渲染用）

流程：
  1. 提问 embedding（bge 文本向量 + CLIP 文本向量）
  2. 多模态检索：bge 文本检索 + CLIP 跨模态图片检索（对应参考实现的检索逻辑）
  3. 组装消息：检索到的文本 + 图片 URL，若用户附带了图片则一并放入（图问同送）
  4. 调用本地 Qwen3-VL（OpenAI 兼容，http://127.0.0.1:8001/v1）
  5. 返回 markdown 答案，其中的图片链接由前端渲染为图文混排
"""
import os
import sys
from pathlib import Path

import uvicorn
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))

import config
import db as dblib
from embed_retrieve import hybrid_retrieve

app = FastAPI(title="多模态 RAG 问答后端")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)

from fastapi.responses import HTMLResponse

_FRONTEND = os.path.join(BASE.parent, "frontend", "index.html")


@app.get("/", response_class=HTMLResponse)
def index():
    if os.path.exists(_FRONTEND):
        return open(_FRONTEND, encoding="utf-8").read()
    return "<h1>多模态 RAG 问答后端</h1><p>前端页面缺失</p>"

from openai import OpenAI

_qwen = OpenAI(api_key="unused", base_url=config.LLM_BASE_URL)


class ChatRequest(BaseModel):
    question: str


@app.get("/api/images/{image_path:path}")
def get_image(image_path: str):
    """提供解析产物图片访问（前端图片渲染）。路径相对 processed/ 目录。"""
    base = os.path.join(config.PROCESSED_DIR, image_path)
    if not os.path.isfile(base):
        # 兼容：直接以文件名查找（mineru 输出 images/xxx.jpg 保留相对结构）
        found = None
        for root, _, files in os.walk(config.PROCESSED_DIR):
            if os.path.basename(image_path) in files:
                found = os.path.join(root, os.path.basename(image_path))
                break
        if not found:
            raise HTTPException(404, "图片不存在")
        base = found
    return FileResponse(base)


@app.post("/api/chat")
async def chat(
    question: str = Form(...),
    image: UploadFile | None = File(None),
):
    """多模态问答：文字提问（可选附图）→ 检索 → 图问同送本地 Qwen3-VL。"""
    q = question.strip()
    if not q:
        raise HTTPException(400, "问题不能为空")

    # 1. 检索（文本 + 图片）
    hits = hybrid_retrieve(q, config.TOP_K_TEXT, config.TOP_K_IMAGE)

    # 2. 组装检索资料（含被引用图片的 URL）。图片路径以相对 processed 目录提供。
    related_parts = []
    image_inputs = []   # 送给 LLM 的图片（检索出的图片）
    for h in hits:
        chunk = h["chunk"].replace("images/", f"/api/images/{h['file_name'].rsplit('.',1)[0]}/images/")
        related_parts.append(chunk)
        if h.get("image_path") and os.path.exists(h["image_path"]):
            rel = "/api/images/" + os.path.relpath(h["image_path"], config.PROCESSED_DIR)
            image_inputs.append(rel)
    related = "\n\n".join(related_parts)

    # 用户附带的图片
    user_image_rel = None
    if image is not None and image.filename:
        img_bytes = await image.read()
        ext = os.path.splitext(image.filename)[1].lower() or ".jpg"
        img_name = f"u_{hash(q)%100000000}{ext}"
        img_dir = os.path.join(config.PROCESSED_DIR, "_user")
        os.makedirs(img_dir, exist_ok=True)
        img_path = os.path.join(img_dir, img_name)
        with open(img_path, "wb") as f:
            f.write(img_bytes)
        user_image_rel = "/api/images/_user/" + img_name

    # 3. 调用本地 Qwen3-VL
    content = [_build_content(q, related)]
    for img in image_inputs:
        content.append({"type": "image_url", "image_url": {"url": f"http://127.0.0.1:8001{img}"}})
    if user_image_rel:
        content.append({"type": "image_url", "image_url": {"url": f"http://127.0.0.1:8001{user_image_rel}"}})

    try:
        resp = _qwen.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {"role": "system", "content": "你是多模态问答助手，基于资料回答，图文混合输出，若引用图片请在合适位置输出其链接（保持原链接不变）。"},
                {"role": "user", "content": content},
            ],
            max_tokens=2048,
        )
        answer = resp.choices[0].message.content
    except Exception as e:  # noqa
        return JSONResponse(status_code=502, content={"error": f"LLM 调用失败: {e}"})

    return {
        "answer": answer,
        "retrieved": [h.to_dict() for h in hits],
        "image_inputs": image_inputs,
        "user_image": user_image_rel,
    }


def _build_content(q, related):
    return {
        "type": "text",
        "text": (
            f"请基于以下相关资料，精简、有逻辑地回答用户问题。\n"
            f"回答要求：\n"
            f"- 客观基于资料回答。\n"
            f"- 若资料中包含图片链接，请单独一行输出图片链接，保留原路径不变，放在相关内容附近。\n\n"
            f"用户问题：{q}\n\n"
            f"相关资料：\n{related[:12000]}\n"
        ),
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8081)
