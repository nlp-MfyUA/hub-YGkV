"""离线解析 worker（功能1 后端 + 功能2 状态流转）。

- 消费 Kafka topic: pdf-parse-tasks （与前端上传解耦，对应参考实现的 Kafka 生产者/消费者模式）
- 调用 mineru（本地 mineru-kit api-server :8000 的 v1 REST API）解析 PDF → markdown + 图片
- 文本切块 + bge 文本向量 + Chinese-CLIP 图文向量 → 写入本地 SQLite 向量库
- 状态流转：待解析 → 解析中 → 解析完成/解析失败（功能2 前端据此展示）
"""
import json
import os
import sys
import glob
import shutil
import zipfile
import tempfile
import hashlib
import traceback
import time
from pathlib import Path
from urllib.parse import urljoin

from kafka import KafkaConsumer

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))

import config
import db as dblib
from embed_retrieve import split_text2chunks, embed_chunks

MINERU_BASE = "http://127.0.0.1:8000/v1"


# ── mineru v1 解析客户端 ────────────────────────────────────────────
def _mineru_health() -> bool:
    try:
        import httpx
        r = httpx.get(f"{MINERU_BASE}/health", timeout=5)
        return r.status_code == 200
    except Exception:  # noqa
        return False


def mineru_parse_to_markdown(pdf_path):
    """调用 MinerU v1 API 解析 PDF。

    流程（与 mineru 官方 Python 客户端一致）：
      1. POST /v1/tasks  创建任务（files[0].status=waiting-file，含 upload.url）
      2. PUT upload.url  上传 PDF 字节
      3. GET  /v1/tasks/{id} 轮询至 completed
      4. GET result_url 下载产物 zip（内含 markdown 与 images/）
    返回 (tmpdir, zip 内文件名列表)。
    """
    import httpx
    pdf_path = os.path.abspath(pdf_path)
    fname = os.path.basename(pdf_path)
    sha256 = hashlib.sha256(open(pdf_path, "rb").read()).hexdigest()

    payload = {
        "files": [
            {
                "file_name": fname,
                "bytes": os.path.getsize(pdf_path),
                "sha256sum": sha256,
                "page_range": "all",
            }
        ],
        "tier": "standard",
        "output_formats": ["default"],
    }

    with httpx.Client(timeout=httpx.Timeout(120, connect=30)) as cli:
        # 1. 创建任务
        r = cli.post(f"{MINERU_BASE}/tasks", json=payload)
        if r.status_code >= 400:
            raise RuntimeError(f"mineru 建任务失败 {r.status_code}: {r.text[:400]}")
        task = r.json()
        task_id = task["task_id"]

        # 2. 等待 upload 链接出现后上传
        for _ in range(30):
            task = _mineru_query(cli, task_id, task)
            if task["files"][0].get("upload"):
                break
            time.sleep(1)
        up = task["files"][0].get("upload")
        if up:
            with open(pdf_path, "rb") as fp:
                r2 = cli.put(up["url"], content=fp.read())
            if r2.status_code >= 400:
                raise RuntimeError(f"mineru 上传失败 {r2.status_code}: {r2.text[:200]}")

        # 3. 轮询至终态
        seen_states = set()
        while True:
            task = _mineru_query(cli, task_id, task)
            st = task["files"][0]["status"]
            if st not in seen_states:
                print(f"  [mineru] 文件状态: {st}")
                seen_states.add(st)
            if st in ("completed", "partial"):
                break
            if st in ("failed", "canceled"):
                raise RuntimeError(f"mineru 解析失败: {task['files'][0].get('error')}")
            time.sleep(2)

        # 4. 下载产物 zip
        result_url = task["files"][0].get("result_url")
        if not result_url:
            raise RuntimeError("mineru 未返回 result_url")
        result_url = result_url if result_url.startswith("http") else urljoin(MINERU_BASE + "/", result_url)

        tmpdir = tempfile.mkdtemp(prefix="mineru_out_")
        zip_path = os.path.join(tmpdir, "result.zip")
        with cli.stream("GET", result_url, follow_redirects=True) as resp:
            resp.raise_for_status()
            with open(zip_path, "wb") as f:
                for chunk in resp.iter_bytes():
                    f.write(chunk)
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            print(f"  [mineru] 产物文件: {names[:20]}")
            z.extractall(tmpdir)
        return tmpdir, names


def _mineru_query(cli, task_id, task):
    """GET /v1/tasks/{task_id}，返回最新 task 快照。"""
    r = cli.get(f"{MINERU_BASE}/tasks/{task_id}", timeout=30)
    if r.status_code >= 400:
        raise RuntimeError(f"mineru 查询失败 {r.status_code}: {r.text[:200]}")
    return r.json()


# ── 主流程 ───────────────────────────────────────────────────────────
def process_one(msg_value):
    file_id = msg_value["id"]
    file_name = msg_value["file_name"]
    file_path = msg_value["file_path"]

    # 功能2：待解析 → 解析中
    dblib.update_file_state(file_id, config.STATUS_PARSING)

    if not os.path.exists(file_path):
        dblib.update_file_state(file_id, config.STATUS_FAILED, error_msg="本地文件不存在")
        return

    if not _mineru_health():
        dblib.update_file_state(file_id, config.STATUS_FAILED, error_msg="mineru 服务不可用")
        return

    doc_key = os.path.basename(file_name).rsplit(".", 1)[0]
    processed_root = os.path.join(config.PROCESSED_DIR, doc_key)
    os.makedirs(processed_root, exist_ok=True)

    try:
        # 步骤1：mineru 解析 PDF → markdown + 图片
        print(f"[worker] 解析 {file_name} (id={file_id})")
        tmpdir, names = mineru_parse_to_markdown(file_path)

        md_candidates = [n for n in names if n.endswith(".md")]
        if not md_candidates:
            dblib.update_file_state(file_id, config.STATUS_FAILED, error_msg="mineru 未产出 markdown")
            return
        md_name = md_candidates[0]
        md_path = os.path.join(processed_root, os.path.basename(md_name))
        shutil.move(os.path.join(tmpdir, md_name), md_path)

        # 复制全部图片到 processed/<doc_key>/（保留 images/ 相对结构）
        for n in names:
            if "/images/" in n or n.startswith("images/"):
                src = os.path.join(tmpdir, n)
                if os.path.isfile(src):
                    dst = os.path.join(processed_root, os.path.normpath(n))
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.move(src, dst)
        shutil.rmtree(tmpdir, ignore_errors=True)

        # 步骤2：切块 → bge/clip 编码 → 写向量库
        lines = open(md_path, "r", encoding="utf-8").readlines()
        chunks = split_text2chunks(lines, config.CHUNK_SIZE)
        print(f"[worker] {file_name}: {len(chunks)} 个文本片段")
        if not chunks:
            dblib.update_file_state(file_id, config.STATUS_DONE, page_count=len(lines))
            return
        embed_chunks(chunks, file_id, file_name, file_path, processed_root)

        # 功能2：解析完成
        dblib.update_file_state(file_id, config.STATUS_DONE, page_count=len(lines))
        print(f"[worker] {file_name} 处理完成")
    except Exception as e:  # noqa
        traceback.print_exc()
        dblib.update_file_state(file_id, config.STATUS_FAILED, error_msg=str(e))


def main():
    print(f"[worker] 启动，消费 topic={config.KAFKA_TOPIC_PARSE} group={config.KAFKA_GROUP_PARSE}")
    consumer = KafkaConsumer(
        config.KAFKA_TOPIC_PARSE,
        bootstrap_servers=config.KAFKA_BOOTSTRAP,
        group_id=config.KAFKA_GROUP_PARSE,
        enable_auto_commit=True,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
    )
    for msg in consumer:
        try:
            print(f"[worker] 收到消息: {msg.value}")
            process_one(msg.value)
        except Exception as e:  # noqa
            traceback.print_exc()
            print(f"[worker] 处理消息失败: {e}")


if __name__ == "__main__":
    main()
