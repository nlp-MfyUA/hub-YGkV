"""全局配置：路径、Kafka、本地大模型、向量存储等。"""
import os

# 项目根目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 数据目录
UPLOAD_DIR = os.path.join(BASE_DIR, "data", "uploads")     # 原始 PDF
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed") # mineru 解析产物
MODEL_DIR = os.path.join(BASE_DIR, "models")
DB_PATH = os.path.join(BASE_DIR, "data", "ms.db")           # 元信息 + 向量

for d in (UPLOAD_DIR, PROCESSED_DIR, MODEL_DIR):
    os.makedirs(d, exist_ok=True)

# Kafka
KAFKA_BOOTSTRAP = os.environ.get("KAFKA_BOOTSTRAP", "127.0.0.1:9092")
KAFKA_TOPIC_PARSE = "pdf-parse-tasks"     # PDF 解析任务
KAFKA_GROUP_PARSE = "pdf-parse-worker"    # worker 消费组

# 本地大模型（Qwen3-VL-8B 通过 vLLM 部署）
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "http://127.0.0.1:8001/v1")
LLM_API_KEY = "unused"
LLM_MODEL = os.environ.get("LLM_MODEL", "qwen")  # 对应 --served-model-name

# mineru 本地解析服务（mineru-kit api-server）
MINERU_PARSE_URL = os.environ.get("MINERU_PARSE_URL", "http://127.0.0.1:8000/parse")

# 文本 / 多模态检索模型（本地下载，见 models/）
BGE_MODEL_NAME = os.environ.get("BGE_MODEL", os.path.join(MODEL_DIR, "bge-small-zh-v1.5"))
CLIP_MODEL_NAME = os.environ.get("CLIP_MODEL", os.path.join(MODEL_DIR, "chinese-clip-vit-base-patch16"))

# 文件状态常量
STATUS_PENDING = "待解析"
STATUS_PARSING = "解析中"
STATUS_DONE = "解析完成"
STATUS_FAILED = "解析失败"

TOP_K_TEXT = 6    # 文本检索条数
TOP_K_IMAGE = 4   # 图片检索条数
CHUNK_SIZE = 256  # 文本切块大小
