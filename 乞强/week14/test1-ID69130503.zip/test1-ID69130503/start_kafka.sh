#!/usr/bin/env bash
# 启动单节点 Kafka（KRaft）。已格式化过的话会跳过 format。
set -euo pipefail

KAFKA_HOME=/workspace/kafka/kafka_2.13-4.4.0
CONF=/workspace/week14/kafka.properties
CLUSTER_ID=week14-demo-cluster-0001

"$KAFKA_HOME/bin/kafka-storage.sh" format \
    -t "$CLUSTER_ID" -c "$CONF" --ignore-formatted >/dev/null 2>&1 || true

exec "$KAFKA_HOME/bin/kafka-server-start.sh" "$CONF"
