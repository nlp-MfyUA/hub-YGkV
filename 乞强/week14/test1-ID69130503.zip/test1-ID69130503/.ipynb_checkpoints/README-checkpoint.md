# 练习：Redis 存对话历史 + Kafka 传消息

用两个 Python 程序组成一个最简单的「聊天 + 机器人」演示：

- **Redis** 负责保存每个人的「历史对话」；
- **Kafka** 负责在发送方用户端和机器人服务端之间传递消息。

```
                      ┌──────────────────────┐
                      │  Redis (6379)        │
                      │  历史对话 chat:<user> │
                      └──────────▲───────────┘
                        写入历史  │  写入历史
              ┌──────────────────┤──────────────────┐
              │                                    │
    ┌─────────┴──────────┐                ┌─────────┴──────────┐
    │ 程序一             │   chat_input   │ 程序二             │
    │ chat_producer.py   │ ───────────────▶│ chat_consumer.py  │
    │ 用户端             │                │ 机器人服务端       │
    │ 发消息 / 显示回复   │ ◀─────────────── │ 收消息 / 生成回复  │
    └────────────────────┘   chat_reply    └────────────────────┘
          Kafka (localhost:9092) 负责全部消息传递
          Redis 负责共享历史对话（两个程序都读写它）
```

## 目录结构

| 文件 | 作用 |
|------|------|
| `chat_producer.py` | 程序一：用户端。输入消息 → 写 Redis 历史 + 发 Kafka；后台订阅回复 |
| `chat_consumer.py` | 程序二：机器人端。收 Kafka 消息 → 写 Redis 历史 → 生成回复 → 回发 Kafka |
| `kafka.properties` | 单节点 Kafka（KRaft）配置 |
| `start_kafka.sh`   | 格式化并启动 Kafka |
| `requirements.txt` | Python 依赖 |

## 数据流

1. 用户在程序一输入一句话
2. 这句话由程序一写入 Redis 列表 `chat:<user>`（用户侧历史）
3. 同一条消息发布到 Kafka topic `chat_input`
4. 程序二（机器人）从 `chat_input` 收到消息，生成回复
5. 程序二把回复写入 Redis 历史，并发布到 `chat_reply`
6. 程序一后台线程收到 `chat_reply`，直接打印回复
   （用户消息由程序一写历史、机器人回复由程序二写历史，Redis 里每条只存一次）

## 运行步骤

```bash
# 0. 安装依赖（redis、kafka-python）
pip install -r requirements.txt

# 1. Redis 应已在本机运行（6379）
redis-cli ping        # 应返回 PONG

# 2. 启动 Kafka（后台常驻）
bash start_kafka.sh   # 另开一个终端跑，或加 & 后台运行

# 3. 先起机器人（程序二）
python3 chat_consumer.py

# 4. 再开一个终端跑用户端（程序一）
python3 chat_producer.py --user alice
# 输入任意内容回车，会立即收到机器人回复；另有 --history 可先看历史

# 5. 两个用户同时聊天？再开一个终端
python3 chat_producer.py --user bob
```

## 验证历史对话被 Redis 保存

```bash
redis-cli lrange chat:alice 0 -1
# 或只看条数
redis-cli llen chat:alice
```

## 停止

```bash
# 停 Kafka（找到它的进程）
pgrep -f kafka.Kafka && pkill -f kafka.Kafka
# Redis / 两个 Python 程序用 Ctrl+C 即可
```

## 常见问题

- **Kafka 连不上**：先确认 `start_kafka.sh` 日志出现 `Kafka Server started`，再跑程序。
- **两个程序都能连但没回复**：确认机器人端先启动、且没有报错（回复要由程序二回发）。
- **想清空历史**：`redis-cli del chat:alice`
