#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
程序一：chat_producer.py —— 聊天发送方（用户端）

职责：
  1. Redis —— 把用户说的每一句写入 Redis，作为「历史对话」的存储（用户侧）；
  2. Kafka —— 把用户消息发布到 chat_input 话题，实现消息传递；
  3. 后台线程 —— 订阅 chat_reply 话题，实时显示机器人回复（回复的历史由程序二写入）。

运行：python3 chat_producer.py [--user alice] [--history]
"""

import argparse
import json
import threading
import time

import kafka
import redis

BOOTSTRAP = "localhost:9092"
INPUT_TOPIC = "chat_input"   # 用户 -> 机器人
REPLY_TOPIC = "chat_reply"   # 机器人 -> 用户

MAX_HISTORY = 100            # Redis 里每个用户最多保留的对话条数


def get_redis():
    return redis.Redis(host="localhost", port=6379, decode_responses=True)


def history_key(user):
    return f"chat:{user}"


def append_history(r, user, role, content, ts):
    """向 Redis 列表追加一条 JSON 消息，并用 LTRIM 裁剪到最近 MAX_HISTORY 条"""
    msg = {"role": role, "content": content, "ts": ts}
    r.rpush(history_key(user), json.dumps(msg, ensure_ascii=False))
    r.ltrim(history_key(user), -MAX_HISTORY, -1)
    return msg


def show_history(r, user, limit=20):
    """从 Redis 读取并打印最近的对话历史"""
    msgs = [json.loads(x) for x in r.lrange(history_key(user), -limit, -1)]
    print(f"\n———— 对话历史（读取自 Redis：{history_key(user)}，{len(msgs)} 条）————")
    for m in msgs:
        who = "你" if m["role"] == "user" else "机器人"
        print(f"  [{who}] {m['content']}")
    print("—" * 46)


def start_reply_listener(r, user):
    """后台线程：消费 chat_reply 话题 -> 写回 Redis 历史 -> 打印回复"""

    def consume():
        consumer = kafka.KafkaConsumer(
            REPLY_TOPIC,
            bootstrap_servers=BOOTSTRAP,
            value_deserializer=lambda b: json.loads(b.decode("utf-8")),
            auto_offset_reset="latest",
        )
        try:
            for record in consumer:
                msg = record.value
                if msg.get("user") != user:
                    continue  # 只关心发给本用户的回复
                # 机器人回复的历史由程序二写入 Redis，这里只负责展示，避免重复保存
                print(f"\n[机器人] {msg['content']}")
                print("你> ", end="", flush=True)
        finally:
            consumer.close()

    t = threading.Thread(target=consume, daemon=True)
    t.start()
    return t


def main():
    p = argparse.ArgumentParser(description="聊天发送方：Redis 存历史，Kafka 传消息")
    p.add_argument("--user", default="alice", help="用户 ID，默认 alice")
    p.add_argument("--history", action="store_true", help="启动时先显示 Redis 里已有的历史")
    args = p.parse_args()
    user = args.user

    r = get_redis()
    r.ping()  # 确认 Redis 可达

    producer = kafka.KafkaProducer(
        bootstrap_servers=BOOTSTRAP,
        value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
    )

    if args.history:
        show_history(r, user)

    start_reply_listener(r, user)
    print(f"开始聊天（用户：{user}）。输入内容回车发送，输入 /quit 退出。")

    try:
        while True:
            content = input("你> ").strip()
            if not content:
                continue
            if content == "/quit":
                break
            ts = int(time.time())
            append_history(r, user, "user", content, ts)   # 第 1 步：写入 Redis 历史
            producer.send(INPUT_TOPIC, {"user": user, "role": "user",
                                        "content": content, "ts": ts})  # 第 2 步：发到 Kafka
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        producer.flush()
        producer.close()
        print("\n本次会话结束，展示 Redis 中的完整历史：")
        show_history(r, user)


if __name__ == "__main__":
    main()
