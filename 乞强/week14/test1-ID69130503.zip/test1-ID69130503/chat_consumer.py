#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
程序二：chat_consumer.py —— 机器人消费者（服务端）

职责：
  1. Kafka —— 订阅 chat_input 话题，接收用户发布的消息；
  2. Redis —— 把生成的机器人回复写入 Redis「历史对话」（用户消息由程序一写入）；
  3. Kafka —— 把回复发布回 chat_reply 话题，送回给用户端。

运行：python3 chat_consumer.py
"""

import json
import time

import kafka
import redis

BOOTSTRAP = "localhost:9092"
INPUT_TOPIC = "chat_input"
REPLY_TOPIC = "chat_reply"
GROUP_ID = "chat-bot"

MAX_HISTORY = 100


def get_redis():
    return redis.Redis(host="localhost", port=6379, decode_responses=True)


def history_key(user):
    return f"chat:{user}"


def append_history(r, user, role, content, ts):
    msg = {"role": role, "content": content, "ts": ts}
    r.rpush(history_key(user), json.dumps(msg, ensure_ascii=False))
    r.ltrim(history_key(user), -MAX_HISTORY, -1)
    return msg


def reply_for(text):
    """一个简单的规则回复器，用来模拟机器人（未接真实 LLM）"""
    low = text.lower()
    if "你好" in text or low in ("hi", "hello", "嗨"):
        return "你好！我是接收 Kafka 消息的规则机器人。聊聊 Redis 和 Kafka 吗？"
    if "redis" in low:
        return "Redis 在这里负责保存我们的对话历史 ✍️"
    if "kafka" in low:
        return "Kafka 在这里负责把我们的话传来传去 📨"
    if any(x in text for x in ("?", "？", "吗")):
        return "好问题——可惜我只会几句固定回复，以后再升级 😅"
    return f"收到：{text}（这条消息经由 Kafka topic={INPUT_TOPIC} 送达我）"


def main():
    consumer = kafka.KafkaConsumer(
        INPUT_TOPIC,
        bootstrap_servers=BOOTSTRAP,
        group_id=GROUP_ID,
        auto_offset_reset="latest",
        enable_auto_commit=True,
        value_deserializer=lambda b: json.loads(b.decode("utf-8")),
    )
    producer = kafka.KafkaProducer(
        bootstrap_servers=BOOTSTRAP,
        value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
    )
    r = get_redis()
    r.ping()

    print("机器人已就绪，正在监听 Kafka topic:", INPUT_TOPIC)
    try:
        for record in consumer:
            msg = record.value
            user = msg.get("user", "unknown")
            ts = int(time.time())

            # 用户消息的历史已由程序一（chat_producer.py）负责写入，这里只处理消息
            print(f"[收到] {user}: {msg['content']}   (offset={record.offset})")

            # 第 2 步：生成回复
            reply = {"user": user, "role": "assistant",
                     "content": reply_for(msg["content"]), "ts": ts}

            # 第 3 步：回复也写入 Redis 历史
            append_history(r, user, "assistant", reply["content"], ts)

            # 第 4 步：回复发布回 Kafka
            producer.send(REPLY_TOPIC, reply).get(timeout=5)
            print(f"[回复] 已回发：{reply['content']}")
    except KeyboardInterrupt:
        pass
    finally:
        producer.close()
        consumer.close()


if __name__ == "__main__":
    main()
