# AGENTS.md

## Web interface (`web/`)

Alongside the CLI, this repo has a **Vue 3 + Vite frontend and FastAPI backend** under `web/`:

- `web/backend/` — FastAPI app. `main.py` exposes `/api/auth/login`, `/api/auth/register`,
  `/api/query`, `/api/history`; wraps `SQLAgentWorkflow()`, stores users + chat history in a
  SQLite file (`web/data/chat.db`) via `auth.py` (JWT + PBKDF2) and `db.py` (stdlib sqlite3).
- `web/frontend/` — Vue 3 + Vite single-page app (login + chat). Dev mode proxies `/api` to
  the backend on 8000. `npm run build` outputs to `web/dist`, which the backend then serves.
- `web/run_backend.py` / `start_web.bat` — no-install launchers that prepend this repo's
  `src/` (same reason as `run.py`). The "foolproof" path is `start_web.bat` (auto build +
  start). Default login: `admin` / `admin123` (created on first start).
- Backend deps (`fastapi`, `uvicorn`, `pyjwt`) are declared in `pyproject.toml`.

## Repo state

- This is a **LangGraph re-implementation** of `00-sql-agent`. The deterministic components
  (`db/`), the four LLM structured-output chains (`agents/`), data contracts (`models.py`) and
  tests are identical to the LangChain parent; only the **orchestration layer** changed:
  `workflow.py` is now a `langgraph.graph.StateGraph` state machine instead of a Python-coded
  for/if loop.
- Implementation lives in `src/sql_agent/`; tests in `tests/`; design in `docs/agent-design.md`.
  `ref/` contains the fixture DB and reference notebook/demo only.
- The pipeline is: **table selection → SQL generation → SQL validation → SQL rewrite/repair →
  execution → result summarization**, orchestrated by a LangGraph `StateGraph`.

## How the LangGraph conversion maps onto LangChain / openai-agents

| openai-agents (00-sql-agent) | LangChain (parent repo) | LangGraph (this repo) |
| --- | --- | --- |
| `Agent(...)` + `Runner.run` | four `Runnable` chains + Python for/if | four **graph nodes** calling the same chains; branch/loop via `add_conditional_edges` |
| orchestration in code loops | orchestration in code loops | orchestration is the graph topology (edges + router functions) |
| state held in a Python object | state held in a Python object | state is `AgentState` (TypedDict) passed between nodes by the graph |

## Key files

- `src/sql_agent/workflow.py` — the **only genuinely new file**. `AgentState`, `SQLAgentWorkflow`,
  node methods (`_node_*`), router functions (`_route_*`), and `_build_graph()` that wires
  `StateGraph`.
- `src/sql_agent/db/`, `src/sql_agent/agents/`, `src/sql_agent/models.py`, `config.py`, `cli.py` —
  copied unchanged from the LangChain parent (LLM wiring still LangChain: `ChatPromptTemplate |
  ChatOpenAI(...).with_structured_output(...)`).
- `tests/` — copied from the parent; LLM calls are mocked by patching each chain's `ainvoke`.

## Conventions (LangGraph-specific)

- **Nodes are async closures** in `_build_graph()` that delegate to `self._node_*`. Do not add
  nodes directly as `self._node_*` bound methods — LangGraph would pass state into `self`. Keep
  them as closures capturing `self`.
- **Router functions return one of the `_ROUTE_*` string keys**, and their mapping lives in the
  `path_map` arg of `add_conditional_edges`. They only *decide* the edge — they must NOT mutate
  state (mutations there are ignored by LangGraph).
- **Terminal output assembly happens in the node**, by setting a `final_output` channel
  (`WorkflowOutput | None`). The `finalize` node is a passthrough to `END`; `run()` reads
  `result["final_output"]`.
- **`attempts` uses overwrite semantics** (each node returns the full list), NOT a LangGraph
  reducer, so a node can amend the last `SQLAttempt`. Keep it that way — a `operator.add`
  reducer would make "update the failed attempt's code/error" impossible without a separate channel.
- The repair loop is the back-edge `rewrite_sql → validate_or_execute`. Budget is
  `max_repair_attempts` (default 3, from `settings.max_repair_attempts`).
- The `agents/llm.py` `LazyStructuredChain` is shared from the parent and is what tests
  monkeypatch (`chain.ainvoke`).

## Environment / commands

- Python 3.12 verified. Deps: `langgraph>=1.0`, `langchain>=1.0`, `langchain-openai>=1.0`,
  `sqlalchemy>=2.0`, `python-dotenv>=1.0`, `pydantic` 2.x.
- **No-install launchers**: `python run.py "…"` (any shell) or `.\sql-agent.bat "…"` (PowerShell)
  prepend this repo's `src/` to `sys.path`, so they always run THIS project and read this
  repo's `.env`. Prefer them over bare `python -m sql_agent` / `sql-agent`: the `py312` env also
  has the week12 langchain parent editable-installed under the same `sql_agent` package name,
  so a bare import there currently resolves to the parent. The `sql-agent` console script
  requires `pip install -e .` in the active env first; PowerShell's `(base)` env has neither.
- Run the CLI from the repo root: `python run.py "总共有多少张专辑？"`.
  Requires an API key; `config.py` loads it from the project-root `.env` file (copy
  `.env.example` → `.env` and fill in `OPENAI_API_KEY`). Real environment variables take
  precedence over `.env`. The demo key currently in `.env` may be expired — replace it with a
  valid key for live runs.
- Run tests: `pytest -q` (no API key needed; LLM mocked). Expected `21 passed`.
- Lint: `ruff check src tests` — the parent's copied `db/` still has intentional broad
  `except Exception` (BLE001); do not "fix" those to exceptions in the graph boundary.
- Logs go to stderr; final JSON to stdout. Control with `--log-level` or `SQL_AGENT_LOG_LEVEL`.
