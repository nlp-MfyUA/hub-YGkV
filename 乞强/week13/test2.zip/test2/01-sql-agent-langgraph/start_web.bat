@echo off
chcp 65001 >nul
title SQL Agent Web (one-click)
cd /d "%~dp0"

echo ============================================================
echo   SQL Agent Web - one-click launcher
echo ============================================================
echo.
echo   Step 1: check / build frontend assets ...
if not exist "web\dist\index.html" (
    echo     frontend not built, building now (requires internet)...
    echo.
    pushd web\frontend
    call npm install
    call npm run build
    popd
) else (
    echo     frontend assets already exist, skip build.
)
echo.
echo   Step 2: starting backend (keep this window open) ...
echo   Open in browser: http://127.0.0.1:8000
echo   Default account: admin / admin123
echo   Press Ctrl+C to stop.
echo.
python web\run_backend.py
pause