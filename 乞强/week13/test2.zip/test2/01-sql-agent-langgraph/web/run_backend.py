"""SQL Agent Web 后端启动器（免安装，傻瓜式）。

用法（在项目根目录执行）：
    python web/run_backend.py

脚本会把本仓库的 src/ 前置到 sys.path（强制使用本项目，避免与 week12
langchain 版同名 sql_agent 包串项目），随后用 uvicorn 托管 FastAPI 应用，
监听 http://127.0.0.1:8000。

结束按 Ctrl+C。若前端已构建（web/dist 存在），打开浏览器访问如下地址即可：
    http://127.0.0.1:8000
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# 必须最先插入，保证 import sql_agent 命中本仓库的 src/
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import uvicorn  # noqa: E402

from web.backend.main import app  # noqa: E402


def main() -> None:
    print("=====================================================")
    print("  SQL Agent Web 后端启动中 ...")
    print(f"  前端地址: http://127.0.0.1:8000")
    print("  默认账号: admin / admin123")
    print("  按 Ctrl+C 停止")
    print("=====================================================")
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")


if __name__ == "__main__":
    main()