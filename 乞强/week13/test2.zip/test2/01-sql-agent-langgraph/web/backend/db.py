"""SQLite 存储：用户 + 会话历史（标准库 sqlite3，零额外依赖）。"""

from __future__ import annotations

import logging
import sqlite3
import threading
from pathlib import Path

from .auth import hash_password

logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "chat.db"

# 默认演示账号：admin / admin123
DEFAULT_ADMIN = "admin"
DEFAULT_ADMIN_PASSWORD = "admin123"

_lock = threading.RLock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username      TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    TEXT NOT NULL,
    username      TEXT NOT NULL,
    question      TEXT NOT NULL,
    answer_json   TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_history_session
    ON history(session_id, id);
"""


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_db() -> None:
    """建表 + 写入默认演示账号 admin/admin123（首次运行才插入）。"""
    with _lock:
        conn = _connect()
        try:
            conn.executescript(_SCHEMA)
            conn.execute(
                "INSERT OR IGNORE INTO users (username, password_hash) VALUES (?, ?)",
                (DEFAULT_ADMIN, hash_password(DEFAULT_ADMIN_PASSWORD)),
            )
            conn.commit()
            logger.info("init_db done db=%s default_user=%s", DB_PATH, DEFAULT_ADMIN)
        finally:
            conn.close()


def get_user(username: str) -> dict | None:
    with _lock:
        conn = _connect()
        try:
            row = conn.execute(
                "SELECT username, password_hash, created_at FROM users WHERE username = ?",
                (username,),
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()


def create_user(username: str, password_hash: str) -> bool:
    """插入新用户；用户名已存在时返回 False。"""
    with _lock:
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, password_hash),
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()


def add_history(session_id: str, username: str, question: str, answer_json: str) -> None:
    with _lock:
        conn = _connect()
        try:
            conn.execute(
                "INSERT INTO history (session_id, username, question, answer_json) VALUES (?, ?, ?, ?)",
                (session_id, username, question, answer_json),
            )
            conn.commit()
        finally:
            conn.close()


def get_history(session_id: str, limit: int = 200) -> list[dict]:
    with _lock:
        conn = _connect()
        try:
            rows = conn.execute(
                "SELECT id, question, answer_json, created_at FROM history"
                " WHERE session_id = ? ORDER BY id DESC LIMIT ?",
                (session_id, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


def clear_history(session_id: str) -> None:
    with _lock:
        conn = _connect()
        try:
            conn.execute("DELETE FROM history WHERE session_id = ?", (session_id,))
            conn.commit()
        finally:
            conn.close()