"""认证与密码/令牌辅助函数（标准库实现，无额外依赖）。

- 密码使用 PBKDF2-SHA256 加盐存储
- 登录成功后签发 JWT（HS256），有效期默认 3 天
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import hmac
import os
import secrets

import jwt

# JWT 密钥：优先读环境变量，否则用默认值（演示项目；生产应改为环境变量）
_SECRET = os.getenv("SQL_AGENT_JWT_SECRET", "sql-agent-web-demo-secret-change-me")
_ALG = "HS256"
TOKEN_TTL_HOURS = int(os.getenv("SQL_AGENT_TOKEN_TTL_HOURS", "72"))

_ITERATIONS = 200_000


def hash_password(password: str) -> str:
    """返回 ``salt$hash`` 十六进制串。"""
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), _ITERATIONS
    )
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """用恒定时间比较校验密码。"""
    try:
        salt, expected = stored.split("$", 1)
    except ValueError:
        return False
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), _ITERATIONS
    )
    return hmac.compare_digest(digest.hex(), expected)


def create_token(username: str) -> str:
    now = _dt.datetime.now(_dt.timezone.utc)
    payload = {
        "sub": username,
        "iat": int(now.timestamp()),
        "exp": int((now + _dt.timedelta(hours=TOKEN_TTL_HOURS)).timestamp()),
    }
    return jwt.encode(payload, _SECRET, algorithm=_ALG)


def decode_token(token: str) -> str | None:
    """解析 JWT，返回用户名；非法/过期返回 None。"""
    try:
        payload = jwt.decode(token, _SECRET, algorithms=[_ALG])
    except jwt.PyJWTError:
        return None
    return payload.get("sub")


def new_session_id() -> str:
    return secrets.token_hex(24)