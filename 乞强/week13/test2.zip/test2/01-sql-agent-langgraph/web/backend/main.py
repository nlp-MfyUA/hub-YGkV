"""SQL Agent Web 后端：FastAPI 提供登录 + 自然语言问答 + 历史记录。

运行前提：项目根目录 .env 里已配置可用的 OPENAI_API_KEY。
启动方式（在项目根目录）：python web/run_backend.py，监听 http://127.0.0.1:8000
"""

from __future__ import annotations

import json
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from sql_agent.config import settings
from sql_agent.workflow import SQLAgentWorkflow

from . import auth, db

logger = logging.getLogger(__name__)

WEB_DIR = Path(__file__).resolve().parents[1]
DIST_DIR = WEB_DIR / "dist"

# ---- 请求/响应模型 ------------------------------------------------------------


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class RegisterRequest(BaseModel):
    username: str = Field(min_length=2, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    password: str = Field(min_length=6, max_length=128)


class QueryRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)


class QueryResponse(BaseModel):
    question: str
    answer: str
    sql: str | None = None
    tables: list[str] = []
    row_count: int = 0
    truncated: bool = False
    repair_attempts: int = 0
    evidence: list[str] = []
    caveats: list[str] = []
    error: str | None = None


class HistoryItem(BaseModel):
    id: int
    question: str
    answer_json: str
    created_at: str


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    logger.info(
        "backend ready api_key_set=%s primary_model=%s base_url=%s",
        bool(os.getenv("OPENAI_API_KEY")),
        settings.primary_model,
        settings.base_url,
    )
    yield


app = FastAPI(title="SQL Agent Web", lifespan=lifespan)

# 开发时允许 Vite dev server 跨域；生产模式后端直接托管 dist/（无需跨域）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- 认证依赖 -----------------------------------------------------------------


def _session_id() -> str:
    """每个会话一个会话 ID（存历史）；前端登录后固定使用。"""
    return "session-default"


def _auth_user(request: Request) -> str:
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="未登录或令牌缺失")
    username = auth.decode_token(auth_header[7:].strip())
    if not username:
        raise HTTPException(status_code=401, detail="登录已过期，请重新登录")
    return username


# ---- 健康检查 ----------------------------------------------------------------


@app.get("/api/health")
def health() -> dict:
    return {
        "status": "ok",
        "api_key_set": bool(os.getenv("OPENAI_API_KEY")),
        "primary_model": settings.primary_model,
    }


# ---- 认证 --------------------------------------------------------------------


@app.post("/api/auth/login")
def login(body: LoginRequest) -> dict:
    user = db.get_user(body.username)
    if not user or not auth.verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    return {"token": auth.create_token(user["username"]), "username": user["username"]}


@app.post("/api/auth/register")
def register(body: RegisterRequest) -> dict:
    if db.create_user(body.username, auth.hash_password(body.password)):
        return {
            "token": auth.create_token(body.username),
            "username": body.username,
        }
    raise HTTPException(status_code=409, detail="用户名已存在")


@app.get("/api/me")
def me(request: Request) -> dict:
    return {"username": _auth_user(request)}


# ---- 问答 --------------------------------------------------------------------


@app.post("/api/query", response_model=QueryResponse)
async def query(body: QueryRequest, request: Request) -> dict:
    username = _auth_user(request)
    try:
        workflow = SQLAgentWorkflow()
        output = await workflow.run(body.question)
        dump = output.model_dump()
    except Exception as exc:  # noqa: BLE001 - 兜底：任何异常都返回可读错误
        logger.exception("query failed username=%s", username)
        dump = {
            "question": body.question,
            "answer": f"处理失败：{exc}",
            "error": str(exc),
        }
    payload = {
        k: dump.get(k)
        for k in ("question", "answer", "sql", "tables", "row_count",
                  "truncated", "repair_attempts", "evidence", "caveats", "error")
    }
    db.add_history(
        _session_id(), username, body.question,
        json.dumps(payload, ensure_ascii=False),
    )
    return payload


@app.get("/api/history")
def history(request: Request, limit: int = Query(default=100, ge=1, le=500)) -> list[HistoryItem]:
    _auth_user(request)
    return db.get_history(_session_id(), limit)


@app.delete("/api/history")
def clear_history(request: Request) -> dict:
    _auth_user(request)
    db.clear_history(_session_id())
    return {"ok": True}


# ---- 前端静态资源（生产模式） --------------------------------------------------


if DIST_DIR.is_dir():
    app.mount("/assets", StaticFiles(directory=DIST_DIR / "assets"), name="assets")

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(DIST_DIR / "index.html")

    # 让 Vue 的 history 路由在刷新时回退到 index.html
    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str) -> FileResponse:
        target = DIST_DIR / full_path
        if full_path and target.is_file():
            return FileResponse(target)
        return FileResponse(DIST_DIR / "index.html")


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.exception("unhandled exception path=%s", request.url.path)
    return JSONResponse(status_code=500, content={"detail": "服务器内部错误"})