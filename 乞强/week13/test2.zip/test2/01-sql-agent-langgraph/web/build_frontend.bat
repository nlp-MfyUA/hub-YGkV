@echo off
chcp 65001 >nul
title SQL Agent Web - frontend build
cd /d "%~dp0frontend"
echo Installing frontend dependencies (first run may take a while)...
call npm install
echo.
echo Building frontend assets (output: web\dist)...
call npm run build
echo.
echo Build finished! Now run start_backend.bat and open http://127.0.0.1:8000
pause