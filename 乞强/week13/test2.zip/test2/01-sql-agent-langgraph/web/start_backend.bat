@echo off
chcp 65001 >nul
title SQL Agent Web - backend
cd /d "%~dp0.."
echo ============================================
echo   SQL Agent Web - backend launcher
echo   Frontend URL: http://127.0.0.1:8000
echo   Default account: admin / admin123
echo   Press Ctrl+C to stop.
echo ============================================
python web\run_backend.py
pause