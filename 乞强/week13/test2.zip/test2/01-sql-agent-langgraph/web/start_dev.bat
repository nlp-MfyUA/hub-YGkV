@echo off
chcp 65001 >nul
title SQL Agent Web - dev mode (two terminals)
cd /d "%~dp0"
echo ============================================================
echo   SQL Agent Web - development mode
echo ============================================================
echo.
echo   Open TWO terminal windows and run:
echo.
echo   Terminal 1 (backend API on port 8000):
echo       python web\run_backend.py
echo.
echo   Terminal 2 (frontend hot-reload on port 5173):
echo       cd web\frontend
echo       npm install   (first time only)
echo       npm run dev
echo.
echo   Dev mode URL: http://127.0.0.1:5173
echo   (Vite proxies /api to backend :8000 automatically)
echo.
pause