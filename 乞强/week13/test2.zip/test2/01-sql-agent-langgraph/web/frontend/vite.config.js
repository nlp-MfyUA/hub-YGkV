import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 开发模式下访问 http://localhost:5173，/api 请求自动代理到后端 8000 端口
export default defineConfig({
  plugins: [vue()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: '../dist',
    assetsDir: 'assets',
    emptyOutDir: true
  }
})