<script setup>
// SQL Agent 前端主应用：登录 + 自然语言问答聊天界面。
import { ref, reactive, onMounted } from 'vue'
import { auth, queryApi } from './api'

const loggedIn = ref(auth.isLoggedIn())
const username = ref(localStorage.getItem('username') || '')

// ---- 登录 / 注册 ----
const mode = ref('login')            // 'login' | 'register'
const loginForm = reactive({ username: '', password: '' })
const loginMsg = ref('')
const loginErr = ref('')
const submitting = ref(false)

async function submitLogin() {
  loginMsg.value = ''
  loginErr.value = ''
  submitting.value = true
  try {
    if (mode.value === 'login') {
      const d = await auth.login(loginForm.username, loginForm.password)
      username.value = d.username
    } else {
      const d = await auth.register(loginForm.username, loginForm.password)
      username.value = d.username
    }
    loggedIn.value = true
    initHistory()
  } catch (e) {
    loginErr.value = e.response?.data?.detail || '请求失败，请检查后端是否已启动'
  } finally {
    submitting.value = false
  }
}

function switchMode() {
  mode.value = mode.value === 'login' ? 'register' : 'login'
  loginMsg.value = ''
  loginErr.value = ''
}

function logout() {
  auth.logout()
  loggedIn.value = false
  messages.value = []
  question.value = ''
}

// ---- 聊天 ----
const messages = ref([])
const question = ref('')
const loading = ref(false)
const suggestions = [
  '总共有多少张专辑？',
  '每位员工各自负责多少位客户？',
  '销量排名前5的曲目是哪些？',
  '哪个国家的客户数量最多？'
]

async function initHistory() {
  loading.value = true
  try {
    const rows = await queryApi.listHistory()
    messages.value = rows
      .slice().reverse()
      .map((r) => {
        try {
          const parsed = JSON.parse(r.answer_json)
          parsed.question = parsed.question || r.question
          return { question: r.question, parsed, created_at: r.created_at }
        } catch {
          return { question: r.question, parsed: { question: r.question, answer: '（无法解析的历史记录）' }, created_at: r.created_at }
        }
      })
  } catch (e) {
    // 后端不可用时静默失败
  } finally {
    loading.value = false
  }
}

async function send() {
  const q = question.value.trim()
  if (!q || loading.value) return
  question.value = ''
  loading.value = true
  const entry = { parsed: null, question: q, pending: true }
  messages.value.push(entry)
  try {
    const data = await queryApi.ask(q)
    entry.parsed = data
    entry.pending = false
  } catch (e) {
    entry.pending = false
    entry.parsed = { question: q, answer: '请求失败：' + (e.response?.data?.detail || e.message), error: true }
  } finally {
    loading.value = false
  }
}

async function clearHistory() {
  if (!confirm('确定清空当前对话历史吗？')) return
  try {
    await queryApi.clearHistory()
    messages.value = []
  } catch (e) { /* ignore */ }
}

function useSuggestion(s) {
  question.value = s
}

function shortErr(text) {
  const s = String(text || '')
  return s.length > 120 ? s.slice(0, 120) + '…' : s
}
</script>

<template>
  <!-- ============ 登录页 ============ -->
  <div v-if="!loggedIn" class="login-wrap">
    <div class="login-card">
      <div class="logo">🐘 SQL<span>Agent</span></div>
      <h1 class="login-title">Chinook 数据库智能问答</h1>
      <p class="login-sub">用自然语言查询音乐数据库，自动生成并执行 SQL</p>

      <div class="tabs">
        <button :class="['tab', { active: mode === 'login' }]" @click="switchMode()">登录</button>
        <button :class="['tab', { active: mode === 'register' }]" @click="switchMode()">注册</button>
      </div>

      <form @submit.prevent="submitLogin" class="login-form">
        <label class="field">
          <span>用户名</span>
          <input v-model.trim="loginForm.username" type="text" placeholder="请输入用户名"
                 autocomplete="username" required />
        </label>
        <label class="field">
          <span>密码</span>
          <input v-model="loginForm.password" type="password" :placeholder="mode === 'login' ? '请输入密码' : '至少 6 位'"
                 autocomplete="current-password" required />
        </label>

        <p v-if="loginMsg" class="form-msg ok">{{ loginMsg }}</p>
        <p v-if="loginErr" class="form-msg err">{{ loginErr }}</p>

        <button class="btn-primary" type="submit" :disabled="submitting">
          {{ submitting ? '请稍候…' : (mode === 'login' ? '登 录' : '注册并登录') }}
        </button>
        <p class="login-hint">默认演示账号：<code>admin</code> / <code>admin123</code></p>
      </form>
    </div>
  </div>

  <!-- ============ 主界面 ============ -->
  <div v-else class="app">
    <header class="topbar">
      <div class="brand">🐘 SQL<span>Agent</span> · Chinook 问答</div>
      <div class="userbox">
        <span class="user">👤 {{ username }}</span>
        <button class="btn-ghost" @click="clearHistory">清空</button>
        <button class="btn-ghost" @click="logout">退出</button>
      </div>
    </header>

    <main class="chat">
      <!-- 消息流 -->
      <div class="messages">
        <div v-if="messages.length === 0" class="welcome">
          <p class="welcome-title">👋 你好，{{ username }}！</p>
          <p class="welcome-sub">用一句中文描述你想查的问题，我会自动选表、生成 SQL 并执行，最后用自然语言回答你。</p>
          <div class="suggestions">
            <button v-for="s in suggestions" :key="s" class="chip" @click="useSuggestion(s)">{{ s }}</button>
          </div>
        </div>

        <!-- 用户问题 -->
        <div v-for="(m, i) in messages" :key="i" class="msg">
          <div class="bubble user">{{ m.question }}</div>

          <div v-if="m.pending" class="bubble ai loading">
            <span class="spinner"></span> 正在思考并查询数据库…
          </div>

          <div v-else-if="m.parsed" class="ai-block">
            <div class="bubble ai" :class="{ error: m.parsed.error }">
              {{ m.parsed.answer }}
            </div>

            <div v-if="m.parsed.sql" class="sql-card">
              <div class="card-head">
                <span class="kbd">SQL 生成</span>
                <button v-if="m.parsed.row_count" class="copy-btn" @click="navigator.clipboard.writeText(m.parsed.sql)">复制</button>
              </div>
              <pre class="sql-code">{{ m.parsed.sql }}</pre>
            </div>

            <div v-if="m.parsed.tables && m.parsed.tables.length" class="meta">
              <span class="kbd">使用表</span>
              <span class="tag" v-for="t in m.parsed.tables" :key="t">{{ t }}</span>
              <span v-if="m.parsed.row_count != null" class="dim">· 返回 {{ m.parsed.row_count }} 行{{ m.parsed.truncated ? '（已截断）' : '' }}</span>
              <span v-if="m.parsed.repair_attempts" class="dim">· 修复 {{ m.parsed.repair_attempts }} 次</span>
            </div>

            <div v-if="m.parsed.error" class="meta warn">⚠ 出错了：{{ shortErr(m.parsed.error) }}</div>
          </div>

          <div v-else class="bubble ai error">历史记录解析失败</div>
        </div>
      </div>

      <!-- 输入区 -->
      <div class="inputbar">
        <textarea v-model="question" rows="1" placeholder="输入你的问题，例如：总共有多少张专辑？"
                  @keydown.enter.exact.prevent="send"></textarea>
        <button class="btn-primary send" :disabled="loading || !question.trim()" @click="send">
          {{ loading ? '查询中…' : '发送' }}
        </button>
      </div>
    </main>
  </div>
</template>

<style scoped>
/* ========== 登录页 ========== */
.login-wrap {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background:
    radial-gradient(900px 400px at 20% 0%, rgba(79,140,255,0.12), transparent),
    radial-gradient(700px 420px at 90% 100%, rgba(52,201,143,0.10), transparent),
    var(--bg);
}
.login-card {
  width: 400px;
  max-width: 92vw;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 32px 34px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.45);
}
.logo { font-size: 22px; font-weight: 800; letter-spacing: 0.5px; }
.logo span { color: var(--accent); margin-left: 2px; }
.login-title { font-size: 19px; margin-top: 10px; }
.login-sub { color: var(--text-dim); font-size: 13px; margin-top: 6px; line-height: 1.6; }
.tabs { display: flex; gap: 8px; margin: 20px 0 16px; }
.tab {
  flex: 1; padding: 9px; border-radius: 8px; font-size: 14px;
  background: var(--bg-soft); color: var(--text-dim); border: 1px solid var(--border);
}
.tab.active { background: var(--accent-soft); color: var(--accent); border-color: var(--accent); }
.login-form { display: flex; flex-direction: column; gap: 14px; }
.field { display: flex; flex-direction: column; gap: 6px; font-size: 13px; color: var(--text-dim); }
.field input {
  padding: 10px 12px; border-radius: 8px; border: 1px solid var(--border);
  background: var(--bg-soft); color: var(--text); font-size: 14px;
}
.field input:focus { border-color: var(--accent); }
.form-msg { font-size: 13px; }
.form-msg.ok { color: var(--green); }
.form-msg.err { color: var(--red); }
.btn-primary {
  padding: 11px; border-radius: 8px; font-size: 15px; font-weight: 600;
  background: var(--accent); color: #fff; transition: background 0.15s;
}
.btn-primary:hover:not(:disabled) { background: var(--accent-strong); }
.login-hint { text-align: center; color: var(--text-dim); font-size: 12px; margin-top: 6px; }
.login-hint code { background: var(--bg-soft); padding: 1px 6px; border-radius: 4px; color: var(--text); }

/* ========== 主界面 ========== */
.app { height: 100%; display: flex; flex-direction: column; }
.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 22px; border-bottom: 1px solid var(--border); background: var(--bg-soft);
}
.brand { font-size: 16px; font-weight: 700; }
.brand span { color: var(--accent); }
.userbox { display: flex; align-items: center; gap: 12px; }
.user { color: var(--text-dim); font-size: 13px; }
.btn-ghost {
  padding: 6px 12px; border-radius: 6px; font-size: 13px;
  background: transparent; color: var(--text-dim); border: 1px solid var(--border);
}
.btn-ghost:hover { color: var(--text); border-color: var(--accent); }

.chat {
  flex: 1; display: flex; flex-direction: column; max-width: 860px;
  width: 100%; margin: 0 auto; padding: 0 18px;
}
.messages { flex: 1; overflow-y: auto; padding: 22px 4px; display: flex; flex-direction: column; gap: 18px; }
.welcome { text-align: center; padding: 60px 10px; }
.welcome-title { font-size: 21px; font-weight: 700; }
.welcome-sub { color: var(--text-dim); font-size: 14px; margin: 10px auto 20px; max-width: 480px; line-height: 1.7; }
.suggestions { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
.chip {
  padding: 8px 14px; border-radius: 999px; font-size: 13px;
  background: var(--bg-card); color: var(--text); border: 1px solid var(--border);
}
.chip:hover { border-color: var(--accent); color: var(--accent); }

.msg { display: flex; flex-direction: column; gap: 8px; }
.bubble {
  padding: 11px 15px; border-radius: 12px; line-height: 1.65;
  font-size: 14.5px; word-break: break-word; white-space: pre-wrap;
}
.bubble.user {
  align-self: flex-end; max-width: 75%;
  background: var(--accent); color: #fff; border-bottom-right-radius: 4px;
}
.bubble.ai {
  align-self: flex-start; max-width: 92%;
  background: var(--bg-card); border: 1px solid var(--border); border-bottom-left-radius: 4px;
}
.bubble.ai.error { border-color: var(--red); color: var(--red); }

.ai-block { display: flex; flex-direction: column; gap: 8px; }
.ai-block .bubble.ai { max-width: 100%; }

.loading { color: var(--text-dim); }
.spinner {
  width: 14px; height: 14px; display: inline-block; vertical-align: -2px;
  border: 2px solid var(--border); border-top-color: var(--accent); border-radius: 50%;
  animation: spin 0.8s linear infinite; margin-right: 8px;
}
@keyframes spin { to { transform: rotate(360deg); } }

.sql-card {
  background: #10141f; border: 1px solid var(--border); border-radius: 10px; overflow: hidden;
}
.card-head { display: flex; justify-content: space-between; align-items: center; padding: 7px 12px; border-bottom: 1px solid var(--border); }
.kbd { font-size: 12px; color: var(--text-dim); background: var(--bg-soft); padding: 2px 8px; border-radius: 4px; }
.copy-btn { font-size: 12px; color: var(--accent); background: transparent; }
.sql-code {
  padding: 12px; font-family: var(--mono); font-size: 13px; color: #9fd0ff;
  overflow-x: auto; white-space: pre-wrap;
}
.meta { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; font-size: 12.5px; }
.tag { background: var(--accent-soft); color: var(--accent); padding: 2px 8px; border-radius: 4px; }
.dim { color: var(--text-dim); }
.meta.warn { color: var(--amber); }

.inputbar {
  display: flex; gap: 10px; padding: 14px 0 18px; align-items: flex-end;
}
.inputbar textarea {
  flex: 1; resize: none; padding: 12px 14px; border-radius: 10px;
  border: 1px solid var(--border); background: var(--bg-card); color: var(--text);
  font-size: 14.5px; min-height: 46px; max-height: 140px;
}
.inputbar textarea:focus { border-color: var(--accent); }
.send { padding: 12px 22px; min-height: 46px; border-radius: 10px; }
</style>