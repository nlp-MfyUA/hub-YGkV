// 与后端交互的轻量封装（axios）。token 保存在 localStorage。

import axios from 'axios'

const client = axios.create({ baseURL: '/api' })

// 请求拦截：自动附带 Authorization
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// 响应拦截：401 时清掉本地 token
client.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('username')
    }
    return Promise.reject(err)
  }
)

export const auth = {
  async login(username, password) {
    const res = await client.post('/auth/login', { username, password })
    localStorage.setItem('token', res.data.token)
    localStorage.setItem('username', res.data.username)
    return res.data
  },
  async register(username, password) {
    const res = await client.post('/auth/register', { username, password })
    localStorage.setItem('token', res.data.token)
    localStorage.setItem('username', res.data.username)
    return res.data
  },
  logout() {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
  },
  isLoggedIn() {
    return Boolean(localStorage.getItem('token'))
  }
}

export const queryApi = {
  async ask(question) {
    const res = await client.post('/query', { question })
    return res.data
  },
  async health() {
    return (await client.get('/health')).data
  },
  async listHistory() {
    return (await client.get('/history')).data
  },
  async clearHistory() {
    return (await client.delete('/history')).data
  }
}