"""免安装启动器：把仓库内的 src/ 加入 sys.path 后调用本项目的 CLI。

用法（在项目根目录执行，Windows PowerShell / git-bash 均可）：
    python run.py "总共有多少张专辑？"

和 `python -m sql_agent ...` 等价，但**不依赖** `pip install -e .`：
即使当前 Python 环境里装了其它同名包（例如 week12 的 langchain 版
`01-sql-agent-langchain`，包名同为 `sql_agent`），也会强制运行本仓库
（01-sql-agent-langgraph）的代码，不会串项目。
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from sql_agent.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
