# SQL Agent 设计文档（LangGraph 版）

> 版本：v0.1（2026-11-03）  \
> 范围：基于 `ref/chinook.db` 的单库、单轮自然语言查询  \
> 定位：`00-sql-agent`（openai-agents）与 LangChain 版的 **LangGraph 复刻**

## 1. 目标

把一条"自然语言 → 可执行 SQL → 中文答案"的流水线，用 **LangGraph `StateGraph`**
显式建模为状态机。核心设计问题不是"用几个 Agent"，而是**哪些步骤交给 LLM，哪些必须
由确定性代码控制**，以及"分支/回环/重试预算"用什么方式表达。

### 非目标（v1）

- 多轮对话、上下文追问
- 多数据库/多方言动态切换
- 写操作（INSERT/UPDATE/DELETE/DDL）
- 完全自主的 Agent 规划（autonomous planning）

## 2. 与上游的框架差异

| 层 | openai-agents / LangChain 版 | LangGraph 版 |
| --- | --- | --- |
| LLM 调用 | `Runner.run(agent,prompt)` / `chain.ainvoke(input)` | 同上（LLM 层不变，复用 LangChain 结构化链） |
| 流程编排 | `workflow._run()` 里手写 `for`/`if`/`while` | **`StateGraph`：节点 + 条件边 + 回边** |
| 共享状态 | 一个 Python `QueryState` 对象 | **`AgentState`（TypedDict），由图在节点间传递** |
| 分支决策 | Python `if` | `_route_*` 路由函数（`add_conditional_edges`） |
| 修复循环 | `for repair_index in range(...)` | **`rewrite_sql → validate_or_execute` 回边** |
| 终止/汇总 | 分支里 `return WorkflowOutput(...)` | 各终点把组装好的 `final_output` 写进状态，`finalize` 收尾 |

设计原则（继承上游 §2）：LLM 只做语义判断；校验/执行是确定性代码；一个节点只做一个
决策；上下文最小化；失败有界（修复回边次数受 `max_repair_attempts` 约束）。

## 3. 图结构（状态机拓扑）

```
START
 │
 ▼
select_tables ── route: clarify ──▶ finalize ──▶ END
 │    └(内部最多重试 1 次)
 │ route: ok
 ▼
generate_sql
 ▼
validate_or_execute ── route: success ──▶ summarize ──▶ finalize ──▶ END
 │    └─ route: exhausted ──▶ finalize ──▶ END
 │    └─ route: repair
 ▼
rewrite_sql ── route: repair ──▶ validate_or_execute   （回边＝修复循环）
 │    └─ route: cannot_fix ──▶ finalize ──▶ END
```

节点与职责：

| 节点 | 类型 | 是否 LLM | 职责 |
| --- | --- | --- | --- |
| `select_tables` | 图节点 | 是 | 选最少表集合；内部最多重试 1 次（非法/不连通表带反馈重选） |
| `generate_sql` | 图节点 | 是 | 基于问题 + 已选表 schema 生成 SQLite SELECT |
| `validate_or_execute` | 图节点 | 否（确定性） | 安全门禁 + `EXPLAIN` 编译校验；通过后只读执行 |
| `rewrite_sql` | 图节点 | 是 | 按精确错误修复 SQL；`cannot_fix` 或预算耗尽则终止 |
| `summarize` | 图节点 | 是 | 结果为空直接回答；否则汇总为中文答案（失败降级为表格） |
| `finalize` | 图节点 | 否 | 终点收尾：打最终日志，透传 `final_output` → `END` |

路由函数（只决策，不改状态）：

| 路由 | 从 | 键 → 目标 |
| --- | --- | --- |
| `_route_select` | `select_tables` | `ok → generate_sql`；`clarify → finalize` |
| `_route_validate` | `validate_or_execute` | `success → summarize`；`exhausted → finalize`；`repair → rewrite_sql` |
| `_route_rewrite` | `rewrite_sql` | `repair → validate_or_execute`（回边）；`cannot_fix → finalize` |

> 关键约定：**终点分支把组装好的 `WorkflowOutput` 写入 `AgentState["final_output"]`**，
> 路由函数只返回键、不写状态（LangGraph 会忽略路由函数对状态的修改）。`finalize` 随后
> 把它们统一汇到 `END`，`run()` 读 `final_output`。

## 4. 数据契约与状态

`AgentState`（TypedDict）字段与 LangChain 版的 `QueryState` 一致，另加两个图专用字段：

```python
class AgentState(TypedDict):
    question: str
    selection: TableSelection | None
    schema_context: str
    sql: str | None
    attempts: list[SQLAttempt]      # 全量覆盖语义（不用 reducer，便于改动最后一项）
    validation: ValidationResult | None
    execution: ExecutionResult | None
    answer: FinalAnswer | None
    repair_attempts: int
    stage: str
    error: str | None
    final_output: WorkflowOutput | None   # ★ 终点节点写，finalize 汇到 END
```

外部契约（`models.py` 的 Pydantic 类）与 LangChain 版逐字节一致：`TableSelection`、
`SQLDraft`、`ValidationResult`、`ExecutionResult`、`SQLAttempt`、`FinalAnswer`、
`WorkflowOutput`。

## 5. 失败与重试（回边预算）

| 场景 | 处理 | 上限/位置 |
| --- | --- | --- |
| 选表返回非法/不连通表 | 带反馈重选 | 节点内部 1 次 |
| 需澄清 / 无相关表 | 终止返回澄清问题 | — |
| SQL 校验失败 / 执行错误 | `rewrite_sql` 修复后经回边回到 `validate_or_execute` | 回边次数 ≤ `max_repair_attempts`（默认 3） |
| 执行超时 | 带 `TIMEOUT` 交给改写 | 共享上述预算 |
| 查询结果为空 | **不回边**，`summarize` 直接回答"未查询到" | — |
| 汇总 LLM 失败 | `summarize` 降级输出 Markdown 表格 | — |

修复预算的判定放在 `validate_or_execute` 节点里：当本次失败且 `repair_attempts` 已
`>= max_repair_attempts`，直接把"已达到最大修复次数"的 `final_output` 写入状态，
`_route_validate` 据此走 `exhausted → finalize`。

## 6. 可观测性

日志默认到 stderr，最终 JSON 到 stdout。每个节点输出 `stage=...` 日志：选表尝试次数、
SQL 生成耗时、校验错误码、执行行数/截断、改写次数与 `cannot_fix`、汇总降级原因、整体耗时。
所有 LLM 链调用、修复与终止路径都有阶段标记。

## 7. 测试

继承上游 21 个测试（无需 API key，LLM 靠 mock）。工作流测试通过替换
`table_selector_chain / sql_generator_chain / sql_rewriter_chain / result_summary_chain`
的 `ainvoke` 来驱动图走不同路径。覆盖：happy path、修复路径（回边）、空结果跳过汇总、
非法表重选、修复预算耗尽。**新增/改动点**：LangGraph 拓扑下必须保证每个到达 `finalize`
的路径都写入了 `final_output`，否则 `run()` 报错（有测试兜底）。

## 8. 实施对照（相对父仓库的改动面）

- **新增**：`src/sql_agent/workflow.py` 的图编排（`AgentState`、节点闭包、路由、`_build_graph`）。
- **复用不改**：`db/`、`agents/`、`models.py`、`config.py`、`cli.py`、`logging_config.py`、`tests/`。
- langgraph 版默认把 `openai-agents` 的 `Runner.run` / langchain 的 Python 手写循环，
  全部抹平成"节点 + 条件边"。
