"""LangChain 模型工厂：统一读取 settings 并懒加载构建结构化输出链。

`ChatOpenAI` 在构造时就会尝试创建 AsyncOpenAI 客户端并校验 API key，
因此不能在模块导入 / 测试收集阶段就构造（否则缺 key 会直接报错）。
API key 来自项目根目录 .env（config.py 已加载），测试用 mock 链、不需要 key。
这里用 LazyStructuredChain 延迟构建：首次 ainvoke 时才真正创建并缓存。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_openai import ChatOpenAI
from pydantic import BaseModel

from ..config import settings

T = TypeVar("T")


class LazyStructuredChain:
    """持有构建逻辑，首次 ainvoke 时才构建并缓存底层 Runnable 链。

    - 无副作用：导入阶段不产生任何网络 / 凭据校验。
    - 进程内复用：同一 chain 只构建一次，之后每次 ainvoke 复用缓存实例。
    - 可被 monkeypatch：直接替换实例的 ainvoke 即可 mock（测试不需要 API key）。
    """

    def __init__(self, builder: Callable[[], Runnable]) -> None:
        self._builder = builder
        self._chain: Runnable | None = None

    def _get(self) -> Runnable:
        if self._chain is None:
            self._chain = self._builder()
        return self._chain

    async def ainvoke(self, inputs: dict) -> T:
        return await self._get().ainvoke(inputs)


def _chat(model: str, temperature: float) -> ChatOpenAI:
    """从 settings 读取 base_url；API key 从 .env / 环境变量读取（config 已加载）。"""
    return ChatOpenAI(
        model=model,
        base_url=settings.base_url,
        api_key=None,
        temperature=temperature,
    )


def structured_chain(
    prompt: ChatPromptTemplate,
    schema: type[BaseModel],
    *,
    model: str | None = None,
    temperature: float = 0.0,
) -> LazyStructuredChain:
    """构造「提示词 + ChatOpenAI + 结构化输出」的懒加载链。

    - model 缺省时使用 settings.primary_model；汇总阶段应显式传 summary_model。
    - temperature 对应原 openai-agents 版的 ModelSettings(temperature=...)。
    """

    def builder() -> Runnable:
        # DeepSeek 兼容端点不支持 response_format(json_schema)，用 json_mode 结构化输出。
        # json_mode 要求 prompt 里出现 "json" 字样（由各 agent 系统提示保证），
        # 返回的 JSON 再被 Pydantic 解析为 schema 实例。
        return prompt | _chat(model or settings.primary_model, temperature).with_structured_output(
            schema, method="json_mode"
        )

    return LazyStructuredChain(builder)
