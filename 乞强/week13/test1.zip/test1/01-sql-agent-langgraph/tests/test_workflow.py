import asyncio
from pathlib import Path

import pytest

import sql_agent.workflow as workflow_module
from sql_agent.config import settings
from sql_agent.db.catalog import SchemaCatalog
from sql_agent.db.executor import SQLExecutor
from sql_agent.db.validator import SQLValidator
from sql_agent.models import FinalAnswer, SQLDraft, TableSelection
from sql_agent.workflow import SQLAgentWorkflow


def _patch_chain(monkeypatch, chain_name, outputs):
    """把某个 chain.ainvoke 替换为返回预置结果的 fake。

    注意：fake 挂到的是实例属性，Python 不会把它绑定成方法，
    所以签名只接收 inputs（不含 self）。
    """
    calls = []

    async def fake_ainvoke(inputs, **kwargs):
        calls.append(inputs)
        return outputs[len(calls) - 1]

    chain = getattr(workflow_module, chain_name)
    monkeypatch.setattr(chain, "ainvoke", fake_ainvoke)
    return calls


@pytest.fixture(scope="module")
def workflow() -> SQLAgentWorkflow:
    catalog = SchemaCatalog(Path("ref/chinook.db"))
    return SQLAgentWorkflow(
        catalog=catalog,
        validator=SQLValidator(catalog.db_path),
        executor=SQLExecutor(catalog.db_path),
    )


def test_happy_path(workflow: SQLAgentWorkflow, monkeypatch) -> None:
    # table 1, gen 1, summary 1
    table_calls = _patch_chain(
        monkeypatch,
        "table_selector_chain",
        [TableSelection(tables=["albums"], reason="统计专辑数量", confidence=0.9)],
    )
    gen_calls = _patch_chain(
        monkeypatch,
        "sql_generator_chain",
        [SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="count")],
    )
    _patch_chain(
        monkeypatch,
        "result_summary_chain",
        [FinalAnswer(answer="共 347 张专辑。", evidence=["347"])],
    )

    result = asyncio.run(workflow.run("总共有多少张专辑？"))

    assert result.error is None
    assert result.tables == ["albums"]
    assert result.row_count == 1
    assert result.answer == "共 347 张专辑。"
    assert len(table_calls) == 1
    assert len(gen_calls) == 1


def test_rewrite_path(workflow: SQLAgentWorkflow, monkeypatch) -> None:
    _patch_chain(
        monkeypatch,
        "table_selector_chain",
        [TableSelection(tables=["albums"], reason="统计专辑数量", confidence=0.9)],
    )
    _patch_chain(
        monkeypatch,
        "sql_generator_chain",
        [SQLDraft(sql="SELECT COUNT(ArtistId FROM albums", explanation="bad")],
    )
    # rewrite 返回修复后的 SQL
    _patch_chain(
        monkeypatch,
        "sql_rewriter_chain",
        [SQLDraft(sql="SELECT COUNT(ArtistId) AS n FROM albums", explanation="fixed")],
    )
    _patch_chain(
        monkeypatch,
        "result_summary_chain",
        [FinalAnswer(answer="共有 275 位艺人。", evidence=["275"])],
    )

    result = asyncio.run(workflow.run("专辑里有多少位不同的艺人？"))

    assert result.repair_attempts == 1
    assert result.error is None
    assert "COUNT(ArtistId)" in (result.sql or "")


def test_empty_result_skips_summary_agent(workflow: SQLAgentWorkflow, monkeypatch) -> None:
    table_calls = _patch_chain(
        monkeypatch,
        "table_selector_chain",
        [TableSelection(tables=["albums"], reason="查不存在的专辑", confidence=0.9)],
    )
    gen_calls = _patch_chain(
        monkeypatch,
        "sql_generator_chain",
        [SQLDraft(sql="SELECT * FROM albums WHERE AlbumId = -1", explanation="empty")],
    )

    result = asyncio.run(workflow.run("编号为 -1 的专辑是什么？"))

    assert result.row_count == 0
    assert result.answer == "未查询到符合条件的数据。"
    assert len(table_calls) == 1
    assert len(gen_calls) == 1


def test_unknown_table_is_rejected(workflow: SQLAgentWorkflow, monkeypatch) -> None:
    # 第 1 次选出非法表，第 2 次选出合法表
    _patch_chain(
        monkeypatch,
        "table_selector_chain",
        [
            TableSelection(tables=["not_a_table"], reason="bad", confidence=0.1),
            TableSelection(tables=["albums"], reason="fixed", confidence=0.9),
        ],
    )
    _patch_chain(
        monkeypatch,
        "sql_generator_chain",
        [SQLDraft(sql="SELECT COUNT(*) AS n FROM albums", explanation="count")],
    )
    _patch_chain(
        monkeypatch,
        "result_summary_chain",
        [FinalAnswer(answer="共 347 张专辑。", evidence=["347"])],
    )

    result = asyncio.run(workflow.run("总共有多少张专辑？"))

    assert result.error is None
    assert result.tables == ["albums"]


def test_max_repair_attempts_returns_error(monkeypatch) -> None:
    catalog = SchemaCatalog(Path("ref/chinook.db"))
    workflow = SQLAgentWorkflow(
        catalog=catalog,
        validator=SQLValidator(catalog.db_path),
        executor=SQLExecutor(catalog.db_path),
        max_repair_attempts=0,
    )
    _patch_chain(
        monkeypatch,
        "table_selector_chain",
        [TableSelection(tables=["albums"], reason="bad sql", confidence=0.9)],
    )
    _patch_chain(
        monkeypatch,
        "sql_generator_chain",
        [SQLDraft(sql="SELECT nope FROM albums", explanation="bad")],
    )

    result = asyncio.run(workflow.run("测试失败路径"))

    assert result.error is not None
    assert result.repair_attempts == 0
    assert "最大修复次数" in result.answer


def test_settings_db_path_exists() -> None:
    assert settings.db_path.exists()
