# 01-sql-agent-langgraph

基于 **LangGraph** 框架实现的 SQL Agent：输入一句自然语言问题，自动完成
**选表 → 生成 SQL → 校验/执行 → 修复 → 汇总**，最终返回中文答案与可执行 SQL。
底层数据库是 [Chinook](https://www.sqlitetutorial.net/sqlite-sample-database/)（SQLite，只读）。

本项目是 `00-sql-agent`（openai-agents 实现）与 `01-sql-agent-langchain`（LangChain 实现）
的 **LangGraph 复刻**：确定性组件与四个 LLM 结构化输出链保持一致，区别在于——
流程编排（分支、回环、重试预算）从 Python 手写控制流改写为 **显式的 `StateGraph` 状态机**。

## 框架对照

| 维度 | `00-sql-agent`（openai-agents） | LangChain 版 | 本仓库（LangGraph） |
| --- | --- | --- | --- |
| 编排方式 | `Runner.run(agent, prompt)` + Python 代码控制 | `chain.ainvoke(...)` + Python 代码控制 | **`StateGraph` 节点 + `add_conditional_edges`** |
| 选表/生成/改写/汇总 | 四个 `Agent` | 四个 `Runnable` 链 | 四个**图节点**（内部调用同一套 LangChain 链） |
| 修复循环 | `for` 循环 + `if/else` | `for` 循环 + `if/else` | **图回边**（`validate_or_execute → rewrite_sql → validate_or_execute`） |
| 分支决策 | Python `if` | Python `if` | **路由函数**（`_route_select` / `_route_validate` / `_route_rewrite`） |
| 共享上下文 | Python 对象 | Python 对象 | **`AgentState`（TypedDict），节点之间通过图状态传递** |

> 一句话：**逻辑不变，控制流交给 LangGraph**。`db/`（catalog/validator/executor）与 `agents/`
> （四个 LLM 链）两个模块从参考项目原样复用，仅新增/改造了 `workflow.py` 这一层。

## 图结构

```
START
 │
 ▼
select_tables ──路由(失败重试/需澄清)──▶ finalize ──▶ END
 │ 选定表
 ▼
generate_sql
 │
 ▼
validate_or_execute ──成功──▶ summarize ──▶ finalize ──▶ END
 │ 失败且预算未耗尽
 ▼
rewrite_sql ──修复──▶ validate_or_execute   （回边，最多 max_repair_attempts 次）
 │ 无法修复
 ▼
finalize ──▶ END
```

- `select_tables`：内部最多重试一次（非法表名/不连通表会带反馈重选）。
- `validate_or_execute`：先做安全门禁 + `EXPLAIN` 编译校验，通过后只读执行。
- `rewrite_sql`：根据精确错误修复 SQL；修复预算耗尽或 `cannot_fix` 时终止。
- `summarize`：结果为空时不调 LLM，直接返回“未查询到符合条件的数据”；否则汇总为中文答案。

## 目录结构

```
01-sql-agent-langgraph/
├── pyproject.toml            # 项目元数据 + 依赖（langgraph / langchain / sqlalchemy / python-dotenv）
├── .env                      # ★ 你的 API key / base_url（私有，不入库）
├── .env.example              # ★ 环境变量模板：复制为 .env 并填入你的 key
├── AGENTS.md                 # 框架对照与改代码约定（协作者/LLM 先读它）
├── readme.md                 # 本文件
├── run.py                    # ★ 免安装启动器：python run.py "问题"（强制用本仓库 src/）
├── sql-agent.bat             # ★ Windows 启动器：.\sql-agent.bat "问题"（免安装）
├── 项目使用说明.md            # 详细使用说明（环境/安装/配置/CLI/测试/FAQ）
├── docs/
│   └── agent-design.md       # 设计文档：Agent 划分、数据契约、LangGraph 状态机
├── ref/
│   ├── chinook.db            # 被查询的样例数据库（只读）
│   ├── agent-demo.py         # 参考 demo（openai-agents 风格，同样从 .env 读 key）
│   └── sql-agent.ipynb       # 参考 notebook（行为参考）
├── src/
│   └── sql_agent/
│       ├── cli.py            # 命令行入口（main）
│       ├── __main__.py       # 支持 python -m sql_agent
│       ├── config.py         # 模型 / 端点 / 超时 / 路径配置（内含 .env 加载）
│       ├── models.py         # Pydantic 数据契约 + AgentState
│       ├── logging_config.py #
│       ├── workflow.py       # ★ LangGraph StateGraph 编排（核心改动）
│       ├── db/               # 确定性组件：catalog / validator / executor
│       └── agents/           # 四个 LangChain 结构化输出链（节点内部调用）
└── tests/                    # 21 个单元/工作流测试（无需 API key，LLM 全部 mock）
```

## 快速开始

```bash
# 1) 进入项目根目录
cd 01-sql-agent-langgraph

# 2) 安装（推荐 editable，保证任意目录可 import）
python -m pip install -e .

# 3) 配置 API key：复制 .env.example 为 .env 并填入你的 key（代码自动读取）
cp .env.example .env   # 然后编辑 .env，填入 OPENAI_API_KEY
# 或用环境变量覆盖 .env：
export OPENAI_API_KEY="sk-..."
export OPENAI_BASE_URL="https://api.deepseek.com"

# 4) 运行（入口任选其一）
python run.py "总共有多少张专辑？"       # ★ 免安装启动器：任何环境/任何目录直接跑
# PowerShell 下等价写法：.\sql-agent.bat "总共有多少张专辑？"
# 以下两个入口需要先在本环境 python -m pip install -e .：
# sql-agent "总共有多少张专辑？"
# python -m sql_agent "总共有多少张专辑？"

# 5) 运行测试（无需 API key）
python -m pytest -q   # 预期：21 passed
```

## 运行链路

```
自然语言问题 → select_tables（选表，可重试1次）
  → generate_sql（生成 SQL）
  → validate_or_execute（安全门禁 + EXPLAIN + 只读执行）
  → 失败 → rewrite_sql（修复，回边，最多3次）→ 回 validate_or_execute
  → 成功 → summarize（中文汇总）→ finalize（组装 WorkflowOutput JSON）
```

## 日志与输出约定

- 日志（含每次 LLM 调用、校验、修复）打到 **stderr**；
- 最终结果 JSON（`WorkflowOutput`）打到 **stdout**，便于管道处理；
- 所有 LLM 调用都有日志（`stage=...`），修复与终止路径都有明确标记。

## 测试说明

测试无需 API key —— LLM 会被 mock（替换 `table_selector_chain / sql_generator_chain /
sql_rewriter_chain / result_summary_chain` 的 `ainvoke`）。21 个测试覆盖：

- catalog 解析（11 张业务表、外键连接图）
- SQL 校验（安全门禁、EXPLAIN、归一化）
- SQL 执行（只读、行数截断、超时映射）
- 工作流 happy path / 修复路径 / 空结果跳过汇总 / 非法表重选 / 修复预算耗尽

## 常见问题

| 问题 | 原因 | 解决 |
| --- | --- | --- |
| `No module named 'sql_agent'` | src-layout，未加入搜索路径 | `python -m pip install -e .` |
| `sql-agent` 不是内部或外部命令 / CommandNotFoundException | 当前环境（如 PowerShell 的 `base`）没装本项目 | ① `conda activate py312` 后 `pip install -e .`；② 或直接 `python run.py "…"`（PowerShell：`.\sql-agent.bat "…"`） |
| 跑出来却是 week12 的 langchain 项目 | `py312` 里两个同名 `sql_agent` 包（week12 + 本仓库）editable 并存，裸跑解析到旧项目 | 用启动器 `python run.py` / `.\sql-agent.bat`（强制本仓库 `src/`），或卸载 week12 的 editable 安装 |
| 提示缺少 OPENAI_API_KEY | 环境变量未设，`.env` 也不存在 | 复制 `.env.example` 为 `.env` 并填 key，或 `export OPENAI_API_KEY=...` |
| 401 Authentication Fails | API key 无效/过期 | 在 `.env` 里换成自己的有效 key |
| 中文乱码 | Windows 终端编码 | `chcp 65001` 或使用支持 UTF-8 的终端 |

## 参考

- 设计文档：`docs/agent-design.md`
- 详细使用说明：`项目使用说明.md`
- 上游实现：`00-sql-agent`（openai-agents）、langchain 版（`01-sql-agent-langchain`）
