@echo off
rem No-install launcher. Equivalent to the `sql-agent` console script but
rem requires NO `pip install -e .`. Always runs THIS repo via run.py
rem (prepends this project's src/ to sys.path, so it never resolves to the
rem week12 langchain project even though both install under package `sql_agent`).
rem
rem Usage (run from the project root, in PowerShell/CMD):
rem     .\sql-agent.bat "总共有多少张专辑？"
rem
rem Prefers the local py312 env (dependencies already installed); otherwise
rem falls back to `python` on PATH.
setlocal
set "ROOT=%~dp0"
set "PY=python"
if exist "D:\badou\anaconda\install\envs\py312\python.exe" set "PY=D:\badou\anaconda\install\envs\py312\python.exe"
"%PY%" "%ROOT%run.py" %*
