# Sentiment Agent Demo

用 **LangGraph** 与 **OpenAI Agents SDK** 分别实现同一套“情感识别 → 分支回应”逻辑，形成可对比、可运行的开发参考项目。两个版本共用同一套 HTTP 接口契约，前端无感切换。

## 业务逻辑

用户输入一段文本，系统完成两个步骤：

1. **情感识别**：判断情感极性（`positive` / `negative` / `neutral`）。
2. **分支回应**：
   - 正向 → 生成**鼓励性**回复；
   - 负面 → 生成**排解性**回复；
   - 中性 → 生成**中性承接**回复（兜底分支）。

用户感知到的最终输出是“一句针对其情感状态的回应”。前端会在回复前附上 `[情感标签]`，便于演示观察。

## 目录结构

```
sentiment-agent-demo/
├── backend/                    # 完整 Python 后端工程
│   ├── app/
│   │   ├── __init__.py
│   │   ├── llm.py              # 公共 LLM 配置 + Sentiment 枚举（含 .env 加载）
│   │   ├── main.py             # FastAPI 入口，串联前端与编排层
│   │   ├── schemas.py          # Pydantic 请求/响应模型
│   │   ├── frontend.py         # Gradio 前端（可选，见“启动方式”）
│   │   ├── langgraph_impl/
│   │   │   ├── __init__.py
│   │   │   ├── graph.py        # StateGraph 定义、节点、条件边
│   │   │   └── state.py        # 状态 TypedDict
│   │   └── agents_impl/
│   │       ├── __init__.py
│   │       └── agents.py       # Agents SDK 定义、handoff 配置
│   ├── tests/
│   │   ├── test_langgraph.py
│   │   └── test_agents.py
│   ├── .env                    # 环境变量配置（由 python-dotenv 自动加载）
│   ├── requirements.txt        # Python 依赖
│   └── CLAUDE.md               # 后端工程指引
├── frontend/                   # Vue 3 + Vite 前端工程
│   ├── package.json            # npm 脚本：dev / build / preview
│   ├── vite.config.js          # 端口 5173，将 /chat 代理到后端 8000
│   └── src/
│       ├── main.js / App.vue
│       └── components/ChatView.vue   # 聊天界面，调用 POST /chat
├── README.md
└── CLAUDE.md
```

## 启动方式

需要 **三样东西**：后端（FastAPI）、前端（任选其一）、以及一个可用的 `OPENAI_API_KEY`。

### 0. 配置环境变量

后端从 `backend/.env` 自动加载配置（本仓库已带模板，内含占位值）。**填入你的 API Key：**

```
# backend/.env
OPENAI_API_KEY=sk-你的真实key
OPENAI_BASE_URL=               # 可选：代理/国产模型 base URL
LLM_MODEL=gpt-4o-mini           # 可选
FRAMEWORK=langgraph             # langgraph | agents_sdk
BACKEND_URL=http://127.0.0.1:8000
```

> 环境变量也可通过系统环境变量覆盖（操作系统环境变量的优先级更高，`load_dotenv` 默认不覆盖已存在的变量）。

### 0. 安装依赖

```bash
# 后端 Python 依赖（在 backend/ 内安装；requirements.txt 与《项目开发文档.md》§11 保持一致）
# 注：跑测试需额外安装 pytest；走 OPENAI_BASE_URL 代理模型时需额外安装 litellm
pip install -r requirements.txt
pip install pytest litellm

# 前端 Node 依赖（只需 Vue 前端时执行；从项目根目录）
cd frontend
npm install
```

### 1. 启动后端（FastAPI，端口 8000）

后端代码在 `backend/` 内，**从 `backend/` 目录启动**：

```bash
cd backend

# 配置已由 backend/.env 自动加载（若未填 .env，也可用系统环境变量覆盖）
uvicorn app.main:app --reload --port 8000
```

切换框架：修改 `backend/.env` 中 `FRAMEWORK=agents_sdk`（或 export FRAMEWORK 覆盖），重启后端。

### 2. 启动前端（二选一）

**方式 A —— Vue 3 + Vite 前端（推荐）：**

```bash
cd frontend
npm run dev        # 打开 http://localhost:5173
```

Vite 开发服务器会把 `/chat` 代理到后端 `http://127.0.0.1:8000`。

生产构建/预览：

```bash
npm run build      # 产物输出到 frontend/dist/
npm run preview    # 本地预览生产构建
```

**方式 B —— Gradio 前端（若不想用 Node）：**

```bash
cd backend
python -m app.frontend        # 打开 http://127.0.0.1:7860
```

> 两种前端共用同一个后端 `POST /chat`，不感知底层是 LangGraph 还是 Agents SDK。

### 3. 验证

浏览器打开前端，依次输入三个示例：

- `今天项目上线了，特别开心！` → 期望 `[正向]` + 鼓励回复
- `最近压力很大，感觉撑不下去了。` → 期望 `[负面]` + 排解回复
- `明天要去开一个普通的周会。` → 期望 `[中性]` + 中性承接

切换框架只需把 `FRAMEWORK` 改为 `agents_sdk` 并重启后端，前端无需任何改动。

## 接口契约

`POST /chat`：

```bash
输入：{"message": "今天被领导批评了，心情很差"}
输出：{"reply": "...", "sentiment": "negative", "framework": "langgraph"}
```

后端**只暴露这一个端点**（见《项目开发文档.md》§2.3）。
`framework` 字段标识本次回复由哪个实现产出（`langgraph` / `agents_sdk`）。

## 测试

```bash
cd backend
python -m pytest tests/ -v
```

测试是**离线确定性**的——通过 patch 替换 LLM / Runner，不触网、无需 API key，即可验证两类实现的分支路由逻辑。LangGraph 版本直接对 `detect_sentiment` 节点做打桩测试；Agents SDK 版本 patch `Runner.run`，验证从最终 Agent 名称反推情感标签的提取逻辑。

## 环境变量

这些变量默认从 `backend/.env` 读取（由 `app/llm.py`、`app/main.py`、`app/frontend.py` 顶部的 `load_dotenv` 自动加载）；系统环境变量可覆盖 `.env`。

| 变量 | 必填 | 默认 | 说明 |
|---|---|---|---|
| `OPENAI_API_KEY` | 是 | — | LLM API Key |
| `OPENAI_BASE_URL` | 否 | — | 兼容接口的 base URL，用于代理或国产模型 |
| `LLM_MODEL` | 否 | `gpt-4o-mini` | 模型 id |
| `FRAMEWORK` | 否 | `langgraph` | `langgraph` 或 `agents_sdk`，后端启动时读取 |
| `BACKEND_URL` | 否 | `http://127.0.0.1:8000` | Gradio 前端调用后端地址；Vue 前端改用 `VITE_BACKEND_URL` 在 `vite.config.js` 里配置代理目标 |

## 两套实现的关键对比

| 维度 | LangGraph 版本 | OpenAI Agents SDK 版本 |
|---|---|---|
| 控制流 | 显式状态图，节点与边静态可读 | 路由由 LLM 在运行时通过 handoff 决策 |
| 状态管理 | `TypedDict` 状态在节点间显式传递 | Agent 无状态，上下文由 SDK 循环管理 |
| 情感标签确定性 | 节点内显式解析，标签写入状态 | 默认不暴露；本项目用最终 Agent 名称反推 |
| 可观测性 | 图结构本身可读 | 依赖 SDK 的 tracing |
| 适用场景 | 流程确定性要求高 | 快速搭建、交接式多 Agent 协作 |

详细设计思路、节点/Agent 实现与扩展建议见 `../项目开发文档.md`。
