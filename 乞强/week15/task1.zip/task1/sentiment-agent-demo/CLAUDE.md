# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this project is

A comparison demo of the same business logic — **情感识别 → 分支回应** (sentiment recognition → branched response) — implemented twice:

- **Version A** (`backend/app/langgraph_impl/`): explicit `StateGraph` for LangGraph. Control flow is static and visible (nodes = functions, conditional edge = routing).
- **Version B** (`backend/app/agents_impl/`): OpenAI Agents SDK, **handoff** pattern. Routing is decided by the LLM at runtime via handoff tools.

Both share one HTTP contract (`backend/app/schemas.py`). There are **two interchangeable frontends**: a Vue 3 + Vite app in `frontend/` (the primary one) and the Gradio `backend/app/frontend.py` (Node-free fallback). The framework is switched at backend startup via the `FRAMEWORK` env var — the frontends never know which implementation is running. The authoritative design rationale (four-process division, framework comparison, production directions) is in `../项目开发文档.md`.

Business flow per user input:
1. Detect polarity: `positive` / `negative` / `neutral` (fallback default).
2. Branch response: positive → encourage, negative → soothe, neutral → acknowledge.

## Layout

```
sentiment-agent-demo/
├── backend/                    # complete Python backend project — read backend/CLAUDE.md
│   ├── app/                    # llm.py, schemas.py, main.py, frontend.py, langgraph_impl/, agents_impl/
│   ├── tests/                  # test_langgraph.py, test_agents.py
│   ├── .env                    # env config, auto-loaded via python-dotenv
│   ├── requirements.txt
│   └── CLAUDE.md
├── frontend/                   # Vue 3 + Vite app (primary frontend)
│   ├── vite.config.js          # port 5173; proxies /chat → backend 8000
│   └── src/components/ChatView.vue   # chat UI calling POST /chat
├── README.md
└── CLAUDE.md                   # this file
```

**Key rule for every Python command**: run it from `backend/`. The Python packages (`app`, `tests`) live there, so `uvicorn`, `pytest`, and `python -m app.frontend` all assume `backend/` as the working directory. Frontend commands run from `frontend/`.

## Commands

```bash
# Backend: tests (offline, deterministic — no API key needed)
cd backend
python -m pytest tests/ -v

# Backend: serve FastAPI (config comes from backend/.env)
cd backend
uvicorn app.main:app --reload --port 8000

# Frontend A (Vue 3 + Vite, recommended — separate terminal)
cd frontend
npm install                           # first time only
npm run dev                           # opens http://localhost:5173

# Frontend B (Gradio, Node-free — separate terminal)
cd backend
python -m app.frontend                # opens http://127.0.0.1:7860

# Install deps
pip install -r backend/requirements.txt
pip install pytest litellm     # extras: pytest for tests; litellm for OPENAI_BASE_URL proxy path
```

**Vite proxy**: `frontend/vite.config.js` proxies `/chat` to `http://127.0.0.1:8000` (default), so the Vue app calls relative paths and FastAPI needs no CORS middleware. The target can be overridden with the `VITE_BACKEND_URL` env var. Note Vite dev binds to `localhost:5173` — access it via `localhost`, not `127.0.0.1`. Static builds (`npm run build`) are NOT proxied, so a production deploy must serve `frontend/dist/` behind a reverse proxy or configure CORS + an absolute backend URL.

There is no linter/formatter config in this repo. Run backend tests from `backend/` so `app` resolves as a package.

## Pointers

- **Backend architecture, design decisions, and testing approach**: see `backend/CLAUDE.md` (shared contract, `_LazyLLM`, version-B label inference, offline test strategy).
- **Environment variables**: default from `backend/.env`, auto-loaded by `python-dotenv` (`load_dotenv(find_dotenv(usecwd=False))` at the top of `app/llm.py`, `app/main.py`, `app/frontend.py`); OS env vars override `.env`.
- **Frontend**: see `frontend/README.md`.
- **Spec**: `../项目开发文档.md` is the authoritative design document.
