# Sentiment Agent 前端（Vue 3 + Vite）

面向后端 `POST /chat` 的单页聊天界面：输入文本 → 识别情感 → 按情感分支生成回应，回复前附情感标签与所用框架名。

## 启动方式

前置要求：后端 FastAPI 已启动（见项目根目录 README），端口默认 `8000`。

```bash
npm install      # 首次安装依赖
npm run dev      # 开发服务器，打开 http://localhost:5173
```

开发模式下 Vite 把 `/chat` 代理到后端 `http://127.0.0.1:8000`（后端只暴露这一个端点），无需配置 CORS。若后端端口不同，可设置环境变量 `VITE_BACKEND_URL` 后重启 dev server。

```bash
npm run build    # 生产构建，产物输出到 frontend/dist/
npm run preview  # 本地预览生产构建
```

> 注意：访问开发服务器请用 `http://localhost:5173`（Vite 默认绑定 localhost）。生产构建产物是纯静态文件，不携带代理，部署时需用反代指向后端（或改为直接调用绝对后端地址）。

## 文件说明

- `vite.config.js` — 端口 5173，代理配置
- `src/main.js` / `src/App.vue` — 应用入口
- `src/components/ChatView.vue` — 聊天界面与接口调用
- `src/style.css` — 全局样式
