import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Dev server 把 /chat 代理到后端 FastAPI（后端只暴露这一个端点，§2.3）
export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    proxy: {
      '/chat': {
        target: process.env.VITE_BACKEND_URL || 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
})
