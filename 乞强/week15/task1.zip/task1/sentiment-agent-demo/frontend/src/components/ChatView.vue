<script setup>
import { ref, nextTick } from 'vue'

// 浏览器同源走 Vite 代理 /chat，可直接相对路径；
// 前端与后端通过 HTTP 解耦，不感知底层是 LangGraph 还是 Agents SDK。
const BASE = '/chat'

const messages = ref([])     // { role: 'user' | 'assistant', content, sentiment?, framework? }
const input = ref('')
const sending = ref(false)
const error = ref('')
const chatList = ref(null)

const examples = [
  '今天项目上线了，特别开心！',
  '最近压力很大，感觉撑不下去了。',
  '明天要去开一个普通的周会。',
]

const sentimentLabel = {
  positive: '正向',
  negative: '负面',
  neutral: '中性',
}

const sentimentClass = {
  positive: 'tag-positive',
  negative: 'tag-negative',
  neutral: 'tag-neutral',
}

function pushMessage(msg) {
  messages.value.push(msg)
  nextTick(() => {
    chatList.value?.scrollTo({ top: chatList.value.scrollHeight, behavior: 'smooth' })
  })
}

async function send() {
  const text = input.value.trim()
  if (!text || sending.value) return

  error.value = ''
  pushMessage({ role: 'user', content: text })
  input.value = ''
  sending.value = true

  // 多轮对话：把当前消息之前的所有轮次作为 history 传给后端，
  // 后端据此拼接上下文，让模型感知历史、做出连贯回应。
  const history = messages.value.slice(0, -1).map(m => ({
    role: m.role === 'user' ? 'user' : 'assistant',
    content: m.content,
  }))

  try {
    const resp = await fetch(BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, history }),
    })
    if (!resp.ok) {
      const body = await resp.json().catch(() => ({}))
      throw new Error(body?.detail || `请求失败（HTTP ${resp.status}）`)
    }
    const data = await resp.json()
    pushMessage({
      role: 'assistant',
      content: data.reply,
      sentiment: data.sentiment,
      framework: data.framework,
    })
  } catch (e) {
    error.value = e.message || '网络错误，请检查后端是否已启动。'
    pushMessage({ role: 'assistant', content: '（请求失败，请稍后再试）' })
  } finally {
    sending.value = false
  }
}

function useExample(text) {
  input.value = text
}
</script>

<template>
  <div class="chat-page">
    <header class="chat-header">
      <h1>情感回应助手</h1>
      <p>输入一段文字，系统识别情感并给出对应回应。</p>
    </header>

    <main ref="chatList" class="chat-list">
      <div v-if="messages.length === 0" class="chat-empty">
        <p>快来试试吧：</p>
        <ul>
          <li v-for="ex in examples" :key="ex">
            <button class="example-btn" @click="useExample(ex)">{{ ex }}</button>
          </li>
        </ul>
      </div>

      <div
        v-for="(m, i) in messages"
        :key="i"
        class="msg"
        :class="m.role === 'user' ? 'msg-user' : 'msg-assistant'"
      >
        <div class="bubble">
          <template v-if="m.role === 'assistant'">
            <span v-if="m.sentiment" class="tag" :class="sentimentClass[m.sentiment]">
              {{ sentimentLabel[m.sentiment] || m.sentiment }}
            </span>
            <span v-if="m.framework" class="framework">{{ m.framework }}</span>
          </template>
          <div class="content">{{ m.content }}</div>
        </div>
      </div>

      <p v-if="sending" class="typing">正在思考中…</p>
    </main>

    <footer class="chat-footer">
      <p v-if="error" class="error">{{ error }}</p>
      <div class="input-row">
        <input
          v-model="input"
          type="text"
          placeholder="说点什么…"
          @keyup.enter="send"
          :disabled="sending"
        />
        <button @click="send" :disabled="sending || !input.trim()">发送</button>
      </div>
    </footer>
  </div>
</template>

<style scoped>
.chat-page {
  height: 100%;
  max-width: 720px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
}

.chat-header {
  padding: 18px 20px 10px;
}
.chat-header h1 {
  margin: 0;
  font-size: 1.35rem;
}
.chat-header p {
  margin: 6px 0 0;
  color: #646a73;
  font-size: 0.9rem;
}

.chat-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.chat-empty {
  color: #646a73;
  text-align: center;
  margin-top: 12%;
}
.chat-empty ul {
  list-style: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: center;
}
.example-btn {
  background: #fff;
  border: 1px solid #d0d3d6;
  border-radius: 999px;
  padding: 6px 14px;
  cursor: pointer;
  color: #3370ff;
}
.example-btn:hover {
  background: #f0f5ff;
}

.msg {
  display: flex;
}
.msg-user {
  justify-content: flex-end;
}
.msg-assistant {
  justify-content: flex-start;
}
.bubble {
  max-width: 78%;
  padding: 10px 14px;
  border-radius: 12px;
  background: #ffffff;
  border: 1px solid #e5e6e8;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
  line-height: 1.55;
}
.msg-user .bubble {
  background: #3370ff;
  color: #fff;
  border: none;
}
.content {
  white-space: pre-wrap;
  word-break: break-word;
}

.tag {
  display: inline-block;
  margin-right: 6px;
  padding: 1px 8px;
  border-radius: 999px;
  font-size: 0.75rem;
}
.tag-positive {
  background: #e8f7ef;
  color: #3bbf7a;
}
.tag-negative {
  background: #fef0f0;
  color: #e5484d;
}
.tag-neutral {
  background: #f0f1f3;
  color: #6b7075;
}
.framework {
  font-size: 0.75rem;
  color: #a0a4ab;
  margin-right: 4px;
}

.typing {
  color: #a0a4ab;
  font-size: 0.85rem;
  text-align: center;
}

.chat-footer {
  padding: 10px 20px 18px;
}
.error {
  color: #e5484d;
  font-size: 0.85rem;
  margin: 0 0 6px;
}
.input-row {
  display: flex;
  gap: 8px;
}
.input-row input {
  flex: 1;
  padding: 10px 14px;
  border: 1px solid #d0d3d6;
  border-radius: 10px;
  outline: none;
  font-size: 0.95rem;
}
.input-row input:focus {
  border-color: #3370ff;
}
.input-row button {
  padding: 10px 20px;
  border: none;
  border-radius: 10px;
  background: #3370ff;
  color: #fff;
  cursor: pointer;
  font-size: 0.95rem;
}
.input-row button:disabled {
  background: #a9c0f7;
  cursor: not-allowed;
}
</style>
