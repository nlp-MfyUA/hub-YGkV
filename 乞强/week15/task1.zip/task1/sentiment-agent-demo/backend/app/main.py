"""后端进程：FastAPI 串联前端与编排层。

对外**只暴露 POST /chat 一个端点**（见《项目开发文档.md》§2.3 统一接口契约）。
通过 FRAMEWORK 环境变量在 LangGraph / Agents SDK 两个实现之间切换，前端无感。

v1.1 支持多轮对话：history 默认为空（单轮），前后端传历史时自动带上。
"""
import os

from dotenv import find_dotenv, load_dotenv
from fastapi import FastAPI

# 与 app/llm.py 一致：自动加载 backend/.env（幂等，此处显式加载一次便于阅读）。
load_dotenv(find_dotenv(usecwd=False))

from app.schemas import ChatRequest, ChatResponse
from app.langgraph_impl.graph import run_langgraph
from app.agents_impl.agents import run_agents_sdk

app = FastAPI(title="Sentiment Agent Demo")

# 通过环境变量切换框架，默认 langgraph
FRAMEWORK = os.getenv("FRAMEWORK", "langgraph")


def _history(req: ChatRequest):
    """把 Pydantic 的 ChatMessage 列表转成纯 dict 列表，便于两种编排层复用。"""
    return [{"role": m.role, "content": m.content} for m in req.history]


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    history = _history(req)
    if FRAMEWORK == "agents_sdk":
        result = await run_agents_sdk(req.message, history=history)
    else:
        result = run_langgraph(req.message, history=history)

    return ChatResponse(**result)
