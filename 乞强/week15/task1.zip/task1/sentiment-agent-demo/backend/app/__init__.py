"""Sentiment Agent Demo 应用包。"""

from app.llm import Sentiment
