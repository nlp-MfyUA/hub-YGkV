"""LangGraph 版本的状态定义（《项目开发文档.md》§4.2）。

用一个显式 TypedDict 状态贯穿全程：原始输入、情感标签、最终回复。
v1.1 起支持多轮对话：新增 history 字段，保存本轮之前的所有轮次，
响应节点据此拼接上下文，使模型能做出连贯回应。
"""

from typing import TypedDict, Literal

class SentimentState(TypedDict):
    user_input: str
    history: list[dict]  # 本轮之前的历史：[{"role": "user"/"assistant", "content": str}, ...]；单轮为空
    sentiment: Literal["positive", "negative", "neutral"]
    reply: str
