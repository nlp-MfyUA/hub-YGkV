"""LangGraph 版本：显式状态图实现"情感识别 → 分支回应"。

节点是函数、边是路由、状态在节点间传递。与 Agents SDK 版本相比，这里把控制流
完全显式化：StateGraph 的结构静态可读，每一步都可 trace、可检查点。

v1.1 支持多轮对话：history 作为上下文，在情感分类与分支回复节点中被拼接到
消息列表里，使模型感知之前的轮次、做出连贯回应。
"""
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END

from app.langgraph_impl.state import SentimentState
from app.llm import LLM_MODEL, OPENAI_API_KEY, OPENAI_BASE_URL


class _LazyLLM:
    """延迟构造 ChatOpenAI：模块导入时不校验凭证，首次 invoke 时才发起连接。

    好处：不设 OPENAI_API_KEY 也能导入模块、构建图、跑单元测试（测试会
    monkeypatch 掉模块级 llm）；运行时才真正需要密钥。
    """

    def __init__(self):
        self._client = None

    def invoke(self, messages, **kwargs):
        if self._client is None:
            self._client = ChatOpenAI(
                model=LLM_MODEL,
                api_key=OPENAI_API_KEY,
                base_url=OPENAI_BASE_URL,
                temperature=0.3,
                **kwargs,
            )
        return self._client.invoke(messages)


llm = _LazyLLM()


def history_messages(state: SentimentState):
    """把历史轮次转成 LangChain 消息序列（assistant→AIMessage，user→HumanMessage）。

    返回一个列表，供各节点在系统提示后、当前输入前拼接为对话上下文。
    """
    msgs = []
    for item in state.get("history") or []:
        content = item["content"]
        if item["role"] == "assistant":
            msgs.append(AIMessage(content=content))
        else:
            msgs.append(HumanMessage(content=content))
    return msgs


def detect_sentiment(state: SentimentState) -> dict:
    """进程1：情感识别。使用结构化约束输出，保证标签稳定。

    多轮时拼接历史上下文，但指令明确：只基于最新一条用户消息判定情感极性，
    避免整段对话的标签被历史轮次稀释、漂移。
    """
    system = SystemMessage(
        content=(
            "你是一个情感分类器，正在参与多轮对话。只输出以下三个标签之一，"
            "不要输出任何其他内容：positive / negative / neutral。\n"
            "判定依据：只看对话中最新的一条用户消息，忽略之前的轮次。"
        )
    )
    past = history_messages(state)
    resp = llm.invoke(
        [system, *past, HumanMessage(content=state["user_input"])]
    )
    raw = resp.content.strip().lower()

    if raw.startswith("positive"):
        label = "positive"
    elif raw.startswith("negative"):
        label = "negative"
    else:
        label = "neutral"

    return {"sentiment": label}


def encourage(state: SentimentState) -> dict:
    """正向分支：鼓励。携带历史上下文，回复与前面轮次连贯。"""
    resp = llm.invoke([
        SystemMessage(content="用户表达了积极情绪。用温暖、鼓励的语气回应，肯定对方的感受，"
                              "不要空洞夸奖，不超过两句话。"),
        *history_messages(state),
        HumanMessage(content=state["user_input"]),
    ])
    return {"reply": resp.content.strip()}


def soothe(state: SentimentState) -> dict:
    """负面分支：排解。携带历史上下文，回复与前面轮次连贯。"""
    resp = llm.invoke([
        SystemMessage(content="用户表达了负面情绪。先共情，再温和地帮助对方梳理情绪，"
                              "不要急于给建议，不要否定对方的感受，不超过三句话。"),
        *history_messages(state),
        HumanMessage(content=state["user_input"]),
    ])
    return {"reply": resp.content.strip()}


def acknowledge(state: SentimentState) -> dict:
    """中性分支：中性承接。携带历史上下文，回复与前面轮次连贯。"""
    resp = llm.invoke([
        SystemMessage(content="用户表达的情感偏中性。用自然、友好的方式接住对方的话，"
                              "可以简短追问或确认，不超过两句话。"),
        *history_messages(state),
        HumanMessage(content=state["user_input"]),
    ])
    return {"reply": resp.content.strip()}


def route_by_sentiment(state: SentimentState) -> str:
    """条件边路由函数：根据情感标签返回目标节点名。"""
    return state["sentiment"]


def build_graph():
    """构建状态图：detect_sentiment → (encourage / soothe / acknowledge) → END。"""
    builder = StateGraph(SentimentState)

    builder.add_node("detect_sentiment", detect_sentiment)
    builder.add_node("encourage", encourage)
    builder.add_node("soothe", soothe)
    builder.add_node("acknowledge", acknowledge)

    builder.add_edge(START, "detect_sentiment")

    builder.add_conditional_edges(
        "detect_sentiment",
        route_by_sentiment,
        {
            "positive": "encourage",
            "negative": "soothe",
            "neutral": "acknowledge",
        },
    )

    builder.add_edge("encourage", END)
    builder.add_edge("soothe", END)
    builder.add_edge("acknowledge", END)

    return builder.compile()


sentiment_graph = build_graph()


def run_langgraph(user_input: str, history=None) -> dict:
    """对外暴露的统一调用入口，返回与 Agents SDK 版本同构的结果。

    history：本轮之前的历史，形如 [{"role": "user"/"assistant", "content": str}, ...]，
    默认 None 表示单轮对话。
    """
    result = sentiment_graph.invoke({
        "user_input": user_input,
        "history": history or [],
    })
    return {
        "reply": result["reply"],
        "sentiment": result["sentiment"],
        "framework": "langgraph",
    }
