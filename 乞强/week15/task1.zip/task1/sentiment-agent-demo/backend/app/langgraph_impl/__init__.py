"""LangGraph 实现版本包。"""

from app.langgraph_impl.graph import run_langgraph

__all__ = ["run_langgraph"]
