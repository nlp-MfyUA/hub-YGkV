"""公共基础层：LLM 配置与情感标签定义。

两个框架版本共用同一套环境变量配置与情感标签枚举，保证实现等价、可对比。
"""
import os
from enum import Enum

from dotenv import find_dotenv, load_dotenv

# 自动加载 backend/.env：find_dotenv(usecwd=False) 从本文件所在目录向上查找，
# 与当前工作目录无关，无论从 backend/ 还是项目根目录运行都能找到 .env。
load_dotenv(find_dotenv(usecwd=False))

# LLM 配置统一从环境变量读取，便于切换模型或代理。
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")  # 可选，用于兼容代理 / 国产模型


class Sentiment(str, Enum):
    """情感极性标签。两个框架共用同一组标签，避免自由文本解析的不稳定性。"""

    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"
