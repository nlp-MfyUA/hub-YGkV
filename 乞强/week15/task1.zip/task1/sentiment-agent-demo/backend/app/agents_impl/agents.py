"""OpenAI Agents SDK 版本：handoff 模式实现\"情感识别 → 分支回应\"。

与 LangGraph 版本不同，这里的路由决策由 LLM 在运行时通过 handoff 完成：
分诊 Agent 判断情感后，将控制权交给对应的专项 Agent 产生最终回复。
控制流藏在 Agent 的 handoffs 配置与 instructions 里，而非静态图结构。

采用 handoff 模式而非 agents-as-tools：回复直接由专项 Agent 面向用户产出，
而不是回到分诊 Agent 再合成。
"""
from agents import Agent, Runner, handoff
from agents.extensions.models.litellm_model import LitellmModel  # 如需非 OpenAI 模型

from app.llm import LLM_MODEL, OPENAI_API_KEY, OPENAI_BASE_URL


def _model():
    """按《项目开发文档.md》§5.2：设置 OPENAI_BASE_URL 时走 LitellmModel（兼容代理/国产模型），
    否则直接传模型名走 OpenAI 默认通道。"""
    if OPENAI_BASE_URL:
        return LitellmModel(
            model=LLM_MODEL,
            api_key=OPENAI_API_KEY,
            base_url=OPENAI_BASE_URL,
        )
    return LLM_MODEL  # 默认走 OpenAI


encourage_agent = Agent(
    name="Encourage Agent",
    instructions=(
        "用户表达了积极情绪。用温暖、鼓励的语气回应，肯定对方的感受，"
        "不要空洞夸奖，不超过两句话。"
    ),
    model=_model(),
)

soothe_agent = Agent(
    name="Soothe Agent",
    instructions=(
        "用户表达了负面情绪。先共情，再温和地帮助对方梳理情绪，"
        "不要急于给建议，不要否定对方的感受，不超过三句话。"
    ),
    model=_model(),
)

neutral_agent = Agent(
    name="Neutral Agent",
    instructions=(
        "用户表达的情感偏中性。用自然、友好的方式接住对方的话，"
        "可以简短追问或确认，不超过两句话。"
    ),
    model=_model(),
)

triage_agent = Agent(
    name="Sentiment Triage Agent",
    instructions=(
        "你是情感分诊器，正在参与多轮对话。先判断**最新一条用户消息**的情感极性，"
        "然后调用对应的交接工具：\n"
        "- 正向 → transfer_to_encourage\n"
        "- 负面 → transfer_to_soothe\n"
        "- 中性或无法判断 → transfer_to_neutral\n"
        "不要在分诊阶段直接回应用户的情绪内容，只需完成分类和交接。"
    ),
    handoffs=[
        handoff(encourage_agent, tool_name_override="transfer_to_encourage"),
        handoff(soothe_agent, tool_name_override="transfer_to_soothe"),
        handoff(neutral_agent, tool_name_override="transfer_to_neutral"),
    ],
    model=_model(),
)

AGENT_NAME_TO_SENTIMENT = {
    "Encourage Agent": "positive",
    "Soothe Agent": "negative",
    "Neutral Agent": "neutral",
}


def _infer_sentiment_from_agent(agent_name: str) -> str:
    """从最终 Agent 名称反推情感标签（保持两边可比的轻量做法）。"""
    return AGENT_NAME_TO_SENTIMENT.get(agent_name, "neutral")


def _conversation_input(user_input: str, history=None):
    """把历史轮次 + 最新用户输入拼成 Runner.run 的 input（消息列表）。

    openai-agents 的 input 接受 list[消息字典]（responses 格式），
    历史里的 assistant 轮次会作为上下文让模型连贯回应，最新消息排在最末。
    """
    turns = [{"role": h["role"], "content": h["content"]} for h in (history or [])]
    turns.append({"role": "user", "content": user_input})
    return turns


async def run_agents_sdk(user_input: str, history=None) -> dict:
    """对外暴露的统一调用入口，返回与 LangGraph 版本同构的结果。

    history：本轮之前的历史，形如 [{"role": "user"/"assistant", "content": str}, ...]，
    默认 None 表示单轮对话。Runner.run 是异步入口，运行一个循环直到产生最终输出。
    """
    result = await Runner.run(
        triage_agent,
        _conversation_input(user_input, history),
    )
    return {
        "reply": result.final_output,
        "sentiment": _infer_sentiment_from_agent(result.last_agent.name),
        "framework": "agents_sdk",
    }
