"""统一接口契约：后端对外只暴露一个端点，两个版本共用同一套请求/响应格式。

v1.1 起支持多轮对话：ChatRequest 增加可选 history（本轮之前的对话，按时间顺序），
供编排层拼接成上下文，使模型能感知历史轮次、做出连贯回应。
"""

from typing import Literal

from pydantic import BaseModel

from app.llm import Sentiment


class ChatMessage(BaseModel):
    """单条历史消息（openai 风格 role/content），便于对齐 LangGraph 与 Agents SDK。"""

    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[ChatMessage] = []  # 本轮之前的所有轮次；单轮对话时为空


class ChatResponse(BaseModel):
    reply: str
    sentiment: Sentiment  # "positive" | "negative" | "neutral"
    framework: str        # "langgraph" | "agents_sdk"
