"""前端进程：Gradio 聊天界面。

通过 HTTP 与后端解耦，前端不感知底层用的是 LangGraph 还是 Agents SDK。
v1.1 起支持多轮对话：把当前消息之前的所有轮次作为 history 传给后端。
"""
import os

import requests
import gradio as gr
from dotenv import find_dotenv, load_dotenv

# 与 app/llm.py 一致：自动加载 backend/.env，使 BACKEND_URL 等配置生效。
load_dotenv(find_dotenv(usecwd=False))

BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")


def _to_history(history: list) -> list:
    """把 Gradio 的 history（user/assistant 交替）转成 {role, content} 列表。

    兼容两种格式：经典元组 [(user, assistant), ...] 与新式字典 [{role, content}, ...]。
    """
    turns = []
    for item in history or []:
        if isinstance(item, dict):
            turns.append({"role": item.get("role", "user"), "content": item.get("content", "")})
        elif isinstance(item, tuple) and len(item) == 2:
            user, assistant = item
            if user:
                turns.append({"role": "user", "content": str(user)})
            if assistant:
                turns.append({"role": "assistant", "content": str(assistant)})
    return turns


def respond(message: str, history: list):
    # 多轮对话：把当前消息之前的所有轮次作为 history 传给后端。
    resp = requests.post(
        f"{BACKEND_URL}/chat",
        json={"message": message, "history": _to_history(history)},
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    # 在回复前附加情感标签，便于演示观察。
    return f"[{data['sentiment']}] {data['reply']}"


demo = gr.ChatInterface(
    fn=respond,
    title="情感回应助手",
    description="输入一段文字，系统识别情感并给出对应回应。",
    examples=[
        "今天项目上线了，特别开心！",
        "最近压力很大，感觉撑不下去了。",
        "明天要去开一个普通的周会。",
    ],
)

if __name__ == "__main__":
    demo.launch(server_port=7860)
