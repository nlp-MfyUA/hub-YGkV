# CLAUDE.md (backend)

This file provides guidance to Claude Code when working in this backend project. **All commands below run from this directory (`backend/`)**, because the Python packages `app` and `tests` live here.

## Layout

```
backend/
├── app/
│   ├── __init__.py
│   ├── llm.py            # shared env-var LLM config + Sentiment enum + .env loading
│   ├── schemas.py        # ChatRequest / ChatResponse (shared contract)
│   ├── main.py           # FastAPI: POST /chat only; FRAMEWORK switch
│   ├── frontend.py       # Gradio ChatInterface → HTTP /chat (optional frontend)
│   ├── langgraph_impl/   # Version A: state.py (TypedDict), graph.py (nodes + edges)
│   └── agents_impl/      # Version B: agents.py (triage + specialty agents + handoffs)
├── tests/
│   ├── test_langgraph.py
│   └── test_agents.py
├── .env                  # env config; auto-loaded by python-dotenv
├── requirements.txt      # follows 项目开发文档.md §11 (+ python-dotenv)
└── CLAUDE.md             # this file
```

## Commands

```bash
# Run tests (offline, deterministic — no API key needed)
python -m pytest tests/ -v

# Serve backend (config comes from backend/.env)
uvicorn app.main:app --reload --port 8000

# Gradio frontend
python -m app.frontend        # opens http://127.0.0.1:7860

# Install deps
pip install -r requirements.txt
pip install pytest litellm    # extras: pytest for tests; litellm for OPENAI_BASE_URL proxy path
```

## Architecture details / design decisions

- **Shared contract**: the backend exposes **exactly one endpoint** — `POST /chat` takes `{"message": str}`, returns `{"reply", "sentiment", "framework"}` (`framework` is `"langgraph"` or `"agents_sdk"`). Per §2.3, no other routes exist; don't add a `/health` route.
- **LLM config is env-driven** (`app/llm.py`): `OPENAI_API_KEY` (required at runtime), optional `OPENAI_BASE_URL` (proxies / domestic models), `LLM_MODEL` (default `gpt-4o-mini`).
- **`.env` loading**: `app/llm.py`, `app/main.py`, and `app/frontend.py` each call `load_dotenv(find_dotenv(usecwd=False))` at the top, so `backend/.env` is found from any working directory. OS environment variables take precedence (python-dotenv does not override existing vars by default).
- **LangGraph version** (`app/langgraph_impl/graph.py`): `SentimentState` TypedDict flows through `detect_sentiment` → conditional edge `route_by_sentiment` → one of `encourage` / `soothe` / `acknowledge` → END. Response nodes return `{"reply": ...}` which LangGraph merges into state.
- **Agents SDK version** (`app/agents_impl/agents.py`): a `triage_agent` holds `handoffs` to three specialty agents with `tool_name_override` (e.g. `transfer_to_encourage`) to align tool names with its `instructions`. `Runner.run()` is async; results are extracted via `result.final_output` / `result.last_agent.name`. When `OPENAI_BASE_URL` is set, `_model()` builds a `LitellmModel` per spec §5.2.
- **The `_LazyLLM` in graph.py is intentional**: `ChatOpenAI` validates credentials at construction, which would make importing the module fail without an API key. The lazy wrapper defers client creation to first `invoke`, so the module can be imported, the graph built, and unit tests run with no key. Nodes still call `llm.invoke(...)` on the module-level `llm`, so tests patch `graph.llm` with a stub.
- **Sentiment label inference in Version B is a deliberate shortcut**: Agents SDK doesn't expose a structured label; the tag is inferred backwards from the final agent name via `AGENT_NAME_TO_SENTIMENT` in `agents.py`. Its purpose is parity with Version A; the doc notes production should pass the label explicitly (e.g. a separate classification step before triage). Don't "fix" this without that context.

## Testing approach

Tests are deterministic and offline — they **patch, not call, the LLM**:

- `tests/test_langgraph.py`: replaces `graph.llm` with a stub that returns the requested label for classifier calls and per-branch canned replies for response-node calls. Verifies label parsing and conditional-edge routing to the correct branch.
- `tests/test_agents.py`: patches `agents.Runner.run` to return a fake result with a chosen `last_agent.name`, verifying `run_agents_sdk` result extraction and the name→sentiment mapping (including the fallback to `neutral`).

Do not convert these to live LLM tests without a real `OPENAI_API_KEY`. For a live smoke test, put the key in `.env`, serve the backend, and `POST /chat`.

## Environment variables (summary)

| Var | Required | Default | Purpose |
|---|---|---|---|
| `OPENAI_API_KEY` | yes (runtime) | — | LLM API key |
| `OPENAI_BASE_URL` | no | — | Compatible base URL (proxy / domestic model) |
| `LLM_MODEL` | no | `gpt-4o-mini` | Model id |
| `FRAMEWORK` | no | `langgraph` | `langgraph` or `agents_sdk`; read at backend startup |
| `BACKEND_URL` | no | `http://127.0.0.1:8000` | Where the Gradio frontend calls the backend |
