"""OpenAI Agents SDK 版本测试。

离线确定性验证：patch Runner.run，返回带指定 last_agent.name 的假结果，
验证 run_agents_sdk 的结果提取与“从最终 Agent 名称反推情感标签”的逻辑。
另验证 triage_agent 的 handoff 配置齐备（工具名与 instructions 对齐）。
"""
from types import SimpleNamespace

import pytest

from app.agents_impl import agents
from app.llm import Sentiment


class FakeResult:
    def __init__(self, final_output: str, agent_name: str):
        self.final_output = final_output
        self.last_agent = SimpleNamespace(name=agent_name)


@pytest.fixture
def patched_runner(monkeypatch):
    """替换 agents.Runner.run 为假实现，避免真实网络调用。"""

    def _patch(agent_name: str, final_output: str = "测试回复"):
        async def fake_run(agent, user_input, **kwargs):
            return FakeResult(final_output=final_output, agent_name=agent_name)

        monkeypatch.setattr(agents.Runner, "run", fake_run)
        return fake_run

    return _patch


def test_run_agents_sdk_positive_handoff(patched_runner):
    patched_runner("Encourage Agent", "太棒了，继续加油！")
    result = __import__("asyncio").run(agents.run_agents_sdk("今天项目上线了，特别开心！"))
    assert result == {
        "reply": "太棒了，继续加油！",
        "sentiment": Sentiment.POSITIVE.value,
        "framework": "agents_sdk",
    }


def test_run_agents_sdk_negative_handoff(patched_runner):
    patched_runner("Soothe Agent", "先别急，我们慢慢来。")
    result = __import__("asyncio").run(agents.run_agents_sdk("最近压力很大，感觉撑不下去了。"))
    assert result["sentiment"] == Sentiment.NEGATIVE.value
    assert result["framework"] == "agents_sdk"


def test_run_agents_sdk_neutral_handoff(patched_runner):
    patched_runner("Neutral Agent", "好的，下午三点见。")
    result = __import__("asyncio").run(agents.run_agents_sdk("明天要去开一个普通的周会。"))
    assert result["sentiment"] == Sentiment.NEUTRAL.value
    assert result["framework"] == "agents_sdk"


def test_infer_falls_back_to_neutral(patched_runner):
    # 兜底：无法识别的 Agent 名称归类为 neutral
    patched_runner("Unknown Agent")
    result = __import__("asyncio").run(agents.run_agents_sdk("随便说说"))
    assert result["sentiment"] == Sentiment.NEUTRAL.value


def test_triage_agent_has_three_handoffs():
    assert len(agents.triage_agent.handoffs) == 3
    tool_names = {
        (h.tool_name or h.name) for h in agents.triage_agent.handoffs
    }
    assert tool_names == {
        "transfer_to_encourage",
        "transfer_to_soothe",
        "transfer_to_neutral",
    }

    # instructions 里提到的交接工具名与 handoff 配置严格对齐
    instructions = agents.triage_agent.instructions
    for tool in tool_names:
        assert tool in instructions
