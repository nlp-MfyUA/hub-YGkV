"""LangGraph 版本单元测试。

通过打桩替换 graph 模块内的 llm，让节点确定性运行（不触网、无需 API key），
验证：detect_sentiment 的标签解析、条件边路由到正确分支、统一结果契约。
"""
from types import SimpleNamespace

import pytest

from app.langgraph_impl import graph
from app.langgraph_impl.state import SentimentState


class StubLLM:
    """替换 graph.llm：根据 system 提示区分“情感分类”与“分支回应”两类调用。"""

    def __init__(self, label: str):
        self.label = label  # 例如 positive / negative / neutral
        self.classifier_calls = 0
        self.branch_calls = 0

    def invoke(self, messages):
        system = messages[0].content
        if "情感分类器" in system:
            self.classifier_calls += 1
            return SimpleNamespace(content=f"{self.label}")
        self.branch_calls += 1
        if "积极情绪" in system:
            tone = "（鼓励回复）"
        elif "负面情绪" in system:
            tone = "（排解回复）"
        else:
            tone = "（中性承接回复）"
        return SimpleNamespace(content=f"{self.label}:{tone}")


@pytest.fixture
def patched_llm(monkeypatch):
    """把 graph 模块里的 llm 换成 StubLLM，并返回更换器与实例记录。"""

    def _patch(label: str) -> StubLLM:
        stub = StubLLM(label)
        monkeypatch.setattr(graph, "llm", stub)
        return stub

    return _patch


def test_detect_sentiment_returns_matching_label(patched_llm):
    stub = patched_llm("positive")
    state = SentimentState(
        user_input="今天拿到了心仪的 offer，太开心了！",
        sentiment="positive",
        reply="",
    )
    result = graph.detect_sentiment(state)
    assert result["sentiment"] == "positive"
    assert stub.classifier_calls == 1


def test_route_encourage_on_positive(patched_llm):
    stub = patched_llm("positive")
    result = graph.sentiment_graph.invoke(
        {"user_input": "今天拿到了心仪的 offer，太开心了！"}
    )
    assert result["sentiment"] == "positive"
    assert result["reply"].startswith("positive:（鼓励回复）")
    assert stub.classifier_calls == 1
    assert stub.branch_calls == 1  # 只走了一条分支


def test_route_soothe_on_negative(patched_llm):
    stub = patched_llm("negative")
    result = graph.sentiment_graph.invoke(
        {"user_input": "我被裁员了，不知道该怎么办"}
    )
    assert result["sentiment"] == "negative"
    assert result["reply"].startswith("negative:（排解回复）")
    assert stub.branch_calls == 1


def test_route_acknowledge_on_neutral(patched_llm):
    stub = patched_llm("neutral")
    result = graph.sentiment_graph.invoke(
        {"user_input": "下午三点开会"}
    )
    assert result["sentiment"] == "neutral"
    assert result["reply"].startswith("neutral:（中性承接回复）")
    assert stub.branch_calls == 1


def test_run_langgraph_returns_same_contract(patched_llm):
    patched_llm("negative")
    result = graph.run_langgraph("最近压力很大，感觉撑不下去了")
    assert set(result.keys()) == {"reply", "sentiment", "framework"}
    assert result["framework"] == "langgraph"
    assert result["sentiment"] == "negative"
