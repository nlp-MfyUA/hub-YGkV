# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

This directory contains a project spec (`项目开发文档.md`) and its implementation. The runnable code lives in **`sentiment-agent-demo/`** — see `sentiment-agent-demo/CLAUDE.md` for architecture, commands, and testing notes. Work in that subfolder, not at this level.
