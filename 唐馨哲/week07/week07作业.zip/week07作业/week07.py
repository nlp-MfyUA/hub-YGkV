"""
第七周作业：
1. 安装pageindex本地运行构建和问答过程
2. 配置autodl镜像环境
"""

# ============================================================
# 作业1：安装 PageIndex 并运行本地文档问答
# ============================================================

# 安装命令：pip install -U pageindex

import os
from pageindex import PageIndexClient

# 设置硅基流动 API Key
SILICONFLOW_API_KEY = "sk-mouweajeocchkgiuqicvfgxalxabdarusgpqkpcbhciqygjs"

# 初始化 PageIndex 客户端
# 使用 index_backend 和 chat_backend 配置硅基流动的 API
client = PageIndexClient(
    index_model="openai/deepseek-ai/DeepSeek-V3",    # 构建 tree index 使用的模型
    chat_model="openai/deepseek-ai/DeepSeek-V3",     # 问答时使用的模型
    storage_path=".pageindex",                       # 本地存储路径
    index_backend={
        "api_key": SILICONFLOW_API_KEY,
        "api_base": "https://api.siliconflow.cn/v1",
    },
    chat_backend={
        "api_key": SILICONFLOW_API_KEY,
        "api_base": "https://api.siliconflow.cn/v1",
    },
)

# 步骤1：建立 PageIndex（离线解析，每个文档只需运行一次）
# 使用课程提供的 GraphRAG 论文作为示例文档
pdf_path = r"C:\Users\17451\Desktop\学习\AI课程资料\第07周：RAG进阶与改进\Week07\Week07\资料\2404.16130v2-GraphRAG.pdf"

# 检查文件是否存在
if os.path.exists(pdf_path):
    print("正在提交文档进行解析...")
    result = client.submit_document(pdf_path)
    doc_id = result["doc_id"]
    print(f"文档解析完成，doc_id: {doc_id}")

    # 步骤2：查看 Tree Index 结构
    print("\n正在获取文档结构...")
    tree = client.get_document_structure(doc_id)
    print("Tree Index 结构:")
    print(tree)

    # 步骤3：基于 PageIndex 进行问答
    print("\n开始问答测试...")
    
    questions = [
        "这份文档主要讲了什么？",
        "什么是 GraphRAG？",
        "GraphRAG 相比传统 RAG 有什么优势？"
    ]
    
    for question in questions:
        print(f"\n问题: {question}")
        answer = client.chat(
            question,
            doc_id=doc_id,
        )
        print(f"回答: {answer}")
        print("-" * 80)
else:
    print(f"文件不存在: {pdf_path}")
    print("请确保 PDF 文件路径正确")
    print("可以使用课程资料中的 PDF 文件：第07周：RAG进阶与改进/Week07/Week07/资料/2404.16130v2-GraphRAG.pdf")

# ============================================================
# 作业2：配置 AutoDL 镜像环境
# ============================================================

"""
AutoDL 环境配置步骤：

1. 注册并登录 AutoDL 平台 (https://www.autodl.com/)

2. 创建实例：
   - 选择 GPU 类型（推荐 RTX 4090 或 A100）
   - 选择镜像：PyTorch 2.x + Python 3.10+
   - 推荐镜像：autodl-ubuntu-20.04-pytorch-2.1.0-cuda12.1

3. 启动实例后，在终端中安装所需依赖：

```bash
# 安装 pageindex
pip install -U pageindex

# 安装其他常用依赖
pip install openai pdfplumber

# 设置环境变量
export DEEPSEEK_API_KEY="sk-你的API密钥"
```

4. 上传代码和数据：
   - 使用 AutoDL 提供的文件上传功能
   - 或使用 scp 命令上传文件

5. 运行代码：
```bash
python week07.py
```

6. 复制 AutoDL 实例 ID：
   - 在 AutoDL 控制台找到你的实例
   - 复制实例 ID 分享给老师/同学

AutoDL 实例 ID 格式：autodl-xxxxxxxx
"""

# 打印配置说明
print("\n" + "=" * 80)
print("AutoDL 环境配置说明")
print("=" * 80)
print("""
1. 访问 https://www.autodl.com/ 并登录
2. 创建 GPU 实例，选择 PyTorch 镜像
3. 安装依赖：pip install -U pageindex openai pdfplumber
4. 设置环境变量：export DEEPSEEK_API_KEY="sk-xxx"
5. 上传代码并运行
6. 复制实例 ID 用于共享环境
""")