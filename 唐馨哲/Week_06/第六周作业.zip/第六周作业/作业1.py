"""
作业：基于ES完成全文检索、条件过滤、向量检索
"""
import json
import time
from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

# ==================== 连接ES ====================
es = Elasticsearch("http://localhost:9200")

if es.ping():
    print("✓ 成功连接到 Elasticsearch！")
else:
    print("✗ 无法连接到 Elasticsearch，请检查服务是否运行。")
    exit()

# ==================== 加载向量模型 ====================
print("\n正在加载 SentenceTransformer 模型...")
model = SentenceTransformer('C:/Users/17451/Desktop/学习/AI课程资料/Week2-大模型使用与深度学习基础/02-课程资料/04Week02_2026Q2/asserts/bge-small-zh-v1.5')
print("✓ 模型加载完成。")

# ==================== 创建索引 ====================
index_name = "homework_es_demo"

if es.indices.exists(index=index_name):
    es.indices.delete(index=index_name)
    print(f"\n旧索引 '{index_name}' 已删除。")

print(f"正在创建新索引 '{index_name}'...")
es.indices.create(
    index=index_name,
    body={
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0
        },
        "mappings": {
            "properties": {
                "title": {"type": "text"},
                "content": {"type": "text"},
                "category": {"type": "keyword"},
                "price": {"type": "float"},
                "author": {"type": "keyword"},
                "tags": {"type": "keyword"},
                "text_vector": {
                    "type": "dense_vector",
                    "dims": 512,
                    "index": True,
                    "similarity": "cosine"
                }
            }
        }
    }
)
print(f"✓ 索引 '{index_name}' 创建成功。")

# ==================== 插入文档 ====================
print("\n正在插入文档...")
documents = [
    {
        "title": "Python编程入门",
        "content": "Python是一门简单易学的编程语言，适合初学者学习。",
        "category": "编程教程",
        "price": 59.9,
        "author": "张三",
        "tags": ["Python", "编程", "入门"]
    },
    {
        "title": "机器学习实战",
        "content": "本书介绍了机器学习的基本算法和实际应用案例。",
        "category": "人工智能",
        "price": 89.9,
        "author": "李四",
        "tags": ["机器学习", "AI", "算法"]
    },
    {
        "title": "深度学习与神经网络",
        "content": "深度学习是人工智能的重要分支，神经网络是核心技术。",
        "category": "人工智能",
        "price": 99.9,
        "author": "王五",
        "tags": ["深度学习", "神经网络", "AI"]
    },
    {
        "title": "Java企业级开发",
        "content": "Java是企业级应用开发的主流语言，广泛应用于后端开发。",
        "category": "编程教程",
        "price": 79.9,
        "author": "赵六",
        "tags": ["Java", "企业级", "后端"]
    },
    {
        "title": "数据结构与算法",
        "content": "数据结构是编程的基础，算法是解决问题的核心。",
        "category": "编程教程",
        "price": 69.9,
        "author": "张三",
        "tags": ["数据结构", "算法", "编程"]
    },
    {
        "title": "自然语言处理技术",
        "content": "自然语言处理让计算机理解和生成人类语言，是AI的重要方向。",
        "category": "人工智能",
        "price": 109.9,
        "author": "李四",
        "tags": ["NLP", "自然语言处理", "AI"]
    }
]

for i, doc in enumerate(documents):
    # 生成向量（标题+内容）
    text = doc["title"] + " " + doc["content"]
    vector = model.encode(text).tolist()
    doc["text_vector"] = vector
    
    es.index(index=index_name, id=str(i+1), document=doc)
    print(f"  ✓ 插入文档 {i+1}: {doc['title']}")

es.indices.refresh(index=index_name)
time.sleep(1)
print("✓ 所有文档插入完成。")

# ==================== 1. 全文检索 ====================
print("\n" + "="*60)
print("【演示1】全文检索 - 搜索包含'人工智能'的文档")
print("="*60)

response = es.search(
    index=index_name,
    body={
        "query": {
            "multi_match": {
                "query": "人工智能",
                "fields": ["title", "content"]
            }
        },
        "_source": ["title", "content", "category", "author"]
    }
)

print(f"找到 {response['hits']['total']['value']} 个结果：")
for hit in response['hits']['hits']:
    doc = hit['_source']
    print(f"  得分: {hit['_score']:.2f} | 标题: {doc['title']} | 作者: {doc['author']}")
    print(f"  内容: {doc['content'][:50]}...")
    print()

# ==================== 2. 条件过滤 ====================
print("\n" + "="*60)
print("【演示2】条件过滤 - 搜索'人工智能'类别且价格低于100的文档")
print("="*60)

response = es.search(
    index=index_name,
    body={
        "query": {
            "bool": {
                "must": [
                    {"match": {"content": "人工智能"}}
                ],
                "filter": [
                    {"term": {"category": "人工智能"}},
                    {"range": {"price": {"lt": 100}}}
                ]
            }
        },
        "_source": ["title", "content", "category", "price", "author"]
    }
)

print(f"找到 {response['hits']['total']['value']} 个结果：")
for hit in response['hits']['hits']:
    doc = hit['_source']
    print(f"  得分: {hit['_score']:.2f} | 标题: {doc['title']} | 价格: ¥{doc['price']} | 作者: {doc['author']}")
    print(f"  内容: {doc['content'][:50]}...")
    print()

# ==================== 3. 向量检索 ====================
print("\n" + "="*60)
print("【演示3】向量检索 - 搜索与'AI技术发展'语义相似的文档")
print("="*60)

query_text = "AI技术发展"
query_vector = model.encode(query_text).tolist()

response = es.search(
    index=index_name,
    body={
        "knn": {
            "field": "text_vector",
            "query_vector": query_vector,
            "k": 3,
            "num_candidates": 10
        },
        "_source": ["title", "content", "category"]
    }
)

print(f"查询文本: '{query_text}'")
print(f"找到 {response['hits']['total']['value']} 个最相似的结果：")
for hit in response['hits']['hits']:
    doc = hit['_source']
    print(f"  相似度得分: {hit['_score']:.4f} | 标题: {doc['title']} | 类别: {doc['category']}")
    print(f"  内容: {doc['content'][:50]}...")
    print()

# ==================== 4. 向量检索 + 条件过滤（混合检索）====================
print("\n" + "="*60)
print("【演示4】向量检索 + 条件过滤 - 搜索'AI技术'且类别为'人工智能'的文档")
print("="*60)

response = es.search(
    index=index_name,
    body={
        "knn": {
            "field": "text_vector",
            "query_vector": query_vector,
            "k": 5,
            "num_candidates": 10,
            "filter": [
                {"term": {"category": "人工智能"}}
            ]
        },
        "_source": ["title", "content", "category", "author"]
    }
)

print(f"查询文本: '{query_text}' (过滤条件: category='人工智能')")
print(f"找到 {response['hits']['total']['value']} 个结果：")
for hit in response['hits']['hits']:
    doc = hit['_source']
    print(f"  相似度得分: {hit['_score']:.4f} | 标题: {doc['title']} | 作者: {doc['author']}")
    print(f"  内容: {doc['content'][:50]}...")
    print()

print("\n" + "="*60)
print("✓ 作业演示完成！请截图以上输出结果。")
print("="*60)